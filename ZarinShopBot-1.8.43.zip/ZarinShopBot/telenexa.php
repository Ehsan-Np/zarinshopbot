<?php
/**
 * Legacy entry-point shim for existing WordPress installations.
 * The plugin has moved to zarinshopbot.php; keep this file to preserve active-plugin references.
 */
if (file_exists(__DIR__ . '/zarinshopbot.php')) {
    require_once __DIR__ . '/zarinshopbot.php';
    if (function_exists('zarincode_activate')) { register_activation_hook(__FILE__, 'zarincode_activate'); }
    if (function_exists('zarincode_deactivate')) { register_deactivation_hook(__FILE__, 'zarincode_deactivate'); }
}
