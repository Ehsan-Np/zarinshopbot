<?php
/* Modified 2026-10-23 by Ehsan NaderiPanah / Zarincode.com. Derived code remains under GPL-2.0-or-later; upstream notices are retained. */
if (!defined('ABSPATH')) exit;

zarincode_set_option();

function zarincode_set_option() {
    $option_ver_new = '1.10.0';
    $zarincode_option_version = get_option('zarincode_option_version');

    if (!get_option('zarincode_webhook_key')) {
        update_option('zarincode_webhook_key', md5(microtime() . wp_rand() . get_site_url()));
    }

    if (version_compare($zarincode_option_version, $option_ver_new, '<')) {
        update_option('zarincode_option_version', $option_ver_new);

        $defaults = [
            ['testmod', 'no'],
            ['token', ''],
            ['username', ''],
            ['channelusername', ''],
            ['telegram_post_title', 'محصول جدید: %product%'],
            ['target', 4],
            ['mode', 0],
            // translators: %FIRST_NAME%: User's Telegram first name.
            ['wmuser', __("سلام %FIRST_NAME% عزیز، به فروشگاه ما خوش آمدید.\nمحصولات را مرور کنید، جست‌وجو کنید یا از گزینه‌های زیر خریدتان را آغاز کنید.", 'zarinshopbot')],
            // translators: %FIRST_NAME%: User's Telegram first name.
            ['bmuser', str_replace('__START_COMMAND__', '/start', __("دوست خوبم %FIRST_NAME%، از همراهی‌تان سپاسگزاریم.\nهر زمان آماده بودید، با ارسال __START_COMMAND__ دوباره به فروشگاه سر بزنید.", 'zarinshopbot'))],
            // translators: %FIRST_NAME%: User's Telegram first name.
            ['messagehome', __("%FIRST_NAME% عزیز، به فروشگاه خوش آمدید.\nبرای یافتن کالای موردنظرتان نام یا شناسهٔ محصول را بفرستید، یا یکی از گزینه‌های منو را انتخاب کنید.", 'zarinshopbot')],
            ['contactuspage', __('تماس با ما', 'zarinshopbot')],
            ['contactuspageurl', get_site_url()],
            ['botsign', '<b>زرین‌کد</b> | همراه هوشمند فروش شما · <a href="https://zarincode.com">Zarincode.com</a>'],
            ['display_productsperpage', 5],
            ['display_alert_in_bot', 1],
            ['display_categories', 1],
            ['display_productslist', 1],
            ['display_product', 1],
            ['display_product_excerpt', 0],
            ['display_product_excerpt_length', 55],
            ['display_search', 1],
            ['display_photosize', 2],
            ['display_categorycount', 1],
            ['display_hideemptycategory', 1],
            ['display_product_link_type', 1],
            ['hide_products_edge_subcategory', 1],
            ['only_display_instock_products', 1],
            ['display_showqty', 0],
            ['display_price_discounted', ['in', 'out']],
            ['display_price', ['in', 'out']],
            ['display_linkbuyonsite', ['out']],
            ['display_linkquickbuy', ['out']],
            ['display_buttonorder', ['in']],
            ['display_buttonviewonsite', ['in']],
            ['display_howgetqty', "1 2 3 4 5\n6 7 8 9 10"],
            ['order_cart_status', 1],
            ['show_coupon_in_cart', 1],
            ['register_req_email', 1],
            ['register_req_qty', 1],
            ['register_req_state', 1],
            ['register_req_city', 1],
            ['register_req_name', 1],
            ['register_req_phone', 3],
            ['register_req_address', 1],
            ['register_req_zip', 1],
            ['register_req_ordernote', 0],
            ['register_req_shipping', 1],
            ['register_req_payment', 1],
            ['posttemplate', '%TITLE%' . PHP_EOL . PHP_EOL . '%LINK%'],
            ['keyboard', ''],
            ['enabledingroups', 1],
            ['feature_wishlist', 1],
            ['feature_live_search', 1],
            ['feature_menu_commands', 1],
            ['feature_webapp_enable', 1],
            ['feature_abandoned_cart', 1],
            ['feature_referrals', 'yes'],

            ['abandoned_cart_delay_hours', 3],
            ['default_language', 'fa'],
            ['wpml_language_sync', 1],
            ['webhook_secret_token', ''],
            ['security_rate_limit_enable', 1],
            ['notify_customer_new_order', 1],
            ['notify_admin_new_order', 1],
            ['notify_status_change', 1],
            ['admin_notification_chat_id', ''],
            ['newest_orderby', 'date'],
            ['search_default_sort', 'date'],
            ['search_sku_enable', 1],
            ['search_price_filter_enable', 1],
            ['telegram_stars_enable', 0],
            ['telegram_rich_messages', 0],
            ['telegram_stars_per_currency_unit', 0],
            ['telegram_invoice_enable', 0],
            ['telegram_provider_token', ''],
            ['proxy_status', 0],
            ['proxy_type', 'http'],
            ['proxy_port', 8080],
            ['proxy_status_fallback', 0],
            ['proxy_type_fallback', 'http'],
            ['proxy_port_fallback', 8080],
            ['telegram_http_timeout', 6],
            ['telegram_api_retries', 0],
            ['zarincode_logging_enabled', 1],
            ['zarincode_log_level', 'all'],
            ['zarincode_log_retention_days', 7],
            ['membership_enabled', 0],
            ['membership_apply_to_admins', 1],
            ['membership_requirements', []],
        ];

        $my_options = get_option('zarincode_settings', []);
        // Replace only untouched English seed messages; preserve any administrator-customized copy.
        $legacy_text_defaults = [
            'wmuser' => "Hi welcome %FIRST_NAME%\nPlease send your search term or select from list below:",
            'bmuser' => "Bye %FIRST_NAME%.\nFor start again send /start",
            'messagehome' => "Dear %FIRST_NAME%.\nPlease send your search term or select from list below",
            'contactuspage' => 'Contact us',
        ];
        $localized_text_defaults = [
            'wmuser' => __("سلام %FIRST_NAME% عزیز، به فروشگاه ما خوش آمدید.\nمحصولات را مرور کنید، جست‌وجو کنید یا از گزینه‌های زیر خریدتان را آغاز کنید.", 'zarinshopbot'),
            'bmuser' => str_replace('__START_COMMAND__', '/start', __("دوست خوبم %FIRST_NAME%، از همراهی‌تان سپاسگزاریم.\nهر زمان آماده بودید، با ارسال __START_COMMAND__ دوباره به فروشگاه سر بزنید.", 'zarinshopbot')),
            'messagehome' => __("%FIRST_NAME% عزیز، به فروشگاه خوش آمدید.\nبرای یافتن کالای موردنظرتان نام یا شناسهٔ محصول را بفرستید، یا یکی از گزینه‌های منو را انتخاب کنید.", 'zarinshopbot'),
            'contactuspage' => __('تماس با ما', 'zarinshopbot'),
        ];
        foreach ($legacy_text_defaults as $text_key => $legacy_text) {
            if (!isset($my_options[$text_key]) || $my_options[$text_key] === $legacy_text) {
                $my_options[$text_key] = $localized_text_defaults[$text_key];
            }
        }
        if (!isset($my_options['search_default_sort'])) {
            $legacy_sort = $my_options['newest_orderby'] ?? 'date';
            $my_options['search_default_sort'] = in_array($legacy_sort, ['date', 'popularity', 'price_asc', 'price_desc', 'on_sale'], true) ? $legacy_sort : 'date';
        }
        if (!in_array($my_options['newest_orderby'] ?? 'date', ['date', 'modified', 'popularity', 'price'], true)) {
            $my_options['newest_orderby'] = ($my_options['newest_orderby'] === 'price_asc') ? 'price' : 'date';
        }
        foreach ($defaults as $def) {
            if (!isset($my_options[$def[0]])) {
                $my_options[$def[0]] = $def[1];
            }
        }
        update_option('zarincode_settings', $my_options);
    }
}


/** Update only known untouched starter copy; preserve all administrator-edited messages and signatures. */
function zarincode_migrate_starter_copy_163() {
    $marker = 'zarincode_starter_copy_version';
    if (get_option($marker) === '1.6.3') { return; }
    $options = get_option('zarincode_settings', array());
    if (!is_array($options)) { $options = array(); }
    $legacy = array(
        'wmuser' => array(
            "Hi welcome %FIRST_NAME%\nPlease send your search term or select from list below:",
            "سلام، خوش آمدید %FIRST_NAME%\nلطفاً عبارت جست‌وجو را بفرستید یا از گزینه‌های زیر انتخاب کنید:",
        ),
        'bmuser' => array(
            "Bye %FIRST_NAME%.\nFor start again send /start",
            "خداحافظ %FIRST_NAME%.\nبرای شروع دوباره /start را بفرستید.",
            "خداحافظ %FIRST_NAME%.\nبرای شروع دوباره، /start را بفرستید.",
        ),
        'messagehome' => array(
            "Dear %FIRST_NAME%.\nPlease send your search term or select from list below",
            "دوست عزیز %FIRST_NAME%،\nلطفاً عبارت جست‌وجو را بفرستید یا از فهرست زیر انتخاب کنید.",
            "%FIRST_NAME% عزیز،\nعبارت موردنظرتان را بفرستید یا یکی از گزینه‌های زیر را انتخاب کنید.",
        ),
    );
    $new_copy = array(
        'wmuser' => __("سلام %FIRST_NAME% عزیز، به فروشگاه ما خوش آمدید.\nمحصولات را مرور کنید، جست‌وجو کنید یا از گزینه‌های زیر خریدتان را آغاز کنید.", 'zarinshopbot'),
        'bmuser' => str_replace('__START_COMMAND__', '/start', __("دوست خوبم %FIRST_NAME%، از همراهی‌تان سپاسگزاریم.\nهر زمان آماده بودید، با ارسال __START_COMMAND__ دوباره به فروشگاه سر بزنید.", 'zarinshopbot')),
        'messagehome' => __("%FIRST_NAME% عزیز، به فروشگاه خوش آمدید.\nبرای یافتن کالای موردنظرتان نام یا شناسهٔ محصول را بفرستید، یا یکی از گزینه‌های منو را انتخاب کنید.", 'zarinshopbot'),
    );
    foreach ($legacy as $key => $known_values) {
        if (!isset($options[$key])) { continue; }
        $current = str_replace("\r\n", "\n", trim((string) $options[$key]));
        foreach ($known_values as $known) {
            if ($current === str_replace("\r\n", "\n", trim($known))) {
                $options[$key] = $new_copy[$key];
                break;
            }
        }
    }
    if (isset($options['botsign']) && trim((string) $options['botsign']) === '===================================') {
        $options['botsign'] = '<b>زرین‌کد</b> | همراه هوشمند فروش شما · <a href="https://zarincode.com">Zarincode.com</a>';
    }
    update_option('zarincode_settings', $options);
    update_option($marker, '1.6.3', false);
}
zarincode_migrate_starter_copy_163();

/** Upgrade only the untouched bundled signature; preserve administrator-customized copy. */
function zarincode_migrate_default_bot_signature_1842() {
    $marker = 'zarincode_default_bot_signature_version';
    if (get_option($marker) === '1.8.42') { return; }
    $options = get_option('zarincode_settings', array());
    if (!is_array($options)) { $options = array(); }
    $old_default = '✦ با مهر، زرین‌کد';
    $new_default = '<b>زرین‌کد</b> | همراه هوشمند فروش شما · <a href="https://zarincode.com">Zarincode.com</a>';
    if (isset($options['botsign']) && trim((string) $options['botsign']) === $old_default) {
        $options['botsign'] = $new_default;
        update_option('zarincode_settings', $options);
    }
    update_option($marker, '1.8.42', false);
}
zarincode_migrate_default_bot_signature_1842();
