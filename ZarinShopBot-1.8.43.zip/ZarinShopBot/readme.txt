=== ربات زرین شاپ ===
Tags: woocommerce, telegram, bale, rubika, ecommerce, chatbot
Requires at least: 5.8
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 1.8.43
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

فروش چندکاناله محصولات ووکامرس از تلگرام، بله و روبیکا؛ محصول زرین‌کد.

== Description ==

ربات زرین شاپ فروشگاه ووکامرس را به تلگرام، بله و روبیکا متصل می‌کند. تنظیمات تلگرام، بله و روبیکا در تب‌های سایدبار همان صفحهٔ تنظیمات افزونه مدیریت می‌شوند؛ هر کانال توکن، وضعیت اتصال و وب‌هوک خود را دارد. جریان‌های مشترک شامل کاتالوگ، محصولات متغیر، سبد، کوپن، نشانی، حمل‌ونقل، مالیات، سفارش و اعلان‌هاست.

مینی‌اپ فروشگاهی Telegram و Bale، هرکدام با SDK و احراز هویت امضاشدهٔ همان پلتفرم، کاتالوگ و مسیر سفارش WooCommerce را ارائه می‌کنند. پرداخت Bale در مینی‌اپ با createInvoiceLink و openInvoice مستند بله انجام می‌شود؛ رشتهٔ صورتحساب بدون تغییر به SDK داده می‌شود و سفارش فقط با تأیید سمت سرور نهایی می‌شود. پرداخت Telegram Mini App و Telegram Stars نیز مطابق مسیرهای موجود تلگرام ارائه می‌شوند. در Mini App، اگر پرداخت بومی همان پیام‌رسان پیکربندی نشده باشد، همهٔ درگاه‌های فعال WooCommerce به‌صورت قابل‌انتخاب نمایش داده می‌شوند و صفحهٔ پرداخت سفارش در همان نمای Mini App باز می‌شود. برای Rubika پرداخت بومی پیاده‌سازی نشده و پرداخت از checkout امن وب‌سایت انجام می‌شود. روش کارت‌به‌کارت WooCommerce در checkout معمول و Mini App قابل استفاده است: چند حساب مقصد، انتخاب حساب برای هر سفارش، بارگذاری رسید خصوصی با سقف/فرمت قابل تنظیم و تأیید دستی مدیر؛ سفارش تا تأیید مدیر پرداخت‌شده نمی‌شود و دسترسی محصول/دانلود آزاد نمی‌شود. پیام‌های پیش‌فرض خوشامدگویی، خانه، خداحافظی و تماس به زبان انتخابی ربات (۱۳ زبان شامل فارسی، انگلیسی، عربی، اردو و چینی) نمایش داده می‌شوند؛ متن‌های سفارشی مدیر حفظ می‌شوند. عضویت اجباری کانال/گروه در تلگرام و بله قابل تنظیم است؛ برای بله باید شناسه و پیوند جداگانه وارد شود. بررسی عضویت روبیکا غیرفعال است، چون Bot API v3 مستندشده متد getChatMember را ارائه نمی‌کند. تپ‌های Inline روبیکا از endpoint جداگانه دریافت می‌شوند و تصویر محصول از مسیر upload API ارسال می‌شود؛ در صورت شکست، پیوند تصویر جایگزین است. رفتار APIهای رسانه، callback و ویرایش پیام را روی حساب واقعی و staging آزمایش کنید.

== Installation ==

1. افزونه را بارگذاری و فعال کنید؛ WooCommerce باید فعال باشد.
2. در صفحهٔ تنظیمات افزونه و سایدبار همان صفحه، تب «ربات بله» یا «ربات روبیکا» را انتخاب کنید و اطلاعات و توکن همان ربات را وارد کنید.
3. HTTPS معتبر را فعال کنید، تنظیمات را ذخیره کنید و وب‌هوک کانال‌های فعال را ثبت کنید. پس از ارتقا به 1.8.0، وب‌هوک Telegram را یک بار دوباره ثبت کنید تا مجوز دریافت callbackهای دکمه‌های خانه و سبد خرید به‌روزرسانی شود.
4. از پنل خود افزونه، تب «کارت‌به‌کارت» را باز کنید؛ در همان‌جا دریافت وجه، حساب‌های مقصد، توضیحات پرداخت و تنظیمات رسید را مدیریت و ذخیره کنید. برای قالب‌های قدیمی نیز قالب `عنوان | بانک | صاحب حساب | شماره کارت | شبا | راهنما` پذیرفته می‌شود و ستون هفتم `شماره حساب` اختیاری است. فایل‌های اجرایی/اسکریپت هرگز به‌عنوان رسید پذیرفته نمی‌شوند؛ روش پرداخت همچنان باید در فهرست درگاه‌های ووکامرس فعال باشد.
5. اگر پرداخت Bale را فعال می‌کنید، Provider Token و ضریب تبدیل به ریال را بررسی کنید. در staging یک سفارش را از شروع گفتگو تا پرداخت آزمایش کنید؛ برای تلگرام وب‌هوک مستقیم را نیز ثبت کنید.

== Privacy ==

در جریان کار، اطلاعات لازم برای پردازش update به API پیام‌رسان مربوط ارسال می‌شود. رسید کارت‌به‌کارت در کتابخانهٔ رسانهٔ عمومی قرار نمی‌گیرد؛ فایل با رمزنگاری OpenSSL در فرادادهٔ خصوصی سفارش نگهداری می‌شود و مشاهدهٔ آن فقط برای مدیر مجازِ سفارش ممکن است. شناسه گفتگو برای تفکیک نشست کانال‌ها استفاده می‌شود؛ سبدهای موقت بله/روبیکا حداکثر ۱۴ روز ذخیره می‌شوند و پیوند checkout یک‌بارمصرف حداکثر ۱۵ دقیقه اعتبار دارد. وب‌هوک تلگرام مستقیم روی دامنه فروشگاه ثبت می‌شود؛ relay ثالثی استفاده نمی‌شود. مدیر سایت باید این پردازش‌ها و دوره نگهداری را در سیاست حریم خصوصی اعلام کند.

== Third-party code ==

این افزونه اثر مشتق‌شده از پروژه GPL-2.0-or-later است. انتساب upstream و مجوزهای اجزای ثالث در THIRD_PARTY_NOTICES.md حفظ می‌شوند. توسعه افزوده: Ehsan NaderiPanah / Zarincode.com.

== Changelog ==

= 1.8.43 =
* Give checkbox settings with explanatory copy distinct responsive rows, clearly separate bold titles from helper text, and align checkbox labels in Telegram/Bale/Rubika channel settings.
* Reuse Rubika-uploaded image file IDs per bot and image URL, avoiding repeated image download and upload round-trips; expire cached IDs and refresh only after an explicit provider rejection.
* Batch structured activity-log writes at request shutdown and record total Bale/Rubika webhook durations alongside existing per-API timings.
* Set a professional default message signature with a clickable Zarincode.com link; migrate only the untouched previous default and preserve custom signatures. PHP CLI and live WordPress are unavailable in the build environment.

= 1.8.41 =
* Reorganize the commands tab: list primary commands and aliases once, move extra commands to their own table, and collapse the Telegram copy block.
* Keep bot command identifiers literal in the UI and translation catalogs; preserve translatable descriptions with positional placeholders. Clarify platform-specific menu registration behavior without repeating support columns.
* Add static regression coverage for command-tab duplication, literal identifiers and gettext catalogs. PHP CLI and live WordPress are unavailable in the build environment.

= 1.8.40 =
* Make the store order phone mode administrator-configurable: mobile or landline, mobile only, landline only, or do not collect.
* Allow downloadable and physical/mixed bot checkout profiles to inherit the global phone mode or override it independently; sanitize all supported values.
* Keep a verified mobile mandatory when account-required or SMS OTP policies are enabled, without discarding the administrator’s saved preference while the mode is locked.
* Add regression smoke checks for phone mode selection, profile inheritance, and account/OTP safeguards. PHP CLI and live WordPress are unavailable in the build environment.

= 1.8.39 =
* Replace store-menu preview emoji with ten packaged local SVG icons and disable WordPress emoji-to-remote-image conversion on the plugin settings screen, preventing broken remote Twemoji images.
* Rebuild core menu setting rows with aligned CSS Grid columns and responsive tablet/mobile layouts for preview, Persian/English labels, enable checkbox and priority.
* Validate local icon mappings and responsive menu styling with static smoke checks; PHP CLI and a live WordPress site are not available in the build environment.

= 1.8.38 =
* Fix empty Persian gettext translations that erased card-transfer menu titles, gateway names, descriptions and the enabled-checkbox label; 37 untranslated entries now map to source text, the compiled MO catalog has no empty translations, and a runtime gettext guard protects against stale external catalogs.
* Render all configured message-editor toolbar glyphs with local SVG masks, independent of icon-font availability or theme overrides.
* Keep card-transfer title and customer instructions visible for empty saved values, and preserve readable labels/contrast.
* JavaScript/static checks pass; PHP CLI and live WordPress staging are unavailable. Validate the admin screen on staging before production.

= 1.8.37 =
* Restore the default card-transfer title and customer copy when saved values are empty, whitespace-only, or contain only empty editor markup.
* Protect card-transfer headings, labels and help text with scoped high-contrast styles so admin theme rules cannot make the text disappear.
* Preserve the correct TinyMCE `tinymce` icon font and WordPress Dashicons fallback; only explicitly mapped icons use local SVG masks.
* JavaScript/static smoke tests pass; PHP CLI and live WordPress staging are unavailable. Validate the PHP files and inspect the editor UI on staging before production.

= 1.8.36 =
* Close all seven inline PHP tags around message editor render calls in the settings panel, preventing the reported parse error when opening plugin settings.
* Make Persian digit conversion safe for null and non-scalar inputs, removing the reported PHP deprecation from OrdersTrait.
* Add regression smoke coverage for inline PHP boundaries and null-safe digit conversion.
* JavaScript/static smoke tests pass; PHP CLI and live WordPress staging are unavailable in the build environment. Verify PHP syntax and open the settings screen on staging before production.

= 1.8.35 =
* Reserve WooCommerce stock for custom Telegram/Bale Mini App orders after line items are saved and before payment handoff; fail safely when stock-managed, non-backorder items cannot be held.
* Preserve WooCommerce-native stock reduction on verified payment completion and the existing immediate reduction for card-transfer orders placed on hold.
* Add cross-platform stock lifecycle smoke checks for Telegram, Bale, Rubika, Mini Apps, native invoices, website gateways, free orders, and manual transfer.
* JavaScript/static checks pass; PHP CLI and live WooCommerce staging are unavailable, so validate PHP syntax and actual stock changes on staging before production.

= 1.8.34 =
* Trace the installation log: parse-time fatals occurred in plugin files loaded globally, so they can prevent all channels from booting; the error log showed different source paths/revisions, not a Bale API failure.
* Remove fully-qualified `instanceof` tokens from the invoice order guard; use a class-string check consistent with the website checkout guard.
* The current source retains safe guards for absent `manage_stock` and initializes the order channel before metadata use, eliminating the two reported PHP warnings.
* The log’s WP-Cron/Action Scheduler `could_not_set` entries are separate WordPress scheduling/storage failures and are not Bale webhook errors.
* JavaScript/static smoke tests pass; PHP CLI and live WordPress/Bale staging were not available. Run PHP lint and a single-copy activation test on staging before production.

= 1.8.33 =
* Repair Bale Mini App administration: delegated URL copying, a clickable direct-launch link, and explicit BotFather Main Mini App setup guidance.
* Keep the shared storefront responsive when WebView localStorage is blocked or contains invalid JSON, using an in-memory fallback.
* Truncate Bale menu button labels on UTF-8 character boundaries when mbstring is unavailable; Telegram and Rubika paths remain unchanged.
* JavaScript syntax checks and all 33 smoke suites pass. PHP CLI and live Bale/WordPress staging were not available; verify on staging before production.

= 1.8.32 =
* Correct the fatal checkout validation guard by using a guarded WooCommerce order-type check instead of a fragile fully-qualified token in the affected hooks.
* Initialize the channel platform before writing platform-specific order metadata, preventing an undefined-variable warning during Bale/Rubika checkout. The cart stock check uses safe absent-key handling.
* Keep the secure bot invoice PDF link, available only for the order owner chat.
* Verify the phone-index table after dbDelta before marking its schema ready; fail safely when unavailable and remove the index/schema marker during plugin uninstall.
* Use WordPress visual editors for bot messages, platform overrides, broadcasts, campaign text and card-transfer customer copy; show per-field dynamic variables and normalize rich formatting to each chat API's supported subset.
* Add the previously implemented chat ID and last-location placeholders to the message palette; correctly resolve bot signatures and register/translate platform-specific overrides through WPML. Remove the nonfunctional product-title/link chips from generic broadcasts; retain the real `%product%` token for product posts.
* JavaScript/static smoke tests pass; no PHP CLI or live WordPress/WooCommerce runtime was available, so site-side PHP execution still requires staging validation.

= 1.8.31 =
* Add a PDF invoice download link to each customer-owned Telegram, Bale and Rubika bot order card. The shared order view verifies the chat ID before showing the link; the generated PDF remains local to the plugin and the existing guest/order-key or account-owner download checks remain in force.
* The Rubika link is represented through its documented HTTPS Link metadata; Telegram and Bale use their supported URL buttons.
* JavaScript/static checks pass. PHP CLI and live platform/WooCommerce staging are unavailable in the build environment.

= 1.8.30 =
* Normalize sales/revenue amounts in the dashboard to render the localized amount first, followed by one space and the WooCommerce currency symbol, independent of the configured currency position.
* Apply the same formatter to platform revenue, today/month summaries and payment-method totals; isolate the amount in LTR layout while preserving surrounding spaces and WooCommerce number precision/separators.
* Add static regression checks for currency-position independence, multi-currency symbol selection and whitespace.
* JavaScript/static tests pass. PHP CLI and WordPress admin runtime are not available in the build environment.

= 1.8.29 =
* Add a customer-downloadable WooCommerce order invoice PDF, generated locally by bundled plugin code without a remote PDF/barcode service or CDN.
* Add a standard Code 128-B barcode containing a unique internal order reference and store-keyed signature, rendered as vector bars in the PDF.
* Embed the locally bundled DejaVu Sans font and glyph metrics for Persian/Arabic and Latin text; include the font license and PDF rendering assets inside the plugin.
* Expose a secured invoice download link on order details, customer order emails, and My Account order actions. Guest downloads require the order key; signed-in customers may download their own order invoice.
* JavaScript/static checks pass. PHP CLI and live WooCommerce rendering are unavailable in the build environment; test generated PDFs and barcode scanning on staging before production.

= 1.8.28 =
* Add administrator-controlled guest/optional/account checkout policy, configurable WooCommerce checkout field profiles, custom order fields for classic checkout and Mini App, and WooCommerce phone-login support.
* Add encrypted SMS provider credential settings for Kavenegar and Melipayamak, rate-limited OTP verification for web checkout, Mini App and bot order flows, and a unique phone ownership index for account linking.
* Add Mini App logo/color branding and shared message defaults with optional Telegram/Bale/Rubika overrides, including editable help and about pages.
* This release has static/JavaScript smoke coverage only in the build environment. Native chat receipt upload across Telegram/Bale/Rubika and complete custom-field parity for every bot flow still require staging validation and follow-up work; do not deploy without reviewing the platform caveats.

= 1.8.27 =
* Add a filter-aware, administrator-only TXT download to Activity Logs, using the same redacted records shown in the dashboard and nonce/capability checks.
* Diagnose Rubika no-reply evidence: webhook route authentication rejects mismatched URL secrets with 403; the Rubika settings page now warns when no registered route verifier exists or it differs from the current secret. Authentication remains fail-closed; register the Rubika webhook after deployment.
* Force Bale/Telegram Mini App AJAX and returned WooCommerce payment URLs to HTTPS, disable intermediary caching for catalog fetches, and add safe console/server diagnostics for catalog failures.
* Add regression smoke checks for TXT export, Rubika auth-state guidance and Bale Mini App HTTPS/payment flow. JavaScript/static tests pass; no live Rubika/Bale or WordPress staging was available.

= 1.8.26 =
* Fix a PHP parse error in the payment-redirect branch that prevented WordPress from activating the plugin. The nested ternary for selecting the redirect key had one extra closing parenthesis.
* Correct malformed fully-qualified namespace references in the bundled admin diagnostics PHP test suite.
* Validate all 91 bundled PHP files with a PHP grammar parser (zero syntax errors); PHP CLI and WordPress/WooCommerce runtime were unavailable.
* Carry forward the free-download display labels, named WooCommerce download links, platform audit and regression tests from 1.8.25.

= 1.8.25 =
* Display a Persian “دانلود رایگان” label for downloadable products whose current WooCommerce price is zero; variable products are labeled only when every purchasable variation is zero-priced. Product names in WooCommerce remain unchanged.
* Apply display-only titles across Telegram, Bale, Rubika, recommendations, cart and Mini App product views.
* Send authorized WooCommerce download URLs as clickable file-name links instead of printing raw URLs; suppress Telegram link previews. Actual file uploads/attachments are not implemented.
* Add static regression coverage and a platform delivery capability/security audit. JavaScript/static checks pass; PHP CLI and live platform staging are not available in the build environment.

= 1.8.24 =
* Audit Rubika transport, webhook event mapping, commerce identity, inline/chat keypad, rich metadata, product image upload and WooCommerce checkout compatibility against the official API catalog.
* Convert URL buttons to documented HTTPS Link metadata for text/edit flows; keep safe visible URLs in file captions and never send an undocumented Button.url field.
* Preserve UTF-8 and UTF-16 metadata offsets, prioritize checkout links under the 30-part metadata limit, harden image upload validation, and fail explicitly for undocumented Rubika member lookup.
* Add a full integration coverage/limitations report. Runtime PHP and live Rubika/WordPress integration tests remain deployment checks.

= 1.8.23 =
* Render WooCommerce payment links in Rubika messages using documented Link metadata; reject non-HTTPS links and do not send the undocumented Button.url field.
* Native Rubika wallet payments remain unavailable until Rubika publishes/provides a merchant payment API and verification contract.
* PHP and live payment tests require an appropriate runtime and merchant credentials.


= 1.8.22 =
* Harden Rubika commerce identity: keep opaque string message IDs intact across the shared bot navigation/edit/delete flow.
* Bind Rubika cart and checkout session ownership to the message sender while preserving chat_id as the reply destination.
* Resolve chat type using the documented getChat method; block group/channel sales flows to avoid exposing private cart and checkout data.
* Ignore non-actionable Rubika lifecycle events and bot-originated messages; accept shared contact phone numbers in checkout.
* PHP/WordPress live tests were not run in the build environment.


= 1.8.21 =
* Avoid fatal errors in Telegram photo-caption truncation and subscriber avatar initials when optional mbstring is unavailable.
* Remove the unused PDO extension from the environment recommendation.
* Review Bale/Rubika reply destination handling; preserve Rubika chat_id routing and avoid exposing private commerce replies to Bale groups.
* Extend offline smoke coverage. PHP CLI and live WordPress/WooCommerce/channel credentials were unavailable for runtime integration tests.

= 1.8.20 =
* Remove obsolete product identifiers and compatibility shims from plugin source, assets, docs and tests; retain only current Zarincode routes and identifiers.
* Remove obsolete legacy migrations and fallback references; add a repository-wide branding smoke test.

= 1.8.19 =
* Namespace the settings admin page as `zarincode_zarinshopbot_setting` across menu registration, section/tab links, redirects, JavaScript and offline guide.
* Redirect old settings page URLs to the new slug while preserving tab/query state.
* Keep the WordPress option name `zarincode_settings` and settings group unchanged so saved configuration is preserved.

= 1.8.18 =
* Fix Rubika reply routing: preserve webhook chat_id separately from sender_id and send shared-engine replies to the correct conversation.
* Add regression coverage for StartedBot fallback, distinct sender/chat identifiers, and protection against redirecting unrelated admin destinations.

= 1.8.17 =
* Fixed Telegram menu synchronization so it no longer replaces a Mini App menu button with a commands-only button; when enabled, the plugin now registers its HTTPS Mini App URL through setChatMenuButton.
* Generated Telegram/Bale Mini App URLs now use HTTPS; menu configuration reruns when either commands or the Mini App setting changes.
* Improved BotFather setup instructions and getMe diagnostics to detect a mismatch between the saved bot username and the bot token.
* Added offline smoke coverage. PHP CLI, Telegram credentials and a live BotFather/API test were not available in the build environment.

= 1.8.16 =
* Fixed a PHP parse error in the Store API checkout validator so the plugin loads on supported PHP versions.
* Guarded the cart stock check against omitted stock metadata and added the WooCommerce CRUD `manage_stock` value to product data.
* Offline JavaScript/static checks are available; PHP CLI and live WordPress/WooCommerce verification were not available in the build environment.

= 1.8.15 =
* Made full name, mobile phone, and valid email mandatory in bot checkout, Mini App checkout, and WooCommerce website checkout for downloadable, physical, and mixed carts; stale/disabled options can no longer bypass the requirement.
* Kept validated email on downloadable WooCommerce orders instead of clearing it, including Mini App orders, so download permissions and order records retain the customer email.
* Made the Mini App email field visible and required even when shipping fields are hidden; added server-side validation to the endpoint and direct WooCommerce Store API checkout hooks.
* Updated admin controls to show these identity fields as mandatory and non-disableable; preserved configurable shipping/address fields and mixed-cart shipping behavior.
* Updated offline smoke tests and checkout guidance. JavaScript/static checks are available; PHP CLI and live WordPress/WooCommerce verification are not available in this environment.

= 1.8.14 =
* Changed the dashboard slug to zarincode_zarinshopbot and retained a query-preserving redirect from zarincode_main.
* Added guarded uninstall cleanup for plugin-owned options, transients, CPT data, metadata, scheduled events, Action Scheduler records, WPML strings and namespaced legacy tables; WooCommerce orders are retained.
* Updated the displayed plugin name to ربات زرین شاپ and set the product/developer URLs.
* Offline smoke checks pass; live WordPress/WooCommerce and PHP runtime verification was not available.

= 1.8.13 =
* Fixed the administrator diagnostics action by bundling its read-only suite.
* Added safe system checks for WooCommerce, REST, channel configuration, secret encryption, webhook scheme, and required assets.
* Escaped diagnostic result labels and details in the admin UI.
* Offline JavaScript smoke checks pass; live WordPress/WooCommerce/provider verification was not available.

= 1.8.12 =
* Fixed Telegram HTML parsing for photo captions and edited messages; escaped HTML entities are no longer decoded into active markup before sanitization.
* Converted shared HTML formatting to Bale's documented Markdown syntax across messages, media captions and edits; Telegram-only parse_mode is not sent to Bale.
* Prevented raw HTML from leaking into Rubika photo captions by sending plain text, without assuming undocumented sendFile caption metadata support.
* Normalized product names in channel product lists, cart messages and add-to-cart confirmations.
* Added offline per-adapter regression checks. No live Telegram, Bale or Rubika API test was available.

= 1.8.11 =
* Fixed escaped HTML tags leaking into Telegram product notifications; product names are normalized and escaped as plain text while the intended bold title remains formatted.
* Applied the same safe title handling to back-in-stock notifications and added regression coverage.

= 1.8.10 =
* Fixed Telegram inline callbacks by acknowledging callback queries at webhook ingress before database and WooCommerce work.
* Added a one-time upgrade webhook refresh for existing Telegram installations so callback_query is explicitly subscribed.
* Expanded webhook diagnostics to show whether callback_query is present in the live allowed_updates list.
* Added independent bot checkout-field profiles for downloadable products and physical/mixed carts. Name, mobile phone and valid email are mandatory for all order types; downloadable email is retained on the WooCommerce order. Shipping/address behavior remains based on cart type.
* Free downloadable orders now complete through WooCommerce and send permitted links; paid downloads are released only after WooCommerce confirms payment. Card-transfer downloads remain gated on manager approval.
* Prevented positive-total orders from being marked paid when no payment method is selected, and added idempotency for free/no-payment order creation.
* Fixed WooCommerce shipping-rate discovery so storefront shipping visibility does not suppress real rates; downloadable lines are excluded, cart/session state is restored, and invalid/missing rates fail closed.
* Offline PHP/JS smoke tests and syntax checks passed. No live WordPress/WooCommerce or gateway test was available.

= 1.8.8 =
* Consolidated Telegram connection, Mini App, alerts, proxy, native payments, and Telegram-only messaging features into one Telegram settings tab, using labeled groups and preserving existing option names.
* Kept all Bale settings in the Bale tab and all Rubika settings in the Rubika tab; moved cross-platform log controls into a separate shared diagnostics tab.
* Preserved old Telegram subsection links as aliases to the consolidated Telegram tab; shared WooCommerce settings remain in their own sections.
* Offline smoke tests, source scans, PHP parsing, and package checks passed. No live WordPress/WooCommerce or messaging API test was run.

= 1.8.7 =
* Finalized the shared save-bar partial for the main settings form and the independent Bale/Rubika option forms; the channel-only save scope remains explicit and the brand footer is identical.
* Clarified token status accurately: a stored token alone is not proof of a live connection; the channel's last explicit API-test result is shown separately.
* Added static checks for save-form IDs, Settings API option group/nonces, and cross-channel preservation; 8 JavaScript smoke suites, source parsing for 80 PHP files, and archive integrity passed. No live WordPress/WooCommerce/API test was run.

= 1.8.6 =
* Unified the sticky save-bar markup for the main settings, Bale, and Rubika through one reusable panel partial; each channel still submits only its own Settings API form and clearly explains its save scope.
* Kept channel forms, option group, nonce, sanitizer, and secret-preservation behavior independent; added an offline contract test for cross-channel settings preservation.
* Corrected token status copy so a saved token is not presented as proof of a live connection; the channel test result remains separately available.
* JavaScript static smoke tests and PHP source parsing passed. No live WordPress Settings API, WooCommerce, or messaging API test was run.

= 1.8.5 =
* Added a capability matrix based on the official Telegram, Bale, Rubika, WordPress, and WooCommerce documentation, with explicit limits for unsupported or unverified platform behavior.
* Separated Telegram-only invoices, Stars, rich messages, post-purchase rating, compact navigation, and the Telegram coupon from shared marketing and WooCommerce settings; moved the shared command-menu toggle to describe only platforms with implemented registration.
* Added clear shared WooCommerce checkout and download-policy guidance for free/paid digital products and mixed-cart shipping, without adding a bypass switch.
* Added offline smoke coverage for the capability matrix, platform scope, and the existing downloadable-product policy; PHP source parsing and JavaScript smoke tests passed. No live WordPress/WooCommerce or messaging API test was run.

= 1.8.4 =
* Added separate immediate-publish buttons for Telegram, Bale, and Rubika on the WooCommerce product editor; each button sends only to that platform's independently configured destination.
* Added capability, product-status, and per-product nonce checks to the authenticated AJAX publishing endpoint; success/failure feedback is shown in the editor.
* Preserved the on-save per-platform selection and the existing Telegram bot-audience notification as a clearly separate action.
* Added an independent product-editor publishing panel with responsive local styling and offline smoke coverage.
* JavaScript smoke tests and PHP syntax parsing passed; no live WordPress/WooCommerce or messaging API runtime test was available.

= 1.8.3 =
* Reorganized settings into clearly marked Telegram-only, Bale-only, Rubika-only, and shared WooCommerce sections without changing saved option keys.
* Added a responsive three-platform control hub with per-channel setup status and direct links to each platform's settings.
* Clarified that Telegram alerts/Mini App/proxy settings are Telegram-specific, while Bale and Rubika retain their own independent settings, product-post destinations/titles, and order-notification switches.
* Kept digital-product checkout, mixed-cart shipping, and responsive RTL card-transfer behavior from 1.8.2.
* Offline JavaScript smoke tests and PHP syntax parsing passed; PHP CLI and live WordPress/WooCommerce/API runtime tests were unavailable in this environment.

= 1.8.2 =
* Added secure free and paid downloadable-product checkout for all three bot channels and the Mini App checkout routes.
* Added independent Telegram, Bale, and Rubika product-post destinations and title templates.
* Improved mobile/RTL card-transfer details.


= 1.8.1 =
* Fixed WooCommerce card-transfer review buttons: the form now renders outside the order editor form so approve/reject reaches the authenticated admin handler in classic and HPOS order screens.
* Added separate Bale and Rubika administrator chat IDs (Telegram continues using its existing Telegram admin chat setting). Receipt upload sends a signed approve/reject prompt to the buyer's own platform, with a protected link to the WooCommerce order/receipt.
* Bot-based review actions are HMAC-signed and restricted to that platform's configured admin identity. Approval calls WooCommerce payment_complete(), verifies the paid status, grants normal WooCommerce download permissions, and sends confirmation/download links to the buyer's originating platform; rejection keeps the order unpaid and prompts for a replacement receipt.
* Added safe diagnostics for receipt alerts, bot review, and WooCommerce payment completion without logging tokens, chat IDs, receipt contents, or request payloads.
* Offline/static review checks pass; live WordPress/WooCommerce and Telegram/Bale/Rubika APIs have not been tested in this environment.

= 1.8.0 =
* Downloadable WooCommerce products are excluded from bot and Mini App shipping requirements/rate packages even if Virtual is unchecked; mixed carts retain rates for physical items only.
* Telegram webhook registration explicitly subscribes to callback_query updates so Home/Cart inline callbacks are not lost through a previously restrictive allowed_updates filter.
* Rubika getMe now sends the documented no-parameter POST without an empty JSON array. On explicit invalid_input only, sendMessage safely retries without metadata and then with the official minimal text payload; no retry occurs after ambiguous transport/server failures.
* Added offline regression coverage for downloadable-only/mixed carts, Telegram callback subscription, Rubika API body and safe invalid_input fallbacks. Live WordPress/WooCommerce and messaging APIs were not available for runtime validation.

= 1.7.9 =
* اصلاح انتقال از Telegram Mini App به درگاه‌های وب ووکامرس با متد رسمی openLink تلگرام؛ درگاه Bale نیز فقط از متد مستند openLink خود Bale استفاده می‌کند و Rubika همچنان مسیر مستقل checkout وب را دارد.
* افزودن مهلت ۶۰ ثانیه‌ای برای درخواست ثبت سفارش و پیام بازیابی امن؛ اگر پاسخ دیر برسد، کاربر به سفارش‌هایش هدایت می‌شود و دربارهٔ احتمال ثبت سفارش و جلوگیری از تکرار هشدار می‌گیرد.
* افزودن ثبت مرحلهٔ checkout و خطاهای fatal بدون ذخیرهٔ شناسهٔ کاربر یا اطلاعات فرم، و تشخیص شکست واقعی پردازش پیام در ربات‌های بله/روبیکا.
* افزودن لاگ امن نتیجهٔ APIهای بله/روبیکا بدون توکن یا شناسهٔ گفتگو و آزمون آفلاین شکل وب‌هوک‌های رسمی Rubika و تحویل پیوند درگاه Mini App.
* اجرای lint و آزمون‌های آفلاین؛ آزمون runtime روی WordPress/WooCommerce واقعی و API زنده در این محیط انجام نشده است.

= 1.7.8 =
* رفع خطای ثبت سفارش در وب‌هوک بله هنگام درخواست نرخ ارسال: سبد ووکامرس در درخواست‌های REST به‌صورت امن و در صورت نیاز بارگذاری می‌شود؛ خطای شیء cart تهی دیگر به مرحلهٔ واردکردن کد پستی سرایت نمی‌کند.
* آماده‌سازی محافظت‌شدهٔ سرویس‌های مشتری، کشورها و ارسال ووکامرس؛ در صورت ناممکن‌بودن مقداردهی، خطا ثبت و مسیر بدون خطای fatal متوقف می‌شود.
* افزودن آزمون آفلاین بازگشت برای بارگذاری cart در وب‌هوک؛ runtime واقعی ووکامرس/API زنده در این محیط آزمایش نشده است.

= 1.7.7 =
* بازطراحی یکپارچهٔ تایپوگرافی، فاصله‌گذاری، کارت‌ها، فرم‌ها، جدول‌ها و واکنش‌گرایی در پنل مدیریت افزونه.
* همسان‌سازی نوار ذخیرهٔ بله و روبیکا با نوار تمام‌عرض ذخیرهٔ تنظیمات، با نمایش مستقل بر پایهٔ تب فعال.
* بهبود خوانایی داشبورد، گزارش‌ها، مخاطبان و ابزار ارسال همگانی.
* آزمون‌های آفلاین و lint اجرا شدند؛ این بسته به‌تنهایی آزمون runtime روی سایت واقعی یا API زنده محسوب نمی‌شود.

= 1.7.6 =
* Fixed the non-responsive Add Account button: enqueue the editor directly from the plugin admin bootstrap, independent of the WooCommerce gateway screen lifecycle.
* Reworked the editor initialization to use broadly supported DOM APIs, attach after document readiness, and retain the editable fallback if initialization fails.
* Added an executable JavaScript DOM smoke test for adding, editing, validating, saving and removing accounts.

= 1.7.5 =
* Move card-transfer enablement, destination accounts, customer instructions, receipt extensions and upload limits into the plugin’s own Settings panel. The WooCommerce gateway now links administrators back to that panel.
* Save into the existing WooCommerce gateway option to preserve previously configured accounts and order snapshots; register a dedicated sanitizer and maintain the legacy account-row format.
* Load the local account editor on the plugin settings page, including no-JavaScript editing fallback and panel-scoped validation; normalize Persian/Arabic digits before validating bank numbers.

= 1.7.4 =
* Fixed a fatal PHP signature incompatibility with current WooCommerce versions by matching the optional posted-data parameter in the payment gateway settings override.
* Added a WooCommerce-compatible parent-signature contract to the card-transfer smoke test to prevent regressions.

= 1.7.3 =
* Made the Telegram/Bale/Rubika channel save action sticky and consistent with the main Settings footer.
* Replaced the card-transfer account textarea with a structured, repeatable account editor for account label, bank, account holder, card number, account number, IBAN, and instructions. Existing six-column account rows continue to load.
* Added large, responsive bank-card details with a separate copy action for the account holder, card number, account number, and IBAN in website checkout/order views and the Telegram/Bale Mini App.
* Confirmed plugin icons are local; added no icon CDN dependencies.

= 1.7.2 =
* Fixed WooCommerce order creation: initialize and validate line-item counts, handle missing/unavailable products and return safe, actionable customer messages while retaining the cart.
* Localized order-creation failures and payment/receipt messages for Persian Mini App users, and applied the selected Mini App language to authenticated AJAX requests.
* Rebuilt the Persian gettext template/catalog from the current PHP sources, added legacy bot prompt strings, and compiled a fresh MO catalog.
* Removed release archives older than 1.7.0; kept the 1.7.0 and later archives unchanged.

= 1.7.1 =
* Resolve Mini App WooCommerce gateways by canonical ID as well as normalized ID; this fixes false “gateway no longer available” errors when an enabled gateway ID differs from the sanitized key.
* Check enabled status consistently from the gateway object/settings, preserve all enabled checkout methods, and report safe gateway-resolution diagnostics without exposing credentials.
* Add offline coverage for normalized IDs, boolean/string enabled values, and disabled gateways. No live WordPress/WooCommerce checkout or provider run is claimed.

= 1.7.0 =
* In Mini App checkout, use the configured native Bale/Telegram payment when available; otherwise show every enabled WooCommerce gateway and open the selected order-pay page in the same Mini App view.
* Add WooCommerce card-transfer gateway for normal checkout and Mini Apps, with multiple destination accounts, per-order account selection, configurable image/PDF receipt formats and a default 2 MB limit.
* Encrypt receipts in private order metadata (never public Media Library); validate upload size, extension and file signature/MIME. Orders stay on hold until an authorized manager reviews an uploaded receipt and approves payment.
* Add private admin receipt viewing and approve/reject controls; releasing payment through WooCommerce payment completion is the only route to fulfillment/download permissions.
* Add offline configuration/fallback smoke coverage. PHP/JS and package checks are offline; live WordPress, WooCommerce, wallet, gateway and provider runtime behavior is not claimed.

= 1.6.9 =
* Persist each registered-route HMAC verifier in a dedicated WordPress option separate from editable channel settings; verify the DB write before reporting success.
* Authentication reads that dedicated state (with compatibility fallback to 1.6.8 data), and registration logs explicitly report whether the verifier was saved. No raw route secret is duplicated.
* Add offline regression coverage for separate-option persistence, registered-route fallback, and rejection of unregistered paths. No live provider delivery is claimed.

= 1.6.8 =
* Fix the final authentication mismatch: after successful provider registration, retain a keyed full-length verifier for the exact registered route. Incoming webhooks are accepted only if they match either the current configured route secret or the last successfully registered route.
* Bale's registered route verifier is updated only after official getWebhookInfo confirms the URL/route. Rubika's verifier is updated only after both documented ReceiveUpdate and ReceiveInlineMessage endpoint updates are accepted.
* Keep the raw registered route secret out of the duplicate verifier; clear the verifier when the bot token is explicitly removed. Offline regression coverage added; no live API delivery is claimed.

= 1.6.7 =
* After Bale setWebhook, verify the active URL using the officially documented getWebhookInfo method; record only safe match flags and keyed route fingerprints, never the URL or secret.
* Log the accepted result and configured fingerprint separately for each documented Rubika ReceiveUpdate/ReceiveInlineMessage endpoint. Rubika's public method list does not document an endpoint-inspection getter, so the plugin does not claim remote read-back verification there.
* Add safe route-fingerprint tests for pretty and query-based WordPress REST URLs. Offline tests only; no live provider call is claimed.

= 1.6.6 =
* Fix webhook secret rotation on settings saves: resubmitting an unchanged Bale/Rubika bot token no longer invalidates the already-registered webhook URL. A genuinely changed token still rotates the route secret and requires webhook registration again.
* Add regression coverage for stable webhook secrets on unchanged tokens and rotation after a token change.
* Offline contract smoke suites and PHP syntax checks passed; no live provider or WordPress/WooCommerce runtime is claimed.

= 1.6.5 =
* Read webhook credentials exclusively from the matched REST URL route parameter, preventing request-body/query values named `secret` from shadowing the registered path value.
* Enrich Bale/Rubika webhook authentication error logs with a non-sensitive reason, presence/length indicators, and keyed truncated fingerprints; never log raw credentials or webhook URLs.
* Add offline regression tests for credential mismatch diagnostics and route-parameter precedence. All 10 smoke suites and PHP syntax checks passed; no live WordPress/WooCommerce or provider webhook/API test is claimed.

= 1.6.4 =
* Split dashboard orders/revenue by source channel (Telegram, Bale, Rubika) using `_order_from`; include CPT and HPOS queries and present mixed currencies separately.
* Add independent Telegram enable/disable, explicit multi-platform broadcast selection, accurate queued/attempted wording, and per-platform audience links.
* Migrate Telegram, Bale, Rubika and Bale provider credentials to authenticated encryption at rest where OpenSSL/Sodium is available; blank secret fields keep current values.
* Offline verification: 9 contract smoke tests, PHP-WASM 8.5 syntax checks for 73 files, JavaScript syntax, gettext/MO and whitespace checks. Live WordPress/WooCommerce/provider delivery was not tested.

= 1.6.3 =
* Replaced WordPress Dashicons in plugin screens with a curated, bundled Lucide SVG subset; Mini App UI controls now use local vector masks and local Telegram/Bale/Rubika marks.
* Added unified Telegram, Bale, Rubika and plugin/system log filters with source counts and privacy-aware display of structured webhook diagnostics; legacy Telegram history remains visible.
* Refined Persian/English and 13-locale bot starter copy; only known untouched seed text and the untouched old divider signature migrate. The administrator-editable signature is appended to shared and direct channel replies and can be disabled by clearing it.
* Added static asset and syntax checks. No WordPress/WooCommerce runtime or live-provider test is claimed.

= 1.6.2 =
* Added privacy-safe, per-platform Bale/Rubika webhook ingress and dispatch diagnostics; shared update logs now identify their source channel.
* This diagnostic release does not claim live provider delivery or end-to-end testing.

= 1.6.1 =
* Expanded the gettext source catalog to 1,044 unique static strings and completed the Persian PO/MO catalog; preserved prior translations and contextual entries.
* Localized Mini App PHP/JavaScript labels, channel-panel feedback, command descriptions, bot chat replies, default greetings, and new settings placeholders.
* Migrated only untouched legacy English seed messages to Persian defaults; administrator-customized message text remains intact.
* Updated release metadata to 1.6.1. Static PHP parsing and JavaScript syntax checks passed; no live WordPress/WooCommerce/API runtime test is claimed.

= 1.6.0 =
* Added opt-in Telegram Rich Messages (Bot API 10.1+) with RTL metadata and conservative fallback only after explicit 400/404 API rejection.
* Recognize modern Telegram update envelopes and safely acknowledge/log update types without a commerce handler.
* Added Bale-native video/audio/document/animation/voice and media-group adapter mappings covered by offline contract tests.
* Reworked the Commands tab into common commands, shared optional aliases, and platform-specific menu setup; clarified Rubika payment and membership API limits.
* Added offline tests for Channel API (22), update idempotency (6), Telegram update envelope (6), Telegram Rich Message routing (8), and command consistency (4): 46 assertions total; added API audit notes for Telegram, Bale, and Rubika.

= 1.5.5 =
* Rename the first settings tab to Telegram and use the Telegram platform icon.
* Align the 11 common Telegram/store commands; sync Rubika's documented setCommands list when registering its webhook, while keeping Bale menu setup platform-specific.
* Preserve Rubika formatting metadata when editing messages and honor the global command-menu setting.
* Clarify that common store commands are shared where each platform API supports them; Telegram, Bale, and Rubika retain platform-specific payment, Mini App, membership, and command-menu behavior.


= 1.5.4 =
* Hardened Bale/Rubika API transport: provider allowlist, bounded TLS-verified requests, strict response-envelope validation, and sanitized transport errors.
* Routed channel storefront messages through the shared provider adapter for consistent button translation and response handling.
* Added webhook payload bounds, short duplicate suppression for event types without a stable provider ID, and privacy-safe delivery-failure logging.
* Persisted new webhook secrets before endpoint registration to prevent first-update authentication races.
* Replaced fatal duplicate-update termination and mutable post GUID usage with backward-compatible update-ID metadata and explicit duplicate acknowledgement.
* Added offline Channel API (14 assertions) and update-idempotency (6 assertions) smoke tests; static syntax/compatibility checks were run without claiming live provider delivery.

= 1.5.3 =
* Added a Bale storefront Mini App entry and responsive, theme-aware SDK integration with BackButton, QR scanning, contact-sharing prompt, and optional home-screen shortcut controls.
* Validate Bale initData server-side with the documented WebAppData HMAC scheme and keep Bale account IDs namespaced separately from Telegram IDs.
* Added native Bale Mini App checkout through createInvoiceLink/openInvoice; retain server-confirmed WooCommerce payment status and never redirect Mini App payments to website checkout.
* Preserve Telegram Mini App and normal WooCommerce behavior; align all release metadata with 1.5.3.
* Static JavaScript syntax and whitespace checks were run; PHP lint and runtime payment tests were not available in this build environment.

= 1.5.2 =
* Added responsive safe gutters around full-width admin panels so cards remain inset from the viewport edges.
* Replaced per-request asset file-stat cache keys with the release version, enabling long-lived browser caching until the next version bump.
* Added transient caching and WooCommerce-order invalidation for dashboard sales and top-product aggregates.
* Avoided repeating WPML dynamic-string registration work on every request when settings have not changed.
* Kept Bale/Rubika panel content lazy-loaded and independent from the main settings form.
* Bumped all current release metadata to 1.5.2.

= 1.5.1 =
* Fixed Bale/Rubika settings navigation so every settings section stays available after switching channels.
* Load channel settings on demand with a permission- and nonce-protected AJAX fragment instead of reloading the entire WordPress settings page.
* Keep independent channel forms outside the Telegram settings form and return to the selected channel after saving.
* Bumped the plugin release version to 1.5.1 across distribution metadata.

= 1.5.0 =
* Corrected the OrderFlowTrait.php parse error caused by a doubled namespace separator; bundled PHP files were checked with a PHP grammar parser.
* Replaced active legacy identifiers with Zarincode identifiers across routes, settings, actions, AJAX names, post types, taxonomy/meta keys, widget IDs and Mini App storage.
* Added one-time migration and compatibility bridges for earlier option names, metadata, posts, widgets, AJAX callers, hooks and settings integrations.
* Added Telegram provider invoice payments inside chat and a Telegram Mini App openInvoice flow; native Mini App mode does not redirect to the WooCommerce payment page.
* Chat checkout no longer presents website-gateway URLs when native payment is unavailable. Native Bale/Telegram configuration is required; Rubika native payment remains unavailable without a documented official flow.

= 1.3.0 =
* به‌روزرسانی نسخهٔ افزونه به 1.3.0 در سربرگ، ثابت اصلی، پنل، خروجی JSON، Composer، Stable tag و راهنما.
* افزودن فونت متغیر Exo 2 لاتین در کنار Vazirmatn؛ متن فارسی/عربی با Vazirmatn و نویسه‌های لاتین/انگلیسی با Exo 2 به‌صورت محلی و بر اساس Unicode fallback نمایش داده می‌شوند.
* اعمال فونت دوگانه در صفحه‌های مدیریت افزونه، ویرایش محصول/دسته، ابزارک Telegram، Mini App و راهنمای آفلاین؛ افزودن مجوز و انتساب Exo 2.
* گسترش راهنمای فارسی بر اساس صفحه‌ها و handlerهای واقعی افزونه؛ افزودن فرایند خرید گام‌به‌گام، صفحهٔ کانال‌ها، ابزارهای ووکامرس و توضیح محدودیت‌های پلتفرم/API.
* همگام‌سازی حداکثر تعداد محصولات هر صفحه در اعتبارسنجی سمت سرور با فرم (تا 50).
* اتصال کنترل‌های جست‌وجوی زنده، SKU، علاقه‌مندی و referral به رفتار بات؛ پایدارشدن گزینهٔ referral و توضیح دقیق محدودیت فیلتر بازهٔ قیمت.
* اصلاح توضیح یادآوری سبد برای اجرای Action Scheduler یا WP-Cron.
* پاک‌سازی قطعهٔ HTML/PHP تکراری و نامعتبر از انتهای stylesheet مربوط به Mini App؛ فایل اکنون فقط CSS دارد.

= 1.2.0 =
* افزایش نسخهٔ افزونه از 1.1.0 به 1.2.0 و همگام‌سازی شمارهٔ نسخه در سربرگ، پنل، خروجی پشتیبان، Composer و Stable tag.
* افزودن راهنمای کامل فارسی آفلاین به‌صورت HTML مستقل و زیرمنوی راهنمای افزونه در پیشخوان.
* افزودن فونت متغیر محلی Vazirmatn همراه با مجوز OFL و استفاده در پنل و Mini App.
* افزودن اردو به فهرست زبان‌های قابل انتخاب.
* بهبود دسترسی سریع به راهنما و اصلاح نسخه‌گذاری cache assetها.

= 1.1.0 =
* معرفی برند زرین‌کد و افزونه ZarinShopBot.
* افزودن آداپتور webhook/API برای Bale و Rubika v3 و هم‌راستاسازی جریان‌های مشترک هسته فروشگاه.
* افزودن سبدهای تفکیک‌شده، keypads بومی، لینک checkout ووکامرس و پرداخت در سایت.
* غیرفعال‌سازی وب‌هوک relay خارجی و اجبار به وب‌هوک مستقیم HTTPS.
* حفظ انتساب upstream و مجوز GPL.
