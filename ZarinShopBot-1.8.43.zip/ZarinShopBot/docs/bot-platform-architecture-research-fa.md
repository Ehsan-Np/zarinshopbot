# پژوهش معماری ربات‌ها: Telegram، Bale و Rubika

**بازبینی:** ۲۷ اکتبر ۲۰۲۶  
**هدف:** مرجع نگهداری‌پذیر برای طراحی/ممیزی runtime ربات؛ نه رتبه‌بندی تبلیغاتی SDKها و نه اثبات اتصال زنده.  
**منابع پایه:** اسناد رسمی هر پلتفرم، کاتالوگ داخلی Rubika و بررسی ایستای README/ساختار/فایل‌های منتخب مخازن پیوست.

> **اصل محوری:** فقط قرارداد مستند همان پلتفرم را مبنا بگیرید. نام‌های هم‌شکل مثل `getUpdates`، `sendMessage`، `callback_query` یا `file_id` به‌تنهایی به معنی یکسان بودن payload، ترتیب تأیید، امنیت webhook، معناشناسی دکمه، سقف فایل، روش پرداخت یا خطا نیستند.
>
> برچسب‌های این سند: **رسمی** = در سند رسمی همان پلتفرم دیده شده؛ **کد** = در فایل/ساختار repository به‌صورت ایستا مشاهده شده؛ **README** = ادعای پروژه؛ **تأییدنشده** = تست زنده یا اجرای تست پروژه انجام نشده است.

---

## ۱. خلاصهٔ تصمیم‌ها

1. ربات را به لایه‌های مستقل transport/client، دریافت update، نرمال‌سازی، dispatch، handler/domain، state/storage، خروجی و عملیات deployment تقسیم کنید.
2. برای هر پلتفرم adapter اختصاصی بسازید. تنها domain eventهای واقعاً مشترک را normalize کنید؛ payload خام و capabilityهای platform-specific را نیز حفظ کنید.
3. رفتار تحویل را با فرض duplicate، retry و crash طراحی کنید؛ idempotency و inbox پایدار را برنامه‌ریزی کنید، نه اینکه «دقیقاً یک‌بار» را از نام SDK نتیجه بگیرید.
4. FSM حافظه‌ای برای نمونهٔ آموزشی مناسب است، نه برای چند worker، restart، scale-out یا فرایند پرداخت. کلید state باید پلتفرم، bot، chat، کاربر و در صورت لزوم thread را پوشش دهد.
5. دکمه‌های callback، keypadهای روبیکا، Mini Appها، فایل‌ها و پرداخت‌ها را capability مستقل مدل کنید. وجود هم‌نام API در Telegram به معنی وجود آن در Bale/Rubika نیست.
6. شاخص «تعداد متد» یا «۱۰۰٪ coverage» را بدون تطبیق با فهرست رسمی همان روز، schema و تست‌های معنایی معتبر ندانید.

---

## ۲. محدوده و روش بررسی

### ۲.۱ منابع رسمی

- **Telegram:** [Bot API](https://core.telegram.org/bots/api)، [changelog](https://core.telegram.org/bots/api-changelog)، [Bots FAQ](https://core.telegram.org/bots/faq). وضعیت اسناد رسمی هنگام این بررسی Bot API **10.3** بود؛ آخرین مورد مشاهده‌شده در Recent changes مورخ ۲۴ اوت ۲۰۲۶ است.
- **Bale:** [مستندات رسمی بازو](https://docs.bale.ai/)، [مستند Mini App](https://docs.bale.ai/miniapp)، [سفیر](https://docs.bale.ai/safir).
- **Rubika:** [کاتالوگ فنی جداگانهٔ این workspace](rubika-bot-api-catalog-fa.md)، متکی بر صفحات رسمی [Bot API](https://rubika.ir/botapi)، [متدها](https://rubika.ir/botapi/methods)، [مدل‌ها](https://rubika.ir/botapi/models) و [گروه/کانال](https://rubika.ir/botapi/group-channel).

### ۲.۲ روش بررسی مخازن

صفحات مخزن، README، فهرست فایل‌ها/پوشه‌ها، تاریخ/حجم تغییرات و در چند مورد فایل‌های runtime منتخب بررسی شدند. **مخازن از راه دور در این بررسی clone و اجرا نشدند، تست‌های CI محلی دوباره اجرا نشدند، token واقعی استفاده نشد و webhook/polling زنده آزمایش نشد.** بنابراین نتیجهٔ آزمون‌پذیر دربارهٔ قابل نصب بودن، سلامت کامل یا پایداری عملیاتی هیچ SDKای ادعا نمی‌شود.

مخازن بررسی‌شده:

- Rubika: `StoryKode/Krubot`، `EhsanGhorbany/Rubika`، `Daniyel-Vanguard/Rubika-Bot`، `sanf-dev/Rubot`، `imhamiddev/telegram-to-rubika`، `mojtabaqri/Rubika-SDK`.
- Bale: `Daniyel-Vanguard/BaleBot`، سازمان `balecore`، `AbolfazlZarei-dev/ParsBale-bot-go`، `ErfanVahabpour/Bale-Bot-SDK`.
- Telegram: `python-telegram-bot`، `aiogram`، `Telegraf`، `grammY`، `go-telegram-bot-api/telegram-bot-api` و PHP SDK `irazasyed/telegram-bot-sdk`; همچنین `AstrBot` به‌عنوان نمونهٔ پلتفرم چندپیام‌رسان.

### ۲.۳ نمونه‌برداری از GitHub Topic

صفحهٔ [github.com/topics/telegram](https://github.com/topics/telegram) هنگام مشاهده **۲۴٬۴۴۵** مخزن عمومی نشان می‌داد (Python 10,508؛ JavaScript 2,550؛ TypeScript 2,348؛ Go 1,527؛ PHP 934). Topic هم مخازن کلاینت رسمی، RSS، ابزار کمکی، mirror و پروژه‌های غیررباتی را کنار SDK ربات نشان می‌دهد؛ برچسب topic معیار کافی برای محصول بودن یا سلامت مخزن نیست. نمونهٔ این سند بر اساس تنوع زبان و نقش فنی (framework/SDK، async، webhook/polling، wrapper کم‌سطح و پلتفرم چندکاناله) انتخاب شده است، نه پیمایش کامل یا رتبه‌بندی کامل همهٔ مخازن.

---

## ۳. معماری runtime پیشنهادی

```text
Platform transport/client
  ├─ Poller یا Webhook ingress (مختص پلتفرم)
  ├─ Raw envelope + schema/version validation
  ├─ Durable inbox + deduplication + checkpoint
  ├─ Update normalizer (حفظ raw payload و platform fields)
  ├─ Dispatcher / Router
  │   ├─ middleware / filters / authorization
  │   ├─ command, callback, text, media, membership, payment handlers
  │   └─ per-chat ordering / bounded concurrency
  ├─ Domain service (فروشگاه/پشتیبانی/بازی/…)
  ├─ Durable state/FSM + business database
  └─ Outbox / platform-specific API client / retry scheduler / metrics
```

### ۳.۱ مرزهای هر لایه

- **Transport:** HTTP، TLS، timeout، upload، API envelope و خطای خام؛ هیچ منطق فروش/گفت‌وگو در این لایه نباشد.
- **Ingestion:** دریافت webhook یا polling، احراز/اعتبارسنجی ورودی، ثبت durable، deduplicate و کنترل checkpoint.
- **Normalizer:** envelopeهای متفاوت را به eventهای domain مانند `TextReceived`، `ButtonPressed`، `PaymentConfirmed` تبدیل می‌کند؛ `raw_update` و `platform`/`bot_id` را برای قابلیت‌های غیرمشترک حفظ می‌کند.
- **Router/Dispatcher:** انتخاب handler بر مبنای نوع update، command، callback، media، نقش کاربر، chat، state، bot و platform. اولویت، کوتاه‌سازی زنجیره و رفتار fallback روشن باشد.
- **Middleware:** logging با redaction، locale، auth، rate-limit، tracing، tenant/bot context، transaction و policy. Middleware شبکه‌ای نباید handler را دوبار اجرا کند.
- **State/FSM:** state گام‌به‌گام + data + expiry + version در storage پایدار؛ transition به شکل کنترل‌شده و قابل تکرار.
- **Outbox:** ثبت قصد ارسال در همان transaction دامنه؛ worker آن را ارسال و نتیجه را ثبت می‌کند. برای timeout مبهم، retry ارسال پیام می‌تواند duplicate بسازد؛ correlation و سیاست reconcile لازم است.
- **Observability:** نرخ update، duplicate، صف، خطای API، `retry_after`، زمان handler، خطای webhook و pending count را بدون افشای token/متن خصوصی گزارش کنید.

### ۳.۲ قرارداد مشترک در برابر اختلاف‌های پلتفرمی

| موضوع | abstraction قابل استفاده | آنچه باید platform-specific باقی بماند |
|---|---|---|
| text | متن/محتوای domain، locale، entityهای معمول | parse mode/metadata، escaping، واحد offset، سقف و markup هر پلتفرم |
| button | intent و شناسهٔ action داخلی | Telegram inline/reply keyboard، Bale reply/inline، Rubika Chat Keypad/Inline Keypad و مدل دادهٔ آن‌ها |
| callback | action ID و authorization | schema، مسیر update، acknowledgement، طول payload، پشتیبانی کلاینت و قابلیت‌های هر API |
| media | نوع معنایی، checksum، storage key | file ID scope، upload/download، اندازه، URL import، endpoint و encoding |
| payment | سفارش، مبلغ integer، وضعیت تراکنش | provider/token، currency unit، pre-checkout، webhook/verification، refunds و قابلیت رسمی platform |
| updates | normalized event + raw input | cursor، update type list، تأیید، ترتیب، retention، webhook security/retry |

**هیچ `UniversalKeyboard`, `UniversalPayment` یا `UniversalUpdate` واحدی را به‌عنوان قرارداد تضمین‌شده نسازید.** در صورت نیاز، capability matrix با مقادیر `supported / unsupported / unknown / client-version-limited` استفاده کنید.

---

## ۴. دریافت update و اتصال؛ رفتار مستندشده

### ۴.۱ Telegram — Bot API 10.3

#### اتصال و درخواست API

- Base URL: `https://api.telegram.org/bot<TOKEN>/METHOD_NAME`.
- HTTPS و UTF‑8؛ متدها case-insensitive؛ GET/POST و query string، `application/x-www-form-urlencoded`، JSON (جز آپلود مستقیم فایل) یا `multipart/form-data`.
- پاسخ JSON دارای `ok` و در موفقیت `result` است؛ در خطا `description`، `error_code` و گاهی `parameters` (از جمله `retry_after`) را پردازش کنید.
- Token در مسیر URL قرار می‌گیرد: access log، exception، tracing و ابزارهای analytics می‌توانند آن را افشا کنند. URL کامل درخواست را log نکنید.

#### دو روش انحصاری دریافت

1. **Long polling با `getUpdates`:** `offset`، `limit` (۱–۱۰۰، پیش‌فرض ۱۰۰)، `timeout` (برای long polling مثبت) و `allowed_updates`. Update با درخواست بعدی دارای offset بزرگ‌تر از `update_id` تأیید می‌شود. آخرین updateهای دریافت‌نشده بیش از ۲۴ ساعت نگهداری نمی‌شوند. منفی‌کردن offset صف قبلی را دور می‌ریزد؛ برای production به‌کار نبرید.
2. **Webhook با `setWebhook`:** HTTPS POST شامل JSON `Update`; در پاسخ ناموفق HTTP غیر 2xx، Telegram تحویل را مدتی retry می‌کند و پس از تعداد نامشخص/معقول تلاش کنار می‌گذارد. `secret_token` در header `X-Telegram-Bot-Api-Secret-Token` می‌آید؛ `max_connections` برابر ۱–۱۰۰ (پیش‌فرض ۴۰)، `allowed_updates` و `drop_pending_updates` قابل تنظیم‌اند. پورت‌های اعلام‌شده: 443، 80، 88، 8443. وضعیت با `getWebhookInfo`، حذف با `deleteWebhook`.

این دو مسیر هم‌زمان قابل استفاده برای یک bot نیستند؛ `getUpdates` وقتی webhook تنظیم است کار نمی‌کند. برای webhook، پس از اعتبارسنجی secret و ثبت update در صف پایدار، پاسخ 2xx بدهید؛ منطق طولانی را در request thread اجرا نکنید.

#### فهرست updateهای کلیدی در 10.3

`Update` یک `update_id` دارد و علاوه بر آن، یکی از فیلدهای نوع‌دار زیر در envelope ظاهر می‌شود: `message`, `edited_message`, `channel_post`, `edited_channel_post`, `business_connection`, `business_message`, `edited_business_message`, `deleted_business_messages`, `guest_message`, `message_reaction`, `message_reaction_count`, `inline_query`, `chosen_inline_result`, `callback_query`, `shipping_query`, `pre_checkout_query`, `purchased_paid_media`, `poll`, `poll_answer`, `my_chat_member`, `chat_member`, `chat_join_request`, `chat_boost`, `removed_chat_boost`, `managed_bot`, `subscription`, `stopped_message_generation`. علاوه بر این، Bot API 10.1+ فیلد `query_id` را در `ChatJoinRequest` اضافه کرده است؛ این **فیلد مدل** است، نه نوع مستقل Update، و برای queryهای واگذارشده به bot باید `answerChatJoinRequestQuery` یا `sendChatJoinRequestWebApp` را در deadline رسمی پاسخ دهد.

درخواست updateهای محدودشده ممکن است permission/ادمین بودن یا `allowed_updates` صریح بخواهد. فهرست پیش‌فرض شامل همه‌چیز نیست: طبق مستند جاری، `chat_member`، `message_reaction` و `message_reaction_count` به‌طور پیش‌فرض حذف‌اند. Parser را برای فیلدهای optional و updateهای ناشناخته tolerant بنویسید.

### ۴.۲ Bale — مستندات رسمی بازو

#### درخواست‌ها

- Base URL عمومی: `https://tapi.bale.ai/bot<TOKEN>/METHOD_NAME`.
- GET/POST، query/form/JSON/multipart و UTF‑8؛ پاسخ دارای `ok`, `result`, `description`, `error_code` و گاهی `parameters.retry_after` است.
- در متن رسمی، 2 روش دریافت update وجود دارد و updateها به شکل JSON دریافت می‌شوند. مستند فعلی retention را **۲۰۰۰ پیام آخر تا ۲۴ ساعت** اعلام می‌کند.

#### Polling و webhook

- `getUpdates` از `offset`, `limit` (۱–۱۰۰) و `timeout` استفاده می‌کند. offset بزرگ‌تر از update قبلی آن را تأیید می‌کند؛ cursor را بعد از پاسخ دوباره محاسبه کنید.
- Webhook با `setWebhook` به HTTPS POST می‌فرستد؛ پورت‌های پشتیبانی‌شده در صفحهٔ رسمی 443 و 88 ذکر شده‌اند. جابه‌جایی به polling با `deleteWebhook`; بررسی با `getWebhookInfo`.
- schema صفحهٔ رسمی فعلی Update این فیلدها را نشان می‌دهد: `message`, `edited_message`, `callback_query`, `pre_checkout_query`. این فهرست را با Telegram expand نکنید.
- در صفحات رسمی بررسی‌شده پارامتر `secret_token`/header امضاشدهٔ webhook مانند Telegram مستند نشده است. مسیر تصادفی/غیرقابل حدس، reverse-proxy controls و اعتبارسنجی schema را به‌عنوان لایهٔ دفاعی در نظر بگیرید؛ آن‌ها را معادل احراز اصالت cryptographic معرفی نکنید.

#### تفاوت‌های قابل توجه

- مستند رسمی می‌گوید API بازو «بر پایهٔ» API بات Telegram ساخته شده، اما تغییرات دارد؛ این گزاره مجوز فرض یکسان بودن تمام متدها نیست.
- `MessageEntity` در schema رسمی فقط `mention` و `bot_command` را فهرست می‌کند؛ offset/length بر حسب UTF‑16 است.
- مستندات Bale می‌گویند متن‌ها Markdown-style هستند؛ syntax/escaping و metadata را از behavior خود Bale بگیرید، نه `parse_mode` تلگرام.
- callback باید با `answerCallbackQuery` خاتمه یابد تا دکمه از حالت انتظار خارج شود. اسناد نسخهٔ قدیمی کلاینت را نیز ذکر می‌کنند: `callback_query_id` با پیشوند `1` به نسخهٔ کلاینت قدیمی و عدم پشتیبانی از answer جدید اشاره دارد؛ در آن حالت fallback پیام متنی را در نظر بگیرید.
- نرخ ارسال API عمومی به‌صورت تعاملی و وابسته به تعامل کاربر با بازو محاسبه می‌شود. `parameters.retry_after` در صورت ارائه مبنای زمان انتظار باشد.
- **API کسب‌وکاری** Base URL جدا دارد: `/business/bot<TOKEN>/<METHOD_NAME>`, هزینه‌دار و با سهمیهٔ مستقل. فهرست رسمیِ فعلی فقط `getMe`, `sendMessage`, `forwardMessage`, `sendPhoto`, `sendVideo`, `sendAudio`, `sendDocument` را نام می‌برد؛ `chat_id` فقط چت شخصی و فایل فقط `file_id` (نه URL/multipart).
- **Safir** Bot API عمومی نیست: `https://safir.bale.ai/api/v3/send_message` با `api-access-key`, `bot_id`, شمارهٔ مقصد، `message_data` و `request_id` اختیاری برای جلوگیری از ارسال تکراری در صورت تکرار درخواست. صفیه/عملیات Safir را با webhook/update API یکی نکنید.

### ۴.۳ Rubika — قرارداد مستقل

جزئیات کامل در [کاتالوگ رسمی Rubika](rubika-bot-api-catalog-fa.md) است. خلاصهٔ runtime:

- endpoint متدها: `POST https://botapi.rubika.ir/v3/{token}/{method}`؛ payload رسمی غالباً JSON است.
- polling با `getUpdates(offset_id?, limit)`؛ response شامل `updates` و `next_offset_id`. cursor **رشته‌ای** را عیناً نگه دارید؛ نه `update_id + 1`.
- webhook با endpointهای جداگانه و `updateBotEndpoints`; نام مفرد/جمع در صفحات رسمی متناقض است و باید با API واقعی/تست کنترل‌شده تأیید شود. انواع endpoint شامل `ReceiveUpdate`, `ReceiveInlineMessage`, `ReceiveQuery`, `GetSelectionItem`, `SearchSelectionItems` است.
- Updateهای مدل رسمی: `NewMessage`, `UpdatedMessage`, `RemovedMessage`, `StartedBot`, `StoppedBot`, `EventData`. Webhook پیام عادی در wrapper `update` و کلیک Inline Keypad در wrapper جداگانهٔ `inline_message` می‌آید.
- برای `ReceiveUpdate` و `ReceiveInlineMessage` شکل payload مستند است؛ برای چند endpoint دیگر schema/response عمومی در بررسی انجام‌شده کامل نیست. endpointهایی که schema مبهم دارند را صرفاً به‌خاطر enum بودن پیاده‌شده فرض نکنید.
- اسناد بررسی‌شده قرارداد عمومی یکسانی برای rate-limit، retry، error envelope و امضای webhook تعیین نمی‌کنند. عملیات حساس را idempotent کنید و درخواست غیرقطعی را کورکورانه retry نکنید.

### ۴.۴ جدول مقایسهٔ دریافت

| خصوصیت | Telegram | Bale | Rubika |
|---|---|---|---|
| Long polling | `getUpdates`, integer `update_id`/offset | `getUpdates`, integer offset؛ نزدیک به Telegram ولی مستقل | `getUpdates`, string `offset_id` → `next_offset_id` |
| Webhook | HTTPS؛ secret header رسمی؛ retry برای HTTP غیر 2xx | HTTPS؛ پورت 443/88؛ secret header معادل در اسناد بررسی‌شده دیده نشد | HTTPS/public endpoint طبق سند؛ endpoint typeهای متعدد؛ قرارداد secret/retry نیازمند تأیید |
| انحصار روش‌ها | polling/webhook mutually exclusive | polling↔webhook با حذف webhook | طبق مستندات هر دو مسیر هست؛ جزئیات switch/ack را از runtime API تأیید کنید |
| نگهداری update | حداکثر 24 ساعت | 2000 update آخر تا 24 ساعت | در کاتالوگ بررسی‌شده سقف retention قطعی ثبت نشده |
| callback/keypad | `callback_query`; پاسخ `answerCallbackQuery` | `callback_query`; پاسخ `answerCallbackQuery` (کلاینت نسخه‌محور) | Chat Keypad event و Inline Keypad event دو envelope متفاوت |
| cursor | عددی، با offset بزرگ‌تر update تأیید می‌شود | مشابه توضیح رسمی Bale | cursor opaque متنی؛ خروجی `next_offset_id` |

---

## ۵. پیام، مدل‌ها و APIها

### ۵.۱ Telegram: خانوادهٔ Update/Message

`Update` یک envelope است؛ معمولاً یک فیلد نوع‌دار دارد، اما تمام فیلدهای `Message` را به‌عنوان update مستقل نشمارید. دسته‌های مهم `Message`:

- **متن و entity:** `text`, `entities`, reply/forward/external reply, quote, link preview.
- **رسانه:** `animation`, `audio`, `document`, `photo`, `sticker`, `video`, `video_note`, `voice`, `paid_media`, `live_photo`.
- **مکان/هویت:** `contact`, `location`, `venue`, `users_shared`, `chat_shared`.
- **تعامل محتوا:** `poll`, `dice`, `game`, `invoice`, `successful_payment`, paid media purchase.
- **محتوای جدید/ساخت‌یافته:** `rich_message`, `checklist`, ephemeral/guest fields.
- **service/گروه:** عضو جدید/ترک، title/photo/topic/forum، pin، migrate، reaction, boost, suggested post, community chat event و سایر رخدادهای سرویس.
- **کانال/Business:** business connection IDs/rights، messageها و deletionهای business، channel post و edited post.

هر فیلد اغلب optional است؛ نوع پیام را با `text != null` تشخیص ندهید و parser را به انواع 10.0–10.3 hard-code ناقص نکنید. نوع‌های `Message`, `Chat`, `User`, `CallbackQuery`, `InlineQuery`, `Poll`, `ChatMemberUpdated`، file/media و payment را از مدل رسمی با version-aware deserialization بخوانید.

#### فهرست کامل نام متدهای رسمی مشاهده‌شده در Bot API 10.3

- **Bot/session و دریافت update:** `getMe`, `logOut`, `close`, `getUpdates`, `setWebhook`, `deleteWebhook`, `getWebhookInfo`.
- **ارسال محتوا و رسانه:** `sendMessage`, `sendPhoto`, `sendLivePhoto`, `sendAudio`, `sendDocument`, `sendVideo`, `sendAnimation`, `sendVoice`, `sendVideoNote`, `sendPaidMedia`, `sendMediaGroup`, `sendLocation`, `sendVenue`, `sendContact`, `sendPoll`, `sendChecklist`, `sendDice`, `sendMessageDraft`, `sendChatAction`, `setMessageReaction`, `sendRichMessage`, `sendRichMessageDraft`, `sendGift`.
- **بازارسال/کپی:** `forwardMessage`, `forwardMessages`, `copyMessage`, `copyMessages`.
- **ویرایش/حذف/پاسخ به سرویس پیام:** `editMessageText`, `editMessageCaption`, `editMessageMedia`, `editMessageLiveLocation`, `stopMessageLiveLocation`, `editMessageChecklist`, `editMessageReplyMarkup`, `stopPoll`, `editEphemeralMessageText`, `editEphemeralMessageMedia`, `editEphemeralMessageCaption`, `editEphemeralMessageReplyMarkup`, `approveSuggestedPost`, `declineSuggestedPost`, `deleteMessage`, `deleteMessages`, `deleteEphemeralMessage`, `deleteMessageReaction`, `deleteAllMessageReactions`.
- **فایل، پروفایل و دادهٔ کاربر:** `getUserProfilePhotos`, `getUserProfileAudios`, `setUserEmojiStatus`, `getFile`, `getUserPersonalChatMessages`.
- **مدیریت چت، اعضا و لینک دعوت:** `banChatMember`, `unbanChatMember`, `restrictChatMember`, `promoteChatMember`, `setChatAdministratorCustomTitle`, `setChatMemberTag`, `banChatSenderChat`, `unbanChatSenderChat`, `setChatPermissions`, `exportChatInviteLink`, `createChatInviteLink`, `editChatInviteLink`, `createChatSubscriptionInviteLink`, `editChatSubscriptionInviteLink`, `revokeChatInviteLink`, `approveChatJoinRequest`, `declineChatJoinRequest`, `answerChatJoinRequestQuery`, `sendChatJoinRequestWebApp`, `setChatPhoto`, `deleteChatPhoto`, `setChatTitle`, `setChatDescription`, `pinChatMessage`, `unpinChatMessage`, `unpinAllChatMessages`, `leaveChat`, `getChat`, `getChatAdministrators`, `getChatMemberCount`, `getChatMember`, `setChatStickerSet`, `deleteChatStickerSet`.
- **Forum topics:** `getForumTopicIconStickers`, `createForumTopic`, `editForumTopic`, `closeForumTopic`, `reopenForumTopic`, `deleteForumTopic`, `unpinAllForumTopicMessages`, `editGeneralForumTopic`, `closeGeneralForumTopic`, `reopenGeneralForumTopic`, `hideGeneralForumTopic`, `unhideGeneralForumTopic`, `unpinAllGeneralForumTopicMessages`.
- **Callback، Inline، Guest و Web App:** `answerCallbackQuery`, `answerGuestQuery`, `answerWebAppQuery`, `answerInlineQuery`.
- **تنظیم و مدیریت bot:** `getUserChatBoosts`, `getBusinessConnection`, `getManagedBotToken`, `replaceManagedBotToken`, `getManagedBotAccessSettings`, `setManagedBotAccessSettings`, `setMyCommands`, `deleteMyCommands`, `getMyCommands`, `setMyName`, `getMyName`, `setMyDescription`, `getMyDescription`, `setMyShortDescription`, `getMyShortDescription`, `setMyProfilePhoto`, `removeMyProfilePhoto`, `setChatMenuButton`, `getChatMenuButton`, `setMyDefaultAdministratorRights`, `getMyDefaultAdministratorRights`.
- **Business، هدایا، تأیید هویت و Story:** `getAvailableGifts`, `giftPremiumSubscription`, `verifyUser`, `verifyChat`, `removeUserVerification`, `removeChatVerification`, `readBusinessMessage`, `deleteBusinessMessages`, `setBusinessAccountName`, `setBusinessAccountUsername`, `setBusinessAccountBio`, `setBusinessAccountProfilePhoto`, `removeBusinessAccountProfilePhoto`, `setBusinessAccountGiftSettings`, `getBusinessAccountStarBalance`, `transferBusinessAccountStars`, `getBusinessAccountGifts`, `getUserGifts`, `getChatGifts`, `convertGiftToStars`, `upgradeGift`, `transferGift`, `postStory`, `repostStory`, `editStory`, `deleteStory`.
- **مدیریت Sticker:** `sendSticker`, `getStickerSet`, `getCustomEmojiStickers`, `uploadStickerFile`, `createNewStickerSet`, `addStickerToSet`, `setStickerPositionInSet`, `deleteStickerFromSet`, `replaceStickerInSet`, `setStickerEmojiList`, `setStickerKeywords`, `setStickerMaskPosition`, `setStickerSetTitle`, `setStickerSetThumbnail`, `setCustomEmojiStickerSetThumbnail`, `deleteStickerSet`.
- **Inline prepared messages/buttons:** `savePreparedInlineMessage`, `savePreparedKeyboardButton`.
- **پرداخت و Telegram Stars:** `sendInvoice`, `createInvoiceLink`, `answerShippingQuery`, `answerPreCheckoutQuery`, `getMyStarBalance`, `getStarTransactions`, `refundStarPayment`, `editUserStarSubscription`.
- **Telegram Passport:** `setPassportDataErrors`.
- **Games:** `sendGame`, `setGameScore`, `getGameHighScores`.

فهرست بالا از صفحهٔ رسمی جاری استخراج و در گروه‌های کاربردی مرتب شده است؛ امضا، پارامترهای اجباری/اختیاری، right، نتیجه و محدودیت‌ها را همچنان از لینک رسمی همان متد بخوانید. نام متد را در client/SDK به‌تنهایی نشانهٔ پشتیبانی endpoint یا behavior در نسخهٔ نصب‌شده ندانید.

### ۵.۲ Bale: خانوادهٔ پیام و متدهای رسمی

Schema رسمی Bale `Message` را با فیلدهای پایهٔ `message_id`, `from`, `date`, `chat`, `text`, `entities`, `caption` و subtypeهای `animation`, `audio`, `document`, `photo`, `sticker`, `video`, `voice`, `contact`, `location`, `invoice`, `successful_payment`, `web_app_data`, `reply_markup` توصیف می‌کند؛ به‌علاوه service fields مانند عضو جدید/ترک، edit و forward. `Chat.type` در اسناد فعلی `private`, `group`, `channel` است. `file_id` برای استفاده/دانلود است؛ `file_unique_id` برای دانلود/ارسال مجدد نیست.

#### متدهای رسمیِ دیده‌شده در مستند بازو

- **اتصال/update:** `getMe`, `getUpdates`, `setWebhook`, `deleteWebhook`, `getWebhookInfo`.
- **ارسال/رسانه:** `sendMessage`, `forwardMessage`, `copyMessage`, `sendPhoto`, `sendAudio`, `sendDocument`, `sendVideo`, `sendAnimation`, `sendVoice`, `sendMediaGroup`, `sendLocation`, `sendContact`, `sendChatAction`, `getFile`.
- **ویرایش/حذف:** `editMessageText`, `editMessageCaption`, `editMessageReplyMarkup`, `deleteMessage`.
- **تعامل/کلاینت:** `answerCallbackQuery`, `askReview` (بله‌محور و وابسته به نسخهٔ کلاینت).
- **مدیریت گروه/کانال:** `banChatMember`, `unbanChatMember`, `promoteChatMember`, `leaveChat`, `getChat`, `getChatAdministrators`, `getChatMembersCount`, `getChatMember`, `pinChatMessage`, `unPinChatMessage`, `unpinAllChatMessages`, `setChatTitle`, `setChatDescription`, `deleteChatPhoto`, `createChatInviteLink`, `revokeChatInviteLink`, `exportChatInviteLink`, `setChatPhoto`.
- **استیکر:** `uploadStickerFile`, `createNewStickerSet`, `addStickerToSet`, به‌علاوهٔ مدل‌های Sticker/StickerSet.
- **پرداخت کیف پول:** `sendInvoice`, `createInvoiceLink`, `answerPreCheckoutQuery`, `inquireTransaction`.

فهرست بالا اسامی متدهایی است که در صفحه‌های رسمی بازو/مینی‌اپ دیده شد؛ آن را برابر «همهٔ متدهای Telegram» یا «همهٔ متدهای SDK بله» تلقی نکنید. مستند رسمی بله تصریح می‌کند قابلیت پرداخت کارت‌به‌کارت قبلی حذف شده و روش رسمی پایدار در بازوها کیف‌پول بله است.

#### فایل‌ها

در مستند رسمی فعلی: `file_id` برای bot مشخص است؛ upload/download سقف‌های جدا دارد. در ارسال مجدد از file_id سقف ارسال مجدد ذکر نشده؛ URL import برای تصویر تا ۵ MB و سایر محتوا تا ۲۰ MB؛ multipart برای تصویر تا ۱۰ MB و انواع دیگر تا ۵۰ MB. `getFile` دانلود تا ۲۰ MB را اعلام می‌کند و لینک فایل حداقل یک ساعت معتبر است. این اعداد فقط snapshot سند جاری‌اند و ممکن است تغییر کنند. URL، MIME و روش upload را براساس نوع محتوا انتخاب کنید؛ `file_unique_id` را به‌جای `file_id` نفرستید.

#### پرداخت Bale

`sendInvoice` / `createInvoiceLink` کیف‌پول و مبلغ ریالی را می‌سازند؛ pre-checkout حداکثر طی ۱۰ ثانیه باید با `answerPreCheckoutQuery` پاسخ بگیرد. **PreCheckoutQuery به معنی پرداخت موفق نیست**؛ فقط update حاوی `SuccessfulPayment` موفقیت را تثبیت می‌کند. payload را با سفارش/مبلغ/ارز سرور تطبیق دهید و callback کلاینت را مدرک پرداخت ندانید. `inquireTransaction` برای استعلام تراکنش در مستند آمده است.

### ۵.۳ Rubika: پیام، keypad و متدها

فهرست کامل‌تر، فیلدهای schema، limitation و تعارض نام‌ها در [کاتالوگ Rubika](rubika-bot-api-catalog-fa.md) است. هستهٔ مستندشده:

- **Chat/identity:** `getMe`, `getChat`, `getUpdates`.
- **Message:** `sendMessage`, `editMessageText`, `deleteMessage`, `forwardMessage`, `editMessageKeypad`.
- **Media:** `requestSendFile` → آپلود multipart به `upload_url` → `file_id`; سپس `sendFile`; `getFile` برای `download_url`.
- **بقیهٔ محتوا:** `sendPoll`, `sendLocation`, `sendContact`.
- **مدیریت:** `banChatMember`, `unbanChatMember`, `setCommands`, `updateBotEndpoints`.
- **تکمیل رویداد:** Chat Keypad و Inline Keypad مسیر/event جدا دارند؛ Inline click را به شکل message عادی فرض نکنید.
- **پرداخت:** در API عمومی رسمی بررسی‌شده، invoice/payment native یا تأیید membership معادل `getChatMember` مستند نشده است. پرداخت جعلی یا نتیجه‌گیری از کلیک دکمه ممنوع؛ هر محصول مالی باید از درگاه واقعی سایت و تأیید سروری استفاده کند.

---

## ۶. Routing، handler، filter، keyboard و FSM

### ۶.۱ الگوی Router

نمونهٔ مناسب (شبه‌کد؛ اسم‌ها illustrative و platform-neutral هستند):

```text
transport.receive(raw)
  -> validate_envelope(platform, raw)
  -> persist_inbox(platform, bot_id, provider_update_key, raw)
  -> normalize(raw)   // raw payload همراه event حفظ شود
  -> route(update_type, command, callback, media, user, chat, state)
  -> authorize + handler
  -> domain transaction + outbox
  -> platform-specific acknowledgement/checkpoint
```

- Update type را قبل از بررسی `message.text` تشخیص دهید؛ ممکن است callback، payment، edit، membership یا media باشد.
- command را با `entities`/offset معتبر پردازش کنید، نه صرفاً regex روی متن که `/start@bot`، locale یا mention را خراب کند.
- routeهای broad (`any message`) را بعد از routeهای تخصصی یا با اولویت روشن بگذارید؛ consume/stop semantics را مستند کنید.
- filter باید pure و بدون side-effect باشد؛ authorization در handler/service دوباره enforce شود.
- callback data یک command قابل اعتماد نیست: action ID مبهم + lookup سمت سرور یا HMAC کوتاه، scope کاربر/چت، nonce، expiry و یک‌بارمصرفی را بررسی کنید.

### ۶.۲ FSM/state

کلید توصیه‌شده:

```text
(platform, bot_id, chat_id, user_id, thread_id?, conversation_scope)
```

- state و data را atomic و versionدار ذخیره کنید؛ TTL، cancel/reset، expiry، migration و lock/lease داشته باشید.
- در گروه‌ها state کاربر و state کل گفتگو را قاطی نکنید؛ پیام thread/topic را در صورت وجود به کلید اضافه کنید.
- memory storage فقط برای demo یا worker منفرد بدون دوام است. Redis/DB یا ذخیره‌ساز پایدار را با partition مناسب انتخاب کنید.
- هر transition باید در برابر update تکراری مقاوم باشد؛ پرداخت/سفارش را با transaction domain و idempotency key کنترل کنید.

### ۶.۳ Keyboardها و callback

- Telegram reply keyboard پیام متنی کاربر می‌سازد؛ inline keyboard callback یا URL/WebApp و انواع دیگر دارد. `callback_data` اندازهٔ محدود دارد (۱–۶۴ بایت). هر callback را سریع با `answerCallbackQuery` acknowledge کنید؛ پاسخ خالی هم spinner را می‌بندد.
- Bale reply/inline markup و دکمه‌های callback/web_app/copy_text دارد؛ پس از کلیک، `answerCallbackQuery` اهمیت دارد و کلاینت قدیمی می‌تواند به fallback نیاز داشته باشد.
- Rubika: `chat_keypad` با `chat_keypad_type` (مثل New/Remove) و `inline_keypad` جداست. subtype Buttonهای رسمی بسیار متنوع‌اند، اما وجود enum به معنی پشتیبانی قطعی همهٔ subtypeها در تمام clientها نیست. کلیک Inline envelope جداگانه دارد.
- UI دکمه‌ها را با capability ماتریس بسازید؛ اگر callbackها در پلتفرم مقصد نیست، fallback به متن/URL و state سمت سرور بدهید.

### ۶.۴ متن، metadata و sanitize

- Telegram و Bale و Rubika syntax/metadata یکسان ندارند؛ escape بر مبنای target encoder و متن/HTML/Markdown مناسب انجام شود.
- offsets ممکن است UTF‑16 باشند (در Telegram و Bale به‌صراحت در schemaهای بررسی‌شده)، نه تعداد code point یا byte. Emoji و حروف مرکب را در تست‌های فارسی/RTL بگنجانید.
- HTML را allowlist و attributeها را sanitize کنید؛ URL را با scheme allowlist بررسی کنید. ورودی کاربر را مستقیم داخل Markdown/HTML قرار ندهید.
- RTL را در UI/data encoding مدیریت کنید؛ افزودن RLM/LRM کورکورانه ممکن است callback/entity position و signature را خراب کند.

---

## ۷. عملیات قابل اتکا، خطا و امنیت

### ۷.۱ Inbox و checkpoint

برای هر bot یک active poller یا webhook deployment داشته باشید و lease/leader election بگذارید. Inbox پایدار را با unique key مانند `(platform, bot_id, update_id/cursor)` deduplicate کنید. update را پیش از checkpoint/offset جلو بردن پایدار کنید. اگر crash پس از تحویل به worker ولی پیش از commit رخ دهد، handler باید idempotent باشد.

Webhook: TLS terminate، secret/path تحقق‌یافته، محدودیت body، schema validation، redaction، replay/dedup، queue durable و پاسخ سریع 2xx. اگر update پردازش‌ناپذیر است، dead-letter + alert؛ پاسخ 200 بی‌قید و رهاکردن رویداد نه.

Polling: long timeout با HTTP read timeout کمی بزرگ‌تر، backoff نمایی همراه jitter برای outage، محدودیت batch/concurrency، checkpoint بعد از commit، shutdown کنترل‌شده. short polling loop پرسرعت تولید نکنید.

### ۷.۲ Retry و پیام تکراری

- `429`/`retry_after` را رعایت کنید؛ در صورت نبود `retry_after` backoff+jitter و سقف retry.
- خطای 4xx داده/permission/config است؛ retry خودکار نامحدود نکنید. 5xx/timeout retry را با احتیاط انجام دهید.
- Timeout هنگام `sendMessage` مبهم است: ممکن است provider پیام را فرستاده ولی پاسخ به برنامه نرسیده باشد. ارسال مجدد می‌تواند duplicate کند. از outbox، idempotency domain/correlation و سیاست بررسی استفاده کنید.
- ترتیب per-chat را حفظ کنید یا actionها را sequence کنید؛ webhook parallel می‌تواند در سطح handler ترتیب مورد نظر برنامه را به هم بزند.

### ۷.۳ Token، callback و Mini App

- Tokenها در secret manager/environment امن؛ دسترسی فایل/env کمینه، rotation، لاگ‌زدایی و عدم قرارگیری در URL گزارش/analytics.
- webhook secret Telegram را constant-time مقایسه کنید؛ در Bale/Rubika که معادل رسمی مستندشده در منابع بررسی‌شده روشن نیست، از secret capability و کنترل شبکه به‌عنوان دفاع تکمیلی استفاده کنید و اصالت provider را بیش از شواهد ادعا نکنید.
- callback data را tamper-resistant، کوتاه، محدود به user/chat/action/order، تاریخ‌دار و یک‌بارمصرف کنید. callback هرگز اثبات پرداخت نیست.
- Telegram Mini App `initData` باید در backend طبق روش رسمی cryptographic verify و timestamp/expiry کنترل شود؛ `initDataUnsafe` یا query پارامترهای مرورگر را اعتماد نکنید. تغییر origin protection رسمی ۲۰۲۶ را هم در release notes رعایت کنید.
- Bale اسناد صریحاً هشدار می‌دهد `WebAppData.data` می‌تواند جعل شود؛ فقط دادهٔ تأییدشده سمت server را اثرگذار کنید. اعتبارسنجی Mini App روبیکا را از مستند خودش بگیرید.

### ۷.۴ Payment/fulfilment

`invoice`/`checkout` → ثبت intent و immutable amount/currency → بررسی server-side موجودی/قیمت/مالک سفارش → pre-checkout reply در deadline → دریافت رویداد نهایی موفق از provider → verify/reconcile transaction → fulfill idempotently → ثبت ledger/refund. هیچ client callback یا متن پیام به‌تنهایی مدرک پرداخت نیست. واحد پول را در column مجزا (integer minor units یا واحد صریح provider) ذخیره کنید و تبدیل ریال/تومان/Stars را با precision و test روشن انجام دهید.

---

## ۸. ممیزی مخازن درخواستی

### ۸.۱ Rubika

| مخزن | آنچه در README/ساختار ادعا یا دیده شد | ارزیابی/احتیاط |
|---|---|---|
| [StoryKode/Krubot](https://github.com/StoryKode/Krubot) | README فعلی خود را Laravel/PHP با یک codebase برای Telegram 10.3، Rubika، Bale، WebApp و Websites معرفی می‌کند؛ route/action/attribute، plugin و multi-bot؛ ریشه دارای `src`, `routes`, `config`, `tests`. حدود ۶۵ commit و آخرین تغییر مشاهده‌شده ۲۹ سپتامبر ۲۰۲۶. | `Docs.md` خودش می‌گوید مستند نسخهٔ v0.7 ALPHA نهایی نیست/ممکن است تکمیل نشود؛ churn و نام‌گذاری/معماری بسیار پرتحرک. برای ایدهٔ adapter/router مفید؛ ادعای multi-platform/production-ready را بدون test matrix واقعی و بررسی کد release قطعی نکنید. |
| [EhsanGhorbany/Rubika](https://github.com/EhsanGhorbany/Rubika) (Botkaplus) | PHP package؛ `BotClient`, `Filters`, `Message`, `Keypad`, `Metadata`; README نمونهٔ webhook و `runPolling`, markup و formatting را نشان می‌دهد. `src` پوشه‌های Filters/Keypad/Message/Metadata دارد؛ README PHP 7.4+ می‌گوید؛ آخرین تغییر مشاهده‌شده دسامبر ۲۰۲۵. | Wrapper کوچک با لایهٔ OOP و filters؛ فهرست ریشهٔ بررسی‌شده تست directory نشان نمی‌داد. وجود README sample اثبات نمی‌کند polling offset/retry/webhook security یا پوشش همهٔ متدهای رسمی درست باشد. |
| [Daniyel-Vanguard/Rubika-Bot](https://github.com/Daniyel-Vanguard/Rubika-Bot) | PHP classes `Bot`, `Message`; `Filters`, `Keyboard`, `Metadata`, `Types`; نمونهٔ fluent send, spam handling, file upload و message filters. حدود ۸۸ commit؛ تغییرات نوامبر ۲۰۲۵. | API surface و filters قابل مطالعه‌اند، اما README marketing («advanced», «automatic spam») را با رفتار کد و تست واقعی جدا کنید. در ریشهٔ مشاهده‌شده tests folder صریحاً دیده نشد؛ `dev-main` نصب را به commit متغیر متصل می‌کند. |
| [sanf-dev/Rubot](https://github.com/sanf-dev/Rubot) | PHP 8.1+، نسخهٔ README 2.1.0 (repo/root commit 2.1.1 در نوامبر ۲۰۲۵)، Guzzle، polling/webhook، `Message` helpers، filters، progress upload/download، ENV، timeout، retry count و debugger. وجود `src`, `client`, `tests`. | از نمونه‌ها از نظر لایه‌بندی و error handling ایده بگیرید؛ retry count به‌تنهایی backoff یا idempotency را ثابت نمی‌کند. اسناد `offset_id`/`seconds` wrapper باید با کد و API رسمی روبیکا cross-check شوند. اجرا/تست مجدد نشده است. |
| [imhamiddev/telegram-to-rubika](https://github.com/imhamiddev/telegram-to-rubika) | برنامهٔ Python انتقال فایل، نه SDK عمومی؛ README pipeline جمع‌آوری batch → دانلود → حالت معمولی/ZIP/ZIP رمزدار → upload/send Rubika و progress را شرح می‌دهد؛ claims شامل لینک‌های yt-dlp، AES‑256، resume و split فایل است؛ تغییر تا ۱۹ اکتبر ۲۰۲۶. | مخزن انتقال بین دو API را برای نمونهٔ queue/pipeline مطالعه کنید؛ ادعای resume پس از restart/AES/قطعه‌بندی 95MB از README به‌تنهایی تأیید نشده. بررسی امنیتی لازم: مدیریت کلید و salt/nonce، حفظ integrity/authentication، path traversal، محدودیت دانلود URL/SSRF، quota، temp cleanup، لغو و reconciliation دو پلتفرم. |
| [mojtabaqri/Rubika-SDK](https://github.com/mojtabaqri/Rubika-SDK) | نام/description صفحه ادعای SDK است؛ اما README خام بررسی‌شده پروژهٔ «Vamban Loan Marketplace» با bot، KYC، SQLite، admin, ads, manual payment را معرفی می‌کند. tree شامل `admin`, `api`, `app`, `classes`, `tests`, `uploads/kyc`, `vendor` و برنامهٔ وب است. | صرف عنوان repository آن را SDK نمی‌کند. بر اساس README و tree فعلی، به‌عنوان wrapper مستقل Rubika در نمونه‌های SDK استفاده نشود تا package/API client و قرارداد قابل reuse از application جدا و اثبات شود. |

### ۸.۲ Bale

| مخزن | آنچه دیده شد | ارزیابی/احتیاط |
|---|---|---|
| [Daniyel-Vanguard/BaleBot](https://github.com/Daniyel-Vanguard/BaleBot) | README می‌گوید PHP 7.4، 60+ method، 100% coverage، webhook/polling، typed models و tests. tree ریشه فقط `BaleBot.php`, `Models.php`, `Example`, README و composer را نشان می‌داد؛ tests directory دیده نشد. | فایل `BaleBot.php` خام، `CURLOPT_SSL_VERIFYPEER=false` را تنظیم می‌کند؛ این TLS peer validation را خاموش می‌کند و برای production blocker امنیتی است. Models مشاهده‌شده فقط User/Chat/Message/Update/Callback/PreCheckout/File/Payment/Transaction اولیه را پوشش می‌دهند. «100% coverage» و test claim با ساختار مشاهده‌شده اثبات نمی‌شوند. پیش از استفاده: TLS را اصلاح، multipart و status/error handling را بازبینی و test suite بسازید. |
| [balecore](https://github.com/balecore) | README سایت ادعا می‌کند BaleCore Python async، event/plugin، YAML، webhook/polling و نسخه `1.0.0-alpha`; نصب به `balecore/balecore` ارجاع دارد. | خود مخزن package `balecore/balecore` هنگام بررسی فقط یک commit (۲۶ مارس ۲۰۲۵)، یک `.gitignore` و بدون سورس/تست/Release قابل مشاهده داشت؛ مستندات `balecore.github.io` عمدتاً README/صفحهٔ ایستا است. ادعای قابلیت package در README اثبات runtime آن نیست؛ وضعیت را «نامشخص/کد قابل ممیزی ناکافی» ثبت کنید. |
| [AbolfazlZarei-dev/ParsBale-bot-go](https://github.com/AbolfazlZarei-dev/ParsBale-bot-go) | Go files جدا برای `client`, `polling`, `network`, `payment`, `safir`, `miniapp`, `models`; README ادعای dispatcher/command/text/callback/state handlers، FSM/middleware، polling/webhook، payment/Safir/Mini App دارد. آخرین تغییر مشاهده‌شده ۱۱ اوت ۲۰۲۶؛ ۳۳ commits. | **مشاهدهٔ کد:** `polling.go` offset را با `u.UpdateID+1` جلو می‌برد و update را روی channel می‌فرستد؛ state اولیه `NewMemoryState`; retry روی error، log + sleep ثابت ۳ ثانیه دارد و sleep/request در قطعهٔ بررسی‌شده context-aware نیست. اگر consumer پس از دریافت update durable commit نکرده و poll بعدی offset جدید را استفاده کند، crash می‌تواند update را از دست بدهد؛ برای production durable checkpoint + backoff قابل لغو + per-chat backpressure لازم است. |
| [ErfanVahabpour/Bale-Bot-SDK](https://github.com/ErfanVahabpour/Bale-Bot-SDK) | PHP SDK با Guzzle و ساختار `src/tests`, integration Laravel, bots manager, command/event system. README/commitها تغییرات API رسمی Bale را نشان می‌دهند: `deleteWebhook`, `sendChatAction`, caption/markup edit، `answerCallbackQuery`, `askReview`, `createInvoiceLink`, `answerPreCheckoutQuery`, `inquireTransaction` و object models. ساختار tests واقعی دارد؛ commit ادعای 53 تست/145 assertion می‌کند. | از میان نمونه‌های Bale بررسی‌شده، شواهد ساختاری/tests بهتر است؛ ولی test claim محلی اجرا نشده و زنده بودن API تضمین نیست. `composer.json` فعلی PHP `^8.2` می‌گوید، در حالی که متن commit از `^8.1` یاد می‌کند؛ Composer را مبنای نیازمندی نصب قرار دهید. SDK unofficial است؛ signature/fieldها را با `docs.bale.ai` تطبیق دهید. |

### ۸.۳ Telegram: نمونه‌های framework و wrapper

| مخزن | الگوی معماری/وضعیت مشاهده‌شده | نکتهٔ نگهداری |
|---|---|---|
| [python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot) | Python asynchronous library؛ `telegram.ext` و high-level Application/handlers؛ polling و webhook؛ بیش از ۳۲۰۰ commits و تغییر ۱۹ اکتبر ۲۰۲۶. README فعلی می‌گوید Bot API 10.0 و Python 3.11+. | Snapshot branch جدید فعال است، اما badge/API-support در README عقب‌تر از API رسمی 10.3 است؛ feature coverage را از schema/tests/release-notes همان version بخوانید، نه فقط از activity یا README. |
| [aiogram](https://github.com/aiogram/aiogram) | async Python/asyncio؛ README `dev-3.x` صریحاً Telegram Bot API 10.3، codegen، routers, FSM, magic filters، incoming/API middleware و webhook reply را می‌گوید؛ آخرین تغییر مشاهده‌شده ۱۸ اکتبر ۲۰۲۶. | الگوی router + filter + FSM + middleware خوب برای یادگیری است. `dev-3.x` شاخهٔ توسعه است؛ برای محصول release/tag و migration notes را pin کنید. |
| [grammY](https://github.com/grammyjs/grammY) | TypeScript/JavaScript روی Node/Deno؛ API 10.3 در README، context-per-update، `bot.on(...)`, long polling quickstart، pluginها و webhook integration؛ fixهای webhook در اکتبر ۲۰۲۶. | نمونهٔ شفاف middleware/context و افزونه‌ها. Persistence/FSM تجاری را از plugin/storage جدا ارزیابی کنید؛ از نمونهٔ echo نمی‌توان durability نتیجه گرفت. |
| [Telegraf](https://github.com/telegraf/telegraf) | Node.js/TypeScript؛ `Context`, middleware/composer, command/text handlers، webhook و `launch`, graceful stop؛ سورس و tests در شاخه v4 با activity سپتامبر ۲۰۲۶. | README شاخه v4 هنوز badge مربوط به Bot API 7.1 را نشان می‌دهد، در حالی که سورس تغییر می‌کند؛ stale API badge نمونهٔ خوبی است که «آخرین commit» با «پوشش جدیدترین API» یکی نیست. |
| [go-telegram-bot-api](https://github.com/go-telegram-bot-api/telegram-bot-api) | Go binding کم‌سطح؛ README عمداً wrapper-only معرفی می‌کند، نمونهٔ `GetUpdatesChan` و webhook listener دارد؛ آخرین commit مشاهده‌شده اکتبر ۲۰۲۲. | برای transport/types ساده و کنترل اپلیکیشن مناسب مطالعه است؛ gap نسخه نسبت به Bot API 10.3 را پیش از انتخاب برای featureهای جدید بسنجید. channel نمونه به‌تنهایی durable queue نیست. |
| [irazasyed/telegram-bot-sdk](https://github.com/irazasyed/telegram-bot-sdk) | PHP SDK/ Laravel integration، شاخه 3.x، `src` و `tests`; README می‌گوید فقط آخرین release پشتیبانی می‌شود و 4.x در مخزن جدا در حال توسعه است؛ آخرین commit مشاهده‌شده ژوئیه ۲۰۲۶. | version/branch و documentation website را دقیق pin کنید؛ README عمومی «current» بودن را برای هر API تازه ثابت نمی‌کند. |
| [AstrBot](https://github.com/AstrBotDevs/AstrBot) | پلتفرم Python/Python 3.12+ با adapters برای چند IM، plugins, LLM/Agent, WebUI؛ ریشه دارای `astrbot`, `dashboard`, `docs`, tests/build infrastructure؛ بیش از 5,000 commits و به‌روزرسانی ۲۶ اکتبر ۲۰۲۶. | برای مطالعهٔ مرز adapter/plugin و platform composition نمونهٔ بزرگ و فعال است؛ هدف اصلی‌اش AI agent platform است، نه مرجع هنجاری Bot API. منطق Telegram را از مستند رسمی جدا نگه دارید. |

---

## ۹. الگوهای قابل اقتباس و footgunها

### الگوهای مثبت

- **Adapter/capability:** یک interface نازک برای send-text/send-media/ack-update؛ featureهای خاص به adapter با result `supported/unsupported/unknown` واگذار شوند.
- **Router + handlerهای کوچک:** هر handler یک event و intent محدود بگیرد؛ business logic را در HTTP callback دفن نکنید.
- **Pure filters و middleware قابل مشاهده:** filterها فقط match؛ middleware برای auth/locale/trace/rate-limit، با order روشن.
- **Schema/code generation:** از مدل رسمی نسخه‌دار client تولید کنید و به‌روزرسانی enumها/fields را در CI با diff بررسی کنید.
- **Durable inbox/outbox:** اثرات خارجی و database transaction با idempotency، dead-letter و replay امن.
- **Fixtureها:** نمونه‌های واقعیِ پاک‌سازی‌شده برای هر platform/update type، payload نامعتبر، field ناشناخته، emoji/UTF‑16، فایل، callback و payment.

### Footgunها

- فرض `update_id+1` در روبیکا یا `offset_id` عددی‌سازی.
- خواندن فقط `message.text` و حذف silent handling برای payment/callback/edit/reaction/member.
- `GET`-loop کوتاه/بی‌وقفه، چند poller همزمان، offset در حافظه بدون persistence.
- پیش‌بردن cursor قبل از ثبت durable یا تحویل مسئولانه به consumer.
- retry دوبارهٔ send بعد از timeout، بدون بررسی احتمال ارسال اولیه.
- نگهداری state فقط در RAM و سپس اجرای چند worker؛ conversationهای کاربر به workerهای مختلف می‌روند.
- trust کردن callback payload، webhook body، Mini App query، screenshot یا receipt متنی.
- استفاده از file unique ID برای دانلود/ارسال؛ تعمیم محدودیت‌های فایل یک پلتفرم به دیگری.
- خاموش کردن TLS peer verification، token در log، یا نمایش URL کامل API.
- به‌کارگیری متدهای Telegram روی Base URL Bale/Rubika چون نام‌ها مشابه‌اند؛ یا تکیه بر SDK که متد را دارد ولی provider آن را مستند/پشتیبانی نکرده.
- استفاده از `dev-main`, `main` یا شاخهٔ alpha بدون lockfile/version pin و audit dependency.
- «تست‌ها موجود است» را با اجرای تست، یا pass شدن Unit test را با live compatibility یکی دانستن.

---

## ۱۰. چک‌لیست عملی پیش از انتشار

### API/مدل
- [ ] جدول متد/نوع از نسخهٔ رسمی هر پلتفرم ساخته و تفاوت‌ها مستند شده‌اند.
- [ ] JSON unknown fields و null/optional fields بدون crash تحمل می‌شوند.
- [ ] update typeهای فعال با `allowed_updates`/webhook subscription همخوان‌اند.
- [ ] قابلیت متکی به نسخهٔ کلاینت Bale/Mini App fallback دارد.

### تحویل و داده
- [ ] polling یا webhook فعال؛ نه هر دو برای یک bot؛ single-owner lease وجود دارد.
- [ ] update پیش از checkpoint پایدار شده؛ dedup key و retry policy تست شده‌اند.
- [ ] state پایدار/expiry/lock و per-chat concurrency تعریف شده‌اند.
- [ ] outbox پیام، timeout مبهم، duplicate و dead-letter سناریو دارد.

### امنیت
- [ ] tokenها secret store/env؛ redaction و rotation فعال‌اند.
- [ ] webhook auth/path، body size, schema, replay/dedup بررسی شده است.
- [ ] HTML/Markdown و URLها sanitize/allowlist می‌شوند.
- [ ] callback و Mini App data در backend authorize/validate می‌شود.
- [ ] TLS peer validation روشن است؛ فایل‌های آپلودی نام‌گذاری/نوع/اندازه/path کنترل می‌شوند.

### پرداخت و فایل
- [ ] مبلغ/واحد ارز از server-side سفارش؛ هر transaction با شناسهٔ provider reconcile می‌شود.
- [ ] موفقیت فقط با event/استعلام معتبر سمت سرور نهایی می‌شود.
- [ ] pre-checkout در deadline پاسخ می‌گیرد؛ fulfillment idempotent است.
- [ ] file size، URL import، multipart، MIME، expiry link و file ID scope برای هر platform جدا تست شده‌اند.

### کیفیت و عملیات
- [ ] adapter conformance tests و fixtureهای واقعی برای هر platform وجود دارد.
- [ ] تست sandbox/staging جدا از production token انجام شده است.
- [ ] monitoring برای webhook errors, pending updates, 429, retries, queue age و handler latency وجود دارد.
- [ ] release و dependency pin شده؛ API version drift alert دارد.

---

## ۱۱. منابع بیرونی منتخب

- [Telegram Bot API](https://core.telegram.org/bots/api) — قرارداد method/type، recent changes و دریافت update.
- [Telegram Bot API changelog](https://core.telegram.org/bots/api-changelog) — نسخه‌ها و تغییر signatures.
- [Telegram Bots FAQ](https://core.telegram.org/bots/faq) — rate limits، long polling/webhook و عملیات.
- [Bale Bot API docs](https://docs.bale.ai/) — قرارداد بازوی عمومی، update، متدها، فایل و پرداخت.
- [Bale Mini Apps](https://docs.bale.ai/miniapp) — lifecycle و invoice Mini App.
- [Bale Safir](https://docs.bale.ai/safir) — مسیر تجاری/پیامک/ارسال انبوه مستقل از Bot API عمومی.
- [Rubika Bot API](https://rubika.ir/botapi) — منبع رسمی و کاتالوگ جداگانهٔ داخل پروژه.
- [GitHub Telegram topic](https://github.com/topics/telegram) — نمونه‌برداری اکتشافی، نه فهرست کامل ربات‌های production.

**حد نهایی اطمینان:** قراردادهای رسمی که صریحاً در صفحات لینک‌شده دیده شدند، از ادعاهای README قوی‌ترند؛ بررسی static کد از README دقیق‌تر است ولی اجرای تست و integration live نیست. برای هر endpoint/feature تازه یا غیرمستند، قبل از ادعای پشتیبانی «قطعی»، fixture رسمی و آزمون staging تهیه شود.
