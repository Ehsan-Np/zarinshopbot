# ممیزی طراحی پنل تنظیمات چندپلتفرمی

**تاریخ بررسی:** ۲۸ اکتبر ۲۰۲۶  
**هدف:** تنظیمات افزونه بر مبنای قابلیت‌های واقعاً پیاده‌شده در کد و مستند رسمی هر پلتفرم گروه‌بندی شوند؛ نام و وضعیت تنظیم، محل ذخیره، نیاز WooCommerce و محدودیت‌های رسمی روشن باشند. این سند نقشهٔ پنل است، نه ادعای تست زنده.

## اصول طراحی

1. **تنظیمات مستقل در سطح پلتفرم:** توکن، وضعیت فعال/غیرفعال، مقصد انتشار، عنوان پست، شناسهٔ مدیر، اعلان‌های همان کانال و روش اتصال/وب‌هوک در بخش همان پلتفرم می‌مانند. تنظیمی که در یک API وجود ندارد، در UI به‌صورت گزینهٔ فعال جعلی نمایش داده نمی‌شود.
2. **تنظیمات مشترک فروشگاه:** موجودی، کاتالوگ، سبد، محصولات متغیر، قوانین ارسال/مالیات، کوپن و منطق سفارش از WooCommerce می‌آیند؛ گزینه‌های مشترک UI برای این رفتارها عمداً زیر بخش تنظیمات فروشگاه می‌مانند.
3. **تفکیک «پیکربندی» از «آزمون اتصال»:** داشتن توکن در option به معنای دسترسی واقعی API یا ثبت وب‌هوک نیست. فقط نتیجهٔ دکمهٔ صریح «آزمایش اتصال» یا ثبت وب‌هوک، همان نتیجهٔ مشخص را گزارش می‌کند.
4. **قابلیت مستندنشده:** اگر API رسمی برای یک عملیات لازم (مانند پرداخت بومی یا استعلام عضویت روبیکا) در منابع عمومی بررسی‌شده وجود ندارد، پنل محدودیت و جایگزین موجود را توضیح می‌دهد؛ نتیجهٔ ساختگی/حدسی قابل تنظیم نیست.
5. **سازگاری داده:** option nameها و کلیدهای legacy تغییر نمی‌کنند. مهاجرت یا rename تنظیمات بدون migration idempotent و آزمون داده‌های قبلی انجام نمی‌شود. دو مقدار قدیمی `referral_reward_text` و `telegram_exclusive_coupon` که runtime فعلی مصرف نمی‌کند از UI حذف شده‌اند و به‌شکل امن در ذخیره‌سازی حفظ می‌شوند؛ آن‌ها قابلیت فعال نیستند.
6. **namespace آدرس پنل:** slug صفحهٔ تنظیمات در URL مدیریتی `zarincode_zarinshopbot_setting` است تا با محصولات دیگر مجموعه تداخل نکند؛ option ذخیره‌سازی وردپرس عمداً `zarincode_settings` باقی می‌ماند. لینک‌های قدیمی صفحه به slug جدید redirect می‌شوند و داده‌های ذخیره‌شده rename نمی‌شوند.

## نقشهٔ گروه‌های پنل و محل فعلی

| گروه | محدوده | گزینه‌ها/منبع اصلی | پلتفرم |
|---|---|---|---|
| اتصال و امنیت Telegram | توکن، فعال‌سازی، نام کاربری، وب‌هوک/secret، محدودیت نرخ، حالت آزمایش، SSL | `zarincode_settings`، فیلدهای `token`, `telegram_enabled`, `username`, `webhook_secret_token`, `security_rate_limit_enable` | فقط Telegram |
| قابلیت‌های Telegram | اتصال Mini App، اعلان‌های Telegram، proxy و timeout/retry، provider invoice/Stars، Rich Messages، rating و ناوبری کم‌حجم | `zarincode_settings`؛ توکن پرداخت رمزگذاری‌شده در `telegram_provider_token_enc` | همهٔ این موارد در تب واحد Telegram؛ نه در تب‌های جداگانه |
| اتصال و کنترل Bale | توکن/نام کاربری، enable، تست `getMe`، وب‌هوک و وضعیت نتیجه | `zarinshopbot_channels` با secretهای رمزگذاری‌شده و status غیرمحرمانه | فقط Bale |
| قابلیت‌های Bale | Mini App، کیف‌پول، Provider Token، ضریب ارز فروشگاه به IRR، اعلان‌های سفارش، مقصد/عنوان انتشار | `bale_miniapp_enabled`, `bale_wallet_enabled`, `bale_provider_token`, `bale_irr_per_store_unit`, `bale_notify_*`, `bale_post_*` | فقط Bale |
| اتصال و قابلیت‌های Rubika | توکن، نام کاربری، enable، تست `getMe`، دو webhook endpoint رسمی، status، دستورهای API رسمی | `rubika_*` در `zarinshopbot_channels` | فقط Rubika |
| محدودیت‌های Rubika | checkout با درگاه WooCommerce؛ توضیح عدم ارائهٔ پرداخت بومی/mini-app در مسیر فعلی؛ بدون عضویت‌سنجی جعلی | متن راهنما/مرز پشتیبانی | فقط Rubika |
| کاتالوگ و جست‌وجو | نمایش محصول، تصویر، دسته‌بندی، SKU، موجودی، ترتیب و فیلتر | تنظیمات مشترک `zarincode_settings` | داده از WooCommerce؛ نمایش در کانال‌های فعال |
| سبد و checkout | فیلدهای سفارش، کوپن، shipping، downloads، پرداخت | WooCommerce cart/order و تنظیمات مشترک افزونه | سبد مختلط shipping لازم دارد؛ دیجیتال فقط طبق پروفایل checkout |
| دریافت و اعلان سفارش | اعلان‌های Telegram در تب آن؛ Bale/Rubika هرکدام سوئیچ‌های مستقل در تب کانال خود | `notify_*` تلگرام و `bale_notify_*` / `rubika_notify_*` | optionهای هر کانال جدا؛ اعلان‌های webhook API زنده آزموده نشده‌اند |
| پرداخت کارت‌به‌کارت | حساب‌های مقصد، روش پرداخت WooCommerce، دریافت امن رسید و تصمیم مدیر | option مستقل درگاه `woocommerce_zarinshopbot_card_transfer_settings`؛ با نگاشت/مهاجرت legacy | روش مشترک WooCommerce، پیام‌های تأیید هر پلتفرم مستقل |
| عضویت اجباری | مقصدها و پیوندهای Telegram/Bale؛ وضعیت فعال و رفتار مدیر | `membership_*` در `zarincode_settings` | فقط APIهایی که lookup عضو قابل اتکا دارند |
| بازاریابی/پشتیبان‌گیری | ارجاع و کمپین مشترک؛ export/import بدون credential | تنظیمات/handlerهای موجود افزونه | امتیازدهی مختص Telegram از این گروه خارج و در صفحهٔ Telegram قرار گرفت؛ گزینهٔ coupon در WooCommerce سراسری است |
| گزارش و تشخیص | فعال‌سازی گزارش، سطح رخداد، نگهداری و خروجی پاک‌سازی‌شده | تنظیمات مشترک `zarincode_settings`؛ لاگ‌های ساخت‌یافتهٔ پلتفرم‌دار | در تب مستقل مشترک «گزارش‌ها و تشخیص»، نه داخل پروکسی Telegram |
| فرمان‌ها و منو | فرمان مشترک در منطق فروشگاه؛ گزینهٔ ثبت منو فقط برای APIهای پشتیبانی‌شده | Telegram `setMyCommands` و Rubika `setCommands`؛ Bale ثبت خودکار ندارد | روش ثبت/نمایش منو در UI شفاف و platform-specific توصیف می‌شود |

## قرارداد ذخیره‌سازی کانال Bale/Rubika

- هر دو فرم در `includes/class-zarinshopbot-channels.php` از Settings API وردپرس استفاده می‌کنند: گروه `zarinshopbot_channels_group`، option `zarinshopbot_channels` و callback `Channels::sanitize_options`؛ هر فرم nonce گروه را با `settings_fields()` می‌فرستد و فقط به `options.php` POST می‌کند.
- شناسهٔ فرم و `form=` دکمهٔ sticky save مشخصاً برای همان پلتفرم ساخته می‌شود. بنابراین دکمهٔ Bale فرم Rubika را submit نمی‌کند و دکمهٔ Rubika نیز فرم Bale را. sanitize از مقدار قبلی شروع می‌کند تا فیلدهای پنهان، secretهای خالی و تنظیمات پلتفرم دیگر پاک نشوند.
- ظاهر و markup نوار ذخیرهٔ هر دو کانال اکنون از همان partial سراسری `panel/partials/settings-save-bar.php` ساخته می‌شود که پنل اصلی استفاده می‌کند؛ تفاوت فقط مقصد فرم و متن توضیح scope است. تنظیمات مشترک WooCommerce همچنان با فرم اصلی ذخیره می‌شوند.
- آزمون static برای registration، nonce، فرم/دکمهٔ جدا، partial مشترک و حفظ مقادیر کانال مقابل افزوده شده است. آزمون اجرایی WordPress Settings API در این محیط موجود نیست.

## ماتریس قابلیت‌های قابل نمایش در UI

| قابلیت | Telegram | Bale | Rubika |
|---|---|---|---|
| اتصال Bot API و وب‌هوک | توکن و ثبت webhook Telegram | توکن و webhook بله؛ `getWebhookInfo` برای بررسی نتیجه | `updateBotEndpoints` برای endpointهای جدا؛ API عمومی بررسی‌شده read-back ندارد |
| فروشگاه/سفارش WooCommerce | مسیر بات و Mini App Telegram | مسیر بات و Mini App Bale | بات/checkout وب امن WooCommerce در مسیرهای موجود افزونه |
| Mini App | فعال/تنظیم در تب Telegram | فعال/تنظیم در صفحهٔ مستقل Bale با initData پلتفرم بله | این افزونه Mini App روبیکا را عرضه نمی‌کند |
| پرداخت native | provider invoice؛ Stars برای محصولات دیجیتال در مسیرهای پشتیبانی‌شده | کیف‌پولی Bale، صورتحساب، `pre_checkout_query`/تأیید سروری و `createInvoiceLink` برای Mini App | پرداخت بومی از API عمومی مستندشده در کد موجود نیست؛ از درگاه‌های عادی WooCommerce استفاده می‌شود |
| انتشار محصول | مقصد Telegram و عنوان اختصاصی | مقصد Bale و عنوان اختصاصی | مقصد Rubika و عنوان اختصاصی |
| اعلان سفارش | سوئیچ‌های Telegram/مدیر موجود در تنظیمات Telegram | سوئیچ‌های مستقل مشتری/مدیر برای Bale | سوئیچ‌های مستقل مشتری/مدیر برای Rubika |
| عضویت کانال/گروه | بررسی عضویت با الزام مجوز مدیر طبق Bot API | `getChatMember` رسمی؛ بات باید مدیر مقصد باشد | تا نبود endpoint رسمی lookup عضو، gate ارائه نمی‌شود |
| command menu | ثبت/نمایش با روش‌های Telegram؛ پنل توضیح می‌دهد کدام مسیر خودکار است | دستورها در منطق فروشگاه پردازش می‌شوند؛ registration خودکار جداگانه ادعا نمی‌شود | `setCommands` رسمی هنگام ثبت webhook، مشروط به گزینهٔ فعال |

## منابع رسمی بررسی‌شده

- Telegram Bot API: <https://core.telegram.org/bots/api>
- Telegram Payments: <https://core.telegram.org/bots/payments>
- Telegram Stars Payments: <https://core.telegram.org/bots/payments-stars>
- Telegram Mini Apps: <https://core.telegram.org/bots/webapps>
- مستند رسمی Bot API بله: <https://docs.bale.ai/>
- مستند رسمی Bot API روبیکا: <https://rubika.ir/botapi>
- فهرست متدهای رسمی روبیکا: <https://rubika.ir/botapi/methods>
- WordPress Settings API: <https://developer.wordpress.org/plugins/settings/settings-api/>
- WooCommerce Settings API: <https://developer.woocommerce.com/docs/extensions/settings-and-config/extend-wc-settings-page/>
- WooCommerce settings overview: <https://woocommerce.com/document/configuring-woocommerce-settings/>

### ملاحظات منبع

- صفحهٔ رسمی بله می‌گوید Bot API آن از Telegram الهام گرفته، اما این به معنای یکسان بودن قراردادها نیست؛ هر قابلیت به endpoint/schema همان مستند بله گره می‌خورد.
- صفحهٔ کامل Telegram Bot API در مرور مستقیم 403 برگرداند؛ موارد Telegram با صفحهٔ رسمی و نتایج نمایه‌شدهٔ دامنهٔ `core.telegram.org` تطبیق داده شدند.
- برای روبیکا فقط `rubika.ir/botapi` و فهرست رسمی متدها معیار است؛ wrapperهای ثالث منبع تصمیم برای افزودن قابلیت native نیستند.
- شواهد این سند استاتیک/مستنداتی‌اند؛ API زنده یا نصب واقعی WordPress/WooCommerce در این محیط آزمایش نشده است.
