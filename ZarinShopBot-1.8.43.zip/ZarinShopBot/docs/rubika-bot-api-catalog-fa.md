# کاتالوگ فنی رسمی Rubika Bot API

**نسخهٔ مرجع:** Bot API v3  
**تاریخ بازبینی مستندات:** ۳۰ اکتبر ۲۰۲۶  
**دامنه:** مستندات عمومی رسمی روبیکا؛ این سند جایگزین آزمایش زندهٔ API یا قراردادهای منتشرنشده نیست.

> **اصل پیاده‌سازی:** API روبیکا را قرارداد مستقل خودش در نظر بگیرید. شباهت نام‌هایی مانند `sendMessage` به تلگرام، به معنی یکسان‌بودن payload، رفتار یا خطاها نیست.

---

## ۱) مرجع‌ها و اعتبار اطلاعات

| مرجع رسمی | کاربرد |
|---|---|
| [معرفی Bot API](https://rubika.ir/botapi) | ایجاد بات، روش دریافت update، نمونهٔ webhook و توصیهٔ عملیاتی |
| [فهرست متدها](https://rubika.ir/botapi/methods) | مسیرها، ورودی‌ها، خروجی‌های متدها و مثال‌های درخواست |
| [مدل‌ها و enumها](https://rubika.ir/botapi/models) | ساختار Chat، Message، Update، Keypad، Button، Metadata و محدودیت‌های مدل |
| [گروه‌ها و کانال‌ها](https://rubika.ir/botapi/group-channel) | افزودن بات، دسترسی‌ها، مشاهدهٔ پیام‌ها و محدودیت‌های مدیریتی |
| [BotFather روبیکا](https://rubika.ir/BotFather) | ساخت و مدیریت بات و تنظیمات مربوط به آن |

در این کاتالوگ، **مستندشده** یعنی صریحاً در یکی از صفحات رسمی بالا آمده است. هرجا مستندات یکدیگر را نقض کنند یا جزئیات لازم را نگویند، مورد با برچسب **ابهام/نیازمند تأیید** مشخص شده است؛ از روی SDKهای ثالث یا تشابه با تلگرام پر نمی‌شود.

---

## ۲) اتصال پایه و قرارداد HTTP

### ایجاد بات

1. بات از طریق BotFather روبیکا ساخته می‌شود.
2. BotFather یک token می‌دهد؛ token را محرمانه نگه دارید و در URL لاگ نکنید.
3. طبق مستندات، درخواست‌های متدها با `POST` به این قالب می‌روند:

```text
https://botapi.rubika.ir/v3/{token}/{method}
```

بدنهٔ متدهای دارای پارامتر در مثال‌های رسمی JSON است و معمولاً `Content-Type: application/json` دارد. استثنا/نمونهٔ قابل توجه: مثال `getMe` یک POST بدون بدنه و بدون پارامتر نشان می‌دهد؛ بنابراین در آن درخواست `[]` نفرستید مگر مستندات متد چنین بدنه‌ای بخواهند.

### انواع شناسه‌ها

مدل‌های رسمی `chat_id`، `user_id` و `message_id` را عموماً از نوع **string** تعریف می‌کنند. شناسهٔ چت ممکن است مقدار opaque/غیرعددی داشته باشد؛ آن را بدون دلیل عددی‌سازی، کوتاه، normalize یا با شناسهٔ کاربر جایگزین نکنید. مدل `Chat` جداگانه `chat_id` و `user_id` دارد.

### پاسخ و خطا

صفحات متدها معمولاً فیلدهای داده‌ای خروجی (مثل `message_id` یا `updates`) را مشخص می‌کنند، اما در صفحات بررسی‌شده یک قرارداد جامع و واحد برای HTTP status، envelope پاسخ موفق، همهٔ کدهای خطا، retry یا rate limit منتشر نشده است. بنابراین:

- HTTP 2xx را به‌تنهایی موفقیت عملیاتی تلقی نکنید؛ پاسخ JSON ارائه‌دهنده را هم بررسی کنید.
- شکل واقعی پاسخِ success/error هر متد را با fixture معتبر همان متد یا آزمایش کنترل‌شده تثبیت کنید.
- متن خطای ارائه‌دهنده را در صورت وجود به‌عنوان دادهٔ تشخیصی نگه دارید، اما token، شناسه‌ها و متن خصوصی را در لاگ نریزید.
- مستندات بررسی‌شده حدود/سیاست عمومی rate limit یا الگوریتم retry را تعیین نمی‌کنند؛ retry کورکورانهٔ عملیات ارسال ممکن است پیام تکراری بسازد.

---

## ۳) دریافت رویدادها: Long polling و Webhook

### الف) Long polling با `getUpdates`

متد رسمی: `getUpdates`

| ورودی | نوع رسمی | کاربرد |
|---|---|---|
| `offset_id` | string | دریافت ادامهٔ فهرست؛ مقدار `next_offset_id` پاسخ قبلی برای صفحه/درخواست بعدی استفاده می‌شود. |
| `limit` | int | تعداد updateهای درخواستی |

خروجی مستندشده:

- `updates`: فهرست `Update`
- `next_offset_id`: cursor درخواست بعدی

صفحهٔ معرفی می‌گوید polling می‌تواند دوره‌ای (مثلاً هر ۵ ثانیه) انجام شود و latency آن تابع فاصلهٔ polling است.

**تعارض مستندات:** صفحهٔ معرفی در توضیح polling از `start_id` نام می‌برد؛ اما schema متد `getUpdates`، نام ورودی را `offset_id` و cursor خروجی را `next_offset_id` اعلام می‌کند. از طرف دیگر `start_id` در مدل `AuxData` برای پارامتر ورودی شروع تعامل/لینک بات به‌کار می‌رود. در پیاده‌سازی polling، قرارداد دقیق متد (`offset_id` ← `next_offset_id`) مبنا باشد، نه عبارت ناسازگار صفحهٔ معرفی.

### ب) Webhook / Endpoint

روبیکا برای webhook درخواست `POST` به endpoint برنامه می‌فرستد. مستندات می‌گویند endpoint باید دامنهٔ عمومی و HTTPS معتبر داشته باشد. اگر endpoint خطا بدهد یا پاسخ معتبر نگیرد، احتمال توقف موقت رویدادها وجود دارد. برای گونه‌های مختلف رویداد endpointهای جدا تعریف می‌شود.

#### `ReceiveUpdate`

هنگام پیام جدید یا تعامل با **Chat Keypad**، بدنه به شکل wrapper `update` است. نمونهٔ رسمی:

```json
{
  "update": {
    "type": "NewMessage",
    "chat_id": "{chat_id}",
    "new_message": {
      "message_id": "{message_id}",
      "text": "custom text",
      "time": "1643122902",
      "is_edited": false,
      "sender_type": "User",
      "sender_id": "{sender_id}",
      "aux_data": {
        "start_id": null,
        "button_id": "{button_id}"
      }
    }
  }
}
```

#### `ReceiveInlineMessage`

با کلیک روی **Inline Keypad**، بدنهٔ جداگانهٔ `inline_message` می‌رسد؛ نمونهٔ رسمی:

```json
{
  "inline_message": {
    "sender_id": "{sender_id}",
    "text": "custom text",
    "location": null,
    "aux_data": {
      "start_id": null,
      "button_id": "{button_id}"
    },
    "message_id": "{message_id}",
    "chat_id": "{chat_id}"
  }
}
```

Inline click را نباید الزاماً همان شکل `Update.new_message` فرض کرد. `sender_id`، `chat_id`، `message_id` و `aux_data.button_id` معنای جدا دارند.

#### انواع update رسمی

`UpdateTypeEnum` در مدل‌ها این مقادیر را فهرست می‌کند:

- `NewMessage`
- `UpdatedMessage`
- `RemovedMessage`
- `StartedBot`
- `StoppedBot`
- `EventData`

مدل `AuxData` شامل `start_id` (شناسهٔ ورودی شروع تعامل، مثلاً از لینک) و `button_id` (شناسهٔ دکمهٔ انتخاب‌شده) است. `start_id` را با cursor مربوط به `getUpdates` اشتباه نگیرید.

#### Endpoint typeها

`UpdateEndpointTypeEnum` در مستندات این گزینه‌ها را دارد:

- `ReceiveUpdate`
- `ReceiveInlineMessage`
- `ReceiveQuery`
- `GetSelectionItem`
- `SearchSelectionItems`

برای `ReceiveQuery`، `GetSelectionItem` و `SearchSelectionItems`، صفحات بررسی‌شده schema کامل request/response و نمونهٔ payload هم‌سطح دو webhook بالا را شرح نمی‌دهند؛ استفاده از آنها نیازمند تأیید مستندات/تست رسمی بیشتر است.

#### ثبت یا تغییر Endpoint

صفحهٔ متدها نام `updateBotEndpoints` (جمع) و ورودی‌های `url` و `type` را نشان می‌دهد؛ مثال آن endpointهای `GetSelectionItem` را به کار می‌برد.

**تعارض نام:** صفحهٔ معرفی یک‌جا نام `updateBotEndpoint` (مفرد) را می‌آورد، ولی صفحهٔ متدها و مسیر مثال HTTP از `updateBotEndpoints` استفاده می‌کنند. پیش از تغییر endpoint عملیاتی، مسیر دقیق را با پاسخ واقعی `getMe`/API یا محیط آزمایشی تأیید کنید.

---

## ۴) کاتالوگ متدهای رسمی

تمام مسیرهای زیر زیر پیشوند نسخهٔ v3 هستند و طبق مستندات با POST فراخوانی می‌شوند، مگر جایی که توضیح دیگری آمده باشد.

### ۴.۱ هویت و چت

| متد | ورودی کلیدی | خروجی مستند | شرح/نکته |
|---|---|---|---|
| `getMe` | ندارد | `bot: Bot` | اطلاعات بات؛ نمونهٔ رسمی POST بدون body. مناسب بررسی اتصال/هویت. |
| `getChat` | `chat_id: string` | `chat: Chat` | جزئیات چت؛ Chat می‌تواند private/group/channel باشد. |
| `getUpdates` | `offset_id?: string`, `limit: int` | `updates`, `next_offset_id` | polling؛ cursor با نام‌های دقیق بخش قبل. |

### ۴.۲ پیام، ویرایش، حذف و انتقال

| متد | ورودی اصلی | خروجی مستند | نکته |
|---|---|---|---|
| `sendMessage` | `chat_id`, `text`; اختیاری `chat_keypad`, `chat_keypad_type`, `inline_keypad`, `disable_notification`, `reply_to_message_id`, یا `metadata` | `message_id` | متن ساده، Chat Keypad و Inline Keypad در همین متد ارائه می‌شوند؛ جزئیات پایین. |
| `editMessageText` | `chat_id`, `message_id`, `text` | در صفحهٔ متدها مشخص نشده | متن پیام موجود را تغییر می‌دهد. در گروه، فقط پیام‌های خود بات قابل ویرایش‌اند (بخش گروه/کانال). |
| `deleteMessage` | `chat_id`, `message_id` | در صفحهٔ متدها مشخص نشده | حذف پیام بات یا پیام دیگران در صورت داشتن دسترسی. |
| `forwardMessage` | `from_chat_id`, `message_id`, `to_chat_id`; اختیاری `disable_notification` | `new_message_id` | انتقال/forward پیام با شناسهٔ چت مبدأ و مقصد. |
| `editMessageKeypad` | طبق تیتر/توضیح: `chat_id`, `message_id`, `inline_keypad` | دقیق تصریح نشده | **نام endpoint در مثال‌های همان صفحه ناسازگار است**؛ قبل از اتکا، بخش ابهام‌ها را ببینید. |

### ۴.۳ محتوای دیگر

| متد | ورودی اصلی | خروجی مستند | نکته |
|---|---|---|---|
| `sendPoll` | `chat_id`, `question`, `options: list[string]` | `message_id` | ایجاد نظرسنجی. جزئیات lifecycle/بستن نظرسنجی در صفحهٔ متدهای بررسی‌شده تشریح نشده. |
| `sendLocation` | `chat_id`, `latitude`, `longitude` | `message_id` | مختصات در schema به صورت string آمده است؛ متد می‌تواند فیلدهای keypad/notification/reply هم بپذیرد. |
| `sendContact` | `chat_id`, `first_name`, `last_name`, `phone_number` | `message_id` | ارسال کارت مخاطب؛ schema همچنین فیلدهای keypad و reply را ذکر می‌کند. |

### ۴.۴ فایل

| متد | ورودی/خروجی | شرح |
|---|---|---|
| `requestSendFile` | ورودی `type: FileTypeEnum`؛ خروجی `upload_url` | ایجاد URL آپلود برای نوع فایل. |
| آپلود به `upload_url` | `file` به صورت `multipart/form-data` در body؛ خروجی `file_id` | upload روی URL بازگشتی انجام می‌شود؛ نمونهٔ رسمی فایل را در multipart body می‌فرستد. |
| `getFile` | ورودی `file_id`؛ خروجی `download_url` | دریافت URL دانلود فایل. |
| `sendFile` | `chat_id`, `file_id`; موارد اختیاری: `text`, `reply_to_message_id`, `disable_notification`, `chat_keypad`, `inline_keypad`, `chat_keypad_type` | `message_id` | ارسال فایل از طریق file ID؛ API عمومی در این مسیر نمونهٔ `sendFile` دارد، نه الزاماً متدهای رسانه‌ای تلگرام. |

#### FileTypeEnum و سقف‌های اعلام‌شده

| مقدار | فرمت/سقف مستند |
|---|---|
| `File` | فایل عمومی تا ۵۰ مگابایت |
| `Image` | jpg، gif، png یا webp تا ۱۰ مگابایت |
| `Voice` | صوت کوتاه mp3 |
| `Video` | mp4 تا ۵۰ مگابایت |
| `Music` | mp3 |
| `Gif` | mp4 متحرک بدون صدا |

مستندات سقف عددی برای همهٔ گونه‌ها تعیین نکرده‌اند؛ از سقف یک نوع به نوع دیگر تعمیم ندهید.

### ۴.۵ مدیریت اعضا و دستورات

| متد | ورودی اصلی | توضیح/محدودیت |
|---|---|---|
| `banChatMember` | `chat_id`, `user_id` | مسدود/حذف عضو؛ روی مالک و ادمین‌ها اعمال نمی‌شود. |
| `unbanChatMember` | `chat_id`, `user_id` | رفع مسدودی و امکان بازگشت از طریق لینک یا افزودن دستی. |
| `setCommands` | `bot_commands: list[BotCommand]` | ثبت/به‌روزرسانی command menu؛ هر فرمان `command` (نام بدون `/`) و `description` دارد. |
| `updateBotEndpoints` | `url`, `type: UpdateEndpointTypeEnum` | ثبت آدرس endpoint؛ نام جمع طبق صفحهٔ متدها، با تعارض مفرد/جمع صفحهٔ معرفی. |

در مستندات بررسی‌شده متدهای Bot API برای پرداخت native، invoice یا pre-checkout در فهرست رسمی این کاتالوگ دیده نشد؛ بنابراین قابلیت پرداخت native را برای Rubika از روی API تلگرام فرض نکنید.

---

## ۵) پیام و صفحه‌کلیدها

### متن ساده و گزینه‌های عمومی `sendMessage`

حداقل ورودی مستند متن ساده:

```json
{
  "chat_id": "CHAT_ID",
  "text": "Hello"
}
```

نمونهٔ رسمی درخواست POST به `/v3/{token}/sendMessage` با `Content-Type: application/json` است. خروجی مدل متد `message_id` را اعلام می‌کند.

### دو نوع keypad را با هم اشتباه نکنید

| نوع | فیلد API | جایگاه در رابط | رویداد کلیک مستند |
|---|---|---|---|
| Chat Keypad | `chat_keypad` همراه `chat_keypad_type` | صفحه‌کلید چت/پایین رابط | `ReceiveUpdate`؛ دکمه ممکن است در `update.new_message.aux_data.button_id` بازگردد. |
| Inline Keypad | `inline_keypad` | دکمه‌های inline زیر پیام | `ReceiveInlineMessage` با wrapper جداگانه `inline_message`. |

برای Chat Keypad، enum `chat_keypad_type` شامل `None`, `New`, `Remove` است. `editChatKeypad` برای `New` یا `Remove` به‌کار می‌رود و `chat_keypad`/`chat_keypad_type` را می‌گیرد.

### ساختار keypad و دکمه

ساختار عمومی:

```json
{
  "rows": [
    {"buttons": [
      {"id": "action-id", "type": "Simple", "button_text": "عنوان"}
    ]}
  ],
  "resize_keyboard": true,
  "one_time_keyboard": false
}
```

- `rows` فهرست `KeypadRow`هاست؛ هر row دارای `buttons` است.
- ترتیب دکمه‌ها در آرایهٔ هر row، ترتیب افقی نمایش است.
- `resize_keyboard` و `one_time_keyboard` در مدل Keypad آمده‌اند؛ مستندات دقیقاً تضمین نمی‌کنند که هر فیلد در هر نوع keypad معنا/اثر یکسان داشته باشد.
- مدل Button فیلدهای `id`, `type`, `button_text` و داده‌های subtype دارد. فیلدهای subtype فقط با نوع متناظر پر شوند.

#### ButtonTypeEnum

`Simple`, `Selection`, `Calendar`, `NumberPicker`, `StringPicker`, `Location`, `CameraImage`, `CameraVideo`, `GalleryImage`, `GalleryVideo`, `File`, `Audio`, `RecordAudio`, `Textbox`, `Link`, `AskMyPhoneNumber`, `AskMyLocation`, `Barcode`.

این فهرست نوع‌های مدل دکمه است؛ صرف وجود یک enum به‌تنهایی تضمین نمی‌کند که تمام ورودی‌ها در همهٔ چت‌ها/نسخه‌ها/کلاینت‌ها فعال باشند.

#### زیرمدل‌های دکمه

- **Selection:** `selection_id`, `search_type`, `get_type`, `items`, `is_multi_selection`, `columns_count`, `title`. آیتم می‌تواند `text`, `image_url`, `type` داشته باشد. enumهای search/get شامل `None`, `Local`, `Api` هستند (شرح مستندات دربارهٔ Local/Api را عیناً برای مدل مربوط بررسی کنید).
- **Calendar:** `default_value`, `type` (`DatePersian` یا `DateGregorian`), `min_year`, `max_year`, `title`.
- **NumberPicker:** `min_value`, `max_value`, `default_value`, `title`.
- **StringPicker:** `items`, `default_value`, `title`.
- **Textbox:** `type_line` (`SingleLine`/`MultiLine`)، `type_keypad` (`String`/`Number`)، `place_holder`, `title`, `default_value`.
- **Location:** `default_pointer_location`, `default_map_location`, `type` (`Picker`/`View`), `title`.

برای ButtonTypeهایی مانند `Link`، مستندات Button در صفحهٔ مدل‌ها شرح کامل فیلد مقصد/قواعد URL را در جدول عمومی Button ارائه نمی‌کند. payload دقیق لینک را از مثال رسمی همان قابلیت یا آزمون واقعی تأیید کنید، نه از schema تلگرام.

---

## ۶) Metadata و قالب‌بندی متن

`sendMessage` یک ورودی اختیاری `metadata` از نوع `Metadata` دارد. ساختار آن یک `meta_data_parts` است.

### MetadataPart

- `type`: یکی از نوع‌های Metadata
- `from_index`: اندیس شروع، صفرمبنا و **بر حسب واحدهای UTF‑16**
- `length`: طول مثبت، باز هم بر حسب UTF‑16
- `link_url`: فقط برای نوع `Link`
- `mention_text_user_id`: فقط برای نوع `MentionText`

### قواعد و محدودیت‌های رسمی

1. حداکثر **۳۰ جزء** metadata در یک پیام.
2. `length` باید بزرگ‌تر از صفر باشد.
3. `from_index + length` نباید از طول متن بر حسب UTF‑16 بزرگ‌تر شود.
4. ایموجی‌های خارج از BMP معمولاً دو واحد UTF‑16 هستند؛ شمردن صرفاً بر حسب بایت یا code point می‌تواند offset را خراب کند.
5. اگر حتی **یک** metadata نامعتبر باشد، کل درخواست رد می‌شود.
6. `MentionText` فقط برای پیام گروهی مستند شده؛ استفاده در private chat موجب رد درخواست طبق مدل‌ها می‌شود.
7. `Bold`, `Italic`, `Underline`, `Strike` روی emoji اثر بصری قابل مشاهده ندارند.

نوع‌های MetadataEnum: `Bold`, `Italic`, `Mono`, `Underline`, `Strike`, `Spoiler`, `Link`, `MentionText`, `Pre`, `Quote`.

**توصیهٔ فنی:** ابتدا متن نهایی را دقیق نهایی کنید؛ سپس offset و length هر entity را روی همان متن و با شمارش UTF‑16 بسازید. متن را بعد از محاسبهٔ offsetها تغییر/HTML-decode/normalize نکنید مگر offsets را دوباره محاسبه کنید. اگر provider صریحاً `invalid_input` داد، payload سادهٔ بدون metadata یک مسیر تشخیصی معتبر است، اما نتیجهٔ mock جای پاسخ واقعی API را نمی‌گیرد.

---

## ۷) مدل‌های مهم داده

### Chat

`chat_id: string`, `chat_type`, `user_id` (در چت private), `first_name`, `last_name`, `title`, `username`. برخی فیلدها بسته به نوع چت null هستند. `ChatTypeEnum`: `User`, `Bot`, `Group`, `Channel`.

### Message

مدل پیام شامل `message_id`, `text`, `time`, `is_edited`, `sender_type`, `sender_id`, `aux_data`, و بسته به پیام می‌تواند `file`, `reply_to_message_id`, `forwarded_from`, `forwarded_no_link`, `location`, `sticker`, `contact_message`, `poll` داشته باشد.

### Update

`type`, `chat_id`, `removed_message_id`, `new_message`, `updated_message`, `event_data`. فیلدهای optional فقط برای نوع رویداد مرتبط معنا دارند.

### InlineMessage

`sender_id`, `text`, `file`, `location`, `aux_data`, `message_id`, `chat_id`. رویداد این مدل از Inline Keypad می‌آید و envelope آن با Update عادی متفاوت است.

### Event و دسترسی

- `Event.type`: `BotJoined`, `BotRemoved`, `BotPermissionsChanged`.
- `Event.access_list` می‌تواند دسترسی‌هایی مانند `SendMessages`, `EditMyMessages`, `EditAllMessages`, `DeleteGlobalAllMessages`, `ViewMembers`, `BanMember` را نشان دهد.
- `join_type`: `Member` یا `Admin`.

### دیگر مدل‌های داده

مدل‌ها همچنین `Bot`, `BotCommand`, `File`, `ForwardedFrom`, `Sticker`, `ContactMessage`, `Location`, `Poll`, `PollStatus`, `MessageTextUpdate` و `MessageKeypadUpdate` را تعریف می‌کنند. فیلدهای مهم File: `file_id`, `file_name`, `size`. `size` در مدل به صورت string تعریف شده است. `PollStatus` شامل `state`, `selection_index`, `percent_vote_options`, `total_vote`, `show_total_votes` است؛ stateهای مستند `Open`, `Closed` هستند.

---

## ۸) گروه و کانال: عضویت، دسترسی و حریم پیام

برای امکانات کامل، بات باید دستی به گروه/کانال افزوده و به Admin ارتقا داده شود. افزودن با لینک دعوت مستند نشده/پشتیبانی نمی‌شود؛ راهنمای رسمی می‌گوید افزودن از طریق ادمین و دستی انجام شود.

### دسترسی‌ها

دسترسی بات پس از Admin شدن قابل تنظیم است. مدل Event نام دسترسی‌هایی مانند ارسال، ویرایش پیام خود/همه، حذف پیام، مشاهدهٔ اعضا و ban را فهرست می‌کند. فقط permissionهای مورد نیاز را فعال کنید؛ دسترسی حذف یا ban می‌تواند اثر مخرب داشته باشد.

### محدودیت‌های صریح صفحهٔ رسمی

- به‌صورت پیش‌فرض بات فقط پیام‌های مرتبط را می‌بیند (مثلاً پیام‌های منشن‌شده یا شروع‌شونده با `/`). برای دیدن همهٔ پیام‌های گروه/کانال باید گزینهٔ «دریافت همه پیام‌های کانال و گروه» را در BotFather فعال کرد.
- در گروه‌ها `editMessageText` فقط روی پیام‌هایی که خود بات فرستاده فعال است.
- افزودن بات به گروه/کانال فقط به‌صورت دستی انجام می‌شود.
- در هر گروه/کانال حداکثر ۱۰ بات می‌توانند هم‌زمان Admin باشند.
- رویداد ویرایش/حذف برای پیام‌های کاربران انسانی گزارش می‌شود؛ تغییرات خود بات یا بات‌های دیگر در این توضیح قابل شناسایی/اعلان نیست.
- متدهای مستند مدیریتی شامل `banChatMember` و `unbanChatMember` هستند؛ فقط با دسترسی مناسب استفاده شوند.

---

## ۹) ناسازگاری‌ها و خلأهای مستندات رسمی

این موارد را باید در طراحی و debugging آشکار نگه داشت، نه اینکه با حدس پنهان کرد:

1. **cursor polling:** متن معرفی `start_id` می‌گوید؛ schema متد `offset_id`/`next_offset_id` می‌گوید. `start_id` در مدل AuxData معنای دیگری هم دارد.
2. **ثبت endpoint:** صفحهٔ معرفی گاهی `updateBotEndpoint` (مفرد) می‌گوید؛ صفحهٔ متدها مسیر `updateBotEndpoints` (جمع) را مستند کرده است.
3. **ویرایش Inline Keypad:** تیتر متد `editMessageKeypad` است؛ مثال cURL در بخش آن به `/editInlineKeypad` اشاره می‌کند؛ برخی مثال‌های همان مجموعه به `/editMessageText` می‌روند و عنوان/کد نمونه نیز همیشه با یکدیگر همسو نیستند. قبل از استفاده، endpoint واقعی را از منبع رسمی روز یا تست کنترل‌شده تأیید کنید.
4. **UpdateEndpointTypeهای query/selection:** enumها نام endpointها را می‌دهند، اما schema درخواست/پاسخ کامل برای `ReceiveQuery`, `GetSelectionItem`, `SearchSelectionItems` در صفحات مرورشده موجود نیست.
5. **envelope و خطا:** صفحات متدها فیلدهای خروجی را معرفی می‌کنند، اما قرارداد واحد و کامل برای HTTP status، success/error envelope، کدهای خطا و retry دیده نشد.
6. **Button.Link:** نوع `Link` در enum هست، اما جدول مدل Button جزئیات مقصد/قواعد URL را به‌طور کامل نشان نمی‌دهد.
7. **ارسال و سقف‌ها:** برای برخی FileTypeها سقف عددی یا فرمت‌های جزئی در صفحه مشخص نشده؛ از محدودیت نوع دیگری تعمیم ندهید.
8. **پرداخت:** در روش‌های رسمی Bot API بررسی‌شده متدهای native payment/checkout در فهرست نبود؛ نبودن در صفحات بررسی‌شده را به‌عنوان اثبات عدم وجود هر قابلیت محصول روبیکا تعمیم ندهید، ولی تا مستند رسمی/قابل‌آزمایش نداریم پیاده‌سازی پرداخت native را ادعا نکنید.

---

## ۱۰) چک‌لیست مهندسی برای پیاده‌سازی امن و قابل‌تشخیص

- [ ] فقط base URL رسمی v3 و methodهای مستند/تأییدشده را صدا بزنید.
- [ ] همهٔ callها را بر اساس قرارداد روبیکا بسازید؛ Telegram `reply_markup`, `parse_mode`, callback query یا payment schema را مستقیم ارسال نکنید.
- [ ] token را secret نگه دارید؛ در URL کامل، exception، analytics یا لاگ ثبت نکنید.
- [ ] برای webhook، HTTPS عمومی، route محدود و پاسخ معتبر داشته باشید؛ body را به‌عنوان untrusted input parse و validate کنید.
- [ ] بین `update`, `inline_message`, `chat_id`, `sender_id`, `button_id`, `start_id` تفکیک بگذارید.
- [ ] رشته‌بودن IDها را حفظ کنید؛ ID چت و ID کاربر را جای هم مصرف نکنید.
- [ ] polling را با `offset_id` و `next_offset_id` مطابق schema متد کنترل کنید؛ cursor را durable نگه دارید.
- [ ] دکمه‌های Chat Keypad و Inline Keypad را جدا طراحی و endpointهای دریافت متفاوتشان را ثبت کنید.
- [ ] Metadata را با UTF‑16، طول مثبت، بازهٔ معتبر و سقف ۳۰ validate کنید؛ MentionText را برای گروه نگه دارید.
- [ ] برای فایل، `requestSendFile` → multipart upload به `upload_url` → `file_id` → `sendFile` را مرحله‌ای ثبت/بررسی کنید؛ download مسیر `getFile` → `download_url` است.
- [ ] دسترسی گروهی را کمینه کنید؛ با توجه به defaults، visibility همهٔ پیام‌ها و BotFather setting را مستقل بررسی کنید.
- [ ] ارسال پیام را پس از timeout/خطای مبهم کورکورانه retry نکنید؛ ممکن است provider قبلاً پیام را پذیرفته باشد.
- [ ] لاگ‌ها را به تفکیک `platform`, `method`, stage و provider outcome ثبت کنید؛ متن خصوصی، token و شناسهٔ خام را حذف/ماسک کنید.
- [ ] پاسخ API را در لایهٔ provider تفسیر کنید؛ HTTP 200 به‌تنهایی موفقیت نیست.
- [ ] تست mock را «قراردادی/ساختاری» بنامید، نه تأیید زنده؛ برای ادعای عملیاتی، یک smoke test واقعی با bot/chat آزمایشی و ثبت نتیجه لازم است.

---

## ۱۱) خلاصهٔ مرجع برای عیب‌یابی `sendMessage`

قرارداد حداقلی مستندشده:

```http
POST https://botapi.rubika.ir/v3/{token}/sendMessage
Content-Type: application/json
```

```json
{"chat_id":"شناسهٔ خام چت روبیکا","text":"متن پیام"}
```

برای عیب‌یابی rejection، به‌ترتیب و با fixture/لاگ کنترل‌شده بررسی شود:

1. آیا HTTP واقعاً به endpoint v3 و متد درست می‌رود؟
2. آیا body واقعاً JSON object است و `Content-Type` JSON روی wire است؟
3. آیا `chat_id` همان شناسهٔ `update.chat_id`/`inline_message.chat_id` است، به‌صورت string و بدون namespace داخلی برنامه؟
4. آیا `text` رشتهٔ UTF‑8 معتبر و غیرخالی است؟
5. آیا در payload پیشرفته، فقط کلیدها/مدل‌های مستند Rubika ارسال می‌شوند؟
6. اگر payload پیشرفته رد شد، آیا `{chat_id,text}` خالص هم رد می‌شود؟ اگر بله، علت را دیگر نباید فقط به metadata یا keypad نسبت داد؛ شناسه، بدنهٔ واقعی، endpoint/token-context یا قواعد provider باید جدا شوند.
7. پاسخ JSON کامل provider را در محیط امن بررسی کنید؛ کد provider و هر developer message ممکن است تعیین‌کننده باشد. آن را بدون شناسه/token به log بیاورید.

**وضعیت مرتبط با پروژهٔ ZarinShopBot (بازبینی ۲۸ اکتبر ۲۰۲۶):** در بررسی ایستای adapter، موتور سازگار با Telegram مقدار `from.id` را برای مقصد پاسخ استفاده می‌کند، ولی مدل‌های Rubika شناسهٔ `sender_id` و مقصد `chat_id` را جدا تعریف می‌کنند. اگر این دو مقدار متفاوت باشند، ارسال پاسخ با sender ID به‌جای chat ID می‌تواند باعث شود پیام شروع/درخواست پاسخ نگیرد. اصلاح adapter در نسخهٔ 1.8.18 فقط sender/conversation همان رویداد را به `chat_id` رسمی Rubika نگاشت می‌کند و مقصدهای نامرتبط را دست‌نخورده می‌گذارد. این نتیجه از schema رسمی و کد استاتیک است؛ در این محیط هیچ token واقعی، webhook production یا پاسخ زندهٔ Rubika آزمایش نشده، بنابراین رفع قطعی روی سایت باید با تست ربات و لاگ‌های پس از نصب تأیید شود.

---

## منابع

- [Rubika Bot API — معرفی و webhook](https://rubika.ir/botapi)
- [Rubika Bot API — Methods](https://rubika.ir/botapi/methods)
- [Rubika Bot API — Models](https://rubika.ir/botapi/models)
- [Rubika Bot API — Group/Channel](https://rubika.ir/botapi/group-channel)
- [Rubika BotFather](https://rubika.ir/BotFather)
