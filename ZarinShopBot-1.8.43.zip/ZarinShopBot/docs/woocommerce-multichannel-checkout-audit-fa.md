# گزارش ممیزی checkout و سفارش WooCommerce در Telegram، Bale و Rubika

**تاریخ:** ۳۰ اکتبر ۲۰۲۶  
**نسخهٔ پایهٔ ممیزی:** 1.8.24؛ اصلاح‌های گزارش در انتشار 1.8.27 گنجانده شدند.  
**دامنه:** محاسبهٔ حمل‌ونقل و کوپن، تشخیص کالای قابل‌ارسال، ایجاد سفارش، کنترل موجودی، مسیر درگاه WooCommerce، دانلود دیجیتال و ماندگاری سبد کانال‌ها.

> این گزارش نتیجهٔ بازبینی کد و آزمون‌های ایستای JavaScript است؛ گواهی سازگاری مطلق یا تأیید عملی روی فروشگاه زنده نیست. هیچ WordPress/WooCommerce staging یا اعتبارنامهٔ زندهٔ Telegram/Bale/Rubika در دسترس این اجرا نبود.

## جمع‌بندی

هر سه پیام‌رسان از موتور مشترک سفارش WooCommerce استفاده می‌کنند، اما پرداخت‌های native و انتقال پیام در adapterهای جدا باقی می‌مانند. Rubika از درگاه استاندارد پرداخت سفارش WooCommerce استفاده می‌کند و برای آن پرداخت merchant بومیِ تأییدنشده ادعا نمی‌شود. پشتیبانی از درگاه‌های شخص‌ثالث به سازگاری همان افزونهٔ درگاه با صفحهٔ پرداخت سفارش WooCommerce و تنظیمات فروشگاه وابسته است.

در کد این دور چند مسیر پرخطر به‌صورت fail-closed اصلاح شدند: سبد چندبسته‌ای دیگر با هزینهٔ ناقص صورتحساب نمی‌شود، کالاهای غیرقابل‌ارسال فقط بر اساس `needs_shipping()` تشخیص داده می‌شوند، سفارش ناقص از سبد ساخته نمی‌شود، و یک GET روی پیوند بات دیگر مستقیماً `process_payment()` را اجرا نمی‌کند.

## اصلاح‌های اعمال‌شده

1. **کالای downloadable در برابر shipping:** downloadable بودن به‌تنهایی دلیل حذف حمل‌ونقل نیست. شرط WooCommerce، `needs_shipping()` است؛ این شرط هم در checkout دیجیتال وب و هم در محدودکردن Telegram Stars رعایت می‌شود. کالا یا سفارش دارای shipping item برای Stars پذیرفته نمی‌شود.
2. **نرخ حمل‌ونقل:** موقتاً سبد واقعی WooCommerce با آدرس و اطلاعات مشتری checkout بات ساخته می‌شود؛ کوپن پیش از محاسبهٔ نرخ اعمال می‌شود. آدرس‌ها، وضعیت VAT exemption، وضعیت محاسبهٔ shipping و داده‌های منتخب session/cart پس از محاسبه بازیابی می‌شوند. مبلغ نمایشی نرخ شامل مالیات نرخ نیز می‌شود.
3. **چندبسته‌ای:** چون UI ربات فقط یک نرخ را می‌تواند انتخاب کند، وجود بیش از یک package شحن‌پذیر یا package فاقد نرخ با خطای مشخص رد می‌شود؛ نرخ package اول به‌جای جمع کل استفاده نمی‌شود. سبد باید در این خطا باقی بماند.
4. **ساخت سفارش و موجودی:** تمام ردیف‌ها پیش از ساخت سفارش بررسی می‌شوند (محصول معتبر و قابل‌خرید، تعداد مثبت، stock و sold-individually). مقدار variationهایی که موجودی را از parent می‌گیرند جمع می‌شود. هرگاه API ووکامرس موجود باشد، `wc_reserve_stock_for_order()` برای نگه‌داشت موجودی به‌کار می‌رود؛ شکست رزرو باعث رد سفارش می‌شود. در نبود آن تابع، اجرای محیط حاضر نتوانست رزرو اتمیک را تأیید کند.
5. **کوپن:** خطای اعمال کوپن هنگام نرخ‌دهی یا ساخت سفارش دیگر نادیده گرفته نمی‌شود؛ checkout fail-closed است و پیام راهنمایی برای حفظ سبد دارد.
6. **نام و تلفن:** نام کامل به `first_name` و `last_name` ووکامرس تفکیک می‌شود. اعتبارسنجی تلفن از `WC_Validation::is_phone()` فیلترپذیر WooCommerce با کنترل طول حداقلی/حداکثری استفاده می‌کند؛ محدودیت regex ایران‌محور حذف شده است. اعتبارسنجی در مسیر checkout دیجیتال وب، شامل Classic/Blocks/Store API، هم اعمال می‌شود.
7. **درگاه و پرداخت:** پیوند پرداخت ابتدا order key را با سفارش تطبیق می‌دهد و برای مسیر جدید HMAC/انقضا را بررسی می‌کند. سپس درگاه ثبت‌شده و فعال را روی سفارش می‌گذارد و به endpoint پرداخت خود WooCommerce می‌رود؛ `process_payment()` مستقیماً روی GET اجرا نمی‌شود تا فرم، nonce، ورودی‌های مخصوص درگاه و POST استاندارد حذف نشوند یا اسکنر پیوند یک intent تکراری نسازد.
8. **سبد کانال‌ها:** transient سبد Bale/Rubika پس از شروع checkout پاک نمی‌شود. fingerprint سبد روی سفارش می‌ماند و فقط پس از `woocommerce_payment_complete`، آن هم اگر سبد فعلی هنوز با سفارش برابر باشد، transient و سبد bot پاک می‌شوند؛ سبد تازهٔ کاربر با پرداخت سفارش قدیمی پاک نخواهد شد.
9. **جمع صفر:** سفارش صفرمبلغ فقط پس از تأیید `is_paid()` از WooCommerce به‌عنوان تکمیل‌شده تلقی می‌شود؛ در غیر این صورت پیام خطا داده می‌شود و سبد حفظ می‌گردد. لینک دانلود تنها پس از اجازهٔ WooCommerce ارسال می‌شود.
10. **تنظیم حمل بات:** اگر کالا shipping می‌خواهد ولی جمع‌آوری shipping برای checkout بات غیرفعال است، سفارش بدون آدرس/هزینهٔ حمل ساخته نمی‌شود؛ کاربر به checkout وب‌سایت یا تماس با فروشگاه راهنمایی می‌شود.

## مرزها و ریسک‌های باقی‌مانده

- رابط بات هنوز فقط **یک shipping package** را مدل می‌کند؛ packageهای متعدد عمداً رد می‌شوند و باید در نسخهٔ آینده برای پشتیبانی کامل، UI جمع چند نرخ اضافه شود.
- آدرس checkout بات بر کشور پایهٔ فروشگاه تکیه دارد و فعلاً billing و shipping را از یک آدرس می‌سازد؛ انتخاب کشور مستقل و آدرس billing جداگانه در این جریان ارائه نشده است.
- نرخ‌های محاسبه‌شده با روش‌ها/افزونه‌های حمل‌ونقل خاص، قواعد وابسته به session، و تخفیف‌های پیچیده روی هزینهٔ حمل در staging تأیید نشده‌اند.
- قابلیت‌های اختصاصی gateway (اشتراک، پرداخت قسطی، pre-order، 3-D Secure یا فرم‌های سفارشی) فقط وقتی قابل انتظارند که gateway در صفحهٔ پرداخت سفارش WooCommerce از آن‌ها پشتیبانی کند؛ آزمون عملی هر gateway انجام نشده است.
- رزرو موجودی تابع نسخه و فیلترهای WooCommerce و تنظیم stock-hold فروشگاه است. موجودی، هم‌زمانی سفارش‌ها و release واقعی روی نصب هدف آزمایش نشده‌اند.
- شمارهٔ تلفن از validator خود WooCommerce عبور می‌کند، ولی کشور آدرس در checkout بات قابل‌انتخاب نیست؛ اعتبارسنجی محلی متفاوت از درگاه/افزونهٔ شمارهٔ کشور خاص ممکن است نتیجهٔ دیگری بدهد.
- Checkout Blocks و Store API برای اعتبارسنجی هویت دارای hookهای جدا هستند؛ بررسی استاتیک انجام شده، اما frontend بلوکیِ یک نصب واقعی اجرا نشده است.
- کانال‌های Bale و Rubika در این دور از نظر API زنده، webhook امضاشدهٔ واقعی، ارسال/دریافت media، callback و پرداخت آزمون end-to-end نشده‌اند.

## آزمون‌ها و راستی‌آزمایی

- هر ۲۱ فایل `tests/*.js` با Node اجرا شدند و موفق بودند؛ آزمون‌های ایستا شامل checkout WooCommerce/کانال‌ها و برچسب/تحویل دانلود هستند.
- `git diff --check` اجرا شد و خطای whitespace گزارش نکرد.
- اسکن case-insensitive برای شناسهٔ تجاری بازنشسته در سورس و آزمون‌ها نتیجه‌ای نداشت.
- PHP CLI در محیط موجود نیست؛ بنابراین PHP lint، PHP tests و اجرای WordPress/WooCommerce واقعاً انجام نشدند. از این گزارش نباید pass شدن PHP syntax/runtime یا E2E برداشت شود.
- بستهٔ 1.8.27 جداگانه ساخته می‌شود و نسخه‌های قبلی overwrite نمی‌شوند.

## منابع فنی

- [WooCommerce `WC_Order` code reference](https://woocommerce.github.io/code-reference/classes/WC-Order.html) — order-pay URL و API سفارش/کوپن.
- [WooCommerce stock functions](https://woocommerce.github.io/code-reference/files/woocommerce-includes-wc-stock-functions.html) — رزرو موجودی سفارش و lifecycle stock.
- [WooCommerce HPOS recipe book](https://developer.woocommerce.com/docs/features/orders/high-performance-order-storage/recipe-book/) — استفاده از CRUD ووکامرس برای سازگاری HPOS.
- [Checkout Block hook alternatives](https://developer.woocommerce.com/docs/block-development/reference/hooks/hook-alternatives/) — تفاوت hookهای checkout کلاسیک و Blocks.
- [WooCommerce Store API checkout validation example](https://developer.woocommerce.com/docs/code-snippets/prevent-po-box-addresses-in-checkout-block/) — اعتبارسنجی پیش از پرداخت در Blocks.
- [Telegram Bot API](https://core.telegram.org/bots/api)، [Bale Bot API](https://docs.bale.ai/) و [Rubika bot APIs](https://rubika.ir/botapi) — مرجع‌های مستقل هر کانال؛ پوشش در اینجا به معنی تأیید live نیست.
