# گزارش ممیزی یکپارچه‌سازی روبیکا در ZarinShopBot

**نسخهٔ کد ممیزی‌شده:** 1.8.24  
**تاریخ بازبینی مستندات:** ۳۰ اکتبر ۲۰۲۶  
**محدوده:** Bot API v3 رسمی، مسیرهای اتصال و webhook، نرمال‌سازی Update و InlineMessage، پیام/کلیدها/رسانه، مسیرهای فروش WooCommerce، اعلان‌ها، امنیت و رفتار خطا.

> این گزارش ممیزی استاتیک کد و تطبیق آن با مستندات رسمی است؛ جایگزین آزمون زنده با توکن روبیکا و سایت staging نیست.

## جمع‌بندی

روبیکا در این افزونه با **Webhook** به موتور فروش مشترک WooCommerce متصل می‌شود. برای تکمیل checkout، مشتری به checkout امن وب‌سایت و درگاه‌های فعال WooCommerce هدایت می‌شود. اتصال native wallet/payment روبیکا فعال نشده؛ مستندات بررسی‌شده Bot API قرارداد merchant برای ساخت/تأیید تراکنش، امضای callback و واحد مبلغ ارائه نمی‌کنند.

Adapter در مرز API، مدل‌های ناسازگار Telegram را به payload روبیکا تبدیل می‌کند. در مسیرهای متنی، دکمهٔ URL به Link metadata مستند تبدیل می‌شود؛ برای فایل ارسالی، چون metadata در قرارداد sendFile مرورشده مستند نشده، مقصد URL به‌شکل متن قابل مشاهده در caption نگه داشته می‌شود. فیلد URL نامستند به Button روبیکا ارسال نمی‌شود.

## ماتریس تطبیق با قابلیت‌های افزونه

| بخش | رفتار روبیکا در افزونه | مبنا/محدودیت |
|---|---|---|
| اتصال و تشخیص توکن | درخواست `getMe` به endpoint رسمی v3؛ نام کاربری بات از پاسخ ذخیره/نمایش داده می‌شود. | POST JSON؛ توکن در log ثبت نمی‌شود. |
| دریافت پیام | webhook نوع `ReceiveUpdate`؛ `NewMessage`، `StartedBot` و ورودی‌های Chat Keypad به dispatcher مشترک نرمال می‌شوند. | رخدادهای lifecycle یا updateهای غیرقابل‌اقدام نادیده گرفته می‌شوند. |
| تپ Inline Keypad | endpoint جداگانهٔ `ReceiveInlineMessage`؛ `chat_id`، `sender_id`، `message_id` و `aux_data.button_id` جداگانه حفظ می‌شوند. | از wrapper مربوط به Update عادی فرض گرفته نمی‌شود. |
| ثبت webhook | HTTPS اجباری؛ ثبت `ReceiveUpdate` و `ReceiveInlineMessage` با `updateBotEndpoints`؛ secret تصادفی در مسیر و verifier امن‌شده در option جدا ذخیره می‌شود. | API مرورشده روش read-back برای اثبات endpoint روبیکا ندارد؛ پذیرش دو فراخوانی ثبت، تأیید زندهٔ تحویل محسوب نمی‌شود. |
| فروشگاه و نشست | رویدادهای پذیرفته‌شده به موتور مشترک WooBot/WooCommerce داده می‌شوند؛ جریان‌های کاتالوگ، جست‌وجو، محصول/تنوع، سبد، coupon، نشانی، حمل‌ونقل/مالیات، سفارش و اعلان‌ها از همان موتور استفاده می‌کنند. | حریم سفارش با محدودکردن فروش به گفت‌وگوی خصوصی حفظ می‌شود. |
| هویت و حریم خصوصی | مقصد پاسخ `chat_id` و مالک نشست/سبد `sender_id` است؛ شناسه‌های پیام رشته‌ای و opaque می‌مانند. `getChat` نوع چت را بررسی می‌کند. | Group/Channel برای checkout خصوصی پردازش نمی‌شود؛ نوع نامشخص یا تأییدنشده با پاسخ 503 رد می‌شود. |
| عضویت اجباری | برای روبیکا غیرفعال است. | Bot API مرورشده متد `getChatMember` ندارد؛ درخواست حدسی ارسال نمی‌شود. |
| متن و قالب | `sendMessage` و `editMessageText` از متن ساده و metadataهای مستند استفاده می‌کنند؛ اندیس entity با UTF‑16 محاسبه، سقف ۳۰ بخش رعایت و Linkها هنگام رسیدن به سقف بر قالب‌بندی تزئینی اولویت می‌گیرند. | HTML پس از محاسبهٔ index به‌نحوی که offset را جابه‌جا کند پاک‌سازی نمی‌شود؛ پشتیبانی فرمت محدود به نگاشت مستند است. |
| دکمه و منو | Inline Keypad و Chat Keypad به ساختار `rows/buttons`, `id`, `type`, `button_text` ترجمه می‌شوند؛ command menu با `setCommands` همگام می‌شود. | URLها در پیام متنی به Link metadata HTTPS تبدیل می‌شوند؛ URL خام داخل مدل Button قرار نمی‌گیرد. |
| ویرایش/حذف | `editMessageText`, `editMessageKeypad`, `deleteMessage` با ID رشته‌ای. | اگر فقط keypad ویرایش شکست بخورد، پیام تکراری ساخته نمی‌شود. برای endpoint ویرایش keypad، نمونه‌های رسمی ناسازگاری دارند؛ پاسخ واقعی باید در staging بررسی شود. |
| تصویر محصول | URL عمومی تصویر از WooCommerce با کنترل SSRF/اندازه و نوع MIME دریافت؛ سپس `requestSendFile` → multipart `file` → `file_id` → `sendFile`. | در خطای دریافت/آپلود، متن و URL تصویر fallback می‌شوند. مقصدهای URL روی caption به‌شکل متن نگه داشته می‌شوند. |
| آلبوم تصاویر | آلبوم فقط‌تصویر، پس از اعتبارسنجی کل batch، به چند `sendPhoto` مستقل تبدیل می‌شود. | Bot API عمومی بررسی‌شده `sendMediaGroup` ندارد؛ ارسال ناقصِ آلبوم‌های غیرتصویری قبل از شروع رد می‌شود. |
| ویدئو/صوت/سند | متدهای جداگانهٔ Telegram مانند `sendVideo`/`sendAudio`/`sendDocument` برای روبیکا خطای صریح unsupported می‌دهند. | Bot API از `requestSendFile` و `sendFile` عمومی پشتیبانی می‌کند، اما این adapter در این release این رسانه‌های افزونه را به workflow عمومی فایل تبدیل نمی‌کند. |
| پرداخت | لینک checkout با HTTPS به checkout استاندارد WooCommerce می‌رود؛ درگاه‌های فعال سایت در وب‌سایت انتخاب می‌شوند. | wallet/invoice/pre-checkout بومی روبیکا پیاده نشده و پرداخت سفارش صرفاً بر اساس پیام یا callback تأیید نمی‌شود. |
| Retry و خطا | API پاسخ HTTP/JSON و `status=OK` را بررسی می‌کند؛ callهای mutation بدون retry خودکار هستند. برای `invalid_input` صریح، ارسال پیام یک‌بار بدون metadata امتحان می‌شود؛ اگر metadata رد شده باشد، URLهای HTTPS از Linkها به متن قابل‌مشاهدهٔ fallback افزوده می‌شوند. | timeout یا پاسخ مبهم باعث ارسال کورکورانهٔ پیام دوم نمی‌شود تا duplicate ایجاد نشود. |

## مواردی که عمداً در scope اجرایی این افزونه نیستند

- **Long polling با `getUpdates`:** قرارداد رسمی cursor در کاتالوگ محلی ثبت شده (`offset_id` / `next_offset_id`)، اما افزونه در این نسخه فقط webhook را برای دریافت رویداد به‌کار می‌برد؛ polling fallback یا worker پس‌زمینه پیکربندی نشده است.
- endpointهای `ReceiveQuery`, `GetSelectionItem`, `SearchSelectionItems`: schemaهای لازم در صفحات رسمی بررسی‌شده کامل نیستند و workflow متناظر در افزونه وجود ندارد.
- `forwardMessage`, `sendPoll`, `sendLocation`, `sendContact`, مدیریت ban/unban: متدهای رسمی در کاتالوگ آمده‌اند، اما قابلیت متناظری در workflowهای فعلی افزونه به آنها وابسته نیست.
- عضویت اجباری روبیکا و پرداخت بومی: به قرارداد رسمی و قابل‌آزمایش روبیکا نیاز دارند؛ این افزونه وانمود نمی‌کند که پشتیبانی می‌شوند.

«همهٔ بخش‌های افزونه» در این ممیزی به معنی سازگاری قابلیت‌های واقعاً مورد استفادهٔ فروشگاه و اعلان‌های موجود با مسیر روبیکاست، نه پیاده‌سازی همهٔ endpointهای Bot API یا همهٔ گونه‌های دکمهٔ enumشده.

## آزمون‌ها و محدودیت‌های راستی‌آزمایی

- آزمون‌های جاوااسکریپت smoke و بررسی‌های ایستا می‌توانند نگاشت‌ها و قواعد قرارداد را کنترل کنند، اما اجرای PHP، WordPress/WooCommerce، توکن واقعی و webhook واقعی در محیط توسعه در دسترس نیستند.
- قبل از انتشار عملیاتی، روی staging این مسیرها را با یک بات آزمایشی انجام دهید: `getMe`، ثبت دو endpoint، `/start`، پیام متن و فرمان، هر دو نوع keypad، محصول تصویری، افزودن به سبد، checkout با هر gateway فعال و اعلان سفارش.
- در پنل، HTTPS عمومی، عضویت/Admin دستی بات در چت لازم، مجوز دسترسی به تصاویر فروشگاه و مشاهدهٔ logهای بدون اطلاعات شخصی را بررسی کنید.

## منابع رسمی

- [معرفی Bot API](https://rubika.ir/botapi)
- [Methods](https://rubika.ir/botapi/methods)
- [Models](https://rubika.ir/botapi/models)
- [Group/Channel](https://rubika.ir/botapi/group-channel)
- کاتالوگ آفلاین پروژه: [`rubika-bot-api-catalog-fa.md`](rubika-bot-api-catalog-fa.md)
