# گزارش ممیزی یکپارچه‌سازی بله در ZarinShopBot

- **نسخهٔ مبنای ممیزی:** 1.8.24؛ اصلاح‌های گزارش در سورس انتشار 1.8.25 حفظ شده‌اند
- **تاریخ تطبیق مستندات:** ۳۰ اکتبر ۲۰۲۶
- **محدوده:** Bot API بله، webhook، انتقال پیام/دکمه، workflowهای مشترک WooCommerce، پرداخت کیف‌پولی و Mini App بله.

> این گزارش بازبینی استاتیک کد در برابر مستندات رسمی است؛ اجرای واقعی با bot token، Bale client و WordPress/WooCommerce staging انجام نشده است.

## تصمیم معماری

بله و روبیکا از موتور مشترک workflowهای فروشگاه استفاده می‌کنند، اما هرکدام adapter مستقل برای transport و payload دارند. «سازگاری» به معنی رفتار یکسان قابلیت‌های مشترک در گفت‌وگوی خصوصی است، نه ارسال درخواست حدسی به endpointهایی که مستند نیستند یا یکسان‌نمایی پرداخت/گروه/دکمه‌های متفاوت دو پیام‌رسان.

## ماتریس قابلیت‌ها

| حوزه | مسیر بله در افزونه | مرز تفاوت با روبیکا |
|---|---|---|
| اتصال و دریافت update | Bot API سازگار با Telegram، HTTPS و webhook؛ payload بله به مدل مشترک Update تبدیل می‌شود. | transport و envelope پاسخ بله (`ok/result`) از قرارداد روبیکا جداست. |
| فروشگاه | workflow مشترک برای کاتالوگ، محصول/تنوع، جست‌وجو، سبد، کوپن، checkout، سفارش، wishlist و اعلان‌ها؛ پاسخ‌های رخداد گروه به شناسهٔ فرستنده ارسال می‌شوند تا اطلاعات سفارش در گروه منتشر نشود. | روبیکا به‌طور محافظه‌کارانه Group/Channel را برای فروش مسدود می‌کند؛ بله از تنظیم `enabledingroups` موتور مشترک تبعیت می‌کند، اما خروجی تجاری را خصوصی نگه می‌دارد. |
| callback دکمه‌ها | callbackهای فروشگاه که از موتور مشترک یا dispatcher مستقیم (`zs:` / `ztr:`) عبور می‌کنند، پیش از کار اصلی با `answerCallbackQuery` پاسخ داده می‌شوند؛ adapter بله پاسخ و `show_alert` را به API بله می‌فرستد. برای callback IDهایی که با `1` شروع می‌شوند، طبق مستند بله درخواست ناسازگار با client قدیمی ارسال نمی‌شود. | روبیکا دکمه را به صورت رخداد پیام جداگانه می‌فرستد و endpoint معادل callback-answer ندارد. |
| تماس تلفنی | contact بله فقط وقتی به ورودی phone مشترک تبدیل می‌شود که `contact.user_id` دقیقاً با `message.from.id` برابر باشد؛ contact دیگران نادیده گرفته می‌شود. | شمارهٔ آزاد تایپ‌شده همچنان تابع اعتبارسنجی مشترک checkout است؛ contact نامعتبر هویت کاربر را اثبات نمی‌کند. |
| عضویت | `getChatMember` در adapter بله پشتیبانی می‌شود. | روبیکا در Bot API عمومی بررسی‌شده قرارداد متناظر مستند ندارد و این قابلیت برای آن غیرفعال/unsupported باقی می‌ماند. |
| پرداخت در گفتگو | پرداخت native کیف‌پولی بله؛ قبل از پذیرش، سفارش، مالک، مبلغ IRR، موجودی و وضعیت کنترل می‌شوند. پس از `successful_payment` مبلغ/ارز/کاربر بررسی و تراکنش با `inquireTransaction` تأیید می‌شود؛ mismatch نیازمند بررسی دستی است. | روبیکا در این نسخه به checkout و درگاه‌های استاندارد WooCommerce سایت هدایت می‌کند؛ قرارداد پرداخت merchant بومی مستند/پیاده‌شده‌ای ندارد. |
| Mini App | اعتبارسنجی server-side دادهٔ امضاشدهٔ Bale initData؛ ایجاد لینک صورتحساب بله و بازکردن همان مقدار `createInvoiceLink` با `openInvoice`؛ وضعیت سفارش پس از بازگشت از سرور کنترل می‌شود. | Mini App تلگرام و روش پرداخت آن مسیر جدا دارند؛ موفقیت callback سمت client به‌تنهایی تأیید پرداخت نیست. |
| دکمه و قالب متن | adapter بله مدل مشترک پیام/keyboard را به شکل بله تبدیل می‌کند؛ Markdown و فیلدهای دکمه مطابق API بله ارسال می‌شوند. | metadata قالب‌بندی روبیکا یا HTML تلگرام به بله نشت داده نمی‌شود. |
| رسانه | ارسال از مسیر API/transport بله با file ID یا multipart طبق قابلیت موجود adapter. | file ID بین botهای مختلف قابل‌انتقال فرض نمی‌شود؛ محدودیت فایل و قالب‌های قابل‌پشتیبانی provider-specific می‌مانند. |

## اصلاح‌های این دور

1. contact اشتراکی بله وارد جریان معمول دریافت phone در فروشگاه می‌شود، اما فقط پس از تطبیق شناسهٔ مالک contact با فرستنده.
2. `extract_message` و نرمال‌سازی ورودی بله از یک قاعدهٔ مشترک برای contact استفاده می‌کنند تا routeهای dispatch و موتور فروش دو رفتار متفاوت نداشته باشند.
3. پاسخ callback بله برای مسیر مشترک و مسیرهای مستقیم `zs:`/`ztr:` زودهنگام انجام می‌شود؛ adapter پارامتر مستند `show_alert` را حفظ می‌کند، شناسهٔ خالی را رد می‌کند و برای callbackهای legacy با پیشوند `1` طبق محدودیت client، فراخوانی API را حذف و نتیجهٔ no-op برمی‌گرداند؛ پیام خروجی workflow همچنان جداگانه ارسال می‌شود.
4. آزمون‌های قرارداد آفلاین برای contact هم‌هویت/ناهم‌هویت و callback جدید/legacy افزوده شدند.
5. مسیر مشترک Bale و checkout اکنون تفاوت گفت‌وگوی گروه با فرستنده را حفظ می‌کنند: پیام‌های فروشگاهی مشتری خصوصی ارسال می‌شوند؛ ویرایش پیام مبدأ گروهی رد می‌شود تا fallback خصوصی هسته اجرا شود و حذف آن پیام بی‌اثر است؛ متدهای غیرارسالی بی‌دلیل به sender remap نمی‌شوند.
6. تأیید پرداخت موفق سخت‌گیرانه‌تر شد: استعلام باید `status=paid`، مبلغ integer-IRR، `Transaction.userID` موجود و برابر با صاحب سفارش، و مبلغ سفارش فعلی مطابق انتظار باشد. invoice قدیمی/جایگزین‌شده فقط برای بررسی دستی نشانه‌گذاری می‌شود و سفارش را خودکار paid نمی‌کند.
7. pre-checkout موجودی را با رزروهای دیگر سفارش‌های WooCommerce می‌سنجد، reservation خود سفارش را از شمارش دوباره کنار می‌گذارد، variationهای دارای stock-managed مشترک را جمع می‌زند و پیش از پاسخ مثبت، در صورت پشتیبانی، از `wc_reserve_stock_for_order()` استفاده می‌کند. سفارش failed هنگام تلاش دوباره پس از اعتبارسنجی به pending برمی‌گردد؛ در صورت شکست reservation به failed بازگردانده می‌شود.

8. checkout مشترک Telegram/Bale/Rubika نیز در [گزارش ممیزی WooCommerce چندکاناله](woocommerce-multichannel-checkout-audit-fa.md) پوشش داده شده است: لینک پرداخت به‌جای اجرای مستقیم درگاه روی GET به order-pay ووکامرس هدایت می‌شود؛ سبد کانال فقط پس از پرداخت موفق و تطبیق fingerprint پاک می‌شود؛ حمل چندبسته‌ای و کوپن نامعتبر fail-closed هستند.

## موارد خارج از ادعای این پیاده‌سازی

- پیاده‌سازی همهٔ endpointهای Bot API بله هدف این افزونه نیست؛ scope، workflowهای واقعی فروشگاه و اعلان‌های موجود است.
- Long polling و endpointهای تجاری/رسانه‌ای بدون workflow متناظر در افزونه، صرفاً به دلیل وجود در مستندات اضافه نشده‌اند.
- پاسخ موفق API یا بازگشت `paid` در UI به‌تنهایی مبنای تکمیل سفارش نیست؛ WooCommerce order status و استعلام سروری پرداخت مرجع‌اند.
- برابری کامل رفتار Group/Channel دو پیام‌رسان ادعا نمی‌شود؛ سیاست خصوصی‌سازی و پشتیبانی واقعی API تفاوت دارند.

## راستی‌آزمایی

- در این ممیزی، هر ۲۰ آزمون smoke جاوااسکریپت پروژه با Node اجرا شدند و موفق شدند؛ همهٔ فایل‌های JavaScript آزمون از `node --check` نیز گذشتند. آزمون `tests/bale-payment-lifecycle-static-smoke.js` ۱۰ assertion ایستا و آزمون `tests/woocommerce-channel-checkout-smoke.js` ۱۴ assertion ایستا دارد؛ این‌ها آزمون PHP یا آزمون زندهٔ Bot API نیستند.
- آزمون PHP `tests/channel-api-smoke.php` (۶۳ بررسی مورد انتظار) و سایر آزمون‌های PHP اجرا نشدند؛ PHP CLI در محیط نصب نیست. PHP lint، آزمون PHP، WordPress/WooCommerce واقعی، callback یا پرداخت زنده تأیید نشده‌اند.
- اسکن case-insensitive برای شناسهٔ تجاری حذف‌شده نتیجه‌ای نداشت. نام‌های صفحه/option/group و داشبورد در آزمون‌های JavaScript موجود همچنان پوشش داده می‌شوند.
- پیش از release، روی staging این مسیرها را با بات آزمایشی بله و WooCommerce بررسی کنید: callback معمولی و legacy، contact خود کاربر و contact شخص دیگر، پیام group با مقصد خصوصی، دریافت/رد pre-checkout، رزرو موجودی سفارش‌های هم‌زمان و محصولات variable، نبود/تطبیق `Transaction.userID`، تأیید `inquireTransaction`، invoice Mini App و ثبت نهایی سفارش.

## منابع رسمی بله

- [مستندات Bot API بله](https://docs.bale.ai/)
- [مستندات Mini App بله](https://docs.bale.ai/miniapp)
- [صفحهٔ توسعه‌دهندگان بله](https://bale.ai/dev)
- [answerCallbackQuery](https://docs.bale.ai/#answercallbackquery)
- [createInvoiceLink](https://docs.bale.ai/#createinvoicelink)
- [پرداخت و sendInvoice](https://docs.bale.ai/#sendinvoice)
- [مرجع کد WooCommerce برای `wc_get_held_stock_quantity` و `wc_reserve_stock_for_order`](https://woocommerce.github.io/code-reference/files/woocommerce-includes-wc-stock-functions.html)
