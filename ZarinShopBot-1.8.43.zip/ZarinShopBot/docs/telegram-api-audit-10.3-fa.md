# ممیزی قابلیت‌های Telegram در ZarinShopBot — مبنای Bot API 10.3

**تاریخ ممیزی:** ۲۴ اکتبر ۲۰۲۶  
**مبنای رسمی:** Bot API 10.3؛ آخرین تغییر ثبت‌شده در مستند changelog رسمی در ۲۴ اوت ۲۰۲۶. صفحهٔ کامل Bot API از ابزار مرور مستقیم 403 می‌دهد، بنابراین جزئیات نسخه از نتایج قابل‌دسترسیِ جست‌وجوی دامنهٔ رسمی و changelog رسمی استخراج شده‌اند. این سند ممیزی سورس است، نه آزمون runtime یا تأیید اتصال زنده.

## آنچه در سورس فعلی دیده شد

- مسیرهای متداول ارسال/ویرایش پیام، callback، رسانه، webhook، ثبت منوی فرمان و `getChatMember` وجود دارند.
- checkout ووکامرس با invoice درگاه Telegram و همچنین مسیر Telegram Stars در شرایط فعلی پلاگین (سبد دیجیتال و تنظیم فعال) پیاده شده است.
- Telegram Mini App، وب‌هوک، کنترل سفارش، عضویت اجباری Telegram، اعلان‌ها و فرمان‌های فروشگاه در سورس موجودند.
- در شاخهٔ مبنا Rich Messages/Drafts، Live Photos، Paid Media، recurring Stars subscriptions، ephemeral messages و paid broadcasts پیاده‌سازی نشده بودند. در این انتشار بعدی، Rich Messages به‌صورت opt-in برای پاسخ‌های متنی افزوده شده است؛ Drafts، Live Photos، Paid Media، اشتراک تکرارشونده، ephemeral و paid broadcast هنوز جریان کاربری کامل ندارند.
- نتیجه فقط مرور استاتیک فایل‌هاست؛ تست با توکن واقعی یا Telegram/WooCommerce زنده انجام نشده است.

## قابلیت‌های تازهٔ رسمی و ارزش افزودهٔ احتمالی

| اولویت | قابلیت | وضعیت در افزونه | پیشنهاد و ملاحظات |
|---|---|---|---|
| ۱ | **Rich Messages و Rich Message Drafts** (Bot API 10.1؛ ۱۱ ژوئن ۲۰۲۶) | در سورس فعلی پیدا نشد | بهترین ارتقای تجربه برای توضیحات محصول/راهنما: محتوای ساخت‌یافته، جدول، مدیا، RTL و پاسخ جریانی. باید لایهٔ مستقل و fallback متنی داشته باشد؛ جایگزینی یک‌بارهٔ تمام `sendMessage`ها ریسک ناسازگاری دارد. |
| ۲ | **Live Photos** (Bot API 10.0؛ ۸ مه ۲۰۲۶) | در سورس فعلی پیدا نشد | برای کاتالوگ تصویری فروشگاه مناسب است، اما نیازمند مدیریت فایل/آپلود، محدودیت‌های اندازه و زمان، تبدیل/ذخیرهٔ media ID و fallback در کانال‌های دیگر است. |
| ۳ | **اشتراک‌های Telegram Stars** برای فاکتورهای تکرارشونده | پشتیبانی از پرداخت Stars یک‌باره برای سبد دیجیتال وجود دارد؛ چرخهٔ اشتراک پیدا نشد | ارزش تجاری بالا برای محتوای دیجیتال/عضویت. قبل از کدنویسی باید نگاشت به WooCommerce Subscriptions یا مدل اشتراک داخلی، تمدید، لغو، عدم پرداخت، بازپرداخت، شناسهٔ هر چرخه و رویدادهای تکراری طراحی و تست شود. مستند رسمی می‌گوید `createInvoiceLink` اشتراک Stars با دورهٔ فعلی ۳۰ روزه را پشتیبانی می‌کند. |
| ۴ | **اشتراک کانال با invite link پولی Stars** | در سورس فعلی پیدا نشد | برای فروش عضویت کانال کاربردی است؛ نیازمند دسترسی ادمین `can_invite_users` و نگاشت عضویت با سفارش/تمدید. این API به‌تنهایی جای `getChatMember` را در کانال‌های دیگر نمی‌گیرد. |
| ۵ | **Paid Media** (عکس/ویدئو با پرداخت Stars) | در سورس فعلی پیدا نشد | برای فروش محتوای دانلودیِ منفرد مناسب است، ولی با checkout عمومی ووکامرس یک جریان متفاوت دارد. قبل از اجرا باید payload امن، ثبت خرید، تحویل پس از تأیید و سیاست refund/تکرار مشخص شود. |
| ۶ | **Ephemeral messages و Guest Mode** (Bot API 10.3) | در سورس فعلی پیدا نشد | اولویت پایین‌تر برای فروشگاه عمومی؛ می‌تواند برای پیش‌نمایش موقت/پشتیبانی مفید باشد، اما باید قابلیت کلاینت، updateهای جدید، مالکیت گیرنده و سیاست نگهداری پیام را پوشش دهد. |
| ۷ | **Paid broadcasts** | در سورس فعلی پیدا نشد | ارتقای throughput در ازای Stars؛ ارزشمند فقط برای فروشگاه‌هایی با حجم بالای broadcast. نیازمند کنترل هزینه، quota، rate-limit و تأیید صریح مدیر است؛ نباید بی‌سروصدا فعال شود. |

## تغییرهای انجام‌شده در نسخهٔ بعدی

- افزودن حالت opt-in برای `sendRichMessage` (Bot API 10.1+) فقط برای Telegram، با `is_rtl` متناسب با زبان و حفظ دکمه‌ها/پارامترهای مجاز.
- fallback به `sendMessage` فقط در پاسخ صریح 400/404؛ پس از timeout، 429 یا 5xx retry/fallback انجام نمی‌شود تا پیام تکراری ارسال نشود. گزینه در پنل خاموش است و staging باید قبل از فعال‌سازی بررسی شود.
- اضافه‌شدن wrapperهای transport برای `sendRichMessage`, `sendRichMessageDraft`, `sendLivePhoto`, `sendPaidMedia` و `createChatSubscriptionInviteLink`; این wrapperها دسترسی روش API می‌دهند، اما به‌تنهایی جریان فروش/پرداخت کامل برای این قابلیت‌ها نمی‌سازند.
- `Update` انواع اشتراک، توقف تولید پیام و چند envelope جدید را می‌شناسد؛ update بدون handler تجاری log و acknowledgement می‌شود و به‌عنوان کاربر ساختگی پردازش نمی‌شود.
- مسیر invoice provider تلگرام برای `pre_checkout_query` شناسهٔ کاربر، ارز، مبلغ دقیق در واحد خرد ISO 4217، وضعیت سفارش و موجودی را دوباره بررسی می‌کند؛ در صورت پشتیبانی WooCommerce، موجودی سفارش را hold می‌کند. تکمیل از `WC_Order::payment_complete()` انجام می‌شود.
- موفقیت provider/Stars با قفل موقت per-order و بارگذاری مجدد سفارش پس از قفل محافظت شده؛ update تکراریِ همان charge idempotent است و charge متعارض یا order تغییرکرده به یادداشت/meta بازبینی دستی می‌رود. association فاکتور در timeout مبهم transport نگه داشته می‌شود تا پرداخت دیررس قابل reconcile باشد.
- تبدیل provider بر اساس minor unit ارز انجام می‌شود، نه تنظیم نمایشی اعشار WooCommerce؛ Stars با مبلغ نهایی ووکامرس تطبیق می‌یابد و اگر tax/fee/shipping اضافه قابل تبدیل نباشد، مسیر Stars fail-closed می‌شود.
- پاسخ pre-checkout timeout حداکثر ۶ ثانیه دارد و شکست JSON encoding در transport خطای WordPress برمی‌گرداند. برای این تغییرها ۱۶ assertion استاتیک افزوده شده است.
- محدودیت را حفظ کنید: در محیط توسعه PHP CLI موجود نیست؛ PHP lint و آزمون runtime PHP/WordPress اجرا نشده‌اند. هر ۱۹ تست JavaScript/static موجود پاس شده‌اند، اما پرداخت زنده و webhookهای Telegram/Bale/Rubika اینجا قابل اثبات نیستند.

## ترتیب اجرایی پیشنهادی

1. Rich Messages محدود به کارت محصول/راهنما با fallback امن به متن و تست RTL.
2. پشتیبانی Live Photo در کاتالوگ با نگهداری شناسهٔ فایل و محدودیت‌های آپلود.
3. اشتراک Stars فقط پس از تعیین قرارداد lifecycle ووکامرس (renew/cancel/refund/reconciliation) و تست آفلاین/محیط staging.
4. Paid Media و invite-link اشتراکی به‌عنوان دو محصول جدا از checkout عادی.
5. Ephemeral/paid broadcast پس از سنجش نیاز واقعی فروشگاه و افزودن داشبورد هزینه و update handling.

## نکتهٔ نسخه و داده

Bot API 10.1 معرفی Rich Messages و Drafts را ثبت می‌کند؛ 10.2 در ۱۴ ژوئیهٔ ۲۰۲۶ فیلدهای media و block را گسترش می‌دهد؛ 10.3 در ۲۴ اوت ۲۰۲۶ پارامترهای ephemeral را معرفی می‌کند. هنگام توسعه باید parser آپدیت‌ها و allowlistهای `allowed_updates` نیز با فیلدهای تازه بازبینی شوند، نه فقط senderها.

## منابع رسمی

- [Telegram Bot API](https://core.telegram.org/bots/api) — Recent changes, Rich Messages, Live Photos, payments و available methods.
- [Telegram Bot API changelog](https://core.telegram.org/bots/api-changelog) — تاریخچهٔ رسمی نسخه‌ها و تغییرات.
- [Telegram Payments](https://core.telegram.org/bots/payments) — جریان پرداخت و provider invoice.
- [Telegram Stars Payments](https://core.telegram.org/bots/payments-stars) — پرداخت‌های Stars و محدودیت‌های مرتبط.

## روبیکا: محدودیت فعلی پرداخت/عضویت

در API عمومی رسمی روبیکا بررسی‌شده، متد invoice/payment تأییدپذیر یا lookup عضویت کاربر مانند `getChatMember` مستند نشده است. بنابراین افزونه نباید رسید/تأیید پرداخت ساختگی بسازد و نباید با دکمهٔ «بررسی عضویت» نتیجهٔ عضویت را حدس بزند. مسیر فعلی روبیکا به لینک پرداخت امن سفارش ووکامرس و درگاه‌های فعال سایت متکی است. پیاده‌سازی بومی فقط پس از دریافت مستندات رسمی شامل ایجاد پرداخت، callback/استعلام سروری، شناسهٔ تراکنش و قواعد مبلغ/ارز قابل انجام است.
