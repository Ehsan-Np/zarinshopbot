<?php
/* Modified 2026-10-23 by Ehsan NaderiPanah / Zarincode.com. Derived code remains under GPL-2.0-or-later; upstream notices are retained. */
/** Settings validation, connection synchronization and private diagnostics. */
if (!defined('ABSPATH')) exit;

/**
 * Move persisted data from pre-Zarincode releases without dropping a store's
 * bot token, webhook URL, subscribers, carts or wishlist information.
 *
 * Legacy names are deliberately assembled here rather than used elsewhere:
 * this is the single, removable compatibility boundary for upgrades.
 */
function zarincode_migrate_legacy_storage() {
    // This file is also loaded by lightweight diagnostics/tests. Migration is
    // meaningful only after the complete WordPress Options API is available.
    if (!function_exists('get_option') || !function_exists('add_option') || !function_exists('update_option')) return;
    if (get_option('zarincode_storage_migrated')) return;

    $legacy_settings = 'wp_' . 'sale' . 'telegram' . 'bot';
    $legacy_key = $legacy_settings . '_apikey';
    $legacy_version = $legacy_settings . '_option_ver';
    $legacy_user_type = 'sale' . 'tbot_user';
    $legacy_group_type = 'sale' . 'tbot_group';

    $settings = get_option('zarincode_settings', null);
    if (!is_array($settings)) {
        $settings = get_option($legacy_settings, []);
        if (is_array($settings)) add_option('zarincode_settings', $settings, '', false);
    }
    if (!get_option('zarincode_webhook_key')) {
        $key = get_option($legacy_key);
        if (is_string($key) && $key !== '') add_option('zarincode_webhook_key', $key, '', false);
    }
    if (!get_option('zarincode_option_version')) {
        $version = get_option($legacy_version);
        if (is_string($version) && $version !== '') add_option('zarincode_option_version', $version, '', false);
    }

    global $wpdb;
    if (isset($wpdb) && isset($wpdb->posts, $wpdb->postmeta, $wpdb->usermeta)) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time legacy migration.
        $wpdb->query($wpdb->prepare("UPDATE {$wpdb->posts} SET post_type = %s WHERE post_type = %s", 'zarincode_user', $legacy_user_type));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time legacy migration.
        $wpdb->query($wpdb->prepare("UPDATE {$wpdb->posts} SET post_type = %s WHERE post_type = %s", 'zarincode_group', $legacy_group_type));
        foreach (['_saved_cart', '_wishlist', '_wishlist_prices', '_stock_subscribers'] as $suffix) {
            $legacy_meta_key = '_' . 'sale' . 'tbot' . $suffix;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time legacy migration.
            $wpdb->query($wpdb->prepare("UPDATE {$wpdb->postmeta} SET meta_key = %s WHERE meta_key = %s", '_zarincode' . $suffix, $legacy_meta_key));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time legacy migration.
            $wpdb->query($wpdb->prepare("UPDATE {$wpdb->usermeta} SET meta_key = %s WHERE meta_key = %s", '_zarincode' . $suffix, $legacy_meta_key));
        }
    }

    $legacy_logs = get_option('wp_' . 'sale' . '_telegram' . '_bot_structured_logs', null);
    if (is_array($legacy_logs) && !get_option('wp_zarincode_activity_log')) {
        add_option('wp_zarincode_activity_log', $legacy_logs, '', false);
    }
    update_option('zarincode_storage_migrated', gmdate('c'), false);
}

function zarincode_private_key($key) {
    return (bool) preg_match('/token|password|secret|authorization|api_?key|plugin_license/i', (string) $key);
}

function zarincode_export_options(array $options) {
    foreach ($options as $key => $value) {
        if (zarincode_private_key($key) || preg_match('/proxy_(address|username)/', $key)) {
            unset($options[$key]);
        } elseif (is_array($value)) {
            $options[$key] = zarincode_export_options($value);
        }
    }
    return $options;
}

function zarincode_redact($value, $key = '') {
    if (in_array($key, ['command', 'route'], true) && is_string($value) && preg_match('~\A/[A-Za-z_]+[0-9]*(?:V[0-9]+)?\z~', $value)) return $value;
    if (zarincode_private_key($key) || preg_match('/\A(?:chat_id|username|phone|email|address|first_name|last_name|input|command|route|text)\z/i', $key)) return '[redacted]';
    if (is_array($value)) {
        foreach ($value as $k => $v) $value[$k] = zarincode_redact($v, (string) $k);
        return $value;
    }
    if (!is_string($value)) return $value;
    $options = (array) get_option('zarincode_settings', []);
    foreach ($options as $k => $v) {
        if (zarincode_private_key($k) && is_scalar($v) && (string) $v !== '') $value = str_replace((string) $v, '[redacted]', $value);
    }
    if (function_exists('zarincode_get_telegram_token')) {
        $telegram_token = zarincode_get_telegram_token($options);
        if ($telegram_token !== '') $value = str_replace($telegram_token, '[redacted]', $value);
    }
    $value = preg_replace('~https?://[^\s<>"\']+~i', '[url redacted]', $value);
    $value = preg_replace('/\b[0-9]{5,}:[A-Za-z0-9_-]+\b/', '[token redacted]', $value);
    $value = preg_replace('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', '[email redacted]', $value);
    $value = preg_replace('/\b\d{7,}\b/', '[number redacted]', $value);
    return function_exists('mb_substr') ? mb_substr($value, 0, 500) : substr($value, 0, 500);
}

function zarincode_validate_settings(array $input, array $previous) {
    $rules = [
        'token' => '/\A[0-9]+:[A-Za-z0-9_-]+\z/',
        'webhook_secret_token' => '/\A[A-Za-z0-9_-]{1,256}\z/',
        'username' => '/\A@?[A-Za-z0-9_]{5,32}\z/',
    ];
    foreach ($input as $key => $value) {
        $invalid = false;
        if (isset($rules[$key])) {
            $invalid = !is_scalar($value) || ((string) $value !== '' && !preg_match($rules[$key], (string) $value));
        } elseif (preg_match('/(?:url|_link)$/', $key)) {
            $invalid = !is_scalar($value) || ((string) $value !== '' && (!filter_var($value, FILTER_VALIDATE_URL) || !in_array(strtolower((string) wp_parse_url($value, PHP_URL_SCHEME)), ['https', 'http'], true)));
        }
        if ($invalid) {
            $input[$key] = $previous[$key] ?? '';
            // translators: %s: Setting field key name.
            add_settings_error('zarincode_settings', 'invalid_' . $key, sprintf(__('Invalid value for %s. The previous value was preserved.', 'zarinshopbot'), $key));
        }
    }
    $ranges = ['display_productsperpage' => [1, 50], 'display_product_excerpt_length' => [0, 1000], 'proxy_port' => [1, 65535], 'proxy_port_fallback' => [1, 65535], 'telegram_http_timeout' => [5, 20], 'telegram_api_retries' => [0, 2], 'zarincode_log_retention_days' => [1, 30]];
    foreach ($ranges as $key => $range) {
        if (isset($input[$key])) {
            if (!is_scalar($input[$key]) || !is_numeric($input[$key])) {
                // translators: %s: Setting field key name.
                add_settings_error('zarincode_settings', 'invalid_' . $key, sprintf(__('Invalid value for %s. The previous value was preserved.', 'zarinshopbot'), $key));
                $input[$key] = $previous[$key] ?? $range[0];
            }
            $input[$key] = (string) max($range[0], min($range[1], (int) $input[$key]));
        }
    }
    $enums = [
        'newest_orderby' => ['date', 'modified', 'popularity', 'price'],
        'search_default_sort' => ['date', 'popularity', 'price_asc', 'price_desc', 'on_sale'],
        'zarincode_log_level' => ['errors', 'all'],
        'mode' => ['0', '1'],
        'default_language' => ['fa', 'en', 'de', 'es', 'fr', 'it', 'pt', 'tr', 'ar', 'ru', 'zh', 'ja', 'ur'],
        'wpml_language_sync' => ['0', '1'],
        'customer_account_policy' => ['guest', 'optional', 'account'],
        'customer_login_identifier' => ['email', 'phone', 'either'],
        'phone_sms_verification' => ['0', '1'],
        // Phone mode values are consumed by order-flow prompts: mobile/landline, mobile, landline, or disabled.
        'register_req_phone' => ['3', '1', '2', '0'],
        'sms_provider' => ['kavenegar', 'melipayamak'],

    ];
    foreach ($enums as $key => $values) {
        if (isset($input[$key]) && !in_array((string) $input[$key], $values, true)) $input[$key] = $previous[$key] ?? $values[0];
    }
    if (array_key_exists('mode', $input)) $input['mode'] = '0';
    return $input;
}

function zarincode_sanitize_membership_requirements($requirements) {
    if (!is_array($requirements)) return [];
    $clean = [];
    foreach (array_slice($requirements, 0, 10) as $requirement) {
        if (!is_array($requirement)) continue;
        $chat_id = sanitize_text_field($requirement['chat_id'] ?? '');
        $bale_chat_id = sanitize_text_field($requirement['bale_chat_id'] ?? '');
        if (($chat_id !== '' && !preg_match('/\A(?:@?[A-Za-z0-9_]{4,}|-?\d{5,})\z/', $chat_id)) || ($bale_chat_id !== '' && !preg_match('/\A(?:@?[A-Za-z0-9_]{4,}|-?\d{5,})\z/', $bale_chat_id))) continue;
        if ($chat_id === '' && $bale_chat_id === '') continue;
        $url = esc_url_raw($requirement['url'] ?? '');
        $bale_url = esc_url_raw($requirement['bale_url'] ?? '');
        foreach (['url', 'bale_url'] as $url_key) {
            $candidate = $url_key === 'url' ? $url : $bale_url;
            if ($candidate !== '' && !in_array(strtolower((string) wp_parse_url($candidate, PHP_URL_SCHEME)), ['https', 'http'], true)) {
                if ($url_key === 'url') $url = ''; else $bale_url = '';
            }
        }
        $clean[] = [
            'enabled' => !empty($requirement['enabled']) ? '1' : '0',
            'type'    => in_array(($requirement['type'] ?? 'channel'), ['channel', 'group'], true) ? $requirement['type'] : 'channel',
            'title'   => sanitize_text_field($requirement['title'] ?? ''),
            'chat_id' => $chat_id,
            'url'     => $url,
            'bale_chat_id' => $bale_chat_id,
            'bale_url' => $bale_url,
        ];
    }
    return $clean;
}

function zarincode_connection_values($options) {
    $options = (array) $options;
    $values = [];
    foreach (['webhook_secret_token', 'mode', 'testmod', 'proxy_status', 'proxy_address', 'proxy_port', 'proxy_type', 'proxy_username', 'proxy_password_enc', 'proxy_status_fallback', 'proxy_address_fallback', 'proxy_port_fallback', 'proxy_type_fallback', 'proxy_username_fallback', 'proxy_password_enc_fallback'] as $key) $values[$key] = (string) ($options[$key] ?? '');
    $values['token'] = function_exists('zarincode_get_telegram_token') ? zarincode_get_telegram_token($options) : (string) ($options['token'] ?? '');
    $values['telegram_enabled'] = array_key_exists('telegram_enabled', $options) ? (string) $options['telegram_enabled'] : ($values['token'] !== '' ? '1' : '0');
    return $values;
}

function zarincode_sync_changed_connection($old, $new) {
    if (defined('ZARINCODE_MIGRATING_STORAGE') || (function_exists('did_action') && !did_action('init'))) return;
    $old_connection = zarincode_connection_values($old);
    $new_connection = zarincode_connection_values($new);
    if ($old_connection === $new_connection || $new_connection['token'] === '' || (function_exists('zarincode_telegram_enabled') && !zarincode_telegram_enabled())) return;
    if (($old_connection['webhook_secret_token'] ?? '') !== ($new_connection['webhook_secret_token'] ?? '') || $old_connection['token'] !== $new_connection['token']) delete_option('zarincode_webhook_header_status');
    $result = \ZarinShopBot\Core\WooBot::setHook(1);
    update_option('zarincode_webhook_sync_status', ['ok' => $result !== false, 'checked_at' => gmdate('c')], false);
}
add_action('update_option_zarincode_settings', 'zarincode_sync_changed_connection', 10, 2);
add_action('add_option_zarincode_settings', function ($name, $value) { zarincode_sync_changed_connection([], $value); }, 10, 2);

function zarincode_prune_logs() {
    $days = max(1, min(30, (int) (zarincode_option('zarincode_log_retention_days') ?: 7)));
    $cutoff = time() - $days * 86400;
    $logs = (array) get_option('wp_zarincode_activity_log', []);
    foreach ($logs as &$entry) {
        if (is_array($entry)) {
            if (!isset($entry['timestamp'])) {
                $date = date_create_immutable($entry['time'] ?? '', wp_timezone());
                $entry['timestamp'] = $date ? $date->getTimestamp() : 0;
            }
            $entry = zarincode_redact($entry);
        }
    }
    unset($entry);
    $logs = array_values(array_filter($logs, function ($entry) use ($cutoff) {
        return is_array($entry) && isset($entry['timestamp']) && (int) $entry['timestamp'] >= $cutoff;
    }));
    update_option('wp_zarincode_activity_log', array_slice($logs, -500), false);
    // Retire duplicate stores that contained unredacted free-form messages.
    delete_option('wp_zarincode_log');
    delete_option('wp_zarincode_structured_logs');
    return $logs;
}
add_action('zarincode_prune_logs', 'zarincode_prune_logs');
add_action('admin_init', function () {
    zarincode_prune_logs();
    if (!wp_next_scheduled('zarincode_prune_logs')) wp_schedule_event(time() + 86400, 'daily', 'zarincode_prune_logs');
});
add_action('admin_post_zarincode_download_logs', function () {
    if (!current_user_can('manage_options')) wp_die(esc_html__('Permission denied', 'zarinshopbot'));
    check_admin_referer('zarincode_download_logs');
    nocache_headers();
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="zarincode-diagnostics.json"');
    echo wp_json_encode(zarincode_redact(zarincode_prune_logs()), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
});
add_action('admin_post_zarincode_download_activity_txt', function () {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Permission denied', 'zarinshopbot'), '', array('response' => 403));
    }
    check_admin_referer('zarincode_download_activity_txt');
    require_once __DIR__ . '/includes/class-zarinshopbot-activity-logs.php';

    $requested_source = isset($_GET['source']) ? sanitize_key(wp_unslash($_GET['source'])) : 'all';
    $result = ZarinShopBot_Activity_Logs::query($requested_source);
    $source = $result['source'];
    $safe_field = static function ($value) {
        if (!is_scalar($value)) return '';
        $value = str_replace(array("\r", "\n", "\t"), ' ', (string) $value);
        return trim((string) preg_replace('/[\x00-\x1F\x7F]+/', ' ', $value));
    };
    $lines = array(
        'ZarinShopBot activity log export',
        'Filter: ' . $safe_field($source),
        'Exported: ' . $safe_field(current_time('mysql')),
        'Records: ' . count($result['entries']),
        str_repeat('-', 72),
    );
    foreach ($result['entries'] as $entry) {
        $lines[] = '[' . $safe_field($entry['time'] ?? '') . '] [' . strtoupper($safe_field($entry['platform'] ?? 'system')) . '] '
            . $safe_field($entry['event'] ?? 'event')
            . ' | chat_id=' . $safe_field($entry['chat_id'] ?? '')
            . ' | ' . $safe_field($entry['description'] ?? '');
    }

    nocache_headers();
    status_header(200);
    header('Content-Type: text/plain; charset=UTF-8');
    header('Content-Disposition: attachment; filename="zarinshopbot-activity-' . gmdate('Ymd-His') . '.txt"');
    echo implode("\r\n", $lines) . "\r\n";
    exit;
});

add_action('admin_post_zarincode_register_webhook', function () {
    if (!current_user_can('manage_options')) wp_die(esc_html__('Permission denied', 'zarinshopbot'));
    check_admin_referer('zarincode_register_webhook');
    $options = (array) get_option('zarincode_settings', []);
    zarincode_sync_changed_connection([], $options);
    wp_safe_redirect(admin_url('admin.php?page=zarincode_zarinshopbot_setting&settings-updated=1'));
    exit;
});

zarincode_migrate_legacy_storage();
