<?php
/**
 * Permanent data cleanup for ZarinShopBot.
 * Runs only when WordPress deletes this plugin, never on deactivation.
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/** Delete this site's ZarinShopBot data without touching shared WordPress/WooCommerce records. */
function zarinshopbot_uninstall_current_site() {
    global $wpdb;

    // These are the plugin's currently owned option names.
    $exact_options = array(
        'zarincode_settings', 'zarinshopbot_channels',
        'zarinshopbot_channel_registered_routes', 'woocommerce_zarinshopbot_card_transfer_settings',
        'zarincode_webhook_key', 'zarincode_option_version', 'zarincode_storage_migrated', 'zsb_phone_schema_version',
        'zarincode_identifier_migration_1_5_0', 'zarincode_free_edition_migrated',
        'zarinshopbot_direct_webhook_migrated', 'zarinshopbot_callback_updates_migrated',
        'zarincode_webhook_header_status', 'zarincode_webhook_sync_status',
        'zarincode_wpml_strings_hash', 'zarincode_telegram_menu_sync', 'zarincode_starter_copy_version',
        'wp_zarincode_activity_log', 'wp_zarincode_log', 'wp_zarincode_structured_logs',
        'sa_te_bo_li', 'sa_te_bo_li_',
        'wp_zarincode_proxy_health', 'widget_zarincode_widget',
    );
    foreach ($exact_options as $option_name) {
        delete_option($option_name);
    }
    $sidebars_widgets = get_option('sidebars_widgets', array());
    if (is_array($sidebars_widgets)) {
        $remove_owned_widgets = function ($widgets) use (&$remove_owned_widgets) {
            foreach ($widgets as $key => $widget) {
                if (is_array($widget)) {
                    $widgets[$key] = $remove_owned_widgets($widget);
                } elseif (is_string($widget) && preg_match('/\Azarincode_widget-\d+\z/', $widget)) {
                    unset($widgets[$key]);
                }
            }
            return $widgets;
        };
        update_option('sidebars_widgets', $remove_owned_widgets($sidebars_widgets), false);
    }

    // Prefixes are confined to identifiers currently owned by this plugin.
    $option_prefixes = array('zarinshopbot_', 'zsb_claim_', '_zsb_bot_download_delivery_lock_', 'zarincode_order_lock_');
    foreach ($option_prefixes as $prefix) {
        $like = $wpdb->esc_like($prefix) . '%';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Uninstall removes only explicitly namespaced plugin options.
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like));
    }

    // Remove only our setting from legacy taxonomy option blobs; preserve other extensions' values.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Targeted cleanup of legacy plugin term settings.
    $taxonomy_options = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
        $wpdb->esc_like('taxonomy_') . '%'
    ));
    foreach ((array) $taxonomy_options as $option_name) {
        $value = get_option($option_name, null);
        if (!is_array($value) || !array_key_exists('zarincode_hide_cat', $value)) {
            continue;
        }
        unset($value['zarincode_hide_cat']);
        if ($value) {
            update_option($option_name, $value, false);
        } else {
            delete_option($option_name);
        }
    }

    // Delete plugin-owned transients, including timeout rows, without sweeping every shared Zarincode key.
    $transient_prefixes = array('zarinshopbot_', 'zsb_', 'zarincode_rate_', 'zarincode_order_created_', 'zarincode_payment_', 'zarincode_prod_');
    foreach ($transient_prefixes as $prefix) {
        foreach (array('_transient_', '_transient_timeout_') as $transient_type) {
            $like = $wpdb->esc_like($transient_type . $prefix) . '%';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Targeted uninstall of this plugin's transient rows.
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like));
        }
    }
    $exact_transients = array(
        'zarincode_sales_stats_v3', 'zarincode_sales_stats_v4', 'zarincode_sales_stats_v5',
        'zarincode_platform_sales_v1', 'zarincode_platform_sales_v2',
        'zarincode_top_bot_products_v3_5', 'zarincode_telegram_menu_backoff',
    );
    foreach ($exact_transients as $transient_name) {
        foreach (array('_transient_', '_transient_timeout_') as $transient_type) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Exact plugin transient key.
            $wpdb->delete($wpdb->options, array('option_name' => $transient_type . $transient_name), array('%s'));
        }
    }

    // Clear plugin-owned scheduled WP-Cron events.
    $cron_hooks = array(
        'zarincode_check_abandoned_cart', 'zarincode_retry_send_message',
        'zarincode_prune_logs', 'zarincode_process_broadcast',
        'zarincode_notify_order_created', 'zarincode_notify_order_status_changed',
        'zarincode_notify_payment_completed', 'zarincode_notify_back_in_stock',
    );
    foreach ($cron_hooks as $hook) {
        wp_clear_scheduled_hook($hook);
        if (function_exists('as_unschedule_all_actions')) {
            foreach (array('zarinshopbot', 'zarincode') as $group) {
                as_unschedule_all_actions($hook, null, $group);
            }
        }
    }
    // Also clear any remaining Action Scheduler records when its API was not loaded during uninstall.
    $actions_table = $wpdb->prefix . 'actionscheduler_actions';
    $logs_table = $wpdb->prefix . 'actionscheduler_logs';
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $actions_table)) === $actions_table) {
        $hook_placeholders = implode(', ', array_fill(0, count($cron_hooks), '%s'));
        $action_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT action_id FROM {$actions_table} WHERE hook IN ({$hook_placeholders})",
            $cron_hooks
        ));
        if ($action_ids && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $logs_table)) === $logs_table) {
            $ids = implode(',', array_map('absint', $action_ids));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Action IDs belong only to this plugin's uniquely named hooks.
            $wpdb->query("DELETE FROM {$logs_table} WHERE action_id IN ({$ids})");
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only this plugin's exact scheduled hook names.
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$actions_table} WHERE hook IN ({$hook_placeholders})",
            $cron_hooks
        ));
    }

    // Remove subscriber/group records owned by the plugin (including their metadata and relations).
    foreach (array('zarincode_user', 'zarincode_group') as $post_type) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Fetch IDs only; deletion uses the WordPress API.
        $post_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s",
            $post_type
        ));
        foreach ((array) $post_ids as $post_id) {
            wp_delete_post((int) $post_id, true);
        }
    }

    // Remove legacy/current plugin taxonomy terms without deleting terms still attached elsewhere.
    if (!empty($wpdb->term_taxonomy) && !empty($wpdb->term_relationships)) {
        $taxonomies = array('zarincode_group');
        $placeholders = implode(', ', array_fill(0, count($taxonomies), '%s'));
        $query = $wpdb->prepare(
            "SELECT term_taxonomy_id, term_id FROM {$wpdb->term_taxonomy} WHERE taxonomy IN ({$placeholders})",
            $taxonomies
        );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Remove only this plugin's historical taxonomy relations.
        $owned_taxonomy_rows = $wpdb->get_results($query);
        if ($owned_taxonomy_rows) {
            $ids = implode(',', array_map(static function ($row) { return absint($row->term_taxonomy_id); }, $owned_taxonomy_rows));
            $term_ids = array_unique(array_map(static function ($row) { return absint($row->term_id); }, $owned_taxonomy_rows));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- IDs originate from this plugin's taxonomy rows.
            $wpdb->query("DELETE FROM {$wpdb->term_relationships} WHERE term_taxonomy_id IN ({$ids})");
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- IDs originate from this plugin's taxonomy rows.
            $wpdb->query("DELETE FROM {$wpdb->term_taxonomy} WHERE term_taxonomy_id IN ({$ids})");
            $term_ids_sql = implode(',', array_map('absint', $term_ids));
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Candidate IDs came from the plugin's taxonomy rows.
            $wpdb->query("DELETE t FROM {$wpdb->terms} t LEFT JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id WHERE t.term_id IN ({$term_ids_sql}) AND tt.term_id IS NULL");
        }
    }

    // Clear only plugin-prefixed metadata globally. Do not remove WooCommerce orders/products.
    $meta_tables = array(
        array('table' => $wpdb->postmeta, 'key_column' => 'meta_key'),
        array('table' => $wpdb->usermeta, 'key_column' => 'meta_key'),
        array('table' => $wpdb->termmeta, 'key_column' => 'meta_key'),
    );
    $hpos_order_meta = $wpdb->prefix . 'wc_orders_meta';
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $hpos_order_meta)) === $hpos_order_meta) {
        $meta_tables[] = array('table' => $hpos_order_meta, 'key_column' => 'meta_key');
    }
    foreach ($meta_tables as $meta_table) {
        if (empty($meta_table['table'])) continue;
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $meta_table['table']));
        if ($exists !== $meta_table['table']) continue;
        foreach (array('_zarincode', '_zarinshopbot', 'zarinshopbot_', '_zsb', 'zsb_') as $prefix) {
            $like = $wpdb->esc_like($prefix) . '%';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only plugin-namespaced metadata.
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$meta_table['table']} WHERE {$meta_table['key_column']} LIKE %s",
                $like
            ));
        }
    }

    // Remove legacy product-publishing markers only from WooCommerce product rows.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Exact plugin keys on product rows only.
    $wpdb->query($wpdb->prepare(
        "DELETE pm FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_type = %s AND pm.meta_key IN (%s, %s)",
        'product', 'telegram_future_publish', 'zarincode_last_sent'
    ));

    // These two unprefixed order keys are used by the plugin only when its platform marker is present.
    $order_meta_tables = array($wpdb->postmeta);
    $hpos_meta_table = $wpdb->prefix . 'wc_orders_meta';
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $hpos_meta_table)) === $hpos_meta_table) {
        $order_meta_tables[] = $hpos_meta_table;
    }
    foreach ($order_meta_tables as $table) {
        $is_hpos = ($table === $hpos_meta_table);
        $owner_column = $is_hpos ? 'order_id' : 'post_id';
        // Remove the plugin's generic chat/order attribution only on orders marked as created by one of its channels.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Exact order metadata keys, limited to plugin channel orders.
        $wpdb->query("DELETE target FROM {$table} target INNER JOIN {$table} source ON source.{$owner_column} = target.{$owner_column} AND source.meta_key = '_order_from' AND source.meta_value IN ('telegram','bale','rubika') WHERE target.meta_key IN ('_order_from','_chat_id')");
    }

    // Drop the phone ownership index created by Phone_Accounts, then remove any remaining strictly namespaced legacy tables.
    $phone_index_table = $wpdb->prefix . 'zsb_phone_index';
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $phone_index_table)) === $phone_index_table) {
        $quoted_phone_index_table = '`' . str_replace('`', '``', $phone_index_table) . '`';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery -- Exact table name owned by this plugin.
        $wpdb->query("DROP TABLE IF EXISTS {$quoted_phone_index_table}");
    }

    $owned_table_prefix = $wpdb->prefix . 'zarinshopbot_';
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange -- Uninstall removes only strictly namespaced plugin tables.
    $database_tables = $wpdb->get_col('SHOW TABLES');
    foreach ((array) $database_tables as $table_name) {
        if (strpos((string) $table_name, $owned_table_prefix) !== 0) continue;
        $quoted_table = '`' . str_replace('`', '``', (string) $table_name) . '`';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery -- Namespace check limits this to ZarinShopBot-owned tables.
        $wpdb->query("DROP TABLE IF EXISTS {$quoted_table}");
    }

    if (function_exists('wp_cache_flush_group')) {
        wp_cache_flush_group('zarincode_bot');
    }

    // WPML strings registered under this plugin's distinct context (if WPML is installed).
    $strings_table = $wpdb->prefix . 'icl_strings';
    $translations_table = $wpdb->prefix . 'icl_string_translations';
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $strings_table)) === $strings_table) {
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $translations_table)) === $translations_table) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Exact WPML context owned by this plugin.
            $wpdb->query($wpdb->prepare(
                "DELETE tr FROM {$translations_table} tr INNER JOIN {$strings_table} s ON s.id = tr.string_id WHERE s.context IN (%s, %s, %s)",
                'ZarinShopBot', 'TeleNexa'
            ));
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Exact WPML context owned by this plugin.
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$strings_table} WHERE context IN (%s, %s, %s)",
            'ZarinShopBot', 'TeleNexa'
        ));
    }
}

/** A plugin directory is shared across a multisite install, so deletion cleans each site's plugin data. */
if (is_multisite()) {
    $blog_ids = get_sites(array('fields' => 'ids', 'number' => 0));
    foreach ((array) $blog_ids as $blog_id) {
        switch_to_blog((int) $blog_id);
        zarinshopbot_uninstall_current_site();
        restore_current_blog();
    }
} else {
    zarinshopbot_uninstall_current_site();
}

// Network options/transients are separate from each blog's options table.
if (is_multisite()) {
    $network_options = array(
        'zarinshopbot_channels', 'zarinshopbot_channel_registered_routes',
        'zarincode_settings', 'woocommerce_zarinshopbot_card_transfer_settings',
        'widget_zarincode_widget',
    );
    foreach ($network_options as $option_name) {
        delete_site_option($option_name);
    }
    global $wpdb;
    if (!empty($wpdb->sitemeta)) {
        foreach (array('zarinshopbot_') as $prefix) {
            $like = $wpdb->esc_like('_site_transient_' . $prefix) . '%';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Targeted network transient cleanup.
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s", $like));
            $like = $wpdb->esc_like('_site_transient_timeout_' . $prefix) . '%';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Targeted network transient cleanup.
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s", $like));
        }
    }
}
