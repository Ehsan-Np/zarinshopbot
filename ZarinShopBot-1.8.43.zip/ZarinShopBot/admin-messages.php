<?php
/* Modified 2026-10-23 by Ehsan NaderiPanah / Zarincode.com. Derived code remains under GPL-2.0-or-later; upstream notices are retained. */
if (!defined('ABSPATH')) exit;

function zarincode_notices() {
    global $current_screen;
    if (!isset($current_screen->post_type)) {
        return;
    }
    if ('zarincode_user' === $current_screen->post_type) {
        zarincode_footer_text_call();
        ?>
        <div class="notice notice-info is-dismissible">
            <p><?php echo esc_html__('List of users who have subscribed to your bot.', 'zarinshopbot'); ?></p>
        </div>
        <?php
    } elseif ('zarincode_group' === $current_screen->post_type) {
        zarincode_footer_text_call();
        ?>
        <div class="notice notice-info is-dismissible">
            <p>
                <?php echo esc_html__('List of groups where your bot has been added.', 'zarinshopbot'); ?><br>
                <small>
                    <?php echo esc_html__('Some ', 'zarinshopbot'); ?>
                    <strong><?php echo esc_html__('BotFather', 'zarinshopbot'); ?></strong>
                    <?php echo esc_html__(' actions could be required to get this working.', 'zarinshopbot'); ?>
                </small>
            </p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'zarincode_notices');