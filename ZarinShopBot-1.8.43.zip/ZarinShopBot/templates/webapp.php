<?php
/* Modified 2026-10-23 by Ehsan NaderiPanah (Zarincode.com). Derived code remains under GPL-2.0-or-later; bundled notices and compatibility identifiers are retained. */
if (!defined('ABSPATH')) exit;
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public Mini App language selector is read-only.
$zarincode_requested_lang = isset($_GET['lang']) ? sanitize_key(wp_unslash($_GET['lang'])) : '';
$zarincode_lang = preg_match('/\A[a-z]{2}\z/', $zarincode_requested_lang) ? $zarincode_requested_lang : 'fa';
$zarincode_is_rtl = ($zarincode_lang === 'fa');
$zarincode_is_persian = ($zarincode_lang === 'fa');
$zarincode_locale_switched = function_exists('switch_to_locale') ? switch_to_locale($zarincode_is_persian ? 'fa_IR' : 'en_US') : false;
// The provider is explicit in Bale entry links; legacy URLs remain Telegram-compatible.
$zarincode_platform = isset($_GET['platform']) ? sanitize_key(wp_unslash($_GET['platform'])) : 'telegram';
$zarincode_is_bale = ($zarincode_platform === 'bale');
$zarincode_currency = function_exists('get_woocommerce_currency_symbol') ? (string) get_woocommerce_currency_symbol() : '$';
// Some currency plugins return an HTML-encoded symbol (for example
// &#x062A;&#x0648;&#x0645;&#x0627;&#x0646;). Decode it before passing it to JavaScript.
for ($zarincode_currency_decode_attempt = 0; $zarincode_currency_decode_attempt < 3; $zarincode_currency_decode_attempt++) {
    $zarincode_decoded_currency = html_entity_decode($zarincode_currency, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($zarincode_decoded_currency === $zarincode_currency) {
        break;
    }
    $zarincode_currency = $zarincode_decoded_currency;
}
$zarincode_currency = wp_strip_all_tags($zarincode_currency);
$zarincode_site_name = get_bloginfo('name');
$zarincode_settings = (array) get_option('zarincode_settings', array());
$zarincode_brand_logo_id = absint($zarincode_settings['miniapp_brand_logo_id'] ?? 0);
$zarincode_brand_logo_url = $zarincode_brand_logo_id ? wp_get_attachment_image_url($zarincode_brand_logo_id, 'medium') : '';
$zarincode_brand_colors = array(
    'primary' => sanitize_hex_color((string) ($zarincode_settings['miniapp_brand_primary'] ?? '')) ?: '#0284c7',
    'accent' => sanitize_hex_color((string) ($zarincode_settings['miniapp_brand_accent'] ?? '')) ?: '#0ea5e9',
    'background' => sanitize_hex_color((string) ($zarincode_settings['miniapp_brand_background'] ?? '')) ?: '#ffffff',
    'text' => sanitize_hex_color((string) ($zarincode_settings['miniapp_brand_text'] ?? '')) ?: '#111827',
);
$zarincode_webapp_nonce = wp_create_nonce('zarincode_webapp_nonce');
?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr($zarincode_lang); ?>" dir="<?php echo $zarincode_is_rtl ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title><?php echo esc_html($zarincode_site_name); ?> - ZarinShopBot <?php esc_html_e('Mini App', 'zarinshopbot'); ?></title>
    <?php
    if ($zarincode_is_bale) {
        // Bale requires its bridge before any other page scripts.
        echo '<script src="https://tapi.bale.ai/miniapp.js"></script>';
    } else {
        wp_enqueue_script('telegram-web-app', 'https://telegram.org/js/telegram-web-app.js', [], null, true);
    }
    wp_enqueue_style('zarinshopbot-typography', plugins_url('assets/css/typography.css', dirname(__FILE__)), [], (string) ZARINSHOPBOT_VERSION);
    wp_enqueue_style('zarinshopbot-webapp', plugins_url('assets/css/webapp.css', dirname(__FILE__)), [], (string) ZARINSHOPBOT_VERSION);
    wp_enqueue_style('zarinshopbot-card-transfer', plugins_url('assets/css/card-transfer.css', dirname(__FILE__)), ['zarinshopbot-webapp'], (string) ZARINSHOPBOT_VERSION);
    wp_enqueue_script('zarinshopbot-card-transfer', plugins_url('assets/js/card-transfer.js', dirname(__FILE__)), [], (string) ZARINSHOPBOT_VERSION, true);
    $webapp_dependencies = $zarincode_is_bale ? [] : ['telegram-web-app'];
    wp_enqueue_script('zarinshopbot-webapp', plugins_url('assets/js/webapp.js', dirname(__FILE__)), $webapp_dependencies, (string) ZARINSHOPBOT_VERSION, true);
    echo '<style id="zsb-miniapp-brand-vars">:root{--zsb-brand-primary:' . esc_html($zarincode_brand_colors['primary']) . ';--zsb-brand-accent:' . esc_html($zarincode_brand_colors['accent']) . ';--zsb-brand-background:' . esc_html($zarincode_brand_colors['background']) . ';--zsb-brand-text:' . esc_html($zarincode_brand_colors['text']) . ';}</style>';

    $webapp_i18n = [
        'bale_auth_required' => $zarincode_is_persian ? __('برای استفادهٔ امن، این فروشگاه را از داخل برنامهٔ بله باز کنید.', 'zarinshopbot') : __('Open this storefront inside Bale to authenticate securely.', 'zarinshopbot'),
        'bale_miniapp_unsupported' => $zarincode_is_persian ? __('نسخهٔ بلهٔ شما از مینی‌اپ پشتیبانی نمی‌کند؛ بله را به‌روزرسانی و دوباره وارد شوید.', 'zarinshopbot') : __('Your Bale version does not support Mini Apps. Update Bale and reopen the store.', 'zarinshopbot'),
        'home_shortcut_unavailable' => $zarincode_is_persian ? __('افزودن میانبر در این نسخهٔ بله در دسترس نیست.', 'zarinshopbot') : __('Home screen shortcuts are unavailable in this Bale version.', 'zarinshopbot'),
        'bale_phone_unverified' => $zarincode_is_persian ? __('شماره فقط برای تکمیل راحت‌تر فرم وارد شد و در سرور بله تأیید نشده است؛ پیش از ثبت سفارش آن را بررسی کنید.', 'zarinshopbot') : __('The phone number was added for convenience only and is not verified by Bale on the server. Please review it before placing the order.', 'zarinshopbot'),
        'contact_share_unavailable' => $zarincode_is_persian ? __('اشتراک‌گذاری شماره در این نسخه در دسترس نیست.', 'zarinshopbot') : __('Contact sharing is unavailable in this Bale version.', 'zarinshopbot'),
        'contact_share_cancelled' => $zarincode_is_persian ? __('اشتراک‌گذاری شماره لغو شد؛ می‌توانید شماره را دستی وارد کنید.', 'zarinshopbot') : __('Contact sharing was cancelled; you can enter your phone number manually.', 'zarinshopbot'),
        'home_shortcut_failed' => $zarincode_is_persian ? __('افزودن میانبر به صفحهٔ اصلی انجام نشد؛ دوباره تلاش کنید.', 'zarinshopbot') : __('The home screen shortcut could not be added. Please try again.', 'zarinshopbot'),
        'bale_qr_unsupported' => $zarincode_is_persian ? __('اسکن QR در نسخهٔ فعلی بله پشتیبانی نمی‌شود.', 'zarinshopbot') : __('QR scanning is not supported in this Bale version.', 'zarinshopbot'),
        'loading_products' => $zarincode_is_persian ? __('در حال دریافت محصولات...', 'zarinshopbot') : __('Loading products...', 'zarinshopbot'),
        'no_products_available' => $zarincode_is_persian ? __('محصولی یافت نشد.', 'zarinshopbot') : __('No products available.', 'zarinshopbot'),
        'products_load_error' => $zarincode_is_persian ? __('خطا در بارگذاری محصولات', 'zarinshopbot') : __('Error loading products', 'zarinshopbot'),
        'no_products_found' => $zarincode_is_persian ? __('محصولی یافت نشد.', 'zarinshopbot') : __('No products found.', 'zarinshopbot'),
        'product_variable' => $zarincode_is_persian ? __('متغیر', 'zarinshopbot') : __('Variable', 'zarinshopbot'),
        'product_digital' => $zarincode_is_persian ? __('دانلودی', 'zarinshopbot') : __('Digital', 'zarinshopbot'),
        'price_from' => $zarincode_is_persian ? __('از ', 'zarinshopbot') : __('From ', 'zarinshopbot'),
        'select_options' => $zarincode_is_persian ? __('انتخاب ویژگی‌ها', 'zarinshopbot') : __('Select Options', 'zarinshopbot'),
        'add_to_cart' => $zarincode_is_persian ? __('افزودن به سبد', 'zarinshopbot') : __('Add to Cart', 'zarinshopbot'),
        'in_stock' => $zarincode_is_persian ? __('موجود در انبار', 'zarinshopbot') : __('In Stock', 'zarinshopbot'),
        'out_of_stock' => $zarincode_is_persian ? __('ناموجود', 'zarinshopbot') : __('Out of Stock', 'zarinshopbot'),
        'cart_added' => $zarincode_is_persian ? __('محصول با موفقیت به سبد افزوده شد!', 'zarinshopbot') : __('Added to cart successfully!', 'zarinshopbot'),
        'cart_empty' => $zarincode_is_persian ? __('سبد خرید شما خالی است', 'zarinshopbot') : __('Your cart is empty', 'zarinshopbot'),
        'cart_empty_hint' => $zarincode_is_persian ? __('محصولات مورد نظرتان را به سبد خرید اضافه کنید.', 'zarinshopbot') : __('Add products from the store to checkout.', 'zarinshopbot'),
        'product_number' => $zarincode_is_persian ? __('محصول شماره ', 'zarinshopbot') : __('Product #', 'zarinshopbot'),
        'digital_delivery_free' => $zarincode_is_persian ? __('تحویل دانلودی (رایگان)', 'zarinshopbot') : __('Digital Delivery (Free)', 'zarinshopbot'),
        'shipping_unavailable_for_address' => $zarincode_is_persian ? __('برای این نشانی روش ارسالی پیدا نشد؛ استان، شهر و کد پستی را بررسی کنید.', 'zarinshopbot') : __('No shipping methods found. Check state, city, and postcode.', 'zarinshopbot'),
        'shipping_method_none' => $zarincode_is_persian ? __('روش ارسال موجود نیست', 'zarinshopbot') : __('No shipping method', 'zarinshopbot'),
        'coupon_validation_error' => $zarincode_is_persian ? __('خطا در بررسی کد تخفیف', 'zarinshopbot') : __('Error validating coupon', 'zarinshopbot'),
        'wishlist_empty' => $zarincode_is_persian ? __('لیست علاقه‌مندی شما خالی است', 'zarinshopbot') : __('Your wishlist is empty', 'zarinshopbot'),
        'wishlist_empty_hint' => $zarincode_is_persian ? __('با کلیک روی آیکون قلب، محصولات را برای بعد ذخیره کنید.', 'zarinshopbot') : __('Tap the heart icon on any product to save it here.', 'zarinshopbot'),
        'loading_orders' => $zarincode_is_persian ? __('در حال بارگذاری سفارش‌ها...', 'zarinshopbot') : __('Loading orders...', 'zarinshopbot'),
        'pay_bale' => $zarincode_is_persian ? __('پرداخت در بله', 'zarinshopbot') : __('Pay in Bale', 'zarinshopbot'),
        'pay_telegram' => $zarincode_is_persian ? __('پرداخت داخل تلگرام', 'zarinshopbot') : __('Pay in Telegram', 'zarinshopbot'),
        'order_date' => $zarincode_is_persian ? __('تاریخ:', 'zarinshopbot') : __('Date:', 'zarinshopbot'),
        'no_orders' => $zarincode_is_persian ? __('هنوز سفارشی ثبت نشده است', 'zarinshopbot') : __('No orders yet', 'zarinshopbot'),
        'orders_error' => $zarincode_is_persian ? __('خطا در دریافت سفارش‌ها.', 'zarinshopbot') : __('Error fetching orders.', 'zarinshopbot'),
        'bale_invoice_unsupported' => $zarincode_is_persian ? __('نسخهٔ بلهٔ شما پرداخت درون‌مینی‌اپ را پشتیبانی نمی‌کند. بله را به‌روزرسانی کنید؛ صفحهٔ وب‌سایت باز نخواهد شد.', 'zarinshopbot') : __('In-app payments are unavailable in this Bale version. Update Bale; no website will be opened.', 'zarinshopbot'),
        'telegram_invoice_unsupported' => $zarincode_is_persian ? __('نسخهٔ تلگرام شما پرداخت درون‌برنامه‌ای را پشتیبانی نمی‌کند. تلگرام را به‌روز کنید؛ صفحهٔ وب‌سایت باز نخواهد شد.', 'zarinshopbot') : __('In-app payments are unavailable in this Telegram version. Update Telegram; no website will be opened.', 'zarinshopbot'),
        'payment_confirmed' => $zarincode_is_persian ? __('پرداخت سفارش شماره %s از سرور تأیید شد.', 'zarinshopbot') : __('Payment for order %s was confirmed by the server.', 'zarinshopbot'),
        'payment_pending_confirmation' => $zarincode_is_persian ? __('درخواست پرداخت دریافت شد، اما تأیید سرور هنوز نرسیده است. وضعیت سفارش را بررسی کنید؛ سبد خرید برای جلوگیری از ثبت تکراری حفظ شده است.', 'zarinshopbot') : __('The payment response was received, but server confirmation is still pending. Check your order status; your cart was kept to prevent accidental duplicate checkout.', 'zarinshopbot'),
        'payment_cancelled' => $zarincode_is_persian ? __('پرداخت لغو شد؛ سفارش در انتظار پرداخت است. با زدن همین دکمه می‌توانید همان صورتحساب را دوباره باز کنید.', 'zarinshopbot') : __('Payment was cancelled; the order remains unpaid. Press this button to reopen the same invoice.', 'zarinshopbot'),
        'payment_pending' => $zarincode_is_persian ? __('پرداخت در حال بررسی است؛ وضعیت سفارش پس از تأیید سرور به‌روزرسانی می‌شود.', 'zarinshopbot') : __('Payment is pending; the order will update after server confirmation.', 'zarinshopbot'),
        'payment_not_completed' => $zarincode_is_persian ? __('پرداخت تکمیل نشد. می‌توانید همین صورتحساب را دوباره باز کنید.', 'zarinshopbot') : __('Payment was not completed. You can reopen this invoice.', 'zarinshopbot'),
        'payment_page_opened' => $zarincode_is_persian ? __('سفارش ثبت شد؛ صفحهٔ پرداخت در حال بازشدن است...', 'zarinshopbot') : __('Order placed; opening the payment page...', 'zarinshopbot'),
        'payment_page_open_failed' => $zarincode_is_persian ? __('سفارش %s ثبت شده، اما صفحهٔ درگاه باز نشد. پرداخت را از بخش سفارش‌های من ادامه دهید.', 'zarinshopbot') : __('Order %s was placed, but the payment page could not be opened. Continue from My Orders.', 'zarinshopbot'),
        'checkout_timeout' => $zarincode_is_persian ? __('سرور در ۶۰ ثانیه پاسخ نداد. ممکن است سفارش ثبت شده باشد؛ برای جلوگیری از سفارش تکراری، ابتدا سفارش‌های من را بررسی کنید و فعلاً دوباره ثبت نکنید.', 'zarinshopbot') : __('The server did not respond within 60 seconds. The order may have been placed; check My Orders before retrying to avoid a duplicate.', 'zarinshopbot'),
        'proceed_to_payment' => $zarincode_is_persian ? __('تکمیل سفارش و پرداخت', 'zarinshopbot') : __('Proceed to Payment', 'zarinshopbot'),
        'invoice_open_unavailable' => $zarincode_is_persian ? __('باز کردن صورتحساب در این نسخهٔ برنامه ممکن نیست.', 'zarinshopbot') : __('This app version could not open the invoice.', 'zarinshopbot'),
        'recipient_fields_required' => $zarincode_is_persian ? __('لطفاً نام، شماره موبایل و ایمیل معتبر را وارد کنید؛ برای کالای فیزیکی آدرس هم لازم است.', 'zarinshopbot') : __('Please enter your full name, mobile number, and a valid email address. A shipping address is also required for physical items.', 'zarinshopbot'),
        'otp_send' => $zarincode_is_persian ? __('ارسال کد تأیید', 'zarinshopbot') : __('Send verification code', 'zarinshopbot'),
        'otp_verify' => $zarincode_is_persian ? __('تأیید کد', 'zarinshopbot') : __('Verify code', 'zarinshopbot'),
        'otp_enter' => $zarincode_is_persian ? __('کد شش‌رقمی پیامک‌شده', 'zarinshopbot') : __('Six-digit SMS code', 'zarinshopbot'),
        'otp_sent' => $zarincode_is_persian ? __('کد پیامک شد؛ آن را وارد و تأیید کنید.', 'zarinshopbot') : __('Code sent. Enter it and verify.', 'zarinshopbot'),
        'otp_verified' => $zarincode_is_persian ? __('شمارهٔ تلفن تأیید شد.', 'zarinshopbot') : __('Phone number verified.', 'zarinshopbot'),
        'otp_failed' => $zarincode_is_persian ? __('ارسال یا تأیید کد ناموفق بود. دوباره تلاش کنید.', 'zarinshopbot') : __('Could not send or verify the code. Please try again.', 'zarinshopbot'),
        'processing_order' => $zarincode_is_persian ? __('در حال پردازش سفارش...', 'zarinshopbot') : __('Processing Order...', 'zarinshopbot'),
        'free_order_placed' => $zarincode_is_persian ? __('سفارش رایگان شماره %s ثبت شد.', 'zarinshopbot') : __('Free order %s was placed.', 'zarinshopbot'),
        'free_download_order_placed' => $zarincode_is_persian ? __('سفارش دانلود رایگان شماره %s ثبت شد؛ لینک فایل در بخش سفارش‌های من آماده است.', 'zarinshopbot') : __('Free download order %s is ready. Open My Orders to access the file.', 'zarinshopbot'),
        'get_download' => $zarincode_is_persian ? __('ثبت سفارش و دریافت فایل', 'zarinshopbot') : __('Get Download', 'zarinshopbot'),
        'order_create_error' => $zarincode_is_persian ? __('ثبت سفارش انجام نشد. سبد خرید شما حفظ شده است؛ لطفاً دوباره تلاش کنید.', 'zarinshopbot') : __('The order could not be placed. Your cart was kept; please try again.', 'zarinshopbot'),
        'transfer_account_prompt' => $zarincode_is_persian ? __('حساب مقصد را انتخاب کنید:', 'zarinshopbot') : __('Choose the destination account:', 'zarinshopbot'),
        'transfer_bank_transfer' => $zarincode_is_persian ? __('انتقال بانکی', 'zarinshopbot') : __('Bank transfer', 'zarinshopbot'),
        'transfer_bank_account' => $zarincode_is_persian ? __('حساب بانکی', 'zarinshopbot') : __('Bank account', 'zarinshopbot'),
        'transfer_account_name' => $zarincode_is_persian ? __('عنوان حساب', 'zarinshopbot') : __('Account name', 'zarinshopbot'),
        'transfer_account_holder' => $zarincode_is_persian ? __('نام صاحب حساب', 'zarinshopbot') : __('Account holder', 'zarinshopbot'),
        'transfer_card_number' => $zarincode_is_persian ? __('شماره کارت', 'zarinshopbot') : __('Card number', 'zarinshopbot'),
        'transfer_account_number' => $zarincode_is_persian ? __('شماره حساب', 'zarinshopbot') : __('Account number', 'zarinshopbot'),
        'transfer_iban' => $zarincode_is_persian ? __('شماره شبا', 'zarinshopbot') : __('IBAN', 'zarinshopbot'),
        'transfer_copy' => $zarincode_is_persian ? __('کپی', 'zarinshopbot') : __('Copy', 'zarinshopbot'),
        'transfer_copied' => $zarincode_is_persian ? __('کپی شد', 'zarinshopbot') : __('Copied', 'zarinshopbot'),
        'transfer_copy_field' => $zarincode_is_persian ? __('کپی %s', 'zarinshopbot') : __('Copy %s', 'zarinshopbot'),
        'transfer_copy_failed' => $zarincode_is_persian ? __('کپی نشد؛ مقدار را انتخاب و به‌صورت دستی کپی کنید.', 'zarinshopbot') : __('Could not copy; select the value and copy it manually.', 'zarinshopbot'),
        'receipt_formats_default' => $zarincode_is_persian ? __('تصویر و فایل PDF', 'zarinshopbot') : __('image and PDF files', 'zarinshopbot'),
        'receipt_max_default' => $zarincode_is_persian ? __('۲ مگابایت', 'zarinshopbot') : __('2 MB', 'zarinshopbot'),
        'receipt_upload_help' => $zarincode_is_persian ? __('فرمت‌های مجاز: %1$s. حداکثر حجم هر فایل: %2$s. فقط رسید مربوط به همین سفارش را بارگذاری کنید.', 'zarinshopbot') : __('Accepted formats: %1$s. Maximum file size: %2$s. Upload only the receipt for this order.', 'zarinshopbot'),
        'payment_method_required' => $zarincode_is_persian ? __('لطفاً یک روش پرداخت موجود را انتخاب کنید.', 'zarinshopbot') : __('Please select an available payment method.', 'zarinshopbot'),
        'transfer_account_required' => $zarincode_is_persian ? __('لطفاً حساب مقصد را انتخاب کنید.', 'zarinshopbot') : __('Please select a destination account.', 'zarinshopbot'),
        'receipt_required' => $zarincode_is_persian ? __('لطفاً رسید پرداخت را بارگذاری کنید.', 'zarinshopbot') : __('Please upload your payment receipt.', 'zarinshopbot'),
        'receipt_too_large' => $zarincode_is_persian ? __('حجم فایل رسید از حد مجاز (%s) بیشتر است.', 'zarinshopbot') : __('Receipt file exceeds the allowed size (%s).', 'zarinshopbot'),
        'receipt_awaiting_upload' => $zarincode_is_persian ? __('در انتظار بارگذاری رسید', 'zarinshopbot') : __('Awaiting receipt upload', 'zarinshopbot'),
        'receipt_review_pending' => $zarincode_is_persian ? __('رسید ثبت شد؛ در انتظار بررسی مدیر فروشگاه', 'zarinshopbot') : __('Receipt received; waiting for store manager review', 'zarinshopbot'),
        'receipt_rejected' => $zarincode_is_persian ? __('رسید رد شد؛ با فروشگاه تماس بگیرید', 'zarinshopbot') : __('Receipt rejected; contact the store', 'zarinshopbot'),
        'receipt_approved' => $zarincode_is_persian ? __('پرداخت تأیید شد', 'zarinshopbot') : __('Payment approved', 'zarinshopbot'),
        'payment_method_label' => $zarincode_is_persian ? __('روش پرداخت', 'zarinshopbot') : __('Payment method', 'zarinshopbot'),
        'complete_payment' => $zarincode_is_persian ? __('ادامهٔ پرداخت', 'zarinshopbot') : __('Continue to payment', 'zarinshopbot'),
        'receipt_review_order_pending' => $zarincode_is_persian ? __('رسید ارسال شد. سفارش %s در انتظار بررسی دستی پرداخت است.', 'zarinshopbot') : __('Receipt submitted. Order %s is awaiting manual payment review.', 'zarinshopbot'),
        'connection_error' => $zarincode_is_persian ? __('خطا در اتصال. لطفاً دوباره تلاش کنید.', 'zarinshopbot') : __('Connection error. Please try again.', 'zarinshopbot'),
        'invalidCoupon' => $zarincode_is_persian ? __('کد تخفیف نامعتبر است.', 'zarinshopbot') : __('Invalid coupon', 'zarinshopbot'),
    ];

    $webapp_config = [
        'ajaxUrl'      => admin_url('admin-ajax.php', 'https'),
        'platform'     => $zarincode_platform,
        'platformName' => $zarincode_is_bale ? 'Bale' : 'Telegram',
        'phoneOtpRequired' => (($zarincode_settings['phone_sms_verification'] ?? '0') === '1'),
        'checkoutCustomFields' => class_exists('ZarinShopBot\\Digital_Checkout') ? [
            'downloadable' => \ZarinShopBot\Digital_Checkout::configured_checkout_fields(true)['custom'],
            'physical' => \ZarinShopBot\Digital_Checkout::configured_checkout_fields(false)['custom'],
        ] : ['downloadable' => [], 'physical' => []],
        'checkoutFieldProfiles' => class_exists('ZarinShopBot\\Digital_Checkout') ? [
            'downloadable' => \ZarinShopBot\Digital_Checkout::configured_checkout_fields(true)['fields'],
            'physical' => \ZarinShopBot\Digital_Checkout::configured_checkout_fields(false)['fields'],
        ] : ['downloadable' => [], 'physical' => []],
        'checkoutCountries' => function_exists('WC') && WC() && isset(WC()->countries) ? WC()->countries->get_countries() : [],
        'nonce'        => $zarincode_webapp_nonce,
        'lang'         => $zarincode_lang,
        'currency'     => $zarincode_currency,
        'isPersian'    => (bool) $zarincode_is_persian,
        'i18n'         => $webapp_i18n,
        'numberLocale' => $zarincode_is_persian ? 'fa-IR' : 'en-US',
    ];
    wp_localize_script('zarinshopbot-webapp', 'zarinshopbotWebAppConfig', $webapp_config);
    wp_localize_script('zarinshopbot-webapp', 'teleNexaWebAppConfig', $webapp_config);

    wp_head();
    ?>
</head>
<body class="<?php echo $zarincode_is_rtl ? 'rtl' : 'ltr'; ?>">
    <!-- Top Header -->
    <header class="app-header">
        <div class="app-brand">
            <div class="app-logo" aria-hidden="true"><?php if ($zarincode_brand_logo_url): ?><img src="<?php echo esc_url($zarincode_brand_logo_url); ?>" alt="" loading="eager"><?php else: ?><span class="zsb-icon zsb-icon-shopping-bag"></span><?php endif; ?></div>
            <div>
                <h1 class="app-title"><?php echo esc_html($zarincode_site_name); ?></h1>
                <div class="app-user" id="tg_user_display">ZarinShopBot</div>
            </div>
        </div>
        <div class="app-header-actions" aria-label="<?php echo esc_attr($zarincode_is_persian ? __('ابزارهای مینی‌اپ', 'zarinshopbot') : __('Mini App tools', 'zarinshopbot')); ?>">
            <button type="button" id="btn_add_home" class="app-tool-button" hidden><?php echo $zarincode_is_persian ? __('افزودن به خانه', 'zarinshopbot') : __('Add to Home', 'zarinshopbot'); ?></button>
            <button type="button" id="btn_scan_coupon" class="app-tool-button" hidden><?php echo $zarincode_is_persian ? __('اسکن کد', 'zarinshopbot') : __('Scan code', 'zarinshopbot'); ?></button>
        </div>
    </header>
    <div id="app_platform_notice" class="app-platform-notice" role="status" hidden></div>

    <!-- TAB 1: SHOP (CATALOG) -->
    <section class="tab-view is-active" id="view-shop">
        <div class="search-container">
            <div class="search-box">
                <input type="text" id="search_input" class="search-input" placeholder="<?php echo $zarincode_is_persian ? __('جستجوی نام کالا یا شناسه SKU...', 'zarinshopbot') : __('Search products by name or SKU...', 'zarinshopbot'); ?>">
                <span class="search-icon zsb-icon zsb-icon-search" aria-hidden="true"></span>
            </div>
        </div>
        <div class="products-grid" id="products_grid"></div>
    </section>

    <!-- TAB 2: CART & CHECKOUT -->
    <section class="tab-view" id="view-cart">
        <div class="cart-container">
            <h2 style="font-size: 18px; margin-bottom: 14px;"><?php echo $zarincode_is_persian ? __('سبد خرید شما', 'zarinshopbot') : __('Shopping Cart', 'zarinshopbot'); ?></h2>
            <div id="cart_items_list"></div>

            <div class="cart-summary" id="cart_summary_box" style="display: none;">
                <!-- Summary breakdown -->
                <div class="summary-row">
                    <span><?php echo $zarincode_is_persian ? __('مجموع خرید:', 'zarinshopbot') : __('Subtotal', 'zarinshopbot'); ?></span>
                    <strong id="cart_subtotal">0</strong>
                </div>
                <div class="summary-row" id="row_discount" style="display: none; color: #15803d;">
                    <span><?php echo $zarincode_is_persian ? __('تخفیف:', 'zarinshopbot') : __('Discount', 'zarinshopbot'); ?></span>
                    <strong id="cart_discount">0</strong>
                </div>
                <div class="summary-row" id="row_shipping">
                    <span><?php echo $zarincode_is_persian ? __('هزینه ارسال:', 'zarinshopbot') : __('Shipping', 'zarinshopbot'); ?></span>
                    <strong id="cart_shipping"><?php echo $zarincode_is_persian ? __('محاسبه در مرحله بعد', 'zarinshopbot') : __('Calculated at checkout', 'zarinshopbot'); ?></strong>
                </div>
                <div class="summary-row" id="row_tax">
                    <span><?php echo $zarincode_is_persian ? __('مالیات:', 'zarinshopbot') : __('Tax', 'zarinshopbot'); ?></span>
                    <strong id="cart_tax">0</strong>
                </div>
                <div class="summary-row total">
                    <span><?php echo $zarincode_is_persian ? __('مبلغ نهایی:', 'zarinshopbot') : __('Final Total', 'zarinshopbot'); ?></span>
                    <strong id="cart_total" style="color: var(--button-color);">0</strong>
                </div>

                <!-- Coupon Box -->
                <div class="form-group" style="margin-top: 14px;">
                    <label class="form-label"><?php echo $zarincode_is_persian ? __('کد تخفیف:', 'zarinshopbot') : __('Discount Coupon', 'zarinshopbot'); ?></label>
                    <div style="display: flex; gap: 8px;">
                        <input type="text" id="chk_coupon" class="form-input" placeholder="<?php echo esc_attr($zarincode_is_persian ? __('کد تخفیف', 'zarinshopbot') : 'DISCOUNT10'); ?>">
                        <button type="button" id="btn_apply_coupon" class="btn-coupon"><?php echo $zarincode_is_persian ? __('اعمال', 'zarinshopbot') : __('Apply', 'zarinshopbot'); ?></button>
                    </div>
                    <div id="coupon_feedback" style="font-size: 12px; margin-top: 4px;"></div>
                    <?php if ($zarincode_is_bale) : ?><button type="button" id="btn_scan_coupon_inline" class="app-inline-tool" hidden><?php echo $zarincode_is_persian ? __('اسکن بارکد / QR کد تخفیف', 'zarinshopbot') : __('Scan coupon QR code', 'zarinshopbot'); ?></button><?php endif; ?>
                </div>

                <!-- Checkout Details Form -->
                <div class="checkout-form">
                    <h3 style="font-size: 15px; margin-bottom: 12px; border-top: 1px solid var(--card-border); padding-top: 12px;">
                        <?php echo $zarincode_is_persian ? __('مشخصات تحویل‌گیرنده', 'zarinshopbot') : __('Recipient Details', 'zarinshopbot'); ?>
                    </h3>
                    <div class="form-group" data-zsb-profile-fields="billing_first_name,billing_last_name">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('نام و نام‌خانوادگی:', 'zarinshopbot') : __('Full Name', 'zarinshopbot'); ?></label>
                        <input type="text" id="chk_name" class="form-input" autocomplete="name" required placeholder="<?php echo $zarincode_is_persian ? __('علی محمدی', 'zarinshopbot') : __('John Doe', 'zarinshopbot'); ?>">
                    </div>
                    <div class="form-group" data-zsb-profile-fields="billing_phone">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('شماره تماس همراه:', 'zarinshopbot') : __('Phone Number', 'zarinshopbot'); ?></label>
                        <input type="tel" id="chk_phone" class="form-input" autocomplete="tel" placeholder="0912...">
                        <div id="zsb_phone_otp_controls" hidden style="margin-top:8px">
                            <button type="button" id="zsb_phone_otp_send" class="app-inline-tool"><?php echo esc_html($webapp_i18n['otp_send']); ?></button>
                            <input type="text" id="zsb_phone_otp_code" class="form-input" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="<?php echo esc_attr($webapp_i18n['otp_enter']); ?>" style="flex:1;min-width:140px">
                            <button type="button" id="zsb_phone_otp_verify" class="app-inline-tool"><?php echo esc_html($webapp_i18n['otp_verify']); ?></button>
                            <small id="zsb_phone_otp_status" style="width:100%"></small>
                        </div>
                        <?php if ($zarincode_is_bale) : ?><button type="button" id="btn_request_contact" class="app-inline-tool" hidden><?php echo $zarincode_is_persian ? __('اشتراک‌گذاری شماره با بله', 'zarinshopbot') : __('Share phone with Bale', 'zarinshopbot'); ?></button><?php endif; ?>
                    </div>
                    <div class="form-group" data-zsb-profile-fields="billing_email">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('آدرس ایمیل:', 'zarinshopbot') : __('Email Address', 'zarinshopbot'); ?></label>
                        <input type="email" id="chk_email" class="form-input" placeholder="you@domain.com" autocomplete="email">
                    </div>
                    <div id="zsb_custom_checkout_fields"></div>
                    <div id="zsb_extra_checkout_fields"></div>
                    <div id="zsb_shipping_checkout_fields">
                    <div class="form-group" data-zsb-profile-fields="billing_state,shipping_state">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('استان:', 'zarinshopbot') : __('Province / State', 'zarinshopbot'); ?></label>
                        <input type="text" id="chk_state" class="form-input" placeholder="<?php echo $zarincode_is_persian ? __('تهران', 'zarinshopbot') : __('Tehran', 'zarinshopbot'); ?>">
                    </div>
                    <div class="form-group" data-zsb-profile-fields="billing_city,shipping_city">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('شهر:', 'zarinshopbot') : __('City', 'zarinshopbot'); ?></label>
                        <input type="text" id="chk_city" class="form-input" placeholder="<?php echo $zarincode_is_persian ? __('تهران', 'zarinshopbot') : __('Tehran', 'zarinshopbot'); ?>">
                    </div>
                    <div class="form-group" data-zsb-profile-fields="billing_address_1,shipping_address_1">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('نشانی دقیق پستی:', 'zarinshopbot') : __('Detailed Address', 'zarinshopbot'); ?></label>
                        <input type="text" id="chk_address" class="form-input" placeholder="<?php echo $zarincode_is_persian ? __('خیابان، کوچه، پلاک...', 'zarinshopbot') : __('Street, No...', 'zarinshopbot'); ?>">
                    </div>
                    <div class="form-group" data-zsb-profile-fields="billing_postcode,shipping_postcode">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('کد پستی ۱۰ رقمی:', 'zarinshopbot') : __('Postal Code', 'zarinshopbot'); ?></label>
                        <input type="text" id="chk_zip" class="form-input" placeholder="1234567890">
                    </div>
                    <div class="form-group" data-zsb-profile-fields="order_comments">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('یادداشت یا توضیحات سفارش:', 'zarinshopbot') : __('Order Notes', 'zarinshopbot'); ?></label>
                        <input type="text" id="chk_note" class="form-input" placeholder="<?php echo $zarincode_is_persian ? __('اختیاری...', 'zarinshopbot') : __('Optional delivery notes...', 'zarinshopbot'); ?>">
                    </div>
                    </div>

                    <!-- Shipping Methods Container -->
                    <div id="shipping_section" style="margin-top: 14px; display: none;">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('روش ارسال کالا:', 'zarinshopbot') : __('Select Shipping Method:', 'zarinshopbot'); ?></label>
                        <div class="option-card-row" id="shipping_methods_list"></div>
                    </div>

                    <!-- Payment Gateways Container -->
                    <div id="payment_section" style="margin-top: 14px; display: none;">
                        <label class="form-label"><?php echo $zarincode_is_persian ? __('روش پرداخت:', 'zarinshopbot') : __('Payment method:', 'zarinshopbot'); ?></label>
                        <div class="option-card-row" id="payment_gateways_list"></div>
                    </div>
                    <div id="manual_transfer_details" class="manual-transfer-details" hidden>
                        <div id="transfer_accounts_list" class="transfer-accounts-list"></div>
                        <div class="form-group">
                            <label class="form-label" for="payment_receipt"><?php echo $zarincode_is_persian ? __('بارگذاری رسید پرداخت:', 'zarinshopbot') : __('Upload payment receipt:', 'zarinshopbot'); ?></label>
                            <input type="file" id="payment_receipt" class="form-input" accept="" />
                            <p id="receipt_upload_help" class="form-help"></p>
                        </div>
                    </div>
                    <p id="payment_notice" class="form-help" style="display:none;color:#9a3412;"><?php echo $zarincode_is_persian ? __('هیچ روش پرداخت فعالی تنظیم نشده است. یک درگاه بومی یا درگاه WooCommerce را فعال کنید.', 'zarinshopbot') : __('No active payment method is configured. Enable a native or WooCommerce payment gateway.', 'zarinshopbot'); ?></p>

                    <button class="btn-checkout" id="btn_proceed_checkout">
                        <span class="zsb-icon zsb-icon-credit-card" aria-hidden="true"></span> <?php echo $zarincode_is_persian ? __('تکمیل سفارش و پرداخت', 'zarinshopbot') : __('Proceed to Payment', 'zarinshopbot'); ?>
                    </button>
                    <div class="cart-nav-clearance" aria-hidden="true"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- TAB 3: WISHLIST -->
    <section class="tab-view" id="view-wishlist">
        <div class="cart-container">
            <h2 style="font-size: 18px; margin-bottom: 14px;"><?php echo $zarincode_is_persian ? __('علاقه‌مندی‌های من', 'zarinshopbot') : __('Saved Wishlist', 'zarinshopbot'); ?></h2>
            <div id="wishlist_items_list"></div>
        </div>
    </section>

    <!-- TAB 4: ORDERS -->
    <section class="tab-view" id="view-orders">
        <div class="cart-container">
            <h2 style="font-size: 18px; margin-bottom: 14px;"><?php echo $zarincode_is_persian ? __('سفارش‌های من', 'zarinshopbot') : __('My Orders', 'zarinshopbot'); ?></h2>
            <div id="orders_list"></div>
        </div>
    </section>

    <!-- Variation Selection Modal -->
    <div class="modal-overlay" id="var_modal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title" id="var_modal_title"><?php esc_html_e('انتخاب مشخصات محصول', 'zarinshopbot'); ?></div>
                <button class="modal-close" onclick="closeVariationModal()" aria-label="<?php esc_attr_e('Close', 'zarinshopbot'); ?>"><span class="zsb-icon zsb-icon-x" aria-hidden="true"></span></button>
            </div>
            <div style="display: flex; gap: 14px; align-items: center; margin-bottom: 16px;">
                <img id="var_modal_img" src="" style="width: 70px; height: 70px; object-fit: cover; border-radius: 8px;">
                <div>
                    <div id="var_modal_price" style="font-size: 16px; font-weight: 700; color: var(--button-color);"></div>
                    <div id="var_modal_stock" style="font-size: 12px; color: var(--hint-color); margin-top: 4px;"></div>
                </div>
            </div>
            <div id="var_options_container"></div>
            <button class="btn-checkout" id="btn_add_variation" style="margin-top: 16px;">
                <span class="zsb-icon zsb-icon-shopping-cart" aria-hidden="true"></span> <?php echo $zarincode_is_persian ? __('افزودن این متغیر به سبد', 'zarinshopbot') : __('Add Variation to Cart', 'zarinshopbot'); ?>
            </button>
        </div>
    </div>

    <!-- Bottom Navigation -->
    <nav class="bottom-nav">
        <div class="nav-item is-active" data-view="view-shop">
            <span class="nav-icon zsb-icon zsb-icon-shopping-bag" aria-hidden="true"></span>
            <span><?php echo $zarincode_is_persian ? __('فروشگاه', 'zarinshopbot') : __('Shop', 'zarinshopbot'); ?></span>
        </div>
        <div class="nav-item" data-view="view-cart">
            <span class="nav-icon zsb-icon zsb-icon-shopping-cart" aria-hidden="true"></span>
            <span><?php echo $zarincode_is_persian ? __('سبد خرید', 'zarinshopbot') : __('Cart', 'zarinshopbot'); ?></span>
            <span class="nav-badge" id="nav_cart_badge" style="display: none;">0</span>
        </div>
        <div class="nav-item" data-view="view-wishlist">
            <span class="nav-icon zsb-icon zsb-icon-heart" aria-hidden="true"></span>
            <span><?php echo $zarincode_is_persian ? __('علاقه‌ها', 'zarinshopbot') : __('Wishlist', 'zarinshopbot'); ?></span>
        </div>
        <div class="nav-item" data-view="view-orders">
            <span class="nav-icon zsb-icon zsb-icon-package" aria-hidden="true"></span>
            <span><?php echo $zarincode_is_persian ? __('سفارش‌ها', 'zarinshopbot') : __('Orders', 'zarinshopbot'); ?></span>
        </div>
    </nav>


    <?php wp_footer(); ?>
    <?php if ($zarincode_locale_switched && function_exists('restore_current_locale')) { restore_current_locale(); } ?>
</body>
</html>
