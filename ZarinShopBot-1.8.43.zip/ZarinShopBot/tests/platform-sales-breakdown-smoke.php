<?php
/** Offline contract check for channel-attributed paid orders and currency separation. */
namespace {
    function wp_cache_get($key, $group = '') { return false; }
    function get_transient($key) { return false; }
    function wp_cache_set($key, $value, $group = '', $expiration = 0) { return true; }
    function set_transient($key, $value, $expiration = 0) { return true; }
    function current_time($format) { return '2026-10-24'; }
    function get_gmt_from_date($date) { return $date; }
    function sanitize_key($key) { return preg_replace('/[^a-z0-9_\\-]/', '', strtolower((string) $key)); }
    function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }

    class ZSB_Sales_Fake_DB {
        public $prefix = 'wp_';
        public $posts = 'wp_posts';
        public $postmeta = 'wp_postmeta';
        public $query = '';
        public $queries = array();
        public function prepare($query, ...$args) { return $query; }
        public function get_results($query) {
            $this->query = $query;
            $this->queries[] = $query;
            return array(
                (object) array('platform' => 'telegram', 'currency' => 'USD', 'order_count' => 4, 'revenue' => '100', 'today_revenue' => '5', 'month_revenue' => '30'),
                (object) array('platform' => 'telegram', 'currency' => 'EUR', 'order_count' => 3, 'revenue' => '25', 'today_revenue' => '10', 'month_revenue' => '18'),
                (object) array('platform' => 'bale', 'currency' => 'USD', 'order_count' => 3, 'revenue' => '76', 'today_revenue' => '0', 'month_revenue' => '22'),
                (object) array('platform' => 'rubika', 'currency' => 'IRR', 'order_count' => 2, 'revenue' => '31', 'today_revenue' => '11', 'month_revenue' => '31'),
            );
        }
    }

    $wpdb = new ZSB_Sales_Fake_DB();
    require_once dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/RepositoryTrait.php';
    class ZSB_Sales_Test_Bot { use \ZarinShopBot\Core\Bot\RepositoryTrait; }
    $actual = ZSB_Sales_Test_Bot::getPlatformSalesBreakdown();
    if ((int) $actual['telegram']['orders'] !== 7 || (float) $actual['telegram']['revenue'] !== 125.0) throw new \RuntimeException('Telegram aggregation mismatch');
    if ((float) $actual['telegram']['currencies']['USD']['revenue'] !== 100.0 || (float) $actual['telegram']['currencies']['EUR']['revenue'] !== 25.0) throw new \RuntimeException('Telegram currency totals were merged or misattributed');
    if ((int) $actual['bale']['orders'] !== 3 || (float) $actual['bale']['revenue'] !== 76.0) throw new \RuntimeException('Bale aggregation mismatch');
    if ((int) $actual['rubika']['orders'] !== 2 || (float) $actual['rubika']['revenue'] !== 31.0) throw new \RuntimeException('Rubika aggregation mismatch');
    if (strpos($wpdb->queries[0], "meta_key = '_order_from'") === false || strpos($wpdb->queries[0], "'telegram', 'bale', 'rubika'") === false || strpos($wpdb->queries[0], 'order_currency.currency') === false || strpos($wpdb->queries[0], 'GROUP BY source.platform, currency') === false) throw new \RuntimeException('CPT query is not grouped by source attribution and currency');
    require_once __DIR__ . '/fixtures/order-util-hpos-stub.php';
    $hpos = ZSB_Sales_Test_Bot::getPlatformSalesBreakdown();
    if ((float) $hpos['telegram']['currencies']['EUR']['revenue'] !== 25.0 || (float) $hpos['bale']['currencies']['USD']['revenue'] !== 76.0) throw new \RuntimeException('HPOS channel/currency aggregation mismatch');
    if (strpos($wpdb->queries[1], 'wc_orders_meta') === false || strpos($wpdb->queries[1], 'o.currency') === false || strpos($wpdb->queries[1], "meta_key = '_order_from'") === false) throw new \RuntimeException('HPOS query does not use the HPOS order/source tables');
    echo "Platform sales breakdown CPT + HPOS contracts passed.\n";
}
