const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const settings = read('panel/settings.php');
const core = read('vendor/zarinshopbot-core/Bot/MenuTrait.php');
const css = read('assets/css/admin-settings.css');
const bootstrap = read('zarinshopbot.php');

const menuKeys = [...core.matchAll(/^\s{12}'([a-z]+)'\s*=>\s*\[/gm)].map((match) => match[1]);
const iconMapBlock = settings.match(/\$menu_local_icons\s*=\s*array\(([\s\S]*?)\);/);
assert(iconMapBlock, 'settings screen defines a local menu icon map');
const iconMap = Object.fromEntries([...iconMapBlock[1].matchAll(/'([a-z]+)'\s*=>\s*'([^']+\.svg)'/g)].map((match) => [match[1], match[2]]));
assert.deepStrictEqual(Object.keys(iconMap).sort(), menuKeys.sort(), 'every core menu button maps to exactly one packaged SVG');
for (const [key, file] of Object.entries(iconMap)) {
  assert.ok(fs.existsSync(path.join(root, 'assets/icons/ui', file)), `${key} icon exists in plugin assets`);
}
assert.match(settings, /zarincode_get_plugin_uri\(\)\s*\.\s*'assets\/icons\/ui\/'\s*\.\s*\$menu_icon_file/, 'preview image uses a local plugin asset path');
assert.match(settings, /<img class="zsb-menu-item-icon"[\s\S]*?alt="" aria-hidden="true"/, 'decorative local icon uses accessible empty alt text');
assert.match(css, /\.zsb-menu-item-row/);
assert.match(css, /\.zsb-menu-title-fields/);
assert.match(css, /\.zsb-menu-priority/);
assert.match(css, /\.zsb-menu-enabled-label/);
assert.match(css, /\.zsb-menu-item-row\s*\{[^}]*display:\s*grid/s, 'rows use explicit grid alignment');
assert.match(css, /grid-template-columns:\s*minmax\(180px,\s*0\.8fr\)\s+minmax\(300px,\s*1\.8fr\)\s+minmax\(115px,\s*0\.55fr\)/, 'desktop columns explicitly align preview, titles and priority');
assert.match(css, /@media\s*\(max-width:\s*782px\)[\s\S]*?\.zsb-menu-item-row\s*\{[^}]*grid-template-columns:\s*minmax\(0,\s*1fr\)/, 'menu rows stack on narrow screens');
assert.match(css, /@media\s*\(max-width:\s*480px\)[\s\S]*?\.zsb-menu-title-fields\s*\{[^}]*grid-template-columns:\s*minmax\(0,\s*1fr\)/, 'title inputs stack on very narrow screens');
assert.match(bootstrap, /add_action\('admin_init',[\s\S]*?\$page\s*!==\s*'zarincode_zarinshopbot_setting'[\s\S]*?remove_action\('admin_enqueue_scripts',\s*'wp_enqueue_emoji_styles'\)[\s\S]*?remove_action\('admin_print_styles',\s*'print_emoji_styles'\)[\s\S]*?remove_action\('admin_print_scripts',\s*'print_emoji_detection_script'\)/, 'emoji image conversion is disabled early and only on the plugin settings page');
assert.match(bootstrap, /strtolower\(\(string\)\s*\$plugin\)\s*!==\s*'wpemoji'/, 'WordPress emoji plugin is excluded from TinyMCE on the settings page');
console.log(`Store menu checks passed (${menuKeys.length} local icons, aligned responsive rows, targeted emoji handling).`);
