<?php
/** Offline contract for Telegram token migration, runtime access, and independent enable state. */
namespace {
    define('ABSPATH', __DIR__ . '/');
    $GLOBALS['zsb_telegram_options'] = array();
    function wp_salt($scheme = 'auth') { return 'offline-telegram-test-salt-not-a-live-secret'; }
    function get_option($name, $default = false) { return array_key_exists($name, $GLOBALS['zsb_telegram_options']) ? $GLOBALS['zsb_telegram_options'][$name] : $default; }
    function update_option($name, $value, $autoload = null) { $GLOBALS['zsb_telegram_options'][$name] = $value; return true; }
    function add_action($hook, $callback, $priority = 10, $accepted_args = 1) { return true; }

    require_once dirname(__DIR__) . '/vendor/zarinshopbot-core/Http/ProxyManager.php';
    require_once dirname(__DIR__) . '/includes/class-zarinshopbot-telegram-secrets.php';
    update_option('zarincode_settings', array('token' => '123456:Legacy_Telegram-Token'));
    zarincode_migrate_telegram_token_secret();
    $stored = get_option('zarincode_settings', array());
    if (isset($stored['token']) || empty($stored['token_enc']) || strpos($stored['token_enc'], '123456:') !== false) throw new \RuntimeException('Telegram token was not removed from plaintext storage');
    if (zarincode_get_telegram_token($stored) !== '123456:Legacy_Telegram-Token') throw new \RuntimeException('Telegram token did not decrypt for runtime use');
    if (!zarincode_telegram_enabled()) throw new \RuntimeException('Legacy installations with a configured token should remain enabled by default');

    $stored['telegram_enabled'] = '0';
    update_option('zarincode_settings', $stored);
    if (zarincode_telegram_enabled() || zarincode_get_telegram_token() !== '123456:Legacy_Telegram-Token') throw new \RuntimeException('Independent Telegram off switch changed or exposed the saved token');
    $stored['telegram_enabled'] = '1';
    update_option('zarincode_settings', $stored);
    if (!zarincode_telegram_enabled()) throw new \RuntimeException('Telegram did not re-enable independently');
    $stored['token_enc'] = '';
    update_option('zarincode_settings', $stored);
    if (zarincode_telegram_enabled()) throw new \RuntimeException('Telegram must not be enabled without a token');
    echo "Telegram token migration and enable-switch smoke tests passed.\n";
}
