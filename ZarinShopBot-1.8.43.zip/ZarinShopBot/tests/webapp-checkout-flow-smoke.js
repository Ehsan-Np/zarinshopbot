const fs = require('fs');
const assert = require('assert');
const js = fs.readFileSync('assets/js/webapp.js', 'utf8');
const template = fs.readFileSync('templates/webapp.php', 'utf8');

assert(js.includes('emailInput?.checkValidity()') && js.includes('checkoutFieldProfiles'), 'client-side Mini App checkout validates email according to the configured profile');
assert(js.includes("typeof tg?.openLink === 'function'") && js.includes('tg.openLink(url)'), 'Telegram website gateways use the documented Mini App openLink bridge');
assert(js.includes("typeof bale?.openLink === 'function'") && js.includes('bale.openLink(url)'), 'Bale website gateways use Bale own openLink bridge when that platform is active');
assert(js.includes("if (!openWebsitePayment(data.data.payment_url))"), 'failed gateway handoff preserves order and directs the user to My Orders');
assert(js.includes('new AbortController()') && js.includes('checkoutAbortController.abort(), 60000'), 'checkout request has a bounded client wait instead of an endless processing state');
assert(js.includes("err?.name === 'AbortError'") && js.includes("data-view=\"view-orders\""), 'a timed-out checkout reports uncertain status and opens order history');
assert(template.includes('id="chk_email"') && template.includes('autocomplete="email"') && template.includes('checkoutFieldProfiles'), 'email input is controlled by the downloadable/physical field profile');
assert(template.includes('payment_page_opened') && template.includes('payment_page_open_failed') && template.includes('checkout_timeout'), 'checkout recovery messages are localized in Persian and English');
assert(!js.includes('window.location.assign(data.data.payment_url)'), 'old direct in-WebView gateway redirect is removed');
console.log('Mini App gateway handoff smoke tests passed (7 checks).');
