'use strict';
const assert = require('assert');
const fs = require('fs');
const panel = fs.readFileSync('panel/settings.php', 'utf8');
const channels = fs.readFileSync('includes/class-zarinshopbot-channels.php', 'utf8');
const css = fs.readFileSync('assets/css/admin-settings.css', 'utf8');
const map = fs.readFileSync('docs/settings-panel-audit-fa.md', 'utf8');
const sanitizer = fs.readFileSync('zarinshopbot.php', 'utf8');

assert.match(panel, /zarin-capability-details/);
for (const platform of ['Telegram', 'Bale', 'Rubika']) assert(panel.includes(platform), `${platform} must be visible in the capability center`);
for (const url of ['https://core.telegram.org/bots/api', 'https://docs.bale.ai/', 'https://rubika.ir/botapi/methods', 'developer.wordpress.org/plugins/settings/settings-api', 'developer.woocommerce.com/docs/extensions/settings-and-config']) {
    assert(panel.includes(url), `Missing official reference ${url}`);
}
assert(panel.includes('createInvoiceLink/openInvoice') && panel.includes('setCommands'));
assert(panel.includes('استعلام عضو در API عمومی بررسی‌شده مستند نیست'));
assert.match(panel, /zarin-digital-policy/);
assert(panel.includes('مبلغ نهایی صفر') && panel.includes('سبد ترکیبی') && panel.includes('دریافت تلفن برای ربات از تنظیم کلی یا پروفایل انتخابی پیروی می‌کند') && panel.includes('فیلدهای انتخاب‌شده'));
assert(panel.includes('name="zarincode_settings[register_req_phone]"') && panel.includes('موبایل یا تلفن ثابت') && panel.includes('دریافت نشود'), 'Phone collection mode is configurable by the site administrator');
assert(panel.includes("$profile_option_key = 'checkout_fields_' . $profile_name") && sanitizer.includes("'checkout_fields_digital', 'checkout_fields_physical'"), 'Separate bot checkout profiles are rendered and sanitized by product type');
assert(!panel.includes('name="zarincode_settings[telegram_exclusive_coupon]'), 'Unimplemented Telegram coupon option must not be advertised');
assert(sanitizer.includes("['telegram_exclusive_coupon', 'referral_reward_text']") && sanitizer.includes('Preserve old, previously exposed but runtime-unimplemented controls'), 'Dormant legacy values must be safely retained when settings are saved');
assert(panel.includes("$current === 'basic'"));
const tabRegistry = panel.slice(panel.indexOf('$tabs = array('), panel.indexOf('// phpcs:ignore WordPress.Security.NonceVerification.Recommended'));
for (const platformTab of ['basic', 'bale', 'rubika']) assert(tabRegistry.includes(`'${platformTab}'`), `Missing platform tab ${platformTab}`);
for (const obsoleteTab of ['webapp', 'notifications', 'proxy', 'telegram-features']) {
    assert(!tabRegistry.includes(`'${obsoleteTab}'`), `${obsoleteTab} must not remain a separate Telegram tab`);
    assert(!panel.includes(`id="tab-${obsoleteTab}"`), `${obsoleteTab} pane must be inside Telegram, not a separate tab`);
}
for (const group of ['telegram-miniapp-group', 'telegram-notifications-group', 'telegram-proxy-group', 'telegram-features-group']) assert(panel.includes(group), `Missing consolidated Telegram settings group ${group}`);
assert(panel.includes("array('webapp', 'notifications', 'proxy', 'telegram-features')"), 'Legacy Telegram tab links should resolve to the consolidated tab');
const telegramPane = panel.slice(panel.indexOf('id="tab-basic"'), panel.indexOf('id="tab-membership"'));
for (const option of ['feature_webapp_enable', 'notify_customer_new_order', 'proxy_address', 'telegram_http_timeout', 'telegram_invoice_enable', 'telegram_stars_enable', 'telegram_rich_messages', 'compact_navigation', 'enable_order_rating', 'telegram_post_title']) assert(telegramPane.includes(option), `Missing Telegram-only setting ${option} from its consolidated tab`);
const diagnosticsPane = panel.slice(panel.indexOf('id="tab-diagnostics"'), panel.indexOf('id="tab-commands"'));
for (const option of ['zarincode_logging_enabled', 'zarincode_log_level', 'zarincode_log_retention_days']) assert(diagnosticsPane.includes(option), `Missing shared diagnostics option ${option}`);
assert(!telegramPane.includes('zarincode_logging_enabled') && !telegramPane.includes('zarincode_log_retention_days'), 'Cross-platform log settings must remain in shared diagnostics');
assert.match(css, /\.zarin-platform-settings-group\s*\{[\s\S]*?margin-top: 30px/);
assert(channels.includes("'bale_post_chat_id'") && channels.includes("'rubika_post_chat_id'") && channels.includes("'bale_miniapp_enabled'"));
assert(channels.includes("'bale_wallet_enabled'") && channels.includes("'bale_provider_token'"));
assert.match(css, /\.zarin-capability-table-wrap\s*\{\s*overflow-x: auto;/);
assert.match(css, /\.zarin-digital-policy/);
assert(map.includes('option nameها') && map.includes('WooCommerce Settings API'));
console.log('Settings capability map and WooCommerce policy smoke tests passed.');
