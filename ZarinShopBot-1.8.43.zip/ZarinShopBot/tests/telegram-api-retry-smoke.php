<?php
/** Prevent duplicate Telegram side effects when the HTTP transport fails ambiguously. */
$GLOBALS['zsb_telegram_responses'] = array();
$GLOBALS['zsb_telegram_requests'] = array();
$GLOBALS['zsb_telegram_wp_options'] = array('proxy_status' => '0', 'proxy_status_fallback' => '0');
$GLOBALS['zsb_telegram_options'] = array(
    'telegram_enabled' => '1',
    'telegram_api_retries' => '2',
    'telegram_http_timeout' => '6',
    'token' => '123456:dummy-token',
);

class WP_Error {
    private $code;
    private $message;
    public function __construct($code = '', $message = '') { $this->code = $code; $this->message = $message; }
    public function get_error_code() { return $this->code; }
    public function get_error_message() { return $this->message; }
    public function get_error_data() { return null; }
}
function is_wp_error($value) { return $value instanceof WP_Error; }
function zarincode_option($key) { return $GLOBALS['zsb_telegram_options'][$key] ?? ''; }
function zarincode_telegram_enabled() { return true; }
function wp_json_encode($value, $flags = 0) { return json_encode($value, $flags); }
function __($text, $domain = null) { return $text; }
function absint($value) { return abs((int) $value); }
function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function get_option($key, $default = false) {
    return $key === 'zarincode_settings' ? $GLOBALS['zsb_telegram_wp_options'] : $default;
}
function add_filter($hook, $callback, $priority = 10, $accepted_args = 1) { return true; }
function remove_filter($hook, $callback, $priority = 10) { return true; }
function current_time($type = 'mysql') { return '2026-10-27 00:00:00'; }
function update_option($name, $value, $autoload = null) { $GLOBALS['zsb_telegram_wp_options'][$name] = $value; return true; }
function wp_remote_post($url, $args) {
    $GLOBALS['zsb_telegram_requests'][] = array($url, $args);
    return array_shift($GLOBALS['zsb_telegram_responses']);
}
function wp_remote_retrieve_response_code($response) { return $response['response']['code'] ?? 0; }
function wp_remote_retrieve_body($response) { return $response['body'] ?? ''; }

require dirname(__DIR__) . '/vendor/zarinshopbot-core/Http/ProxyManager.php';
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Http/TelegramApiAdapter.php';

$GLOBALS['zsb_telegram_responses'][] = new WP_Error('http_request_failed', 'Connection timed out after request dispatch');
$result = \ZarinShopBot\Core\Http\TelegramApiAdapter::call('sendMessage', array('chat_id' => '123', 'text' => 'hello'));
if (!is_wp_error($result) || count($GLOBALS['zsb_telegram_requests']) !== 1) {
    fwrite(STDERR, "FAILED: ambiguous Telegram send transport failure was retried\n");
    exit(1);
}

$GLOBALS['zsb_telegram_wp_options'] = array(
    'proxy_status' => '1', 'proxy_address' => 'proxy-primary.test', 'proxy_port' => '8080', 'proxy_type' => 'http',
    'proxy_status_fallback' => '1', 'proxy_address_fallback' => 'proxy-fallback.test', 'proxy_port_fallback' => '8080', 'proxy_type_fallback' => 'http',
);
$before_send_failover = count($GLOBALS['zsb_telegram_requests']);
$GLOBALS['zsb_telegram_responses'][] = new WP_Error('http_request_failed', 'Ambiguous primary-proxy failure');
$GLOBALS['zsb_telegram_responses'][] = array('response' => array('code' => 200), 'body' => '{"ok":true,"result":{}}');
$result = \ZarinShopBot\Core\Http\TelegramApiAdapter::call('sendMessage', array('chat_id' => '123', 'text' => 'hello'));
if (!is_wp_error($result) || count($GLOBALS['zsb_telegram_requests']) !== $before_send_failover + 1) {
    fwrite(STDERR, "FAILED: Telegram send was replayed through the fallback proxy\n");
    exit(1);
}

$before_read_failover = count($GLOBALS['zsb_telegram_requests']);
$GLOBALS['zsb_telegram_responses'] = array();
$GLOBALS['zsb_telegram_responses'][] = new WP_Error('http_request_failed', 'Primary proxy unavailable');
$GLOBALS['zsb_telegram_responses'][] = array('response' => array('code' => 200), 'body' => '{"ok":true,"result":{"id":7}}');
$result = \ZarinShopBot\Core\Http\TelegramApiAdapter::call('getMe', array());
if (is_wp_error($result) || count($GLOBALS['zsb_telegram_requests']) !== $before_read_failover + 2) {
    fwrite(STDERR, "FAILED: read-only Telegram request did not use configured proxy failover\n");
    exit(1);
}

fwrite(STDOUT, "Telegram retry/failover safety smoke tests passed (3 checks).\n");
