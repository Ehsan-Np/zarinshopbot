const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const suitePath = path.join(__dirname, 'zarincode_test_suite.php');
const bootstrap = fs.readFileSync(path.join(root, 'zarinshopbot.php'), 'utf8');
const adminJs = fs.readFileSync(path.join(root, 'assets/js/admin-settings.js'), 'utf8');

assert.ok(fs.existsSync(suitePath), 'AJAX diagnostics suite file must be included in the plugin package');
const suite = fs.readFileSync(suitePath, 'utf8');
assert.match(bootstrap, /tests\/zarincode_test_suite\.php/);
assert.ok(bootstrap.includes('new \\SaleBotTestSuite()'));
assert.match(suite, /final class SaleBotTestSuite/);
assert.match(suite, /'passed'\s*=>/);
assert.match(suite, /'failed'\s*=>/);
assert.match(suite, /'results'\s*=>/);
assert.match(suite, /check_secret_encryption/);
assert.match(suite, /check_webhook_scheme/);
assert.match(suite, /does not verify certificate reachability or provider registration/i);
assert.match(adminJs, /function escapeHtml\(/);
assert.match(adminJs, /escapeHtml\(r\.name\)/);
assert.match(adminJs, /escapeHtml\(r\.details\)/);
assert.doesNotMatch(adminJs, /<strong>' \+ r\.name \+ '<\/strong>/);

console.log('Admin diagnostics runner smoke checks passed (14 checks).');
