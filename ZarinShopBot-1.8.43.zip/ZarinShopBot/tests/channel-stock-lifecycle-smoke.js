'use strict';
const fs = require('fs');
const assert = require('assert');
const read = (file) => fs.readFileSync(file, 'utf8');
const cart = read('vendor/zarinshopbot-core/Bot/CartTrait.php');
const woo = read('vendor/zarinshopbot-core/Bot/WooCommerceTrait.php');
const webapp = read('vendor/zarinshopbot-core/Bot/WebAppTrait.php');
const flow = read('vendor/zarinshopbot-core/Bot/OrderFlowTrait.php');
const payments = read('vendor/zarinshopbot-core/Bot/PaymentsTrait.php');
const bale = read('includes/class-zarinshopbot-bale-payments.php');
const transfer = read('includes/class-zarinshopbot-card-transfer.php');
const channels = read('includes/class-zarinshopbot-channels.php');

assert(cart.includes('$product->managing_stock()') && cart.includes('$product->get_stock_quantity()') && cart.includes('$product->is_in_stock()'),
  'bot carts validate current WooCommerce stock before order placement');
assert(woo.includes('get_stock_managed_by_id') && woo.includes('stock_totals[$stock_id]'),
  'bot orders aggregate quantities for shared parent-managed variation stock');
assert(woo.includes('wc_reserve_stock_for_order($order)'),
  'shared bot order creation reserves stock before payment handoff for Telegram, Bale and Rubika');
assert(woo.includes("if (!function_exists('wc_reserve_stock_for_order'))") && woo.includes('zarinshopbot_stock_reservation_unavailable'),
  'shared bot order creation fails closed for managed-stock items when WooCommerce cannot reserve stock');
assert(webapp.includes('private static function reserveWebAppOrderStock($order)') && webapp.includes('wc_reserve_stock_for_order($order)'),
  'custom Telegram/Bale Mini App order creation explicitly reserves stock');
const reserveAt = webapp.indexOf('$stock_reservation = self::reserveWebAppOrderStock($order)');
const saveAt = webapp.lastIndexOf('$order->save();', reserveAt);
const freeAt = webapp.indexOf("if ((float) $order->get_total() <= 0)", reserveAt);
const cardAt = webapp.indexOf("if ($selected_payment_type === 'card_transfer')", reserveAt);
const webGatewayAt = webapp.indexOf("if ($selected_payment_type === 'website')", reserveAt);
assert(saveAt >= 0 && reserveAt > saveAt && freeAt > reserveAt && cardAt > reserveAt && webGatewayAt > reserveAt,
  'Mini App stock is reserved after saving line items and before free, transfer or web-gateway branches');
assert(webapp.includes("if (!function_exists('wc_reserve_stock_for_order'))") && webapp.includes('zarinshopbot_stock_reservation_unavailable'),
  'Mini App checkout fails closed for stock-managed, non-backorder items if WooCommerce cannot reserve them');
assert(webapp.includes('$order->delete(true)') && webapp.includes('self::releaseOrderLock($auth_chat_id)') && webapp.includes("'stock_reservation_failed'"),
  'failed stock reservations clean up the incomplete order and checkout lock');
assert(payments.includes('telegramOrderItemsAvailable($order)') && payments.includes('reserveTelegramOrderStock($order)') && payments.includes('$order->payment_complete($transaction_id)'),
  'Telegram native invoice payment checks/reserves stock and reduces it through WooCommerce on verified payment');
assert(payments.includes("!function_exists('wc_reserve_stock_for_order')"),
  'Telegram native pre-checkout fails closed for limited stock if reservation support is missing');
assert(payments.includes('$order->payment_complete($charge_id)') && payments.includes('reserveTelegramOrderStock($order)'),
  'Telegram Stars checks/reserves stock and completes through WooCommerce');
assert(bale.includes('self::order_items_available($order)') && bale.includes('self::reserve_order_stock($order)') && bale.includes('$order->payment_complete('),
  'Bale wallet payment checks/reserves stock before checkout approval and completes through WooCommerce');
assert(webapp.includes('$order->payment_complete();') && webapp.includes('wc_reduce_stock_levels($order->get_id())'),
  'Mini App free orders and manual transfer orders trigger WooCommerce stock reduction');
assert(transfer.includes("$order->update_status('on-hold'") && transfer.includes('wc_reduce_stock_levels($order_id)'),
  'card-transfer orders reduce stock while awaiting manual receipt approval');
assert(woo.includes('get_checkout_payment_url(true)') && woo.includes('self::getPaymentUrl($order)'),
  'Rubika and other website-gateway bot orders hand off to WooCommerce order-pay; stock is finalized by the gateway payment lifecycle');
assert(channels.includes("'_order_from'"), 'channel attribution is stored separately from WooCommerce stock lifecycle');
console.log('Cross-platform WooCommerce stock lifecycle smoke checks passed (16 checks).');
