const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const telegram = fs.readFileSync(path.join(root, 'vendor/zarinshopbot-core/Bot/TelegramTrait.php'), 'utf8');
const panel = fs.readFileSync(path.join(root, 'panel/main.php'), 'utf8');
const bootstrap = fs.readFileSync(path.join(root, 'zarinshopbot.php'), 'utf8');
const assert = (condition, message) => {
  if (!condition) throw new Error(`FAILED: ${message}`);
};
assert(telegram.includes("function_exists('mb_substr')") && telegram.includes(': substr($params[\'caption\'], 0, $telegram_max_length_photo_caption);'), 'Telegram photo caption truncation guards the optional mbstring extension');
assert(panel.includes("preg_match('/^./us', $full_name, $avatar_initial)"), 'Subscriber avatar initials do not require mbstring');
assert(bootstrap.includes("$recommended_extensions = ['curl', 'mbstring']") && !bootstrap.includes("['curl', 'mbstring', 'pdo']"), 'Environment notice does not require the unused PDO extension');
console.log('Optional mbstring compatibility static smoke checks passed (3 checks).');
