<?php
/** Exercise atomic checkout-lock ownership and stale-lock recovery without WordPress. */
$GLOBALS['zsb_lock_options'] = array();
$GLOBALS['zsb_lock_token_counter'] = 0;

function absint($value) { return abs((int) $value); }
function wp_generate_password($length = 12, $special_chars = true, $extra_special_chars = false) {
    $value = str_pad((string) ++$GLOBALS['zsb_lock_token_counter'], (int) $length, 'x');
    return substr($value, 0, (int) $length);
}
function add_option($name, $value, $deprecated = '', $autoload = 'yes') {
    if (array_key_exists($name, $GLOBALS['zsb_lock_options'])) return false;
    $GLOBALS['zsb_lock_options'][$name] = $value;
    return true;
}
function get_option($name, $default = false) { return $GLOBALS['zsb_lock_options'][$name] ?? $default; }
function maybe_serialize($value) { return is_array($value) || is_object($value) ? serialize($value) : (string) $value; }
function wp_cache_delete($key, $group = '') { return true; }

class Zsb_Order_Lock_DB {
    public $options = 'wp_options';
    private $prepared = array();
    public function prepare($query, ...$args) { $this->prepared = array($query, $args); return 'prepared-lock-delete'; }
    public function query($query) {
        if ($query !== 'prepared-lock-delete' || count($this->prepared[1]) !== 2) return false;
        list($key, $value) = $this->prepared[1];
        if (!array_key_exists($key, $GLOBALS['zsb_lock_options']) || $GLOBALS['zsb_lock_options'][$key] !== $value) return 0;
        unset($GLOBALS['zsb_lock_options'][$key]);
        return 1;
    }
}
$GLOBALS['wpdb'] = new Zsb_Order_Lock_DB();
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/SecurityTrait.php';
class Zsb_Order_Lock_Probe { use \ZarinShopBot\Core\Bot\SecurityTrait; }

function zsb_lock_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}

$chat = 'rubika_0123456789';
zsb_lock_assert(Zsb_Order_Lock_Probe::acquireOrderLock($chat), 'first concurrent checkout acquires the lock');
zsb_lock_assert(!Zsb_Order_Lock_Probe::acquireOrderLock($chat), 'a concurrent checkout cannot acquire an existing lock');
Zsb_Order_Lock_Probe::releaseOrderLock($chat);
zsb_lock_assert(Zsb_Order_Lock_Probe::acquireOrderLock($chat), 'released lock is immediately reusable');
Zsb_Order_Lock_Probe::releaseOrderLock($chat);

$key = 'zarincode_order_lock_' . md5($chat);
$GLOBALS['zsb_lock_options'][$key] = (string) (time() - 1) . ':stale-lock-token';
zsb_lock_assert(Zsb_Order_Lock_Probe::acquireOrderLock($chat), 'expired lock is recovered safely');

// Simulate a lock replacement by another request; releasing the old owner must not delete it.
$new_owner_value = (string) (time() + 120) . ':new-owner-token';
$GLOBALS['zsb_lock_options'][$key] = $new_owner_value;
Zsb_Order_Lock_Probe::releaseOrderLock($chat);
zsb_lock_assert(($GLOBALS['zsb_lock_options'][$key] ?? '') === $new_owner_value, 'an old request cannot release a replacement owner lock');

fwrite(STDOUT, "Atomic checkout lock smoke tests passed (5 checks).\n");
