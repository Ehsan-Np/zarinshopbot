'use strict';
const fs = require('fs');
const assert = require('assert');
const adminJs = fs.readFileSync('assets/js/admin-settings.js', 'utf8');
const channels = fs.readFileSync('includes/class-zarinshopbot-channels.php', 'utf8');
const menu = fs.readFileSync('vendor/zarinshopbot-core/Bot/MenuTrait.php', 'utf8');
const webapp = fs.readFileSync('assets/js/webapp.js', 'utf8');
const adminCss = fs.readFileSync('assets/css/admin-settings.css', 'utf8');

assert.match(adminJs, /\$\(document\)\.on\('click', '\.zarin-copy-webapp-url'/,
  'Bale URL copy action is delegated for the lazily loaded channel panel');
assert.match(adminJs, /navigator\.clipboard\.writeText\(value\)/,
  'Bale URL copy uses the secure Clipboard API when available');
assert.match(adminJs, /document\.execCommand\('copy'\)/,
  'Bale URL copy has a legacy clipboard fallback');
assert.match(channels, /https:\/\/ble\.ir\/' \. rawurlencode\(ltrim\(\(string\) \$options\['bale_username'\]/,
  'Bale direct Mini App link uses the official bot username launch URL');
assert.match(channels, /href="<\?php echo esc_url\(\$bale_main_app_link\); \?>" target="_blank"/,
  'Bale main-app link is directly clickable from settings');
assert.match(channels, /تنظیم Main Mini App در BotFather/,
  'admin setup guidance explains the required Bale BotFather registration');
assert.match(menu, /\(\$channel_context\['platform'\] \?\? ''\) === 'bale'/,
  'UTF-8-safe label handling is limited to Bale Web App buttons');
assert.match(menu, /preg_split\('\/\/u', \$title/,
  'Bale button title truncation preserves UTF-8 when mbstring is unavailable');
assert.match(webapp, /function storageGet\(key\)/,
  'Mini App storage access is protected against restricted WebViews');
assert.match(webapp, /function storageJson\(key, fallback\)/,
  'invalid or unavailable stored JSON cannot abort Mini App startup');
assert.match(webapp, /storageSet\('zarincode_cart'/,
  'cart state continues to persist through the safe storage wrapper');
assert.match(adminCss, /\.zarin-channel-card \.zarin-channel-app-link a/,
  'clickable Bale deep links wrap safely in the admin panel');
console.log('Bale Mini App controls smoke checks passed (12 checks).');
