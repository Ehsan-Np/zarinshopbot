<?php
/** Offline regression tests for per-product checkout fields and no-payment safety. */
if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
$GLOBALS['zsb_checkout_options'] = array();
$GLOBALS['zsb_checkout_products'] = array();
$GLOBALS['zsb_checkout_events'] = array();
function absint($value) { return abs((int) $value); }
function zarincode_option($key) { return $GLOBALS['zsb_checkout_options'][$key] ?? false; }
function get_option($key, $default = false) { return $key === 'zarincode_settings' ? $GLOBALS['zsb_checkout_options'] : $default; }
function wc_get_product($id) { return $GLOBALS['zsb_checkout_products'][(string) $id] ?? null; }
function is_wp_error($value) { return $value instanceof WP_Error; }
function __($text, $domain = null) { return $text; }
function zsb_checkout_assert($condition, $label) { if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); } }
class WP_Error { private $code; public function __construct($code = '') { $this->code = $code; } public function get_error_code() { return $this->code; } }
class ZSB_CheckoutProduct {
    private $downloadable; private $price; private $shipping;
    public function __construct($downloadable, $price, $shipping) { $this->downloadable = $downloadable; $this->price = $price; $this->shipping = $shipping; }
    public function exists() { return true; }
    public function is_downloadable() { return $this->downloadable; }
    public function get_price() { return $this->price; }
    public function needs_shipping() { return $this->shipping; }
    public function is_virtual() { return !$this->shipping; }
}
class ZSB_CheckoutOrder {
    public $total = 0; public $paid = false; public $status = 'pending'; public $meta = array('_zsb_digital_only_checkout' => 'yes');
    public function get_id() { return 77; }
    public function get_total() { return $this->total; }
    public function update_status($status, $note = '') { $this->status = $status; $GLOBALS['zsb_checkout_events'][] = 'status:' . $status; }
    public function payment_complete() { $this->paid = true; $GLOBALS['zsb_checkout_events'][] = 'payment_complete'; }
    public function is_paid() { return $this->paid; }
    public function has_downloadable_item() { return true; }
    public function is_download_permitted() { return $this->paid; }
    public function get_meta($key, $single = true) { return $this->meta[$key] ?? ''; }
}
class_alias('ZSB_CheckoutOrder', 'WC_Order');
function wc_get_order($id) { return $GLOBALS['zsb_checkout_order']; }
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/ApiTrait.php';
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/OrderFlowTrait.php';
class ZSB_CheckoutBot {
    use \ZarinShopBot\Core\Bot\ApiTrait;
    use \ZarinShopBot\Core\Bot\OrderFlowTrait;
    public static $cart = array();
    public static $register_req_email = 0, $register_req_state = 0, $register_req_city = 0, $register_req_name = 0;
    public static $register_req_phone = 0, $register_req_address = 0, $register_req_zip = 0, $register_req_ordernote = 0;
    public static $register_req_shipping = 0, $register_req_payment = 0, $chat_id = 'chat-1';
    public static function getCart() { return self::$cart; }
    public static function getSession($key) { return $key === 'cart' ? self::$cart : null; }
    public static function setLastRequest($value) {}
    public static function wooCreateOrder() { return array('order_db_id' => 77); }
    public static function releaseOrderLock($id) {}
    public static function sendMessage($message) { $GLOBALS['zsb_checkout_events'][] = 'message'; }
    public static function emptyCart() { $GLOBALS['zsb_checkout_events'][] = 'empty_cart'; }
    public static function step9OrderChange($id, $status) { $GLOBALS['zsb_checkout_events'][] = 'order_change:' . $status; }
    public static function showDownloadLink($order) { $GLOBALS['zsb_checkout_events'][] = 'download_link'; }
    public static function botTranslate($text, $domain = null) { return $text; }
    public static function btnHome() { return array('text' => 'Home'); }
}

$GLOBALS['zsb_checkout_products'] = array(
    '101' => new ZSB_CheckoutProduct(true, 0, false),
    '102' => new ZSB_CheckoutProduct(true, 25, false),
    '202' => new ZSB_CheckoutProduct(false, 40, true),
);
$GLOBALS['zsb_checkout_options'] = array(
    'register_req_email' => '1', 'register_req_state' => '1', 'register_req_city' => '1',
    'register_req_name' => '1', 'register_req_phone' => '3', 'register_req_address' => '1',
    'register_req_zip' => '1', 'register_req_ordernote' => '0', 'register_req_shipping' => '1',
    'register_req_payment' => '0',
);

ZSB_CheckoutBot::$cart = array('101' => 1);
ZSB_CheckoutBot::applyCheckoutFieldProfile();
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_name === 1 && ZSB_CheckoutBot::$register_req_phone === 3 && ZSB_CheckoutBot::$register_req_email === 1, 'download-only defaults require name, email, and mobile-only phone');
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_email === 1 && ZSB_CheckoutBot::$register_req_address === 0 && ZSB_CheckoutBot::$register_req_shipping === 0, 'download-only default requires email while skipping address and shipping');
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_payment === 0, 'free downloadable-only cart bypasses payment');

$GLOBALS['zsb_checkout_options']['checkout_fields_digital'] = array('name' => '0', 'phone' => '3', 'email' => '1', 'address' => '1', 'shipping' => '1');
ZSB_CheckoutBot::$cart = array('102' => 1);
ZSB_CheckoutBot::applyCheckoutFieldProfile();
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_name === 0 && ZSB_CheckoutBot::$register_req_phone === 3 && ZSB_CheckoutBot::$register_req_email === 1, 'download profile can disable the name field while preserving the explicitly enabled phone and email fields');
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_address === 1 && ZSB_CheckoutBot::$register_req_shipping === 0, 'download profile may collect configured metadata but can never request shipping');
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_payment === 1, 'paid downloadable-only cart requires payment even when the legacy payment checkbox is off');

$GLOBALS['zsb_checkout_options']['checkout_fields_physical'] = array('name' => '0', 'phone' => '0', 'email' => '1', 'state' => '1', 'city' => '1', 'address' => '1', 'zip' => '1', 'ordernote' => '0', 'shipping' => '1');
ZSB_CheckoutBot::$cart = array('202' => 1);
ZSB_CheckoutBot::applyCheckoutFieldProfile();
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_name === 0 && ZSB_CheckoutBot::$register_req_phone === 0 && ZSB_CheckoutBot::$register_req_email === 1, 'physical field profile can independently disable name and phone while keeping email enabled');
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_shipping === 1, 'physical profile retains WooCommerce shipping selection');

// The administrator's global phone mode is used when a per-cart profile follows the global setting.
unset($GLOBALS['zsb_checkout_options']['checkout_fields_physical']);
$GLOBALS['zsb_checkout_options']['register_req_phone'] = '1';
$GLOBALS['zsb_checkout_options']['checkout_fields_physical'] = array('phone' => 'global');
ZSB_CheckoutBot::applyCheckoutFieldProfile();
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_phone === 1, 'per-cart profile inherits the global mobile-or-landline mode');
unset($GLOBALS['zsb_checkout_options']['checkout_fields_physical']);
ZSB_CheckoutBot::applyCheckoutFieldProfile();
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_phone === 1, 'global phone mode allows a general mobile-or-landline prompt');
$GLOBALS['zsb_checkout_options']['register_req_phone'] = '0';
ZSB_CheckoutBot::applyCheckoutFieldProfile();
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_phone === 0, 'global phone mode can turn phone collection off');

// Account creation or OTP always wins over a conflicting phone preference.
$GLOBALS['zsb_checkout_options']['checkout_fields_physical'] = array('phone' => '0');
$GLOBALS['zsb_checkout_options']['customer_account_policy'] = 'account';
$GLOBALS['zsb_checkout_options']['phone_sms_verification'] = '1';
ZSB_CheckoutBot::applyCheckoutFieldProfile();
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_phone === 3, 'account and OTP policy force verified mobile collection');
unset($GLOBALS['zsb_checkout_options']['checkout_fields_physical'], $GLOBALS['zsb_checkout_options']['customer_account_policy']);
$GLOBALS['zsb_checkout_options']['phone_sms_verification'] = '0';
$GLOBALS['zsb_checkout_options']['register_req_phone'] = '3';
ZSB_CheckoutBot::applyCheckoutFieldProfile();
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_phone === 3 && ZSB_CheckoutBot::$register_req_name === 1 && ZSB_CheckoutBot::$register_req_email === 1, 'legacy physical settings cannot override mandatory identity fields');
$GLOBALS['zsb_checkout_options']['checkout_fields_physical'] = array('name' => '0', 'phone' => '0', 'email' => '1', 'state' => '1', 'city' => '1', 'address' => '1', 'zip' => '1', 'ordernote' => '0', 'shipping' => '1');
ZSB_CheckoutBot::$cart = array('101' => 1, '202' => 1);
ZSB_CheckoutBot::applyCheckoutFieldProfile();
zsb_checkout_assert(ZSB_CheckoutBot::$register_req_shipping === 1, 'mixed cart uses physical checkout fields and shipping');

$GLOBALS['zsb_checkout_order'] = new ZSB_CheckoutOrder();
$GLOBALS['zsb_checkout_order']->total = 25;
$GLOBALS['zsb_checkout_events'] = array();
ZSB_CheckoutBot::step8_1_RegisterOrderNoPayment();
zsb_checkout_assert(!$GLOBALS['zsb_checkout_order']->paid && $GLOBALS['zsb_checkout_order']->status === 'failed', 'positive-total no-payment order cannot be marked paid or grant downloads');
zsb_checkout_assert(!in_array('empty_cart', $GLOBALS['zsb_checkout_events'], true) && !in_array('download_link', $GLOBALS['zsb_checkout_events'], true), 'unpaid order preserves cart and emits no download link');

$GLOBALS['zsb_checkout_order'] = new ZSB_CheckoutOrder();
$GLOBALS['zsb_checkout_order']->total = 0;
$GLOBALS['zsb_checkout_events'] = array();
ZSB_CheckoutBot::step8_1_RegisterOrderNoPayment();
zsb_checkout_assert($GLOBALS['zsb_checkout_order']->paid && in_array('download_link', $GLOBALS['zsb_checkout_events'], true), 'zero-total WooCommerce order completes and delivers its permitted download');

$panel_source = file_get_contents(dirname(__DIR__) . '/panel/settings.php');
$settings_source = file_get_contents(dirname(__DIR__) . '/zarinshopbot.php');
$flow_source = file_get_contents(dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/OrderFlowTrait.php');
zsb_checkout_assert(strpos($panel_source, "'digital' => array(") !== false && strpos($panel_source, "'physical' => array(") !== false && strpos($panel_source, "'checkout_fields_'") !== false, 'settings panel exposes separate downloadable and physical field profiles');
zsb_checkout_assert(strpos($panel_source, 'wc_checkout_fields') !== false && strpos($panel_source, 'نمایش/فعال') !== false && strpos($panel_source, 'اجباری') !== false, 'panel exposes independent enabled and required controls for WooCommerce profiles');
zsb_checkout_assert(strpos($settings_source, "if (\$profile_key === 'checkout_fields_digital' && \$field === 'shipping')") !== false && strpos($settings_source, "\$profile['email'] = '1'") === false && strpos($settings_source, "\$profile['phone'] = '3'") === false, 'settings sanitizer enforces the digital shipping restriction without hard-locking identity fields');
zsb_checkout_assert(strpos($flow_source, 'if (!self::acquireOrderLock(self::$chat_id))') !== false && strpos($flow_source, 'Payment is required for orders with a positive total') !== false, 'free checkout is idempotently locked and positive-total orders cannot be completed without payment');
echo "Checkout-field profile and download-payment smoke tests passed (19 checks).\n";
