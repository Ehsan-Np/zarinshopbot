const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const editor = read('includes/class-zarinshopbot-message-editor.php');
const settings = read('panel/settings.php');
const main = read('panel/main.php');
const sanitize = read('zarinshopbot.php');
const parser = read('vendor/zarinshopbot-core/Bot/TelegramTrait.php');
const commands = read('vendor/zarinshopbot-core/Bot/CommandsTrait.php');
const languages = read('vendor/zarinshopbot-core/Bot/LanguageTrait.php');
const adminJs = read('assets/js/message-editor.js');
const mainJs = read('assets/js/admin-main.js');

for (const id of ['zsb_msg_start', 'zsb_msg_bye', 'zsb_msg_home', 'zsb_msg_contact', 'zsb_msg_help', 'zsb_msg_about', 'zsb_msg_signature', 'zsb_campaign_banner', 'zsb_transfer_description', 'zsb_transfer_instructions']) {
  assert(settings.includes(`Message_Editor::render('${id}'`), `${id} uses the visual editor`);
}
assert(settings.includes("'customer', 'zarin-message-override'"), 'per-platform overrides use rich editors and retain their clear-to-shared interaction');
assert(settings.includes('id="telegram_post_title"') && settings.includes("Message_Editor::renderVariables('telegram_post_title', 'product')"), 'Telegram product-post title exposes its valid product token');
for (const token of ['%FIRST_NAME%', '%LAST_NAME%', '%USERNAME%', '%CHAT_ID%', '%LOCATION_LATITUDE%', '%LOCATION_LONGITUDE%']) {
  assert(editor.includes(token) && parser.includes(token), `${token} is shown and implemented by the message parser`);
}
assert(editor.includes('forecolor,backcolor') && editor.includes("'style' => true"), 'visual editor offers color controls and KSES permits safe editor styles');
assert(parser.includes('normalizeRichEditorMarkup') && parser.includes("'br' => []") && parser.includes("'tg-spoiler' => []"), 'chat output normalizes paragraphs/lists and keeps supported inline formatting');
assert(parser.includes('escapeMessageVariable') && parser.includes('$text = strtr($text, $variables)'), 'dynamic profile values are inserted as escaped plain text');
assert(settings.includes('campaign_banner_text') && commands.includes('localizedOptionMessage(\'campaign_banner_text\''), 'campaign banner is rich-editable, dynamically expanded and localized');
assert(main.includes("Message_Editor::render('telegram_new_message'") && main.includes('Message_Editor::sanitize'), 'broadcast content uses the rich editor and safe sanitizer');
assert(!main.includes('data-var="%TITLE%"') && !main.includes('data-var="%LINK%"'), 'generic broadcast UI no longer offers unsupported product tokens');
assert(adminJs.includes("'.zsb-message-variable'") && adminJs.includes('tinymce.get'), 'dynamic-variable buttons insert into their own TinyMCE editor');
assert(mainJs.includes('safePreviewMarkup') && mainJs.includes('bindBroadcastEditor'), 'broadcast preview safely follows visual-editor content');
assert(languages.includes('setting.override.') && sanitize.includes('setting.override.'), 'platform-specific override strings are registered and resolved through WPML');
console.log('Rich message editor and dynamic-variable smoke checks passed (27 checks).');
