'use strict';
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const payments = fs.readFileSync(path.join(root, 'vendor/zarinshopbot-core/Bot/PaymentsTrait.php'), 'utf8');
const stars = fs.readFileSync(path.join(root, 'vendor/zarinshopbot-core/Stars.php'), 'utf8');
const api = fs.readFileSync(path.join(root, 'vendor/zarinshopbot-core/Http/TelegramApiAdapter.php'), 'utf8');
const telegram = fs.readFileSync(path.join(root, 'vendor/zarinshopbot-core/Bot/TelegramTrait.php'), 'utf8');
const assert = (condition, message) => {
  if (!condition) throw new Error(`FAILED: ${message}`);
};

assert(/telegramProviderOrderAmount\(\\WC_Order \$order\)/.test(payments) && /telegramCurrencyDecimals\(\$currency\)/.test(payments), 'provider totals use ISO currency minor units rather than the WooCommerce display-decimal setting');
assert(payments.includes("array('BIF', 'CLP', 'DJF'") && payments.includes("array('BHD', 'IQD', 'JOD'") && payments.includes("'CLF', 'UYW'"), 'zero-, three- and unsupported four-decimal ISO currencies are handled explicitly');
assert(/telegramAmountMatches\(\$query->getTotalAmount\(\),\s*\$expected_amount\)/.test(payments), 'pre-checkout validates the exact Telegram amount');
assert(/\$actual_user = self::telegramPaymentUserId\(\$user \? \$user->getId\(\) : null\)/.test(payments), 'pre-checkout binds the payment to the expected numeric Telegram user');
assert(/telegramOrderItemsAvailable\(\$order\)/.test(payments) && /reserveTelegramOrderStock\(\$order\)/.test(payments), 'pre-checkout verifies inventory and asks WooCommerce to reserve stock');
assert(/acquireTelegramPaymentLock\(\$order->get_id\(\)\)/.test(payments) && /finally\s*\{\s*self::releaseTelegramPaymentLock\(\$lock\)/.test(payments), 'successful-payment processing is serialized per order and releases the lock');
assert(/wc_get_order\(\$order_id\).*?Reload after acquiring the lock/s.test(payments) && /getStarsOrderFromPayload\(\$payload\); \/\/ Reload under lock/.test(payments), 'order state and invoice association are refreshed after lock acquisition to prevent stale-object duplicate fulfillment');
assert(/payment_after_existing_payment/.test(payments) && /multiple_provider_charges/.test(payments) && /multiple_stars_charges/.test(payments), 'second or conflicting charges are not silently fulfilled');
assert(/order_changed_after_invoice/.test(payments) && /stars_order_changed/.test(payments), 'unpaid orders changed after invoice issuance are routed to review');
assert(/legacy_provider_match/.test(payments) && /saved_provider_charge/.test(payments), 'provider payment replay is compatible with previously stored charge-ID metadata');
assert(/_zarinshopbot_payment_review_required/.test(payments) && /payment_complete\(\$transaction_id\)/.test(payments), 'inconsistent evidence is recorded and validated payments use WooCommerce completion');
assert(stars.includes('public static function calculateStarsForOrder($order)') && stars.includes('$order_total = (float) $order->get_total();'), 'Stars amounts are computed from the actual WooCommerce order');
assert(/remainder = \$order_total - \$items_total_sum/.test(stars) && /if \(\$rate <= 0\) return 0; \/\/ Do not undercharge tax, shipping, or fees\./.test(stars), 'Stars pricing accounts for non-item order charges and fails closed when they lack a conversion rate');
assert(/answerPreCheckoutQuery', \$params, 0, 6\)/.test(api), 'Telegram pre-checkout responses use a bounded six-second HTTP timeout');
assert(/return new \\WP_Error\('zarincode_telegram_json_encode',/.test(api), 'JSON encoding failures use a syntactically complete WordPress error result');
assert(/is_successful_payment_update/.test(telegram) && /duplicate.*!\$is_successful_payment_update/.test(telegram), 'successful-payment updates bypass the generic update dedupe so payment idempotency can be applied');

console.log('Telegram payment hardening static smoke checks passed (16 checks).');
