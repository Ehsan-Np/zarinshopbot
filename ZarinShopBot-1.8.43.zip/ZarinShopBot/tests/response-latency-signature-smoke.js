'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const channels = read('includes/class-zarinshopbot-channels.php');
const plugin = read('zarinshopbot.php');
const defaults = read('defaults.php');
const core = read('vendor/zarinshopbot-core/Bot/CoreTrait.php');
const telegram = read('vendor/zarinshopbot-core/Bot/TelegramTrait.php');
const api = read('vendor/zarinshopbot-core/Http/TelegramApiAdapter.php');

assert.match(channels, /zsb_rubika_photo_' \. hash\('sha256', \$this->token \. "\\0" \. \$photo_url\)/, 'Rubika photo cache is scoped to this bot token and exact image URL');
assert.match(channels, /get_transient\(\$cache_key\)[\s\S]*?request\('sendFile', \$cached_body\)/, 'a cached Rubika file ID skips image download and upload');
assert.match(channels, /set_transient\(\$cache_key, \$file_id, 30 \* DAY_IN_SECONDS\)/, 'freshly uploaded Rubika file IDs are cached for reuse');
assert.match(channels, /is_rubika_invalid_input\(\$cached_result\)[\s\S]*?delete_transient\(\$cache_key\)/, 'only an explicit provider rejection invalidates a cached file ID');
assert.match(channels, /rubika_photo_pipeline_complete[\s\S]*?duration_ms[\s\S]*?file_cache_hit/, 'Rubika photo sends expose cache-hit and total-stage timing without logging user content');
assert.match(channels, /channel_update_handled[\s\S]*?duration_ms/, 'Bale/Rubika webhook duration is recorded for comparison with API-call timings');

assert.match(api, /telegram_api_success[\s\S]*?duration_ms/, 'Telegram outbound API calls already log per-call durations');
assert.match(telegram, /update_completed[\s\S]*?duration_ms/, 'Telegram inbound workflow already logs total handling duration');
assert.match(plugin, /function zarincode_flush_event_log_buffer\(\)[\s\S]*?array_merge\(\$logs, \$buffer\)[\s\S]*?update_option\('wp_zarincode_activity_log'/, 'activity events are persisted in one batched option write');
assert.match(plugin, /add_action\('shutdown', 'zarincode_flush_event_log_buffer', 999\)/, 'batched activity logs flush after response handling');
const logger = plugin.slice(plugin.indexOf('function zarincode_log_event('), plugin.indexOf('function zarincode_sendmessagetoall('));
assert.doesNotMatch(logger, /get_option\('wp_zarincode_activity_log'/, 'each API/update event no longer rereads the large activity-log option');

const professionalSignature = '<b>زرین‌کد</b> | همراه هوشمند فروش شما · <a href="https://zarincode.com">Zarincode.com</a>';
assert(defaults.includes(`['botsign', '${professionalSignature}']`), 'new installs receive the professional linked signature by default');
assert(defaults.includes("$old_default = '✦ با مهر، زرین‌کد';") && defaults.includes("trim((string) $options['botsign']) === $old_default") && defaults.includes("$options['botsign'] = $new_default;"), 'only the untouched old default is upgraded; custom signatures are preserved');
assert.match(core, /self::parseText\(\$configured_sign, 'HTML'\)/, 'signature markup passes through the existing HTML allowlist/formatter');
assert.match(telegram, /'a' => \['href' => true\]/, 'the shared formatter permits safe website links before platform-specific formatting');
assert.match(channels, /\$tag === 'a'|\$tag === \"a\"|\$tag === 'a'|rubika_link_buttons_to_metadata/, 'Bale/Rubika formatters receive and convert linked signature markup');
console.log('Response latency/signature static smoke checks passed (15 checks).');
