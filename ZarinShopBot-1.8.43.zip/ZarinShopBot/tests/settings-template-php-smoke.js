'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const settings = fs.readFileSync(path.join(root, 'panel/settings.php'), 'utf8');
const lines = settings.split(/\r?\n/);
const inlineRenderLines = lines
  .map((text, index) => ({ text, line: index + 1 }))
  .filter(({ text }) => text.includes('<?php') && text.includes('Message_Editor::render('));
assert(inlineRenderLines.length > 0, 'Settings page contains inline message-editor render calls');
for (const { text, line } of inlineRenderLines) {
  assert(text.includes('?>'), `Inline PHP render call must close its PHP tag on line ${line}`);
}

const orders = fs.readFileSync(path.join(root, 'vendor/zarinshopbot-core/Bot/OrdersTrait.php'), 'utf8');
assert(/if\s*\(!is_scalar\(\$text\)\)\s*\{\s*return\s+'';\s*\}/.test(orders), 'toPersian safely handles null/non-scalar values');
assert(/str_ireplace\(\$src,\s*\$des,\s*\(string\)\s*\$text\)/.test(orders), 'toPersian passes a string subject to str_ireplace');

console.log(`Settings-template PHP boundary smoke checks passed (${inlineRenderLines.length} inline render tags and null-safe digit conversion).`);
