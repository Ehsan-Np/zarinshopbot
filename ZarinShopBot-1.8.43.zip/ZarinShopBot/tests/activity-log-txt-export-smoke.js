const fs = require('fs');
const assert = require('assert');
const panel = fs.readFileSync('panel/main.php', 'utf8');
const admin = fs.readFileSync('settings-management.php', 'utf8');
const logs = fs.readFileSync('includes/class-zarinshopbot-activity-logs.php', 'utf8');

assert(panel.includes("'action' => 'zarincode_download_activity_txt'") && panel.includes("'source' => $log_source"), 'activity history exposes TXT download for the active platform filter');
assert(panel.includes("'zarincode_download_activity_txt'") && panel.includes("esc_html_e('Download TXT'"), 'the activity log header includes a nonce-protected TXT download action');
assert(admin.includes("add_action('admin_post_zarincode_download_activity_txt'") && admin.includes("current_user_can('manage_options')") && admin.includes("check_admin_referer('zarincode_download_activity_txt')"), 'TXT export is restricted to authorized administrators and a valid nonce');
assert(admin.includes("ZarinShopBot_Activity_Logs::query($requested_source)"), 'export uses the same sanitized, filtered log records as the activity table');
assert(admin.includes("Content-Type: text/plain; charset=UTF-8") && admin.includes('Content-Disposition: attachment; filename="zarinshopbot-activity-') && admin.includes(".txt\"');"), 'export downloads as a UTF-8 plain-text TXT attachment');
assert(admin.includes("preg_replace('/[\\x00-\\x1F\\x7F]+/'") && admin.includes("implode(\"\\r\\n\", $lines)"), 'export strips control characters and creates one record per line');
assert(logs.includes('function zarincode_redact') || logs.includes("function_exists('zarincode_redact')"), 'activity log normalization redacts sensitive structured values before export');
console.log('Activity log TXT export smoke checks passed (7 checks).');
