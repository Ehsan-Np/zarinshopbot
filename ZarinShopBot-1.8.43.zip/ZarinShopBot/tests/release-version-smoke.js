const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const version = '1.8.43';

assert(read('zarinshopbot.php').includes(`Version:      ${version}`), 'plugin header matches the audited release');
assert(read('zarinshopbot.php').includes(`define('ZARINSHOPBOT_VERSION', '${version}')`), 'runtime constant matches the audited release');
assert(read('composer.json').includes(`"version": "${version}"`), 'Composer metadata matches the audited release');
assert(read('readme.txt').includes(`Stable tag: ${version}`), 'WordPress readme stable tag matches the audited release');
assert(read('README.md').includes(`نسخهٔ ${version}`), 'Persian project README matches the audited release');
assert(read('docs/guide-fa.html').includes(`نسخه ${version}`), 'offline guide labels match the audited release');
assert(read('languages/zarinshopbot.pot').includes(`Project-Id-Version: ZarinShopBot ${version}`), 'POT metadata matches the audited release');
assert(read('languages/zarinshopbot-fa_IR.po').includes(`Project-Id-Version: ZarinShopBot ${version}`), 'PO metadata matches the audited release');
const mo = fs.readFileSync(path.join(root, 'languages/zarinshopbot-fa_IR.mo')).toString('latin1');
assert(mo.includes(`Project-Id-Version: ZarinShopBot ${version}`), 'compiled MO metadata matches the audited release');
console.log('Release-version metadata checks passed (9 checks).');
