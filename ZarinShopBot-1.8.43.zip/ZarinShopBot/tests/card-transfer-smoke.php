<?php
/** Offline card-transfer configuration/fallback regression checks. */
if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
$GLOBALS['zsb_card_settings'] = [];
$GLOBALS['zsb_test_options'] = [];
$GLOBALS['zsb_lookup_order'] = false;
$GLOBALS['zsb_sent_messages'] = [];
$GLOBALS['zsb_card_gateway_objects'] = [];
$GLOBALS['zsb_test_actions'] = [];
$GLOBALS['zsb_registered_settings'] = [];
function add_action($hook, $callback, $priority = 10, $accepted_args = 1) { $GLOBALS['zsb_test_actions'][$hook][] = $callback; if ($hook === 'plugins_loaded') call_user_func($callback); }
function register_setting($group, $name, $args = []) { $GLOBALS['zsb_registered_settings'][$name] = ['group' => $group, 'args' => $args]; }
function add_filter($hook, $callback, $priority = 10, $accepted_args = 1) { $GLOBALS['zsb_card_filters'][$hook] = $callback; }
class WC_Payment_Gateway { public function get_field_value($key, $field, $post_data = array()) { return ''; } }
class WC_Order {
    public $payment_method = 'zarinshopbot_card_transfer'; public $status = 'on-hold'; public $meta = []; public $payment_completed = false;
    public $paid = false; public $download_permitted = false; public $has_downloads = true;
    public function get_payment_method() { return $this->payment_method; }
    public function get_status() { return $this->status; }
    public function get_meta($key, $single = true) { return $this->meta[$key] ?? ''; }
    public function update_meta_data($key, $value) { $this->meta[$key] = $value; }
    public function save() {}
    public function get_id() { return 123; }
    public function get_order_number() { return '123'; }
    public function is_paid() { return $this->paid; }
    public function has_downloadable_item() { return $this->has_downloads; }
    public function is_download_permitted() { return $this->download_permitted; }
    public function get_downloadable_items() { return [['download_url' => 'https://shop.example/download/abc', 'download_name' => 'Course file']]; }
    public function payment_complete() { $this->payment_completed = true; $this->paid = true; }
}
class WP_Error { private $code; public function __construct($code = '') { $this->code = $code; } public function get_error_code() { return $this->code; } }
function is_wp_error($value) { return $value instanceof WP_Error; }
function wp_salt($scheme = 'auth') { return 'zsb-test-secret-salt'; }
function absint($value) { return abs((int) $value); }
function __($text, $domain = null) { return $text;}
function esc_html($text) { return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8'); }
function esc_attr($text) { return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8'); }
function esc_textarea($text) { return htmlspecialchars((string) $text, ENT_NOQUOTES, 'UTF-8'); }
function esc_html__($text, $domain = null) { return esc_html($text); }
function esc_attr__($text, $domain = null) { return esc_attr($text); }
function get_option($key, $default = false) {
    if ($key === 'woocommerce_zarinshopbot_card_transfer_settings') return $GLOBALS['zsb_card_settings'];
    if (strpos((string) $key, '_zsb_bot_download_delivery_lock_') === 0) return $GLOBALS['zsb_test_options'][$key] ?? $default;
    return $GLOBALS['zsb_gateway_options'][$key] ?? $default;
}
function add_option($key, $value = '', $deprecated = '', $autoload = 'yes') {
    if (isset($GLOBALS['zsb_test_options'][$key])) return false;
    $GLOBALS['zsb_test_options'][$key] = $value;
    return true;
}
function delete_option($key) { unset($GLOBALS['zsb_test_options'][$key]); return true; }
function wc_get_order($id) { return $GLOBALS['zsb_lookup_order'] ?? false; }
function esc_url($value) { return filter_var((string) $value, FILTER_VALIDATE_URL) ? (string) $value : ''; }
function sanitize_key($value) { return preg_replace('/[^a-z0-9_\-]/', '', strtolower((string) $value)); }
function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function wp_kses_post($value) { return strip_tags((string) $value); }
function wp_strip_all_tags($value) { return strip_tags((string) $value); }
function zarincode_option($key) { return $key === 'admin_notification_chat_id' ? '456' : ($GLOBALS['zsb_card_telegram_native'] ?? '0'); }
function WC() { return $GLOBALS['zsb_fake_wc'] ?? null; }
class ZSB_Fake_Gateway_Manager { public function payment_gateways() { return $GLOBALS['zsb_card_gateway_objects']; } }
class ZSB_Fake_WC { public $manager; public function __construct() { $this->manager = new ZSB_Fake_Gateway_Manager(); } public function payment_gateways() { return $this->manager; } }
class ZSB_Fake_Gateway {
    public $id; public $title; public $description; public $enabled = 'yes'; public $availability = true;
    public function __construct($id, $title) { $this->id = $id; $this->title = $title; $this->description = 'Checkout on the website'; }
    public function is_available() { return $this->availability; }
}
require dirname(__DIR__) . '/includes/class-zarinshopbot-card-transfer.php';
$registered_gateways = call_user_func($GLOBALS['zsb_card_filters']['woocommerce_payment_gateways'] ?? static function($list) { return $list; }, []);
$GLOBALS['zsb_card_checks'] = 0;
function zsb_card_assert($condition, $message) { $GLOBALS['zsb_card_checks']++; if (!$condition) { fwrite(STDERR, 'FAILED: ' . $message . PHP_EOL); exit(1); } }
zsb_card_assert(class_exists('ZarinShopBot\\WC_Gateway_Card_Transfer'), 'WooCommerce gateway class is registered after WooCommerce loads');
zsb_card_assert(in_array('ZarinShopBot\\WC_Gateway_Card_Transfer', $registered_gateways, true), 'payment gateway registration filter includes the class');
foreach ($GLOBALS['zsb_test_actions']['admin_init'] ?? [] as $callback) {
    if (is_array($callback) && $callback[0] === \ZarinShopBot\Card_Transfer::class && $callback[1] === 'registerPanelSettings') call_user_func($callback);
}
zsb_card_assert(($GLOBALS['zsb_registered_settings'][\ZarinShopBot\Card_Transfer::OPTION_KEY]['group'] ?? '') === 'zarincode_settings_options', 'gateway settings are registered in the plugin panel form group');

$GLOBALS['zsb_card_settings'] = [
    'enabled' => 'yes',
    'accounts' => "Main account | Example Bank | Store Owner | 1234-5678-9012-3456 | IR111 | Order number\nMain account | Second Bank | Store Owner | 9999-8888-7777-6666 | IR222 | Second account",
    'allowed_extensions' => 'jpg,jpeg,png,webp,pdf,heic,exe,php',
    'custom_mimes' => "heic|image/heic\nphp|application/x-php",
    'max_upload_mb' => '2',
];
$accounts = \ZarinShopBot\Card_Transfer::accounts();
zsb_card_assert(count($accounts) === 2, 'multiple account rows parse');
zsb_card_assert($accounts[0]['card_number'] === '1234-5678-9012-3456', 'card number is retained as digits and separators');
zsb_card_assert($accounts[0]['id'] !== $accounts[1]['id'], 'duplicate labels still produce unique account ids');
zsb_card_assert($accounts[0]['instructions'] === 'Order number' && $accounts[0]['account_number'] === '', 'legacy six-column settings retain instructions and remain readable');
$localized_digits = \ZarinShopBot\Card_Transfer::parseAccountsValue("حساب | بانک نمونه | صاحب حساب | ۱۲۳۴-۵۶۷۸-۹۰۱۲-۳۴۵۶ | IR۱۲۳۴ | توضیح | ۹۸۷۶۵۴");
zsb_card_assert($localized_digits[0]['card_number'] === '1234-5678-9012-3456' && $localized_digits[0]['account_number'] === '987654', 'Persian and Arabic bank digits normalize to ASCII before validation');
$structured_accounts = \ZarinShopBot\Card_Transfer::parseAccountsValue(json_encode([[
    'label' => 'Main account', 'bank' => 'Example Bank', 'holder' => 'Shop Owner',
    'card_number' => '1234-5678-9012-3456', 'account_number' => '987654321', 'iban' => 'IR111222',
    'instructions' => 'Order number',
]]));
zsb_card_assert(count($structured_accounts) === 1 && $structured_accounts[0]['holder'] === 'Shop Owner', 'structured account records retain the account-holder name');
zsb_card_assert($structured_accounts[0]['account_number'] === '987654321' && $structured_accounts[0]['iban'] === 'IR111222', 'structured records retain account number and IBAN');
$legacy_roundtrip = \ZarinShopBot\Card_Transfer::serializeAccountsValue($structured_accounts);
$legacy_roundtrip_accounts = \ZarinShopBot\Card_Transfer::parseAccountsValue($legacy_roundtrip);
zsb_card_assert(strpos($legacy_roundtrip, '987654321') !== false && $legacy_roundtrip_accounts[0]['account_number'] === '987654321', 'account number is appended to the legacy format and survives round-trip parsing');
$panel_saved = \ZarinShopBot\Card_Transfer::sanitizeGatewaySettings([
    'enabled' => 'yes', 'title' => 'Bank transfer', 'description' => 'Transfer securely',
    'instructions' => 'Upload the receipt after payment.',
    'accounts' => [[
        'label' => 'Main account', 'bank' => 'Example Bank', 'holder' => 'Shop Owner',
        'card_number' => '1111-2222-3333-4444', 'account_number' => '123456', 'iban' => 'IR112233',
        'instructions' => 'Use order number',
    ]],
    'allowed_extensions' => 'jpg,png,pdf,php', 'custom_mimes' => "heic|image/heic\nphp|application/x-php",
    'max_upload_mb' => '30',
]);
$panel_saved_accounts = \ZarinShopBot\Card_Transfer::parseAccountsValue($panel_saved['accounts']);
zsb_card_assert($panel_saved['enabled'] === 'yes' && $panel_saved['title'] === 'Bank transfer', 'plugin-panel settings sanitize and save the gateway enablement and title');
zsb_card_assert(count($panel_saved_accounts) === 1 && $panel_saved_accounts[0]['account_number'] === '123456' && $panel_saved_accounts[0]['holder'] === 'Shop Owner', 'plugin-panel account arrays are normalized into the backward-compatible format');
zsb_card_assert($panel_saved['custom_mimes'] === 'heic|image/heic' && (float) $panel_saved['max_upload_mb'] === 20.0, 'plugin-panel receipt settings reject unsafe MIME types and clamp the upload cap');
$empty_title_saved = \ZarinShopBot\Card_Transfer::sanitizeGatewaySettings(['title' => '']);
zsb_card_assert($empty_title_saved['title'] === \ZarinShopBot\Card_Transfer::defaults()['title'], 'saving an empty card-transfer title restores the default instead of removing the visible title');
$GLOBALS['zsb_card_settings'] = ['title' => '', 'description' => '<p>&nbsp;</p>', 'instructions' => '<p><br></p>'];
zsb_card_assert(\ZarinShopBot\Card_Transfer::customerTitle() === \ZarinShopBot\Card_Transfer::defaults()['title'], 'empty legacy title uses the visible default');
zsb_card_assert(\ZarinShopBot\Card_Transfer::customerDescription() === \ZarinShopBot\Card_Transfer::defaults()['description'], 'empty HTML editor markup restores the customer description');
zsb_card_assert(\ZarinShopBot\Card_Transfer::customerInstructions() === \ZarinShopBot\Card_Transfer::defaults()['instructions'], 'empty HTML editor markup restores the receipt instructions');
$panel_editor_html = \ZarinShopBot\Card_Transfer::renderAccountsEditor(\ZarinShopBot\Card_Transfer::OPTION_KEY . '[accounts]', $legacy_roundtrip);
zsb_card_assert(strpos($panel_editor_html, 'data-account-editor') !== false && strpos($panel_editor_html, 'data-account-raw') !== false, 'plugin-panel account editor includes repeatable UI and a no-JavaScript fallback');
zsb_card_assert(strpos($panel_editor_html, 'woocommerce_zarinshopbot_card_transfer_settings[accounts]') !== false && strpos($panel_editor_html, '987654321') !== false, 'plugin-panel editor posts to the existing WooCommerce option and retains account data');
ob_start();
\ZarinShopBot\Card_Transfer::renderBankDetails($structured_accounts[0]);
$bank_card_html = ob_get_clean();
zsb_card_assert(strpos($bank_card_html, 'zsb-transfer-account-card') !== false && strpos($bank_card_html, 'Shop Owner') !== false, 'customer view renders a readable named bank-card component');
zsb_card_assert(strpos($bank_card_html, '987654321') !== false && strpos($bank_card_html, 'data-copy-value="987654321"') !== false, 'account number is visible and has its own copy control');
$allowed = \ZarinShopBot\Card_Transfer::allowedTypes();
zsb_card_assert(isset($allowed['jpg'], $allowed['pdf'], $allowed['heic']), 'default image/PDF and configured image extension are available');
zsb_card_assert(!isset($allowed['exe'], $allowed['php']), 'script/executable formats are never accepted');
zsb_card_assert(\ZarinShopBot\Card_Transfer::enabled(), 'gateway requires explicit enablement and at least one destination account');
zsb_card_assert(\ZarinShopBot\Card_Transfer::maxUploadBytes() <= 2 * 1024 * 1024, 'configured receipt cap is enforced, bounded by server upload limits');
$pending_receipt_order = new WC_Order();
$pending_receipt_order->meta[\ZarinShopBot\Card_Transfer::META_RECEIPT] = 'encrypted-receipt';
$pending_receipt_order->meta[\ZarinShopBot\Card_Transfer::META_REVIEW] = 'pending';
$replacement_result = \ZarinShopBot\Card_Transfer::storeReceipt($pending_receipt_order, []);
zsb_card_assert($replacement_result instanceof WP_Error && $replacement_result->get_error_code() === 'zsb_receipt_already_submitted', 'customer cannot replace a receipt while the manager is reviewing it');
$pending_receipt_order->meta[\ZarinShopBot\Card_Transfer::META_REVIEW] = 'rejected';
$replacement_result = \ZarinShopBot\Card_Transfer::storeReceipt($pending_receipt_order, []);
zsb_card_assert($replacement_result instanceof WP_Error && $replacement_result->get_error_code() === 'zsb_receipt_upload', 'receipt replacement is allowed after explicit manager rejection and still undergoes upload validation');
$approve_review = new ReflectionMethod('ZarinShopBot\\Card_Transfer', 'approveOrder');
if (PHP_VERSION_ID < 80100) $approve_review->setAccessible(true);
$stale_approval = $approve_review->invoke(null, $pending_receipt_order, 'smoke_test');
zsb_card_assert($stale_approval instanceof WP_Error && $stale_approval->get_error_code() === 'zsb_transfer_review_not_ready' && !$pending_receipt_order->payment_completed, 'a rejected receipt cannot be approved by a stale review action');
$review_callback_method = new ReflectionMethod('ZarinShopBot\\Card_Transfer', 'reviewCallback');
if (PHP_VERSION_ID < 80100) $review_callback_method->setAccessible(true);
$review_callback = $review_callback_method->invoke(null, 'telegram', 123, 'approve', '456', 'AbCDef0123456789');
zsb_card_assert((bool) preg_match('/^ztr:a:123:AbCDef0123456789:[a-f0-9]{12}$/', $review_callback), 'bot review callback carries a signed receipt-cycle nonce within provider callback limits');
$callback_parse_result = \ZarinShopBot\Card_Transfer::handleBotReview('telegram', '456', 'ztr:a:123:AbCDef0123456789:000000000000');
zsb_card_assert($callback_parse_result instanceof WP_Error && $callback_parse_result->get_error_code() === 'zsb_transfer_callback_signature', 'review handler accepts the receipt-bound callback shape and verifies its signature');
$transfer_source = file_get_contents(dirname(__DIR__) . '/includes/class-zarinshopbot-card-transfer.php');
$webapp_source = file_get_contents(dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/WebAppTrait.php');
zsb_card_assert(strpos($transfer_source, 'finfo_file') !== false && strpos($transfer_source, "'%PDF-'") !== false && strpos($transfer_source, 'getimagesize') !== false, 'receipt MIME/signature checks cover PDF and images');
zsb_card_assert(strpos($transfer_source, 'admin-post.php') !== false && strpos($transfer_source, 'wp_upload_dir') === false, 'receipt is served by a private admin endpoint and not the public Media Library');
$settings_panel_source = file_get_contents(dirname(__DIR__) . '/panel/settings.php');
zsb_card_assert(strpos($settings_panel_source, 'id="tab-card-transfer"') !== false && strpos($settings_panel_source, 'renderAccountsEditor') !== false, 'plugin settings panel contains the card-transfer account editor');
zsb_card_assert(strpos($transfer_source, "register_setting('zarincode_settings_options'") !== false && strpos($transfer_source, 'sanitizeGatewaySettings') !== false, 'card-transfer options are registered and sanitized through the plugin settings form');
$bootstrap_source = file_get_contents(dirname(__DIR__) . '/zarinshopbot.php');
zsb_card_assert(strpos($bootstrap_source, "if (\$page === 'zarincode_zarinshopbot_setting')") !== false && strpos($bootstrap_source, "wp_enqueue_script('zarinshopbot-card-transfer-admin'") !== false, 'account-editor assets load directly from the plugin bootstrap on its client-side settings tabs');
zsb_card_assert(strpos($transfer_source, 'WooCommerce settings page') !== false || strpos($transfer_source, 'پنل اصلی افزونه') !== false, 'WooCommerce gateway management points administrators to the plugin panel');
zsb_card_assert(strpos($transfer_source, 'data-copy-value') !== false && strpos($transfer_source, 'zsb-copy-value') !== false, 'bank details expose separately copyable customer fields');
zsb_card_assert(strpos($webapp_source, 'get_checkout_payment_url(true)') !== false && strpos($webapp_source, "'payment_mode' => 'woocommerce_gateway'") !== false, 'Mini App website gateway orders receive a WooCommerce payment-page URL');
$manual_branch = strpos($webapp_source, '$stored_receipt =');
$website_branch = strpos($webapp_source, "if (\$selected_payment_type === 'website')", $manual_branch ?: 0);
$manual_code = $manual_branch !== false && $website_branch !== false ? substr($webapp_source, $manual_branch, $website_branch - $manual_branch) : '';
zsb_card_assert($manual_code !== '' && strpos($manual_code, 'storeReceipt') !== false && strpos($manual_code, 'update_status(\'on-hold\'') !== false && strpos($manual_code, 'payment_complete') === false, 'Mini App card-transfer branch stores receipt and remains on hold without payment completion');
zsb_card_assert(strpos($transfer_source, "add_action('woocommerce_payment_complete', [__CLASS__, 'notifyPaidOrderDownloads'], 50, 1)") !== false, 'valid WooCommerce payments trigger deferred bot download delivery');
zsb_card_assert(strpos($transfer_source, '|| !$order->is_download_permitted() || $order->get_payment_method() === self::METHOD_ID') !== false && strpos($transfer_source, "META_BOT_DOWNLOADS_NOTICE, 'sent'") !== false, 'paid-order bot delivery requires WooCommerce download permission, excludes card-transfer duplicate delivery, and is idempotent');
zsb_card_assert(strpos($transfer_source, "get_downloadable_items()") !== false && strpos($transfer_source, 'sendPlatformMessage($platform, $chat_id, $text') !== false, 'paid downloadable items are sent through the matching Telegram, Bale, or Rubika channel');
$review_start = strpos($transfer_source, 'private static function approveOrder(');
$review_end = strpos($transfer_source, 'private static function rejectOrder(', $review_start ?: 0);
zsb_card_assert($review_start !== false && $review_end !== false && strpos(substr($transfer_source, $review_start, $review_end - $review_start), 'payment_complete()') !== false, 'manager approval path is the card-transfer payment-completion path');

$GLOBALS['zsb_card_telegram_native'] = '0';
$GLOBALS['zsb_fake_wc'] = new ZSB_Fake_WC();
$GLOBALS['zsb_card_gateway_objects'] = [
    'bank_gateway' => new ZSB_Fake_Gateway('bank_gateway', 'Bank Gateway'),
    'wallet_gateway' => new ZSB_Fake_Gateway('wallet_gateway', 'Wallet Gateway'),
];
$GLOBALS['zsb_card_gateway_objects']['wallet_gateway']->availability = false;
$methods = \ZarinShopBot\Card_Transfer::miniAppPaymentMethods('telegram');
zsb_card_assert(count($methods) === 2 && $methods[0]['id'] === 'bank_gateway' && $methods[1]['id'] === 'wallet_gateway', 'fallback exposes all enabled WooCommerce gateways even when local context availability cannot be resolved');
zsb_card_assert($methods[0]['type'] === 'website', 'ordinary gateway is marked as a WooCommerce payment page');
zsb_card_assert(\ZarinShopBot\Card_Transfer::gatewayObject('BANK_GATEWAY') === $GLOBALS['zsb_card_gateway_objects']['bank_gateway'], 'gateway resolver handles normalized IDs without relying only on array keys');
zsb_card_assert(\ZarinShopBot\Card_Transfer::gatewayIsEnabled($GLOBALS['zsb_card_gateway_objects']['bank_gateway']), 'enabled flag recognizes WooCommerce gateway status');
$GLOBALS['zsb_card_gateway_objects']['bank_gateway']->enabled = true;
zsb_card_assert(\ZarinShopBot\Card_Transfer::gatewayIsEnabled($GLOBALS['zsb_card_gateway_objects']['bank_gateway']), 'enabled flag also recognizes boolean gateway statuses');
$GLOBALS['zsb_card_gateway_objects']['bank_gateway']->enabled = 'no';
zsb_card_assert(!\ZarinShopBot\Card_Transfer::gatewayIsEnabled($GLOBALS['zsb_card_gateway_objects']['bank_gateway']), 'disabled gateways remain rejected');
$GLOBALS['zsb_gateway_options']['woocommerce_bank_gateway_settings'] = ['enabled' => 'yes'];
zsb_card_assert(\ZarinShopBot\Card_Transfer::gatewayIsEnabled($GLOBALS['zsb_card_gateway_objects']['bank_gateway']), 'enabled status can be recovered from the WooCommerce settings option');
unset($GLOBALS['zsb_gateway_options']['woocommerce_bank_gateway_settings']);
$GLOBALS['zsb_card_gateway_objects']['bank_gateway']->enabled = 'yes';
$GLOBALS['zsb_card_telegram_native'] = '1';
$GLOBALS['zsb_card_settings']['telegram_provider_token'] = 'dummy';
$native = \ZarinShopBot\Card_Transfer::miniAppPaymentMethods('telegram');
zsb_card_assert(count($native) === 1 && $native[0]['id'] === 'zarincode_telegram_invoice' && $native[0]['type'] === 'native', 'configured Telegram invoice takes precedence over website fallback');
if (!class_exists('ZarinShopBot\\Core\\Http\\TelegramApiAdapter')) {
    eval('namespace ZarinShopBot\\Core\\Http; class TelegramApiAdapter { public static function call($method, $params, $retries = 0) { $GLOBALS["zsb_sent_messages"][] = $params; return ["ok" => true]; } }');
}
$unpaid_download_order = new WC_Order();
$unpaid_download_order->payment_method = 'bank_gateway';
$unpaid_download_order->paid = true;
$unpaid_download_order->download_permitted = false;
$unpaid_download_order->meta = ['_chat_id' => '456', '_order_from' => 'telegram'];
$GLOBALS['zsb_lookup_order'] = $unpaid_download_order;
zsb_card_assert(\ZarinShopBot\Card_Transfer::notifyPaidOrderDownloads(123) === false && count($GLOBALS['zsb_sent_messages']) === 0, 'WooCommerce download links are not sent unless download permission is active');
$permitted_download_order = new WC_Order();
$permitted_download_order->payment_method = 'bank_gateway';
$permitted_download_order->paid = true;
$permitted_download_order->download_permitted = true;
$permitted_download_order->meta = ['_chat_id' => '456', '_order_from' => 'telegram'];
$GLOBALS['zsb_lookup_order'] = $permitted_download_order;
zsb_card_assert(\ZarinShopBot\Card_Transfer::notifyPaidOrderDownloads(123) === true, 'paid orders with WooCommerce download permission notify the purchasing chat');
zsb_card_assert(count($GLOBALS['zsb_sent_messages']) === 1 && strpos($GLOBALS['zsb_sent_messages'][0]['text'], 'https://shop.example/download/abc') !== false && $permitted_download_order->get_meta(\ZarinShopBot\Card_Transfer::META_BOT_DOWNLOADS_NOTICE, true) === 'sent', 'permitted WooCommerce download URL is sent once and recorded');
zsb_card_assert(\ZarinShopBot\Card_Transfer::notifyPaidOrderDownloads(123) === false && count($GLOBALS['zsb_sent_messages']) === 1, 'duplicate payment-complete events do not repeat download delivery');
$card_transfer_download_order = new WC_Order();
$card_transfer_download_order->payment_method = \ZarinShopBot\Card_Transfer::METHOD_ID;
$card_transfer_download_order->paid = true;
$card_transfer_download_order->download_permitted = true;
$card_transfer_download_order->meta = ['_chat_id' => '456', '_order_from' => 'telegram'];
$GLOBALS['zsb_lookup_order'] = $card_transfer_download_order;
zsb_card_assert(\ZarinShopBot\Card_Transfer::notifyPaidOrderDownloads(123) === false, 'card-transfer downloads remain owned by the separate manager-approval notification path');
echo 'Card-transfer smoke tests passed (' . $GLOBALS['zsb_card_checks'] . ' checks).' . PHP_EOL;
