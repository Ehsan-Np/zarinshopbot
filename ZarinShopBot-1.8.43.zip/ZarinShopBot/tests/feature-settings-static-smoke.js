const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
let passed = 0;
function check(condition, label) {
    if (!condition) { console.error('FAILED:', label); process.exit(1); }
    passed++;
}
const settings = read('panel/settings.php');
const sanitizer = read('zarinshopbot.php');
const phone = read('includes/class-zarinshopbot-phone-accounts.php');
const checkout = read('includes/class-zarinshopbot-digital-checkout.php');
const webapp = read('vendor/zarinshopbot-core/Bot/WebAppTrait.php');
const branding = read('templates/webapp.php') + read('assets/css/webapp.css');
const messages = read('vendor/zarinshopbot-core/Bot/CommandsTrait.php') + read('vendor/zarinshopbot-core/Bot/CoreTrait.php');
check(settings.includes("'accounts'") && settings.includes("'checkout-fields'"), 'settings expose account and per-profile checkout panels');
check(settings.includes('customer_account_policy') && ['guest', 'optional', 'account'].every((v) => settings.includes(`value="${v}"`)), 'guest, optional and required account policies are configurable');
check(settings.includes('Kavenegar') && settings.includes('Melipayamak') && settings.includes('sms_kavenegar_api_key_new') && settings.includes('sms_melipayamak_password_new'), 'both SMS providers have secure credential entry fields');
check(sanitizer.includes('sms_kavenegar_api_key_enc') && sanitizer.includes('sms_melipayamak_password_enc') && sanitizer.includes('ProxyManager::encrypt'), 'SMS secrets use encrypted option storage');
check(phone.includes('VerifyLookup') || phone.includes('/verify/lookup.json'), 'Kavenegar VerifyLookup adapter exists');
check(phone.includes('BaseServiceNumber') && phone.includes('bodyId'), 'Melipayamak pattern-send adapter exists');
check(phone.includes('PRIMARY KEY  (phone_hash)') && phone.includes('UNIQUE KEY user_id'), 'phone ownership uses a database uniqueness index');
check(webapp.includes('ajaxSendPhoneOtp') && webapp.includes('ajaxVerifyPhoneOtp') && webapp.includes('Phone_Accounts::isVerified'), 'Mini App OTP endpoints verify signed platform identity and phone code');
check(settings.includes('wc_checkout_fields') && settings.includes('custom_checkout_fields_json') && checkout.includes('configured_checkout_fields'), 'WooCommerce standard and custom checkout fields are configurable and applied');
check(branding.includes('miniapp_brand_logo_id') && branding.includes('--zsb-brand-primary') && branding.includes('miniapp_brand_background'), 'Mini App logo and color settings reach rendered CSS');
check(settings.includes('message_overrides') && sanitizer.includes('message_overrides') && messages.includes('/about'), 'shared/overridden messages include help and about pages');
check(fs.existsSync(path.join(root, 'assets/js/checkout-otp.js')) && read('assets/js/webapp.js').includes('phoneOtpVerified'), 'checkout and Mini App require verified OTP in the client flow');
console.log(`Feature settings static smoke checks passed (${passed} checks).`);
