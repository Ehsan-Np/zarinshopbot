<?php
/** Offline Bot API 10.x update-envelope smoke test. Run with: php tests/telegram-update-envelope-smoke.php */
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Telegram/Entity.php';
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Telegram/Update.php';

function zsb_update_type_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}

zsb_update_type_assert((new \ZarinShopBot\Core\Telegram\Update(array('update_id' => 1, 'message' => array())))->getUpdateType() === 'message', 'Standard message update');
zsb_update_type_assert((new \ZarinShopBot\Core\Telegram\Update(array('update_id' => 2, 'pre_checkout_query' => array())))->getUpdateType() === 'pre_checkout_query', 'Pre-checkout update remains prioritized');
zsb_update_type_assert((new \ZarinShopBot\Core\Telegram\Update(array('update_id' => 3, 'stopped_message_generation' => array())))->getUpdateType() === 'stopped_message_generation', 'Bot API 10.3 stop-generation update recognized');
zsb_update_type_assert((new \ZarinShopBot\Core\Telegram\Update(array('update_id' => 4, 'subscription' => array())))->getUpdateType() === 'subscription', 'Subscription update recognized for safe acknowledgement');
zsb_update_type_assert((new \ZarinShopBot\Core\Telegram\Update(array('update_id' => 5, 'message_reaction_count' => array())))->getUpdateType() === 'message_reaction_count', 'Newer non-commerce update recognized');
zsb_update_type_assert((new \ZarinShopBot\Core\Telegram\Update(array('update_id' => 6)))->getUpdateType() === '', 'Unknown envelope has no inferred user');

echo 'Telegram update envelope smoke tests passed (6 checks).' . PHP_EOL;
