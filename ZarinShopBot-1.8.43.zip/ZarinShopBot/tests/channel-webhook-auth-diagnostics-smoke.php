<?php
/**
 * Offline webhook-auth regression tests. Run with: php tests/channel-webhook-auth-diagnostics-smoke.php
 * No WordPress install, credentials, or external network is used.
 */
if (!defined('ABSPATH')) { define('ABSPATH', __DIR__ . '/'); }

class WP_REST_Response {
    public $data;
    public $status;
    public function __construct($data = null, $status = 200) { $this->data = $data; $this->status = $status; }
}
class WP_REST_Request {
    private $params;
    private $url_params;
    private $body;
    public function __construct($params, $url_params, $body = array()) {
        $this->params = $params; $this->url_params = $url_params; $this->body = $body;
    }
    public function get_param($key) { return $this->params[$key] ?? null; }
    public function get_url_params() { return $this->url_params; }
    public function get_method() { return 'POST'; }
    public function get_json_params() { return $this->body; }
}

$GLOBALS['zsb_webhook_test_options'] = array();
$GLOBALS['zsb_webhook_test_registered_routes'] = array();
$GLOBALS['zsb_webhook_test_logs'] = array();
function get_option($key, $default = false) {
    if ($key === 'zarinshopbot_channels') return $GLOBALS['zsb_webhook_test_options'];
    if ($key === 'zarinshopbot_channel_registered_routes') return $GLOBALS['zsb_webhook_test_registered_routes'];
    return $default;
}
function update_option($key, $value, $autoload = null) {
    if ($key === 'zarinshopbot_channel_registered_routes') { $GLOBALS['zsb_webhook_test_registered_routes'] = $value; return true; }
    return false;
}
function wp_parse_args($args, $defaults = array()) { return array_merge($defaults, is_array($args) ? $args : array()); }
function sanitize_key($value) { return preg_replace('/[^a-z0-9_\\-]/', '', strtolower((string) $value)); }
function wp_salt($scheme = 'auth') { return 'offline-test-salt'; }
function wp_parse_url($url, $component = -1) { return parse_url($url, $component); }
function zarincode_log_event($event, $context = array()) { $GLOBALS['zsb_webhook_test_logs'][] = array('event' => $event, 'context' => $context); }

require dirname(__DIR__) . '/includes/class-zarinshopbot-channels.php';

function zsb_webhook_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}
function zsb_webhook_find_log($event) {
    foreach ($GLOBALS['zsb_webhook_test_logs'] as $log) { if ($log['event'] === $event) return $log; }
    return null;
}
function zsb_webhook_request($path_secret, $combined_secret = null) {
    $params = array('platform' => 'bale', 'secret' => $combined_secret === null ? $path_secret : $combined_secret);
    return new WP_REST_Request($params, array('platform' => 'bale', 'secret' => $path_secret), array());
}

$GLOBALS['zsb_webhook_test_options'] = array('bale_enabled' => '1', 'bale_secret' => 'expectedRouteKey');
$response = \ZarinShopBot\Channels::receive(zsb_webhook_request('wrongRouteKey'));
$auth_log = zsb_webhook_find_log('channel_webhook_auth_error');
zsb_webhook_assert($response instanceof WP_REST_Response && $response->status === 403, 'mismatched route credential remains rejected');
zsb_webhook_assert(($auth_log['context']['reason'] ?? '') === 'key_mismatch', 'auth failure records a non-sensitive reason');
zsb_webhook_assert(($auth_log['context']['expected_present'] ?? false) && ($auth_log['context']['received_present'] ?? false), 'auth failure records presence flags');
zsb_webhook_assert(!empty($auth_log['context']['expected_fingerprint']) && !empty($auth_log['context']['received_fingerprint']), 'auth failure records opaque fingerprints');
zsb_webhook_assert(strpos(json_encode($auth_log), 'expectedRouteKey') === false && strpos(json_encode($auth_log), 'wrongRouteKey') === false, 'auth diagnostics never include credential values');

$GLOBALS['zsb_webhook_test_logs'] = array();
$response = \ZarinShopBot\Channels::receive(zsb_webhook_request('expectedRouteKey', 'shadowValue'));
zsb_webhook_assert($response instanceof WP_REST_Response && $response->status === 200, 'route credential is authoritative over a shadowing parameter');
zsb_webhook_assert(zsb_webhook_find_log('channel_webhook_auth_error') === null, 'shadowing parameter does not trigger auth failure');
zsb_webhook_assert(zsb_webhook_find_log('channel_update_received') !== null, 'authorized request advances past webhook authentication');

// A successful provider registration remains authoritative if a later local
// settings save changes the editable route secret before the next delivery.
$registered_route = 'lastProviderRegisteredRoute';
$GLOBALS['zsb_webhook_test_options'] = array('bale_enabled' => '1', 'bale_secret' => 'newLocalRouteValue');
$GLOBALS['zsb_webhook_test_registered_routes'] = array(
    'bale' => hash_hmac('sha256', $registered_route, wp_salt('auth')),
);
$GLOBALS['zsb_webhook_test_logs'] = array();
$response = \ZarinShopBot\Channels::receive(zsb_webhook_request($registered_route));
zsb_webhook_assert($response instanceof WP_REST_Response && $response->status === 200, 'last confirmed registered route is accepted after local secret drift');
zsb_webhook_assert(zsb_webhook_find_log('channel_webhook_auth_error') === null, 'confirmed registered route avoids false auth rejection');
zsb_webhook_assert(zsb_webhook_find_log('channel_webhook_auth_registered_route') !== null, 'accepted registered fallback is diagnosed safely');
$GLOBALS['zsb_webhook_test_logs'] = array();
$response = \ZarinShopBot\Channels::receive(zsb_webhook_request('unregisteredAttackerRoute'));
zsb_webhook_assert($response instanceof WP_REST_Response && $response->status === 403, 'unregistered route remains rejected when a registered verifier exists');
$persist = new ReflectionMethod('ZarinShopBot\\Channels', 'persist_registered_route_digest');
@$persist->setAccessible(true);
$rubika_digest = hash_hmac('sha256', 'rubikaRegisteredRoute', wp_salt('auth'));
zsb_webhook_assert($persist->invoke(null, 'rubika', $rubika_digest) === true, 'registered route verifier persists to a dedicated option');
zsb_webhook_assert(($GLOBALS['zsb_webhook_test_registered_routes']['rubika'] ?? '') === $rubika_digest, 'dedicated verifier option contains only the keyed digest');

$extractor = new ReflectionMethod('ZarinShopBot\\Channels', 'webhook_secret_from_url');
@$extractor->setAccessible(true);
zsb_webhook_assert($extractor->invoke(null, 'https://shop.example/wp-json/zarinshopbot/v1/hook/bale/AbC123', 'bale') === 'AbC123', 'Bale route secret is safely extracted from pretty REST URL');
zsb_webhook_assert($extractor->invoke(null, 'https://shop.example/?rest_route=%2Fzarinshopbot%2Fv1%2Fhook%2Frubika%2FQrS456', 'rubika') === 'QrS456', 'Rubika route secret is safely extracted from query REST URL');
zsb_webhook_assert($extractor->invoke(null, 'https://shop.example/wp-json/zarinshopbot/v1/hook/bale/AbC123', 'rubika') === '', 'route extractor rejects a different platform');

echo 'Webhook auth diagnostics smoke tests passed (17 checks).' . PHP_EOL;
