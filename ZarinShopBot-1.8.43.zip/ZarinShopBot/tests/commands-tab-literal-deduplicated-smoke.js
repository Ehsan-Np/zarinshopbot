'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const panel = read('panel/settings.php');
const pot = read('languages/zarinshopbot.pot');
const po = read('languages/zarinshopbot-fa_IR.po');
const core = read('vendor/zarinshopbot-core/Bot/CoreTrait.php');
const channels = read('includes/class-zarinshopbot-channels.php');
const dispatcher = read('vendor/zarinshopbot-core/Bot/CommandsTrait.php');
const block = panel.slice(panel.indexOf('id="tab-commands"'), panel.indexOf('</form>', panel.indexOf('id="tab-commands"')));
assert(block.length > 0, 'commands settings tab is found');

const commandNames = ['/start','/shop','/home','/search','/category','/categories','/cats','/newproducts','/new','/cart','/orders','/tracking','/wishlist','/settings','/language','/contactus','/help','/referral','/suggest','/foryou','/bestsellers','/onsale','/stop','/setcommands'];
for (const command of commandNames) {
  const escaped = command.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  assert.doesNotMatch(block, new RegExp(`(?:__|_e|_x|esc_html_e|esc_attr_e)\\s*\\(\\s*['\"]${escaped}['\"]`), `${command} must not be wrapped in a translation call`);
}
assert.match(block, /<td><code>\/start<\/code><\/td>/, 'slash commands are rendered as literal code');
assert.match(block, /<code>\/orders<\/code>[\s\S]*?<code>\/tracking<\/code>/, 'tracking is shown as an alias, not a second duplicate row');
assert.match(block, /<code>\/shop<\/code>[\s\S]*?<code>\/home<\/code>/, 'home is shown as a shop alias');
assert.match(block, /<details class="zarin-command-registration"/, 'the required BotFather copy text is collapsed instead of repeating the main table visually');
assert.match(block, /\$telegram_command_lines\[\]\s*=\s*\$command_name\s*\.\s*' - '\s*\.\s*\$command_description/);
assert.match(block, /<textarea id="zarin_commands_text"[^>]*><\?php echo esc_textarea\(implode\("\\n", \$telegram_command_lines\)\); \?><\/textarea>/);
assert.doesNotMatch(block, /<th>[^<]*Telegram[^<]*<\/th>[\s\S]*<th>[^<]*Bale[^<]*<\/th>[\s\S]*<th>[^<]*Rubika[^<]*<\/th>/, 'same platform checkmarks are not repeated on every command row');
for (const catalog of [pot, po]) assert.doesNotMatch(catalog, /^msgid "\/(?:start|stop|shop|home|search|category|newproducts|cart|orders|tracking|wishlist|settings|language|contactus|help|referral|suggest|bestsellers|onsale)"$/m, 'slash-command names are not gettext entries');

function poField(block, name) {
  const lines = block.split(/\r?\n/); const start = lines.findIndex((line) => line.startsWith(`${name} `));
  if (start < 0) return null;
  let value = JSON.parse(lines[start].slice(name.length + 1));
  for (let i = start + 1; i < lines.length && lines[i].startsWith('"'); i++) value += JSON.parse(lines[i]);
  return value;
}
const forbiddenTranslatedTokens = /\/(?:start|stop|shop|home|search|category|categories|cats|newproducts|new|cart|orders|tracking|wishlist|settings|language|contactus|help|referral|suggest|foryou|bestsellers|onsale|setcommands)\b|\bsetCommands\b/;
for (const part of po.split(/\n\s*\n/).filter((entry) => entry.trim() && !entry.trimStart().startsWith('#~'))) {
  const id = poField(part, 'msgid'); const translation = poField(part, 'msgstr');
  if (id !== null) {
    assert(!forbiddenTranslatedTokens.test(id), `active gettext msgid does not embed a command/API token: ${id}`);
    assert(!forbiddenTranslatedTokens.test(translation || ''), `active Persian translation does not rewrite a command/API token: ${translation}`);
  }
}
assert.match(po, /msgid "Empower your customers to invite friends via %1\$s and track referral statistics"/);
assert.match(po, /msgid "Keep product search available via %1\$s and interactive search hub\."/);
assert.match(po, /__START_COMMAND__/);

const mo = fs.readFileSync(path.join(root, 'languages/zarinshopbot-fa_IR.mo'));
const magic = mo.readUInt32LE(0); assert.strictEqual(magic, 0x950412de, 'MO magic is valid');
const count = mo.readUInt32LE(8); const originalsOffset = mo.readUInt32LE(12);
for (let i = 0; i < count; i++) {
  const length = mo.readUInt32LE(originalsOffset + i * 8);
  const offset = mo.readUInt32LE(originalsOffset + i * 8 + 4);
  const msgid = mo.subarray(offset, offset + length).toString('utf8');
  assert(!commandNames.includes(msgid), `${msgid} must not exist as a translated MO msgid`);
  const translationEntry = mo.readUInt32LE(16) + i * 8;
  const translationLength = mo.readUInt32LE(translationEntry);
  const translationOffset = mo.readUInt32LE(translationEntry + 4);
  const translation = mo.subarray(translationOffset, translationOffset + translationLength).toString('utf8');
  assert(!forbiddenTranslatedTokens.test(translation), `compiled Persian translation does not rewrite a command/API token: ${translation}`);
}
for (const command of ["['command' => 'start'", "['command' => 'shop'", "['command' => 'orders'"]) assert(core.includes(command), 'Telegram command identifiers stay literal in the API payload');
assert(channels.includes("array('command' => 'start'") && channels.includes("array('command' => 'help'"), 'Rubika command identifiers stay literal in the API payload');
assert(dispatcher.includes("self::$command == '/stop'") && dispatcher.includes("self::$command == '/language'"), 'dispatcher accepts exact literal command tokens');
console.log('Commands tab checks passed: duplicate rows removed, IDs remain literal, and gettext catalogs exclude command names.');
