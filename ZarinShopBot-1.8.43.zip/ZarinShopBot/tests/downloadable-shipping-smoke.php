<?php
/** Offline regression tests for downloadable shipping classification. */
if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
function absint($value) { return abs((int) $value); }
$GLOBALS['zsb_shipping_products'] = array();
function wc_get_product($id) { return $GLOBALS['zsb_shipping_products'][(string) $id] ?? null; }
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/ApiTrait.php';
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Stars.php';

class ZSB_ShippingProduct {
    private $downloadable;
    private $shipping;
    private $virtual;
    public function __construct($downloadable, $shipping, $virtual = false) { $this->downloadable = $downloadable; $this->shipping = $shipping; $this->virtual = $virtual; }
    public function is_downloadable() { return $this->downloadable; }
    public function needs_shipping() { return $this->shipping; }
    public function is_virtual() { return $this->virtual; }
    public function is_purchasable() { return true; }
}
class ZSB_ShippingBot {
    use \ZarinShopBot\Core\Bot\ApiTrait;
    public static $cart = array();
    public static function getSession($key) { return $key === 'cart' ? self::$cart : null; }
}
function zsb_shipping_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}

$download = new ZSB_ShippingProduct(true, true, false); // Downloadable but WooCommerce says it needs shipping.
$physical = new ZSB_ShippingProduct(false, true, false);
$virtual = new ZSB_ShippingProduct(false, false, true);
$GLOBALS['zsb_shipping_products'] = array('101' => $download, '202' => $physical, '303' => $virtual);

zsb_shipping_assert(ZSB_ShippingBot::productNeedsShipping($download), 'Downloadable products remain shippable when WooCommerce says they need physical shipping');
zsb_shipping_assert(ZSB_ShippingBot::productNeedsShipping($physical), 'Physical products still require shipping');
zsb_shipping_assert(!ZSB_ShippingBot::productNeedsShipping($virtual), 'Virtual products remain non-shippable');
zsb_shipping_assert(!\ZarinShopBot\Core\Stars::isDigitalProduct($download), 'Downloadable products that require shipping are not eligible for Stars');
ZSB_ShippingBot::$cart = array('101' => 1);
zsb_shipping_assert(ZSB_ShippingBot::existPhysicalProduct(), 'Downloadable products that need a physical shipment keep shipping enabled');
ZSB_ShippingBot::$cart = array('101' => 1, '202' => 1);
zsb_shipping_assert(ZSB_ShippingBot::existPhysicalProduct(), 'Mixed cart keeps shipping for its physical item');
ZSB_ShippingBot::$cart = array('303' => 1);
zsb_shipping_assert(!ZSB_ShippingBot::existPhysicalProduct(), 'Virtual-only cart has no shipping requirement');

$webapp = file_get_contents(dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/WebAppTrait.php');
zsb_shipping_assert(substr_count($webapp, '!self::productNeedsShipping($product)') >= 2, 'WebApp shipping packages exclude downloadable/virtual items in both cart and order paths');
zsb_shipping_assert(strpos($webapp, 'if (self::productNeedsShipping($product))') !== false, 'WebApp checkout sets needs_shipping only for shippable products');
$woo = file_get_contents(dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/WooCommerceTrait.php');
zsb_shipping_assert(strpos($woo, 'if (!$product || !self::productNeedsShipping($product)) continue;') !== false, 'Bot WooCommerce rate calculation excludes non-shippable cart lines');
zsb_shipping_assert(strpos($woo, '->show_shipping(') === false && strpos($woo, 'show_shipping() is a presentation gate') !== false, 'rate discovery does not suppress configured rates behind the storefront visibility setting');

$telegram_core = file_get_contents(dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/CoreTrait.php');
zsb_shipping_assert(strpos($telegram_core, "'callback_query'") !== false && strpos($telegram_core, "'allowed_updates'") !== false, 'Telegram webhook explicitly subscribes to callback updates');
$commands = file_get_contents(dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/CommandsTrait.php');
zsb_shipping_assert(strpos($commands, "'/HOME' => '/home'") !== false && strpos($commands, "'/CART' => '/cart'") !== false, 'Telegram Home and Cart callback aliases remain routable');

// Safe logging/event contracts must not serialize chat IDs, tokens or user content.
echo 'Downloadable shipping and navigation smoke tests passed (12 checks).' . PHP_EOL;
