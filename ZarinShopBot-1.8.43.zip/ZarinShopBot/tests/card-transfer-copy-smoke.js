'use strict';
const fs = require('fs');
const assert = require('assert');
const transfer = fs.readFileSync('includes/class-zarinshopbot-card-transfer.php', 'utf8');
const panel = fs.readFileSync('panel/settings.php', 'utf8');
const webapp = fs.readFileSync('assets/js/webapp.js', 'utf8');
const orderCss = fs.readFileSync('assets/css/card-transfer.css', 'utf8');
const miniCss = fs.readFileSync('assets/css/webapp.css', 'utf8');

assert.match(transfer, /مبلغ نهایی سفارش را به حساب بانکی مقصدی که انتخاب می‌کنید واریز کنید/,
  'default customer copy explains the amount and selected destination account');
assert.match(transfer, /در Mini App، فایل رسید را همین‌جا و پیش از ثبت نهایی سفارش انتخاب کنید/,
  'default customer copy explains the Mini App receipt-upload timing');
assert.match(transfer, /در وب‌سایت، پس از ثبت سفارش آن را از صفحهٔ تأیید سفارش بارگذاری کنید/,
  'default customer copy explains the website receipt-upload location');
assert.match(transfer, /رمز کارت، رمز پویا، CVV2 یا اطلاعات ورود به حساب بانکی لازم نیست؛ این اطلاعات را ارسال نکنید/,
  'receipt guidance explicitly warns against sharing sensitive banking credentials');
assert.match(transfer, /public static function customerDescription\(\)/,
  'empty legacy description fields use a clear fallback');
assert.match(transfer, /public static function customerInstructions\(\)/,
  'empty legacy instruction fields use a clear fallback');
assert.match(transfer, /Card_Transfer::customerDescription\(\)/,
  'WooCommerce gateway is wired to the plugin panel description');
assert.match(transfer, /Card_Transfer::renderCustomerInstructions\(\)/,
  'website checkout and order views render the customer instructions');
assert.match(transfer, /\$method\['instructions'\]\s*=\s*self::plainCustomerText\(self::customerInstructions\(\)\)/,
  'Mini App receives the configured instruction copy as plain text');
assert.match(panel, /Card_Transfer::customerDescription\(\)/,
  'the description editor is prefilled when legacy settings are empty');
assert.match(panel, /Card_Transfer::customerInstructions\(\)/,
  'the instructions editor is prefilled when legacy settings are empty');
assert.match(webapp, /instructions\.textContent = gateway\.instructions/,
  'Mini App displays the configured safe instruction text');
assert.match(orderCss, /\.zsb-transfer-instructions\s*\{/,
  'checkout and order instruction copy has a dedicated readable style');
assert.match(miniCss, /\.manual-transfer-details \.zsb-transfer-instructions/,
  'Mini App instruction copy has a responsive style');
console.log('Card-transfer customer copy smoke checks passed (13 checks).');
