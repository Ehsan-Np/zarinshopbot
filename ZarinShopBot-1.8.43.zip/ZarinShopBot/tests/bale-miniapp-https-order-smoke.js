const fs = require('fs');
const assert = require('assert');
const template = fs.readFileSync('templates/webapp.php', 'utf8');
const js = fs.readFileSync('assets/js/webapp.js', 'utf8');
const api = fs.readFileSync('vendor/zarinshopbot-core/Bot/WebAppTrait.php', 'utf8');

assert(template.includes("'ajaxUrl'      => admin_url('admin-ajax.php', 'https')"), 'Mini App AJAX base URL is emitted as HTTPS for secure Bale WebViews and reverse-proxy SSL');
assert(js.includes("endpoint.protocol = 'https:'") && js.includes("window.location.protocol === 'https:'"), 'browser upgrades accidental HTTP AJAX URLs when page is secure');
assert(js.includes("endpoint.searchParams.set('platform', platform)") && js.includes("cache: 'no-store'"), 'catalog request identifies the platform and avoids stale intermediary cache responses');
assert(js.includes("console.error('[ZarinShopBot] Mini App catalog request failed'") && js.includes('ajaxHost:'), 'catalog network/JSON failures expose actionable sanitized console diagnostics');
assert(api.includes("zarincode_log_event('webapp_catalog_failed'") && api.includes("catch (\\Throwable $error)"), 'server-side WooCommerce catalog exceptions produce structured platform diagnostics and a JSON error');
assert(js.includes("fetch(cfg.ajaxUrl || 'admin-ajax.php', {") && template.includes("admin_url('admin-ajax.php', 'https')"), 'checkout and product loading share the corrected secure AJAX endpoint');
assert(api.includes("set_url_scheme($order->get_checkout_payment_url(true), 'https')") && api.includes("esc_url_raw(set_url_scheme($order->get_checkout_payment_url(true), 'https'))"), 'payment links returned to Bale Mini App are explicitly HTTPS for its link-opening bridge');
console.log('Bale Mini App HTTPS/order smoke checks passed (7 checks).');
