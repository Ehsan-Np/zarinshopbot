const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const phone = fs.readFileSync(path.join(root, 'includes/class-zarinshopbot-phone-accounts.php'), 'utf8');
const uninstall = fs.readFileSync(path.join(root, 'uninstall.php'), 'utf8');

assert(phone.includes("private static function phoneIndexTable()") && phone.includes("SHOW TABLES LIKE %s"), 'phone account operations verify the owned index table exists before querying it');
assert(phone.includes("if (self::phoneIndexTable() === $table)") && phone.includes("delete_option('zsb_phone_schema_version')"), 'schema version is stored only after successful table creation');
assert(phone.includes("zsb_phone_schema_retry_after") && phone.includes('time() + 300'), 'failed schema setup uses a bounded retry backoff');
assert(phone.includes("if ($table === '') return 0;") && phone.includes("if ($table === '') return false;"), 'missing phone index table fails closed without SQL query errors');
assert(uninstall.includes("'zsb_phone_schema_version'") && uninstall.includes("$wpdb->prefix . 'zsb_phone_index'"), 'plugin uninstall removes the phone index and its schema marker');
console.log('Phone account schema and uninstall smoke checks passed (4 checks).');
