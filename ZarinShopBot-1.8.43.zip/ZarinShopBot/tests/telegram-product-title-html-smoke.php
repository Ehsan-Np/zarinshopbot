<?php
/** Offline regression checks for encoded product titles sent through Telegram HTML parse mode. */
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/TelegramTrait.php';

function wp_kses($text, $allowed_tags) { return $text; }

class ZsbTelegramTextProbe {
    use \ZarinShopBot\Core\Bot\TelegramTrait;
    protected static $chat_id = '';
}

function zsb_product_title_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}

$encoded = ZsbTelegramTextProbe::telegramPlainText('&lt;b&gt;کارگاه سرمایه روان‌شناختی&lt;/b&gt;');
zsb_product_title_assert($encoded === 'کارگاه سرمایه روان‌شناختی', 'Encoded formatting tags are normalized away from the product name');
$double_encoded = ZsbTelegramTextProbe::telegramPlainText('&amp;lt;b&amp;gt;کارگاه&lt;/b&amp;gt;');
zsb_product_title_assert($double_encoded === 'کارگاه', 'Double-encoded markup does not leak into the visible title');
$plain = ZsbTelegramTextProbe::telegramPlainText('فرهنگ & هنر <نسخه>');
zsb_product_title_assert($plain === 'فرهنگ &amp; هنر &lt;نسخه&gt;', 'Plain special characters survive one safe HTML escape');
$formatted = '<b>' . $encoded . '</b>';
zsb_product_title_assert(strpos($formatted, '<b>کارگاه سرمایه روان‌شناختی</b>') === 0, 'Product title retains intentional bold wrapper');
$parsed = ZsbTelegramTextProbe::parseText('<b>Bold</b> &lt;b&gt;literal&lt;/b&gt;', 'HTML');
zsb_product_title_assert($parsed === '<b>Bold</b> &lt;b&gt;literal&lt;/b&gt;', 'HTML formatter preserves real tags but never decodes entity-escaped tags');
$safe_dynamic = ZsbTelegramTextProbe::parseText('<b>' . $plain . '</b>', 'HTML');
zsb_product_title_assert($safe_dynamic === '<b>فرهنگ &amp; هنر &lt;نسخه&gt;</b>', 'Dynamic title entities remain text under an intentional bold wrapper');

$root = dirname(__DIR__);
$catalog = file_get_contents($root . '/vendor/zarinshopbot-core/Bot/CatalogTrait.php');
$notifications = file_get_contents($root . '/vendor/zarinshopbot-core/Bot/NotificationTrait.php');
$telegram_trait = file_get_contents($root . '/vendor/zarinshopbot-core/Bot/TelegramTrait.php');
$publisher = file_get_contents($root . '/zarinshopbot.php');
$expected_catalog_call = "self::telegramPlainText(\$product['name'] ?? '')";
zsb_product_title_assert(strpos($catalog, $expected_catalog_call) !== false, 'Product notification title uses safe Telegram text encoding');
zsb_product_title_assert(strpos($notifications, 'self::telegramPlainText($product->get_name())') !== false, 'Back-in-stock notification title uses safe Telegram text encoding');
zsb_product_title_assert(strpos($publisher, '::normalizeProductTitle($product->get_name())') !== false, 'Per-platform product posts normalize escaped product names');
$expected_bold_wrapper = "'<b>' . " . '$safe_name' . " . '</b>'";
zsb_product_title_assert(strpos($publisher, $expected_bold_wrapper) !== false, 'Telegram product post keeps the product name bold');
$photo_start = strpos($telegram_trait, 'public static function sendPhoto');
$photo_end = strpos($telegram_trait, 'protected static function handleTelegramApiResponse', $photo_start);
$photo_source = substr($telegram_trait, $photo_start, $photo_end - $photo_start);
zsb_product_title_assert(strpos($photo_source, "parse_mode'] = 'HTML'") !== false, 'Photo captions explicitly request Telegram HTML parsing');
$edit_start = strpos($telegram_trait, 'public static function editMessage');
$edit_end = strpos($telegram_trait, 'public static function cleanupCallbackSourceMessage', $edit_start);
$edit_source = substr($telegram_trait, $edit_start, $edit_end - $edit_start);
zsb_product_title_assert(strpos($edit_source, "parse_mode'] = 'HTML'") !== false, 'Edited product pages explicitly request Telegram HTML parsing');

echo 'Telegram product-title HTML smoke tests passed (12 checks).' . PHP_EOL;
