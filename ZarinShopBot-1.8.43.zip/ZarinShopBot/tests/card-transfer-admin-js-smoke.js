/* Minimal DOM contract smoke test for the repeatable card-transfer account button. */
'use strict';

const assert = require('assert');
const path = require('path');

class Element {
    constructor(tagName) {
        this.tagName = String(tagName || 'div').toLowerCase();
        this.children = [];
        this.parentNode = null;
        this.attributes = {};
        this.className = '';
        this.listeners = {};
        this.value = '';
        this.textContent = '';
        this.innerHTML = '';
        this.hidden = false;
        this.type = '';
    }
    setAttribute(name, value) {
        this.attributes[name] = String(value);
        if (name === 'hidden') this.hidden = true;
        if (name === 'class') this.className = String(value);
    }
    getAttribute(name) { return Object.prototype.hasOwnProperty.call(this.attributes, name) ? this.attributes[name] : null; }
    removeAttribute(name) {
        delete this.attributes[name];
        if (name === 'hidden') this.hidden = false;
    }
    appendChild(child) { child.parentNode = this; this.children.push(child); return child; }
    removeChild(child) {
        const index = this.children.indexOf(child);
        if (index >= 0) this.children.splice(index, 1);
        child.parentNode = null;
        return child;
    }
    get firstChild() { return this.children[0] || null; }
    addEventListener(name, callback) {
        if (!this.listeners[name]) this.listeners[name] = [];
        this.listeners[name].push(callback);
    }
    dispatch(name) {
        const event = { defaultPrevented: false, preventDefault() { this.defaultPrevented = true; } };
        (this.listeners[name] || []).forEach((callback) => callback(event));
        return event;
    }
    matches(selector) {
        const attr = selector.match(/^\[([^=\]]+)(?:="([^"]*)")?\]$/);
        if (attr) return Object.prototype.hasOwnProperty.call(this.attributes, attr[1]) && (attr[2] === undefined || this.attributes[attr[1]] === attr[2]);
        if (selector.charAt(0) === '.') return (' ' + this.className + ' ').indexOf(' ' + selector.slice(1) + ' ') !== -1;
        return selector.toLowerCase() === this.tagName;
    }
    querySelectorAll(selector) {
        let result = [];
        this.children.forEach((child) => {
            if (child.matches(selector)) result.push(child);
            result = result.concat(child.querySelectorAll(selector));
        });
        return result;
    }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    focus() { this.focused = true; }
}

const document = {
    readyState: 'complete',
    createElement: (tagName) => new Element(tagName),
    querySelectorAll(selector) { return selector === '[data-account-editor]' ? [editor] : []; },
    addEventListener() {}
};
const window = { console };

const form = new Element('form'); form.className = 'zarin-form';
const pane = new Element('section'); pane.className = 'zarin-tab-pane is-active';
const editor = new Element('div'); editor.setAttribute('data-account-editor', '');
const labels = {
    label: 'عنوان حساب', bank: 'نام بانک', holder: 'صاحب حساب', card_number: 'شماره کارت',
    account_number: 'شماره حساب', iban: 'شبا', instructions: 'یادداشت'
};
Object.keys(labels).forEach((name) => editor.setAttribute('data-label-' + name, labels[name]));
editor.setAttribute('data-empty-label', 'حسابی ثبت نشده');
editor.setAttribute('data-remove-label', 'حذف');
editor.setAttribute('data-card-placeholder', 'شماره کارت');
editor.setAttribute('data-required-message', 'عنوان، صاحب حساب و شماره کارت لازم است.');
const list = new Element('div'); list.setAttribute('data-account-list', '');
const raw = new Element('textarea'); raw.setAttribute('data-account-raw', ''); raw.value = '';
const error = new Element('div'); error.setAttribute('data-account-error', ''); error.setAttribute('hidden', 'hidden');
const add = new Element('button'); add.setAttribute('data-add-account', '');
editor.appendChild(list); editor.appendChild(error); editor.appendChild(add); editor.appendChild(raw);
pane.appendChild(editor); form.appendChild(pane);

global.document = document;
global.window = window;
require(path.join(__dirname, '..', 'assets', 'js', 'card-transfer-admin.js'));

assert((editor.className.indexOf('has-js') !== -1), 'editor initializes and enables the enhanced controls');
add.dispatch('click');
assert.strictEqual(list.querySelectorAll('.zsb-account-editor-card').length, 1, 'Add account creates a new account card');
const firstCard = list.querySelector('.zsb-account-editor-card');
firstCard.querySelector('[data-field="label"]').value = 'حساب فروشگاه';
firstCard.querySelector('[data-field="label"]').dispatch('input');
firstCard.querySelector('[data-field="holder"]').value = 'نام صاحب حساب';
firstCard.querySelector('[data-field="holder"]').dispatch('input');
firstCard.querySelector('[data-field="card_number"]').value = '1234-5678-1234-5678';
firstCard.querySelector('[data-field="card_number"]').dispatch('input');
assert(raw.value.indexOf('حساب فروشگاه') !== -1 && raw.value.indexOf('1234-5678-1234-5678') !== -1, 'account fields serialize into the submitted legacy-compatible value');

add.dispatch('click');
assert.strictEqual(list.querySelectorAll('.zsb-account-editor-card').length, 2, 'Add account works repeatedly');
const invalidSubmit = form.dispatch('submit');
assert(invalidSubmit.defaultPrevented && !error.hidden, 'active card-transfer tab reports incomplete account fields');
const secondCard = list.querySelectorAll('.zsb-account-editor-card')[1];
secondCard.querySelector('[data-field="label"]').value = 'حساب دوم';
secondCard.querySelector('[data-field="label"]').dispatch('input');
secondCard.querySelector('[data-field="holder"]').value = 'صاحب دوم';
secondCard.querySelector('[data-field="holder"]').dispatch('input');
secondCard.querySelector('[data-field="card_number"]').value = '9999-8888-7777-6666';
secondCard.querySelector('[data-field="card_number"]').dispatch('input');
const validSubmit = form.dispatch('submit');
assert(!validSubmit.defaultPrevented && error.hidden, 'complete accounts can be saved');

const removeButtons = list.querySelectorAll('.zsb-account-remove');
removeButtons[1].dispatch('click');
assert.strictEqual(list.querySelectorAll('.zsb-account-editor-card').length, 1, 'Remove account deletes the selected account');
console.log('Card-transfer admin JavaScript smoke tests passed (7 checks).');
