const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

const bootstrap = read('zarinshopbot.php');
const legacy = read('includes/legacy-compat.php');
const uninstall = read('uninstall.php');
const main = read('panel/main.php');
const settings = read('panel/settings.php');
const guide = read('docs/guide-fa.html');
const css = read('assets/css/admin-menu.css') + read('assets/css/typography.css');

if (!/Plugin Name:\s+ربات زرین شاپ\s*\n/.test(bootstrap)) throw new Error('Plugin display name was not updated to the exact Persian name');
if (!/Plugin URI:\s+https:\/\/zarincode\.com\/product\/zarinshopbot/.test(bootstrap)) throw new Error('Canonical product URL is missing');
if (!/Author URI:\s+https:\/\/zarincode\.com/.test(bootstrap)) throw new Error('Developer website URL is missing');
if (!/add_menu_page\([\s\S]*?'zarincode_zarinshopbot'/.test(bootstrap)) throw new Error('New dashboard slug is not registered');
if (!legacy.includes("'zarincode_main' => 'zarincode_zarinshopbot'")) throw new Error('Legacy dashboard slug does not redirect');
if (!legacy.includes("$args = wp_unslash($_GET)") || !legacy.includes("add_query_arg($args, admin_url('admin.php'))")) throw new Error('Legacy redirect must preserve other query arguments');
if (!bootstrap.includes('zarincode_zarinshopbot_page_zarincode_zarinshopbot_setting')) throw new Error('New settings screen ID was not registered');
if (!bootstrap.includes("'zarincode_zarinshopbot_setting', 'zarincode_render_settings_panel'")) throw new Error('Namespaced settings page slug is not registered');
if (!legacy.includes("'zarincode_settings' => 'zarincode_zarinshopbot_setting'")) throw new Error('Old settings URLs do not redirect to the new slug');
for (const [file, source] of [['panel/main.php', main], ['panel/settings.php', settings], ['docs/guide-fa.html', guide], ['admin CSS', css]]) {
  if (!source.includes('zarincode_zarinshopbot')) throw new Error(`New dashboard slug missing from ${file}`);
  if (source.includes('zarincode_main')) throw new Error(`Old dashboard slug remains in internal links/selectors: ${file}`);
}
if (!bootstrap.includes("register_setting('zarincode_settings_options', 'zarincode_settings'")) throw new Error('Stored settings option name was changed along with the page slug');

if (!/defined\('WP_UNINSTALL_PLUGIN'\)/.test(uninstall)) throw new Error('Uninstall guard is missing');
for (const token of [
  'zarincode_settings', 'zarinshopbot_channels', 'woocommerce_zarinshopbot_card_transfer_settings', 'wp_zarincode_log', 'sa_te_bo_li',
  'zarincode_user', 'zarincode_group', 'zarincode_check_abandoned_cart', 'zsb_phone_schema_version', 'zsb_phone_index',
  'as_unschedule_all_actions', 'actionscheduler_actions', 'actionscheduler_logs', 'wp_delete_post', 'wc_orders_meta',
  'zarinshopbot_', 'zarincode_hide_cat', 'WPML', 'DROP TABLE IF EXISTS',
]) {
  if (!uninstall.includes(token)) throw new Error(`Uninstall cleanup coverage missing: ${token}`);
}
if (!/source\.meta_key = '_order_from' AND source\.meta_value IN \('telegram','bale','rubika'\)/.test(uninstall)) throw new Error('Unprefixed order metadata is not scoped to plugin-originated orders');
if (!/WHERE t\.term_id IN \(\{\$term_ids_sql\}\) AND tt\.term_id IS NULL/.test(uninstall)) throw new Error('Taxonomy cleanup is not limited to this plugin\'s candidate terms');
if (/DELETE\s+FROM\s+\{\$wpdb->posts\}\s+WHERE\s+post_type\s*=\s*'shop_order'/i.test(uninstall)) throw new Error('Uninstall must not delete WooCommerce orders');

console.log('Dashboard slug, branding, and uninstall smoke checks passed.');
