<?php
/** Offline regression checks for Telegram inline callback ingress. */
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Telegram/Entity.php';
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Telegram/User.php';
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Telegram/Chat.php';
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Telegram/Message.php';
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Telegram/CallbackQuery.php';
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Telegram/Update.php';

function zsb_callback_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}

$payload = [
    'update_id' => 90210,
    'callback_query' => [
        'id' => 'callback-query-abc',
        'from' => ['id' => 12345, 'first_name' => 'Test'],
        'message' => [
            'message_id' => 77,
            'chat' => ['id' => 12345, 'type' => 'private'],
        ],
        'data' => '/home',
    ],
];
$update = new \ZarinShopBot\Core\Telegram\Update($payload);
$query = $update->getCallbackQuery();
zsb_callback_assert($update->getUpdateType() === 'callback_query', 'Callback envelope is identified');
zsb_callback_assert($query->getId() === 'callback-query-abc', 'Callback query ID is accessible');
zsb_callback_assert($query->getData() === '/home', 'Callback data is preserved as the command route');
zsb_callback_assert($query->getFrom()->getId() === 12345, 'Callback sender is accessible');
zsb_callback_assert($query->getMessage()->getMessageId() === 77, 'Source message is accessible');

$root = dirname(__DIR__);
$telegram_trait = file_get_contents($root . '/vendor/zarinshopbot-core/Bot/TelegramTrait.php');
$core_trait = file_get_contents($root . '/vendor/zarinshopbot-core/Bot/CoreTrait.php');
$main_plugin = file_get_contents($root . '/zarinshopbot.php');
$callback_parse = strpos($telegram_trait, 'self::$callback_query_id = $callback_query->getId();');
$early_ack = strpos($telegram_trait, "self::answerCallback('');");
$user_persistence = strpos($telegram_trait, 'self::updateUser($update_id)');
zsb_callback_assert($callback_parse !== false && $early_ack !== false && $user_persistence !== false && $callback_parse < $early_ack && $early_ack < $user_persistence, 'Callback is acknowledged before persistence and WooCommerce work');
zsb_callback_assert(strpos($core_trait, "'callback_query'") !== false && strpos($core_trait, "'allowed_updates'") !== false, 'Webhook subscription explicitly includes callback_query');
zsb_callback_assert(strpos($main_plugin, 'zarinshopbot_callback_updates_migrated') !== false && strpos($main_plugin, 'WooBot::setHook(1)') !== false, 'Existing webhook is refreshed once during upgrade');
zsb_callback_assert(strpos($main_plugin, '$info->getAllowedUpdates()') !== false && strpos($main_plugin, 'NOT subscribed') !== false, 'Webhook diagnostics expose callback_query subscription status');

echo 'Telegram callback flow smoke tests passed (9 checks).' . PHP_EOL;
