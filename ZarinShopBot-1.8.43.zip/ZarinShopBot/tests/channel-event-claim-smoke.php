<?php
/** Atomic provider-update claim smoke tests; no WordPress or network required. */
if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
$GLOBALS['zsb_event_options'] = array();
$GLOBALS['zsb_event_token_counter'] = 0;
function add_option($name, $value, $deprecated = '', $autoload = 'yes') {
    if (array_key_exists($name, $GLOBALS['zsb_event_options'])) return false;
    $GLOBALS['zsb_event_options'][$name] = $value;
    return true;
}
function get_option($name, $default = false) { return $GLOBALS['zsb_event_options'][$name] ?? $default; }
function wp_generate_password($length = 12, $special_chars = true, $extra_special_chars = false) {
    return substr(str_pad((string) ++$GLOBALS['zsb_event_token_counter'], (int) $length, 'x'), 0, (int) $length);
}
function absint($value) { return abs((int) $value); }
function maybe_serialize($value) { return is_array($value) || is_object($value) ? serialize($value) : (string) $value; }
function wp_cache_delete($key, $group = '') { return true; }
class Zsb_Event_Claim_DB {
    public $options = 'wp_options';
    private $args = array();
    public function prepare($query, ...$args) { $this->args = $args; return 'prepared-event-claim-delete'; }
    public function query($query) {
        if ($query !== 'prepared-event-claim-delete' || count($this->args) !== 2) return false;
        list($key, $value) = $this->args;
        if (!array_key_exists($key, $GLOBALS['zsb_event_options']) || $GLOBALS['zsb_event_options'][$key] !== $value) return 0;
        unset($GLOBALS['zsb_event_options'][$key]);
        return 1;
    }
}
$GLOBALS['wpdb'] = new Zsb_Event_Claim_DB();
require dirname(__DIR__) . '/includes/class-zarinshopbot-channels.php';
function zsb_event_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}
$acquire = new ReflectionMethod('ZarinShopBot\\Channels', 'acquire_event_claim');
$release = new ReflectionMethod('ZarinShopBot\\Channels', 'release_event_claim');
if (PHP_VERSION_ID < 80100) { $acquire->setAccessible(true); $release->setAccessible(true); }
$event = 'zsb_event_' . hash('sha256', 'bale|chat|update-77');
zsb_event_assert($acquire->invoke(null, $event), 'first concurrent delivery claims the event');
zsb_event_assert(!$acquire->invoke(null, $event), 'duplicate concurrent delivery cannot claim the active event');
$release->invoke(null, $event);
zsb_event_assert($acquire->invoke(null, $event), 'event can be retried after the previous handler releases its claim');
$release->invoke(null, $event);
$key = 'zsb_claim_' . substr(hash('sha256', $event), 0, 48);
$GLOBALS['zsb_event_options'][$key] = (string) (time() - 1) . ':expired-claim';
zsb_event_assert($acquire->invoke(null, $event), 'expired event claim can be recovered');
$new_owner = (string) (time() + 90) . ':new-event-owner';
$GLOBALS['zsb_event_options'][$key] = $new_owner;
$release->invoke(null, $event);
zsb_event_assert(($GLOBALS['zsb_event_options'][$key] ?? '') === $new_owner, 'old handler cannot release a newer event claim');
fwrite(STDOUT, "Atomic channel event claim smoke tests passed (5 checks).\n");
