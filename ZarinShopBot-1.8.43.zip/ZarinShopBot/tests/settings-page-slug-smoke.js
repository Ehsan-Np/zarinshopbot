'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const files = [
  'zarinshopbot.php',
  'panel/main.php',
  'panel/settings.php',
  'includes/class-zarinshopbot-channels.php',
  'includes/class-zarinshopbot-card-transfer.php',
  'includes/legacy-compat.php',
  'settings-management.php',
  'assets/js/admin-settings.js',
  'docs/guide-fa.html',
];
const source = Object.fromEntries(files.map((f) => [f, fs.readFileSync(path.join(root, f), 'utf8')]));
const newSlug = 'zarincode_zarinshopbot_setting';

assert(source['zarinshopbot.php'].includes(`'${newSlug}', 'zarincode_render_settings_panel'`), 'Settings menu registers the requested new slug');
assert(source['zarinshopbot.php'].includes(`$page === '${newSlug}'`), 'Plugin assets and settings-only behavior use the new slug');
assert(source['includes/legacy-compat.php'].includes(`'zarincode_settings' => '${newSlug}'`), 'Old page URLs remain backward-compatible through redirect');
assert(source['assets/js/admin-settings.js'].includes(`searchParams.set('page', '${newSlug}')`), 'Client-side tab navigation retains the new page slug');
for (const [file, text] of Object.entries(source)) {
  assert(!/admin\.php\?page=zarincode_settings(?:&|['"\s<])/.test(text), `No old settings URL remains in ${file}`);
  assert(!/['"]page['"]\s*=>\s*['"]zarincode_settings['"]/.test(text), `No PHP page argument uses the old slug in ${file}`);
}
const bootstrap = source['zarinshopbot.php'];
assert(bootstrap.includes("register_setting('zarincode_settings_options', 'zarincode_settings'"), 'Persistent settings option/group stay unchanged to preserve saved data');
console.log('Namespaced settings-page URL smoke checks passed (23 checks).');
