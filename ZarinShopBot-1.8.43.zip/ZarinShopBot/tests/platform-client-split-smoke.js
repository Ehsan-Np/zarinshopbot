const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const facade = fs.readFileSync(path.join(root, 'includes/class-zarinshopbot-channels.php'), 'utf8');
const transport = fs.readFileSync(path.join(root, 'includes/platforms/class-json-http-transport.php'), 'utf8');
const bale = fs.readFileSync(path.join(root, 'includes/platforms/class-bale-api-client.php'), 'utf8');
const rubika = fs.readFileSync(path.join(root, 'includes/platforms/class-rubika-api-client.php'), 'utf8');

assert.match(facade, /new \\ZarinShopBot\\Platforms\\Bale\\ApiClient/);
assert.match(facade, /new \\ZarinShopBot\\Platforms\\Rubika\\ApiClient/);
assert.match(facade, /return \$this->client->request\(\$method, \$params, \$timeout\)/);
assert.doesNotMatch(facade.slice(facade.indexOf('public function request('), facade.indexOf('public function telegram_call(')), /tapi\.bale\.ai|botapi\.rubika\.ir|\['ok'\]|\['status'\]/);
assert.match(bale, /https:\/\/tapi\.bale\.ai\/bot/);
assert.match(bale, /\$data\['ok'\] !== true/);
assert.doesNotMatch(bale, /botapi\.rubika\.ir|\$data\['status'\]/);
assert.match(rubika, /https:\/\/botapi\.rubika\.ir\/v3\//);
assert.match(rubika, /strtoupper\(\(string\) \$data\['status'\]\) !== 'OK'/);
assert.doesNotMatch(rubika, /tapi\.bale\.ai|\$data\['ok'\]/);
assert.match(transport, /'sslverify'\s*=>\s*true/);
assert.match(transport, /'redirection'\s*=>\s*0/);
assert.match(transport, /if \(\$params !== array\(\)\)/);
assert.match(transport, /\$request_args\['headers'\]\['Content-Type'\]\s*=\s*'application\/json; charset=utf-8'/);
assert.match(transport, /'data_format'\s*=>\s*'body'/);

console.log('Independent Bale/Rubika transport adapter smoke checks passed (14 checks).');
