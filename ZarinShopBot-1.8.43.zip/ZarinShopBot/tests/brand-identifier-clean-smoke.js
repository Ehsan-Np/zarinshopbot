'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const retiredIdentifier = ['woo', 'gram'].join('').toLowerCase();
const ignored = new Set(['.git', 'node_modules', 'build', 'dist', 'coverage']);
let scanned = 0;
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ignored.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    const relative = path.relative(root, full);
    assert(!relative.toLowerCase().includes(retiredIdentifier), `Retired identifier remains in path: ${relative}`);
    if (entry.isDirectory()) {
      walk(full);
    } else if (entry.isFile()) {
      const bytes = fs.readFileSync(full);
      const content = bytes.toString('latin1').toLowerCase();
      assert(!content.includes(retiredIdentifier), `Retired identifier remains in file: ${relative}`);
      scanned += 1;
    }
  }
}
walk(root);
console.log(`Project branding scan passed: ${scanned} files contain no retired identifier.`);
