const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const php = fs.readFileSync(path.join(root, 'includes/class-zarinshopbot-invoice.php'), 'utf8');
const bootstrap = fs.readFileSync(path.join(root, 'zarinshopbot.php'), 'utf8');
const orders = fs.readFileSync(path.join(root, 'vendor/zarinshopbot-core/Bot/OrdersTrait.php'), 'utf8');
const channels = fs.readFileSync(path.join(root, 'includes/class-zarinshopbot-channels.php'), 'utf8');
assert(php.includes("admin_post_' . self::ACTION") && php.includes("admin_post_nopriv_' . self::ACTION"), 'PDF route is available to logged-in and guest buyers');
assert(php.includes("hash_equals((string) $order->get_order_key()") && php.includes('get_current_user_id()'), 'invoice download requires order-key validation or matching account ownership');
assert(php.includes("header('Content-Type: application/pdf')") && php.includes("filename*=UTF-8"), 'handler returns a downloadable PDF response');
assert(php.includes("assets/fonts/DejaVuSans.ttf") && php.includes("assets/fonts/DejaVuSans-metrics.json"), 'font and glyph metrics are packaged locally');
assert(php.includes('private static $code128_patterns') && php.includes("'2331112'"), 'barcode encoder includes the standard Code 128 pattern set and stop symbol');
const barcodeBlock = php.split('private static $code128_patterns = [')[1].split('];')[0];
const barcodePatterns = [...barcodeBlock.matchAll(/'([1-4]{6,7})'/g)].map(m => m[1]);
assert.strictEqual(barcodePatterns.length, 107, 'all Code 128 codewords are embedded locally');
assert.strictEqual(new Set(barcodePatterns).size, 107, 'Code 128 patterns are distinct');
barcodePatterns.forEach((pattern, i) => {
  assert.strictEqual(pattern.length, i === 106 ? 7 : 6, `pattern ${i} has the expected width count`);
  if (i < 106) assert.strictEqual([...pattern].reduce((sum, n) => sum + Number(n), 0), 11, `pattern ${i} spans 11 modules`);
});
assert(bootstrap.includes("require_once __DIR__ . '/includes/class-zarinshopbot-invoice.php'") && bootstrap.includes('\\ZarinShopBot\\Invoice::boot()'), 'invoice module is loaded and registered');
assert(php.includes('public static function getBotDownloadUrl($order, $chat_id)') && php.includes("$order->get_meta('_chat_id', true)") && php.includes('hash_equals($owner_chat_id, $chat_id)'), 'bot invoice URL is generated only for the chat that owns the order');
assert(php.includes("private static function isWooOrder($order)") && php.includes("is_a($order, 'WC_Order')") && !php.includes('instanceof') && orders.includes('\\ZarinShopBot\\Invoice::getBotDownloadUrl'), 'invoice order checks avoid fragile class-name tokens and retain the order-owner link path');
assert(orders.includes("'orders.invoice_pdf'") && orders.includes("'url' => $invoice_url"), 'each owned bot order card exposes a PDF download link');
assert(channels.includes('rubika_link_buttons_to_metadata') && channels.includes("esc_url_raw((string) $raw_url, array('https'))"), 'the shared invoice link is supported as an HTTPS link for Rubika as well as Telegram/Bale');
assert(!/https?:\/\//i.test(php) && !/wp_remote_(get|post)/.test(php), 'invoice/barcode/PDF generation has no network or CDN dependency');
assert(!php.includes('gzcompress') && php.includes("number_format((float) $number, $decimals, '.', '')"), 'PDF output uses no optional compression extension and formats locale-safe PDF numbers');
for (const file of ['assets/fonts/DejaVuSans.ttf', 'assets/fonts/DejaVuSans-metrics.json', 'assets/fonts/DejaVu-COPYRIGHT.txt']) {
  assert(fs.existsSync(path.join(root, file)), `${file} is present in the plugin`);
}
const metrics = JSON.parse(fs.readFileSync(path.join(root, 'assets/fonts/DejaVuSans-metrics.json'), 'utf8'));
assert(metrics.cmap['1605'] && metrics.cmap['1662'] && metrics.cmap['65'], 'bundled font maps Persian and Latin glyphs');
console.log('Invoice PDF/Code 128 static smoke checks passed.');
