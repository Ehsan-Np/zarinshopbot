const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const panel = read('panel/settings.php');
const sanitizer = read('settings-management.php');
const bootstrap = read('zarinshopbot.php');
const flow = read('vendor/zarinshopbot-core/Bot/OrderFlowTrait.php');
const phoneTest = read('tests/checkout-field-profiles-smoke.php');

const globalField = panel.slice(panel.indexOf('<!-- Phone collection mode'), panel.indexOf('$checkout_field_labels'));
assert.match(globalField, /name="zarincode_settings\[register_req_phone\]"/);
assert.match(globalField, /\$phone_m_saved\s*=\s*isset\(\$options\['register_req_phone'\]\)/, 'global setting reads the saved value rather than hard-coding mobile-only');
for (const [value, label] of [[0, 'Do Not Collect'], [1, 'Mobile or Landline'], [2, 'Landline Only'], [3, 'Mobile Only']]) {
  assert.match(globalField, new RegExp(`${value}\\s*=>\\s*__\\('${label}'`), `global selector includes mode ${value}`);
}
assert.doesNotMatch(globalField, /name="zarincode_settings\[register_req_phone\]" value="3"/, 'no hidden input silently overwrites the administrator choice');
assert.match(globalField, /disabled\(\$phone_mode_locked\)/, 'account/OTP policy locks the effective mode to mobile');
assert.match(globalField, /value="<\?php echo esc_attr\(\$phone_m_saved\); \?>"/, 'locked display preserves the administrator\'s previous preference instead of overwriting it');
assert.match(globalField, /phone_sms_verification/);
assert.match(globalField, /customer_account_policy/);

const profile = panel.slice(panel.indexOf('$checkout_profile_specs'), panel.indexOf('<!-- TAB: CARD TRANSFER SETTINGS'));
assert.match(profile, /'global'\s*=>\s*sprintf\(__\('تنظیم کلی:/, 'each product profile can explicitly inherit the global choice');
assert.match(profile, /name="zarincode_settings\[<\?php echo esc_attr\(\$profile_option_key\); \?>\]\[phone\]"/);
assert.match(profile, /<?php selected\(\(string\) \$field_value\('phone'\), \(string\) \$phone_value\); \?>/);
assert.match(profile, /disabled\(\$phone_mode_locked\)/, 'profile-specific controls remain administrator-editable unless phone verification requires mobile');

assert.match(sanitizer, /'register_req_phone'\s*=>\s*\['3',\s*'1',\s*'2',\s*'0'\]/, 'global phone enum is sanitized to supported values');
assert.match(bootstrap, /array\('global',\s*'0',\s*'1',\s*'2',\s*'3'\)/, 'profile phone choices are sanitized, including inherit-global mode');
assert.match(flow, /\$all_options\['register_req_phone'\]/, 'order flow reads the administrator phone mode');
assert.match(flow, /\$raw_phone_mode\s*===\s*'global'[\s\S]*?\$global_phone_mode/, 'per-cart profiles can inherit the global mode');
assert.match(flow, /if\s*\(\$phone_requires_mobile\)\s*\$fields\['phone'\]\s*=\s*3/, 'account/OTP policy cannot be bypassed by a no-phone profile');
assert.match(phoneTest, /global phone mode can turn phone collection off/);
assert.match(phoneTest, /account and OTP policy force verified mobile collection/);
console.log('Phone collection settings checks passed (global choice, per-cart inheritance, sanitization, and account/OTP safeguards).');
