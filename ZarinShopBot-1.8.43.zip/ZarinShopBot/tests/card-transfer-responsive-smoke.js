'use strict';
const fs = require('fs');
const assert = require('assert');
const cardCss = fs.readFileSync('assets/css/card-transfer.css', 'utf8');
const appCss = fs.readFileSync('assets/css/webapp.css', 'utf8');
const php = fs.readFileSync('includes/class-zarinshopbot-card-transfer.php', 'utf8');
const appJs = fs.readFileSync('assets/js/webapp.js', 'utf8');

assert.match(cardCss, /@media\s*\(max-width:\s*320px\)/, 'checkout/order card-transfer has an explicit 320px treatment');
assert.match(cardCss, /\.zsb-transfer-account-choice\s*>\s*label\s*\{[^}]*font-size:\s*14px/s, 'narrow account option label remains readable and wraps');
assert.match(cardCss, /\.zsb-bank-instructions\s*\{[^}]*font-size:\s*15px/s, 'bank instructions use readable type');
assert.match(cardCss, /\.zsb-transfer-upload input\[type="file"\]\s*\{[^}]*width:\s*100%/s, 'receipt file input fits its container');
assert.match(cardCss, /overflow-wrap:\s*anywhere/, 'long labels and formatted text can wrap');
assert.match(appCss, /@media\s*\(max-width:\s*320px\)/, 'Mini App has an explicit 320px treatment');
assert.match(appCss, /\.payment-option-description\s*\{[^}]*font-size:\s*14px/s, 'Mini App gateway descriptions use readable type');
assert.match(appCss, /#receipt_upload_help\s*\{[^}]*font-size:\s*14px/s, 'Mini App upload helper uses readable type');
assert.match(php, /class="zsb-transfer-account-selection"/, 'website checkout account selection markup remains styled');
assert.match(appJs, /className\s*=\s*`zsb-transfer-account-choice transfer-account-option/, 'Mini App account option markup remains styled');
console.log('Card-transfer responsive smoke checks passed.');
