'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const mo = fs.readFileSync(path.join(root, 'languages/zarinshopbot-fa_IR.mo'));
const po = fs.readFileSync(path.join(root, 'languages/zarinshopbot-fa_IR.po'), 'utf8');
const bootstrap = fs.readFileSync(path.join(root, 'zarinshopbot.php'), 'utf8');

assert(bootstrap.includes("add_filter('gettext_zarinshopbot', 'zarincode_fallback_empty_plugin_translation', 10, 3)"), 'runtime fallback handles stale external or cached empty translation files');
assert(bootstrap.includes("$translation === '' && is_string($source_text)"), 'empty plugin translations return their original source text');

for (const block of po.split(/\n\s*\n/)) {
  const lines = block.split(/\r?\n/);
  if (block.trim().startsWith('#~') || lines.some((line) => line.trim() === '#, fuzzy')) continue;
  const msgidIndex = lines.findIndex((line) => /^msgid\s+/.test(line));
  const msgstrIndex = lines.findIndex((line) => /^msgstr\s+/.test(line));
  if (msgidIndex < 0 || msgstrIndex < 0 || lines[msgidIndex] === 'msgid ""') continue; // skip header
  if (lines[msgstrIndex] === 'msgstr ""') {
    const next = lines[msgstrIndex + 1] || '';
    assert(next.trim().startsWith('"'), `active PO entry must not have an empty translation: ${lines[msgidIndex]}`);
  }
}

function moEntries(buffer) {
  const littleMagic = buffer.readUInt32LE(0);
  const bigMagic = buffer.readUInt32BE(0);
  const little = littleMagic === 0x950412de;
  assert(little || bigMagic === 0x950412de, 'compiled MO file has a valid GNU gettext magic header');
  const read32 = (offset) => little ? buffer.readUInt32LE(offset) : buffer.readUInt32BE(offset);
  const count = read32(8);
  const originals = read32(12);
  const translations = read32(16);
  const decodeRecord = (table, index) => {
    const length = read32(table + index * 8);
    const offset = read32(table + index * 8 + 4);
    return buffer.subarray(offset, offset + length).toString('utf8');
  };
  const entries = new Map();
  for (let i = 0; i < count; i++) entries.set(decodeRecord(originals, i), decodeRecord(translations, i));
  return entries;
}

const entries = moEntries(mo);
const requiredLabels = [
  'کارت‌به‌کارت',
  'حساب‌های بانکی و دریافت رسید پرداخت',
  'تنظیمات پرداخت کارت‌به‌کارت',
  'حساب‌های بانکی مقصد، نمایش اطلاعات به مشتری و بررسی رسید پرداخت',
  'فعال‌سازی پرداخت کارت‌به‌کارت در تسویه‌حساب ووکامرس',
  'عنوان روش پرداخت',
  'توضیحات پرداخت برای مشتری',
  'راهنمای بارگذاری رسید',
  'پرداخت کارت‌به‌کارت (بررسی دستی)',
];
for (const source of requiredLabels) {
  assert.strictEqual(entries.get(source), source, `untranslated Persian UI copy must fall back to its source text: ${source}`);
}
for (const [source, translation] of entries) {
  assert.notStrictEqual(translation, '', `compiled MO must not contain an empty translation for ${JSON.stringify(source)}`);
}
console.log(`Persian gettext catalog fallback smoke checks passed (${requiredLabels.length} card-transfer labels; ${entries.size} non-empty entries).`);
