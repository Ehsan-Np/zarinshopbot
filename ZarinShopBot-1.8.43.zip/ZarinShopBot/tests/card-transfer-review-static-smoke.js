/* Static regression checks for the card-transfer review workflow. */
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const card = fs.readFileSync(path.join(root, 'includes/class-zarinshopbot-card-transfer.php'), 'utf8');
const channels = fs.readFileSync(path.join(root, 'includes/class-zarinshopbot-channels.php'), 'utf8');
const commands = fs.readFileSync(path.join(root, 'vendor/zarinshopbot-core/Bot/CommandsTrait.php'), 'utf8');
const notifications = fs.readFileSync(path.join(root, 'vendor/zarinshopbot-core/Bot/NotificationTrait.php'), 'utf8');
const settings = fs.readFileSync(path.join(root, 'panel/settings.php'), 'utf8');
let checks = 0;
function assert(ok, message) {
  checks++;
  if (!ok) throw new Error(`FAILED: ${message}`);
}

const rendererStart = card.indexOf('public static function renderAdminOrderReview($order)');
const rendererEnd = card.indexOf('public static function renderAdminReviewForms()', rendererStart);
const renderer = card.slice(rendererStart, rendererEnd);
assert(renderer.includes('form="\' . esc_attr($form_id)'), 'admin approval controls target a form rendered outside WooCommerce order editor');
assert(!renderer.includes('<form method='), 'review metabox does not create invalid nested forms');
assert(card.includes("add_action('admin_footer', [__CLASS__, 'renderAdminReviewForms'])"), 'separate POST form is emitted in the admin footer');
assert(card.includes("$order->payment_complete();") && card.includes("if (!$order->is_paid())"), 'approval invokes WooCommerce payment completion and verifies paid status');
assert(card.includes('notifyPlatformAdminReceipt($order)') && card.includes('reviewCallback($platform'), 'receipt submission notifies the matching platform admin with signed actions');
assert(card.includes('notifyBuyerApproved($order)') && card.includes('get_downloadable_items()'), 'approval sends a buyer confirmation and eligible download links');
assert(card.includes("admin_notification_chat_id") && card.includes("$platform . '_admin_chat_id'"), 'Telegram uses its existing admin chat setting and channels use independent admin IDs');
assert(channels.includes("strpos((string) $message['text'], 'ztr:') === 0") && channels.includes('callback_actor_id($platform, $body'), 'Bale and Rubika review callbacks are dispatched with the actual clicking user');
assert(commands.includes("strpos(self::$command, 'ztr:') === 0") && commands.includes('Card_Transfer::handleBotReview'), 'Telegram review callbacks are handled before ordinary shop commands');
assert(card.includes("hash_hmac('sha256', $payload, wp_salt('auth'))") && card.includes('hash_equals($admin_id, $actor_id)'), 'bot review buttons are signed and restricted to the configured admin identity');
assert(card.includes('META_REVIEW_NONCE') && card.includes('This receipt has already been reviewed or replaced') && card.includes('([A-Za-z0-9]{16}):([a-f0-9]{12})'), 'bot approval callback is bound to the exact receipt review cycle');
assert(card.includes("get_meta(self::META_REVIEW, true) !== 'pending'") && card.includes("name=\"review_nonce\""), 'rejected and stale admin review actions cannot approve an older receipt');
assert(notifications.includes("'_zsb_transfer_approval_notice_state'") && notifications.includes("'approved'"), 'duplicate generic status message is suppressed for card-transfer approval');
assert(settings.includes('هم اعلان سفارش و هم رسید کارت‌به‌کارت و دکمه‌های تأیید/رد را دریافت می‌کند'), 'Telegram admin setting explains its order and receipt review use');
assert(settings.includes('Telegram گزینهٔ Start یا') && settings.includes('<code>/start</code>') && settings.includes('پنل اصلی افزونه ← مخاطبان و گروه‌ها ← کاربران') && settings.includes('#telegram-admin-chat-id'), 'Telegram setup help keeps /start literal, explains where to find the ID and links directly to its ID field');
assert(settings.includes('مقدار ستون Chat ID را در این فیلد وارد و ذخیره کند'), 'Telegram setup help identifies the exact Chat ID value to copy');
assert(channels.includes('شناسهٔ chat.id گفت‌وگوی خصوصی مدیر') && channels.includes('مخاطبان و گروه‌ها ← کاربران') && channels.includes('دکمه‌های تأیید/رد را دریافت می‌کند'), 'Bale and Rubika setup help explains where to find the private admin ID and the review purpose');
assert(channels.includes('id="<?php echo esc_attr($platform); ?>-admin-chat-id"'), 'Bale and Rubika settings expose direct-link anchors for the admin ID field');
console.log(`Card-transfer review static checks passed (${checks} checks).`);
