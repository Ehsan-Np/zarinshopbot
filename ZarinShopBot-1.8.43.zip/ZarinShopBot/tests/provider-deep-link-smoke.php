<?php
namespace {
    function home_url($path = '/') { return 'https://store.example' . $path; }
    function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
    function add_query_arg($key, $value, $url) { return $url . '?' . rawurlencode($key) . '=' . rawurlencode((string) $value); }
    function zarincode_option($key) {
        $context = $GLOBALS['zarinshopbot_channel_context'] ?? array();
        return $context[$key] ?? '';
    }
    require_once __DIR__ . '/fixtures/channel-context-stub.php';
    require_once dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/ApiTrait.php';
    class ZSB_Deep_Link_Test_Bot {
        use \ZarinShopBot\Core\Bot\ApiTrait;
        public static $chat_id = '';
        public static function getBotInfo() { return array('name' => zarincode_option('username')); }
    }
    ZSB_Deep_Link_Test_Bot::$chat_id = 'bale_123';
    $bale = ZSB_Deep_Link_Test_Bot::getBotDeepLink('product id/7');
    if ($bale !== 'https://ble.ir/bale_shop?start=product%20id%2F7') throw new \RuntimeException('Bale deep link did not infer the provider from a saved chat ID');
    if (isset($GLOBALS['zarinshopbot_channel_context'])) throw new \RuntimeException('Temporary provider context was not restored');
    ZSB_Deep_Link_Test_Bot::$chat_id = 'rubika_456';
    $rubika = ZSB_Deep_Link_Test_Bot::getBotDeepLink('order-42');
    if ($rubika !== 'https://rubika.ir/rubika_shop?start=order-42') throw new \RuntimeException('Rubika deep link did not use the Rubika base URL');
    echo "Provider deep-link inference smoke tests passed.\n";
}
