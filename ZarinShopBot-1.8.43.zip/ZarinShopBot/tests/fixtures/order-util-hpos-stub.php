<?php
namespace Automattic\WooCommerce\Utilities;
final class OrderUtil {
    public static function custom_orders_table_usage_is_enabled() { return true; }
}
