<?php
namespace ZarinShopBot;
final class Channels {
    public static function context_for_chat($chat_id) {
        if (strpos((string) $chat_id, 'bale_') === 0) return array('platform' => 'bale', 'token' => 'bale-secret', 'username' => 'bale_shop');
        if (strpos((string) $chat_id, 'rubika_') === 0) return array('platform' => 'rubika', 'token' => 'rubika-secret', 'username' => 'rubika_shop');
        return array();
    }
}
