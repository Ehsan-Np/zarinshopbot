'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const iconsCss = read('assets/css/local-icons.css');
const typographyCss = read('assets/css/typography.css');
const polishCss = read('assets/css/admin-polish.css');
const adminSettingsCss = read('assets/css/admin-settings.css');
const bootstrap = read('zarinshopbot.php');
const panel = read('panel/settings.php');
const transfer = read('includes/class-zarinshopbot-card-transfer.php');
const editor = read('includes/class-zarinshopbot-message-editor.php');

const localSvgPaths = [...iconsCss.matchAll(/mask:\s*url\("([^\"]+\.svg)"\)/g)].map((match) => match[1]);
assert(localSvgPaths.length >= 50, 'local SVG replacements remain available for explicitly mapped plugin icons');
for (const relative of new Set(localSvgPaths)) {
  assert(fs.existsSync(path.resolve(root, 'assets/css', relative)), `mapped icon file exists: ${relative}`);
}
assert(!/\.dashicons\s*\{[^}]*font-family\s*:\s*inherit/i.test(iconsCss), 'local SVG layer does not replace the native Dashicons font globally');
assert(!/\.dashicons::before\s*\{[^}]*content\s*:\s*["']?["']?\s*!important/i.test(iconsCss), 'unmapped icons retain their native Dashicons glyph');
assert(!iconsCss.includes('.dashicons-email-alt::before'), 'unmapped email-alt icon is left to the native Dashicons font');
assert(bootstrap.includes("wp_enqueue_style('dashicons')"), 'WordPress Dashicons font is explicitly loaded on plugin admin pages');

for (const [name, css] of [['typography', typographyCss], ['admin polish', polishCss]]) {
  assert(css.includes(':not(.mce-ico)'), `${name} typography rules exclude TinyMCE icon glyphs`);
  assert(css.includes(':not(.mce-btn)'), `${name} generic descendant rules exclude TinyMCE toolbar controls`);
}
assert(!adminSettingsCss.includes('font-family: "tinymce"'), 'plugin no longer guesses/forces an editor icon font');
const toolbarMatch = editor.match(/\$toolbar\s*=\s*'([^']+)'/);
assert(toolbarMatch, 'message editor toolbar configuration is available for coverage check');
const toolbarButtons = toolbarMatch[1].split(',').filter((name) => name !== 'formatselect');
for (const command of toolbarButtons) {
  assert(adminSettingsCss.includes(`mce-i-${command}::before`), `TinyMCE ${command} icon has a local SVG replacement`);
}
const mceSvgPaths = [...adminSettingsCss.matchAll(/mask-image:\s*url\("([^\"]+\.svg)"\)/g)].map((match) => match[1]);
assert(mceSvgPaths.length >= toolbarButtons.length, 'every visual-editor icon is rendered from an explicit local SVG mask');
for (const relative of new Set(mceSvgPaths)) {
  assert(fs.existsSync(path.resolve(root, 'assets/css', relative)), `visual editor SVG exists: ${relative}`);
}

assert(transfer.includes('public static function customerTitle()'), 'card-transfer title has a centralized non-empty fallback');
assert(transfer.includes("return $value !== '' ? $value : (string) self::defaults()['title'];"), 'empty legacy title falls back to the Persian default');
assert(transfer.includes('private static function hasMeaningfulCustomerText($value)'), 'empty rich-text markup is distinguished from meaningful customer copy');
assert(transfer.includes("self::hasMeaningfulCustomerText($value) ? (string) $value : (string) self::defaults()['description']"), 'blank legacy descriptions restore clear default copy');
assert(transfer.includes("self::hasMeaningfulCustomerText($value) ? (string) $value : (string) self::defaults()['instructions']"), 'blank legacy instructions restore clear default copy');
assert(panel.includes('Card_Transfer::customerTitle()'), 'admin title input is prefilled through the fallback helper');
assert(panel.includes('Card_Transfer::customerDescription()') && panel.includes('Card_Transfer::customerInstructions()'), 'both visual editors are prefilled from effective customer copy');
assert(adminSettingsCss.includes('.zarin-settings-wrap .zarin-card-transfer-pane .zarin-card-title'), 'card-transfer heading has a scoped readability rule');
assert(adminSettingsCss.includes('.zarin-settings-wrap .zarin-card-transfer-pane .zarin-help-text'), 'card-transfer explanatory text has a scoped readability rule');
console.log(`Card-transfer content and icon-rendering smoke checks passed (${new Set([...localSvgPaths, ...mceSvgPaths]).size} local SVG paths checked).`);
