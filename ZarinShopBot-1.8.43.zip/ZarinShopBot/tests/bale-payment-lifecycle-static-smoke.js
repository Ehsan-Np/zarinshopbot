const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'includes/class-zarinshopbot-bale-payments.php'), 'utf8');
const channels = fs.readFileSync(path.join(root, 'includes/class-zarinshopbot-channels.php'), 'utf8');
const assert = (condition, message) => {
  if (!condition) throw new Error(`FAILED: ${message}`);
};

assert(/\$transaction_user\s*===\s*''\s*\|\|\s*!hash_equals\(\$expected_user,\s*\$transaction_user\)/.test(source), 'successful payment verification requires a present and matching Bale transaction.userID');
assert(/private static function user_id_string\(\$value\)/.test(source) && /preg_match\('\/\\A\(\?:bale_\)\?\[0-9\]\+\\z\/', \$value\)/.test(source), 'Bale payer IDs reject missing, boolean, float and non-numeric identifiers');
assert(/\$live_amount\s*=\s*self::amount_in_irr\(\$order\)/.test(source) && /is_wp_error\(\$live_amount\)\s*\|\|\s*\(int\) \$live_amount !== \$expected_amount/.test(source), 'final payment confirmation rechecks the current WooCommerce order total');
assert(/private static function amount_matches\(\$value, \$expected\)/.test(source) && /preg_match\('\/\\A\[0-9\]\+\\z\/'/.test(source), 'payment amounts accept only complete integer-IRR values');
assert(/wc_get_held_stock_quantity\(\$product,\s*\$order->get_id\(\)\)/.test(source) && /get_stock_managed_by_id\(\)/.test(source), 'pre-checkout availability subtracts competing WooCommerce stock holds while excluding this order and aggregates shared variation stock');
assert(/wc_reserve_stock_for_order\(\$order\)/.test(source) && /reserve_order_stock\(\$order\)/.test(source), 'Bale pre-checkout invokes WooCommerce stock reservation before approving payment');
assert(/!\$product->backorders_allowed\(\)/.test(source) && /has_enough_stock\(\$quantity\)/.test(source), 'stock reservations do not block explicitly allowed backorders and item quantities are not truncated to integers');
assert(/answerPreCheckoutQuery', \$params, 5\)/.test(source), 'the outbound pre-checkout API call has a bounded timeout below Bale’s ten-second deadline');
assert(/bale_invoice_payload_mismatch/.test(source) && /invoice_payload_mismatch/.test(source), 'a superseded invoice payment is surfaced for manual review without automatic fulfillment');
assert(/private_group_reply/.test(channels) && /zsb_bale_group_edit_private/.test(channels), 'Bale group commerce retains private-reply context and blocks edits to shared group source messages');

console.log('Bale payment lifecycle static smoke checks passed (10 checks).');
