<?php
/** Offline migration contract for Bale/Rubika tokens and the Bale payment token. */
namespace {
    define('ABSPATH', __DIR__ . '/');
    $GLOBALS['zsb_test_options'] = array();
    function wp_salt($scheme = 'auth') { return 'offline-test-salt-that-is-not-a-live-site-secret'; }
    function get_option($name, $default = false) { return array_key_exists($name, $GLOBALS['zsb_test_options']) ? $GLOBALS['zsb_test_options'][$name] : $default; }
    function update_option($name, $value, $autoload = null) { $GLOBALS['zsb_test_options'][$name] = $value; return true; }
    function wp_parse_args($args, $defaults = array()) { return array_merge($defaults, is_array($args) ? $args : array()); }
    function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
    function wp_generate_password($length = 12, $special_chars = true, $extra_special_chars = false) { return str_repeat('x', $length); }

    require_once dirname(__DIR__) . '/vendor/zarinshopbot-core/Http/ProxyManager.php';
    require_once dirname(__DIR__) . '/includes/class-zarinshopbot-channels.php';

    $GLOBALS['zsb_test_options']['zarinshopbot_channels'] = array(
        'bale_enabled' => '1', 'bale_token' => 'legacy-bale-token', 'bale_provider_token' => 'legacy-payment-token',
        'rubika_enabled' => '1', 'rubika_token' => 'legacy-rubika-token',
    );
    \ZarinShopBot\Channels::migrate_plaintext_secrets();
    $stored = get_option('zarinshopbot_channels', array());
    foreach (array('bale_token', 'rubika_token', 'bale_provider_token') as $field) {
        if ($stored[$field] === '' || strpos($stored[$field], 'legacy-') === 0) throw new \RuntimeException('Secret remained stored as plaintext: ' . $field);
    }
    $encoded_bale = $stored['bale_token'];
    \ZarinShopBot\Channels::migrate_plaintext_secrets();
    if (get_option('zarinshopbot_channels', array())['bale_token'] !== $encoded_bale) throw new \RuntimeException('Secret migration was not idempotent');

    $runtime = \ZarinShopBot\Channels::options();
    if ($runtime['bale_token'] !== 'legacy-bale-token' || $runtime['rubika_token'] !== 'legacy-rubika-token' || $runtime['bale_provider_token'] !== 'legacy-payment-token') {
        throw new \RuntimeException('Encrypted channel credentials did not decrypt for runtime use');
    }
    $updated = \ZarinShopBot\Channels::sanitize_options(array('bale_token' => 'new-bale-token', 'rubika_token' => '', 'bale_provider_token' => ''));
    if ($updated['bale_token'] === 'new-bale-token' || \ZarinShopBot\Core\Http\ProxyManager::decrypt($updated['bale_token']) !== 'new-bale-token') throw new \RuntimeException('New channel tokens were not encrypted');
    if (\ZarinShopBot\Core\Http\ProxyManager::decrypt($updated['rubika_token']) !== 'legacy-rubika-token' || \ZarinShopBot\Core\Http\ProxyManager::decrypt($updated['bale_provider_token']) !== 'legacy-payment-token') throw new \RuntimeException('Blank secret fields did not preserve existing credentials');
    // Re-saving an unchanged bot token must not rotate the route secret and
    // invalidate the webhook already registered with the provider.
    $GLOBALS['zsb_test_options']['zarinshopbot_channels'] = array(
        'bale_token' => \ZarinShopBot\Core\Http\ProxyManager::encrypt('stable-bale-token'),
        'bale_secret' => 'stable-route-secret',
        'rubika_token' => '', 'rubika_secret' => '',
    );
    $unchanged = \ZarinShopBot\Channels::sanitize_options(array('bale_token' => 'stable-bale-token'));
    if ($unchanged['bale_secret'] !== 'stable-route-secret') throw new \RuntimeException('Unchanged bot token rotated the webhook route secret');
    $changed = \ZarinShopBot\Channels::sanitize_options(array('bale_token' => 'rotated-bale-token'));
    if ($changed['bale_secret'] === 'stable-route-secret' || strlen($changed['bale_secret']) !== 40) throw new \RuntimeException('Changed bot token did not rotate the webhook route secret');

    // Saving one platform must not reset the other platform's settings or secrets.
    $GLOBALS['zsb_test_options']['zarinshopbot_channels'] = array_merge(\ZarinShopBot\Channels::defaults(), array(
        'bale_enabled' => '1', 'bale_username' => 'bale_store', 'bale_post_title' => 'Old Bale title',
        'bale_notify_admin_new_order' => '0', 'rubika_enabled' => '1', 'rubika_post_title' => 'Old Rubika title',
    ));
    $rubika_only = \ZarinShopBot\Channels::sanitize_options(array('rubika_enabled' => '0', 'rubika_post_title' => 'New Rubika title'));
    if ($rubika_only['rubika_enabled'] !== '0' || $rubika_only['rubika_post_title'] !== 'New Rubika title') throw new \RuntimeException('Rubika settings did not persist through its option group');
    if ($rubika_only['bale_enabled'] !== '1' || $rubika_only['bale_username'] !== 'bale_store' || $rubika_only['bale_post_title'] !== 'Old Bale title' || $rubika_only['bale_notify_admin_new_order'] !== '0') throw new \RuntimeException('Saving Rubika mutated Bale settings');

    echo "Channel secret storage, independent channel saves, and webhook-secret stability contracts passed.\n";
}
