<?php
/**
 * Read-only runtime checks shown by the administrator diagnostics screen.
 * These checks do not call external APIs, create orders, alter options, or expose secrets.
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('SaleBotTestSuite', false)) {
    final class SaleBotTestSuite {
        private $results = array();

        /** @return array{passed:int,failed:int,results:array} */
        public function runAll() {
            $this->results = array();

            $this->check(
                'PHP runtime',
                version_compare(PHP_VERSION, '7.4.0', '>='),
                sprintf(__('PHP %s detected; minimum supported version is 7.4.', 'zarinshopbot'), PHP_VERSION)
            );

            $woocommerce_loaded = class_exists('WooCommerce') && defined('WC_VERSION');
            $this->check(
                'WooCommerce',
                $woocommerce_loaded,
                $woocommerce_loaded
                    ? sprintf(__('WooCommerce %s is loaded.', 'zarinshopbot'), WC_VERSION)
                    : __('WooCommerce is not active or its runtime is not loaded.', 'zarinshopbot')
            );

            $rest_available = function_exists('register_rest_route') && function_exists('rest_url');
            $this->check(
                'WordPress REST API',
                $rest_available,
                $rest_available
                    ? __('WordPress REST route functions are available.', 'zarinshopbot')
                    : __('Required WordPress REST API functions are unavailable.', 'zarinshopbot')
            );

            $commerce_class = class_exists('\\ZarinShopBot\\Core\\WooBot');
            $this->check(
                'Commerce runtime',
                $commerce_class,
                $commerce_class
                    ? __('The WooCommerce bot runtime class is loaded.', 'zarinshopbot')
                    : __('The WooCommerce bot runtime class could not be loaded.', 'zarinshopbot')
            );

            $channels_loaded = class_exists('\\ZarinShopBot\\Channels')
                && class_exists('\\ZarinShopBot\\Channel_API');
            $channel_defaults = $channels_loaded ? \ZarinShopBot\Channels::defaults() : array();
            $channels_independent = $channels_loaded
                && array_key_exists('bale_enabled', $channel_defaults)
                && array_key_exists('bale_token', $channel_defaults)
                && array_key_exists('rubika_enabled', $channel_defaults)
                && array_key_exists('rubika_token', $channel_defaults);
            $this->check(
                'Independent channel adapters',
                $channels_independent,
                $channels_independent
                    ? __('Bale and Rubika have separate adapter classes and settings keys.', 'zarinshopbot')
                    : __('Channel adapters or their independent settings are unavailable.', 'zarinshopbot')
            );

            $this->check_enabled_channel_credentials();
            $this->check_secret_encryption();
            $this->check_webhook_scheme();
            $this->check_required_files();

            $passed = 0;
            foreach ($this->results as $result) {
                if ($result['success']) {
                    $passed++;
                }
            }

            return array(
                'passed'  => $passed,
                'failed'  => count($this->results) - $passed,
                'results' => $this->results,
            );
        }

        private function check_enabled_channel_credentials() {
            $legacy = (array) get_option('zarincode_settings', array());
            $telegram_enabled = !function_exists('zarincode_telegram_enabled')
                || zarincode_telegram_enabled();
            $telegram_token = function_exists('zarincode_get_telegram_token')
                ? (string) zarincode_get_telegram_token($legacy)
                : (string) ($legacy['token'] ?? '');

            $this->check(
                'Telegram configuration',
                !$telegram_enabled || $telegram_token !== '',
                !$telegram_enabled
                    ? __('Telegram is disabled; no Telegram credential is required.', 'zarinshopbot')
                    : ($telegram_token !== ''
                        ? __('Telegram is enabled and a bot credential is stored.', 'zarinshopbot')
                        : __('Telegram is enabled but its bot credential is missing.', 'zarinshopbot'))
            );

            $channels = class_exists('\\ZarinShopBot\\Channels')
                ? \ZarinShopBot\Channels::options()
                : array();
            foreach (array('bale', 'rubika') as $platform) {
                $enabled = !empty($channels[$platform . '_enabled']);
                $token = trim((string) ($channels[$platform . '_token'] ?? ''));
                $this->check(
                    ucfirst($platform) . ' configuration',
                    !$enabled || $token !== '',
                    !$enabled
                        ? sprintf(__('%s is disabled; no credential is required.', 'zarinshopbot'), ucfirst($platform))
                        : ($token !== ''
                            ? sprintf(__('%s is enabled and a bot credential is stored.', 'zarinshopbot'), ucfirst($platform))
                            : sprintf(__('%s is enabled but its bot credential is missing.', 'zarinshopbot'), ucfirst($platform)))
                );
            }
        }

        private function check_secret_encryption() {
            $encrypted = false;
            $round_trip = false;
            if (class_exists('\\ZarinShopBot\\Core\\Http\\ProxyManager')) {
                try {
                    $probe = 'zsb-diagnostics-' . wp_generate_password(24, false, false);
                    $ciphertext = \ZarinShopBot\Core\Http\ProxyManager::encrypt($probe);
                    $encrypted = strpos($ciphertext, 'gcm:') === 0 || strpos($ciphertext, 'sod:') === 0;
                    $round_trip = hash_equals($probe, \ZarinShopBot\Core\Http\ProxyManager::decrypt($ciphertext));
                } catch (\Throwable $error) {
                    $round_trip = false;
                }
            }
            $this->check(
                'Secret storage encryption',
                $encrypted && $round_trip,
                $encrypted && $round_trip
                    ? __('Authenticated encryption is available and an in-memory round trip succeeded.', 'zarinshopbot')
                    : __('Authenticated encryption could not be verified. A compatibility encoding fallback is not encryption; enable OpenSSL or Sodium before storing production credentials.', 'zarinshopbot')
            );
        }

        private function check_webhook_scheme() {
            $url = function_exists('rest_url') ? rest_url() : '';
            $scheme = $url !== '' ? strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) : '';
            $https = $scheme === 'https';
            $this->check(
                'Webhook HTTPS prerequisite',
                $https,
                $https
                    ? __('The configured REST URL uses HTTPS. This does not verify certificate reachability or provider registration.', 'zarinshopbot')
                    : __('The configured REST URL is not HTTPS. Public webhook providers require HTTPS; this check does not test external reachability.', 'zarinshopbot')
            );
        }

        private function check_required_files() {
            $root = dirname(__DIR__);
            $files = array(
                'assets/js/webapp.js',
                'assets/js/admin-settings.js',
                'assets/css/webapp.css',
                'templates/webapp.php',
                'docs/guide-fa.html',
            );
            $missing = array();
            foreach ($files as $relative) {
                if (!is_readable($root . '/' . $relative)) {
                    $missing[] = $relative;
                }
            }
            $this->check(
                'Plugin files',
                empty($missing),
                empty($missing)
                    ? __('Required interface, template, and guide files are readable.', 'zarinshopbot')
                    : sprintf(__('Unreadable or missing files: %s', 'zarinshopbot'), implode(', ', $missing))
            );
        }

        private function check($name, $success, $details) {
            $this->results[] = array(
                'name'    => sanitize_text_field((string) $name),
                'success' => (bool) $success,
                'details' => sanitize_text_field((string) $details),
            );
        }
    }
}
