const fs = require('fs');
const path = require('path');
const source = fs.readFileSync(path.join(__dirname, '..', 'includes/class-zarinshopbot-channels.php'), 'utf8');
const assert = (condition, message) => {
  if (!condition) throw new Error(`FAILED: ${message}`);
};

assert(source.includes('private static function channel_reply_context($platform, array $body, $chat_id)'), 'A shared channel reply-context extractor handles provider event IDs');
assert(source.includes("$sender = $callback['from'] ?? ($message['from'] ?? array())"), 'Bale message and callback sender IDs are preserved separately');
assert(source.includes("$message['sender_id'] ?? $chat_id"), 'Rubika NewMessage keeps sender_id distinct and falls back for StartedBot');
assert(source.includes("'reply_chat_id' => $chat_id") && source.includes("'reply_sender_id' => $sender_id"), 'Conversation and sender IDs are preserved in runtime context');
assert(source.includes("$platform === 'rubika' && ($requested_chat_id === $sender_chat_id || $requested_chat_id === $conversation_chat_id)") && source.includes("$platform === 'bale' && $requested_chat_id === $conversation_chat_id") && source.includes("$params['chat_id'] = (string) $context['reply_sender_id']"), 'Rubika replies retain conversation routing while customer-facing Bale group replies are private to the sender');
assert(source.includes("$requested_chat_id === $sender_chat_id || $requested_chat_id === $conversation_chat_id"), 'Only the active event sender/conversation destination is remapped');
assert(source.includes("$params['chat_id'] = (string) $context['reply_chat_id']"), 'Shared-engine replies target the webhook conversation chat_id');
assert(source.includes("'method' => sanitize_key((string) $method)"), 'Routing diagnostics omit token, chat ID and message text');

console.log('Bale/Rubika reply routing static smoke checks passed (8 checks).');
