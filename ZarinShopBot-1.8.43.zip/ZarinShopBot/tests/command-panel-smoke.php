<?php
/** Offline consistency check for user-facing common commands. */
$root = dirname(__DIR__);
$panel = file_get_contents($root . '/panel/settings.php');
$core = file_get_contents($root . '/vendor/zarinshopbot-core/Bot/CoreTrait.php');
$channels = file_get_contents($root . '/includes/class-zarinshopbot-channels.php');
function zsb_command_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}
$expected = array('start', 'shop', 'search', 'category', 'newproducts', 'cart', 'orders', 'wishlist', 'settings', 'contactus', 'help');
$section_start = strpos($panel, 'فرمان‌های اصلی مشترک');
$section_end = $section_start === false ? false : strpos($panel, 'فرمان‌های تکمیلی و نام‌های جایگزین', $section_start);
$common_section = ($section_start !== false && $section_end !== false) ? substr($panel, $section_start, $section_end - $section_start) : '';
preg_match_all('/[\'\"]\/([a-z]+)[\'\"]/', $common_section, $panel_matches);
$panel_commands = $panel_matches[1] ?? array();
preg_match('/public static function configureTelegramMenu\(\)\s*\{(.*?)\n\s*\$menu_text/s', $core, $core_match);
preg_match_all('/\[\s*[\'\"]command[\'\"]\s*=>\s*[\'\"]([a-z]+)[\'\"]/', $core_match[1] ?? '', $core_commands_match);
$core_commands = $core_commands_match[1] ?? array();
preg_match('/private static function rubika_commands\(\)\s*\{(.*?)\n\s*\}/s', $channels, $rubika_match);
preg_match_all('/[\'\"]command[\'\"]\s*=>\s*[\'\"]([a-z]+)[\'\"]/', $rubika_match[1] ?? '', $rubika_commands_match);
$rubika_commands = $rubika_commands_match[1] ?? array();
zsb_command_assert($panel_commands === $expected, 'Panel shows exact common command list');
zsb_command_assert($core_commands === $expected, 'Telegram command menu matches common list');
zsb_command_assert($rubika_commands === $expected, 'Rubika setCommands list matches common list');
zsb_command_assert(strpos($panel, "esc_html_e('Telegram', 'zarinshopbot')") !== false && strpos($panel, "esc_html_e('Bale', 'zarinshopbot')") !== false && strpos($panel, "esc_html_e('Rubika', 'zarinshopbot')") !== false, 'Panel separates per-platform menu setup');
echo 'Command panel smoke tests passed (4 checks).' . PHP_EOL;
