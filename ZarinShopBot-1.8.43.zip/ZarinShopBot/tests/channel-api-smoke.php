<?php
/**
 * Offline contract smoke tests for the Bale/Rubika transport.
 * Run with: php tests/channel-api-smoke.php
 * No WordPress install, credentials, or external network is used.
 */
if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
if (!defined('MB_IN_BYTES')) { define('MB_IN_BYTES', 1048576); }

class WP_Error {
    private $code;
    private $message;
    private $data;
    public function __construct($code = '', $message = '', $data = null) { $this->code = $code; $this->message = $message; $this->data = $data; }
    public function get_error_code() { return $this->code; }
    public function get_error_message() { return $this->message; }
    public function get_error_data() { return $this->data; }
}

$GLOBALS['zsb_test_responses'] = array();
$GLOBALS['zsb_test_requests'] = array();
$GLOBALS['zsb_test_channel_logs'] = array();
function zarincode_log_event($event, $context = array()) { $GLOBALS['zsb_test_channel_logs'][] = array($event, $context); }
function is_wp_error($value) { return $value instanceof WP_Error; }
function __($text, $domain = null) { return $text; }
function wp_json_encode($value, $flags = 0) { return json_encode($value, $flags); }
function absint($value) { return abs((int) $value); }
function sanitize_key($value) { return preg_replace('/[^a-z0-9_\\-]/', '', strtolower((string) $value)); }
function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function esc_url_raw($value) { return filter_var($value, FILTER_SANITIZE_URL); }
function wp_strip_all_tags($value, $remove_breaks = false) { return strip_tags((string) $value); }
function wp_remote_post($url, $args) {
    $GLOBALS['zsb_test_requests'][] = array($url, $args);
    return array_shift($GLOBALS['zsb_test_responses']);
}
function wp_safe_remote_get($url, $args = array()) {
    $GLOBALS['zsb_test_requests'][] = array($url, $args);
    return array('response' => array('code' => 200), 'body' => 'fake-image-bytes', 'headers' => array('content-type' => 'image/jpeg'));
}
function wp_parse_url($url, $component = -1) { return parse_url($url, $component); }
function wp_generate_password($length = 12, $special_chars = true, $extra_special_chars = false) { return str_repeat('x', $length); }
function wp_remote_retrieve_response_code($response) { return $response['response']['code'] ?? 0; }
function wp_remote_retrieve_body($response) { return $response['body'] ?? ''; }
function wp_remote_retrieve_header($response, $header) { return $response['headers'][strtolower($header)] ?? ''; }

require dirname(__DIR__) . '/includes/class-zarinshopbot-channels.php';

function zsb_test_assert($condition, $label) {
    if (!$condition) {
        fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL);
        exit(1);
    }
}
function zsb_test_response($body, $status = 200) {
    $GLOBALS['zsb_test_responses'][] = array('response' => array('code' => $status), 'body' => json_encode($body));
}

$bale = new \ZarinShopBot\Channel_API('bale', 'test-secret');
$rubika = new \ZarinShopBot\Channel_API('rubika', 'test-secret');

zsb_test_response(array('ok' => true, 'result' => array('id' => 7)));
$result = $bale->request('getMe');
zsb_test_assert(!is_wp_error($result) && $result['result']['id'] === 7, 'Bale success envelope');

zsb_test_response(array('ok' => true, 'result' => array('url' => 'https://shop.example/wp-json/zarinshopbot/v1/hook/bale/routeKey')));
$info = $bale->request('getWebhookInfo');
zsb_test_assert(!is_wp_error($info) && ($info['result']['url'] ?? '') === 'https://shop.example/wp-json/zarinshopbot/v1/hook/bale/routeKey', 'Bale getWebhookInfo response envelope');

zsb_test_response(array('status' => 'OK', 'data' => array('bot' => array('username' => 'shop'))));
$result = $rubika->request('getMe');
$last = end($GLOBALS['zsb_test_requests']);
zsb_test_assert(!is_wp_error($result) && $result['data']['bot']['username'] === 'shop', 'Rubika success envelope');
zsb_test_assert(strpos($last[0], '/getMe') !== false && !array_key_exists('body', $last[1]) && !isset($last[1]['headers']['Content-Type']), 'Rubika getMe sends the documented no-parameter POST without JSON []');

zsb_test_response(array('data' => array()));
$result = $rubika->request('getMe');
zsb_test_assert(is_wp_error($result) && $result->get_error_code() === 'zsb_api_rejected', 'Reject missing Rubika status');

zsb_test_response(array('ok' => false, 'description' => 'rejected'));
$result = $bale->request('sendMessage', array('chat_id' => '1', 'text' => 'x'));
zsb_test_assert(is_wp_error($result) && $result->get_error_code() === 'zsb_api_rejected', 'Bale API rejection');

zsb_test_response(array('ok' => true, 'result' => true));
$result = $bale->telegram_call('answerCallbackQuery', array('callback_query_id' => 'cb-42', 'text' => 'Done', 'show_alert' => true));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(!is_wp_error($result) && ($payload['callback_query_id'] ?? '') === 'cb-42' && ($payload['show_alert'] ?? false) === true, 'Bale callback acknowledgement forwards documented alert controls');
$requests_before_old_callback = count($GLOBALS['zsb_test_requests']);
$result = $bale->telegram_call('answerCallbackQuery', array('callback_query_id' => '123456789', 'text' => 'Done'));
zsb_test_assert(!is_wp_error($result) && ($result['ok'] ?? false) === true && count($GLOBALS['zsb_test_requests']) === $requests_before_old_callback, 'Bale legacy callback IDs skip the unsupported answerCallbackQuery API call');
$direct_ack_method = new \ReflectionMethod('\\ZarinShopBot\\Channels', 'acknowledge_direct_bale_callback');
if (PHP_VERSION_ID < 80100) $direct_ack_method->setAccessible(true);
zsb_test_response(array('ok' => true, 'result' => true));
$direct_ack = $direct_ack_method->invoke(null, array('callback_query' => array('id' => 'cb-direct')), array('bale_token' => 'test-secret'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(!is_wp_error($direct_ack) && ($last[0] ?? '') === 'https://tapi.bale.ai/bot' . 'test-secret' . '/answerCallbackQuery' && ($payload['callback_query_id'] ?? '') === 'cb-direct', 'Direct Bale commerce callback paths answer before their custom handler runs');

zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'm1')));
$result = $rubika->send('rubika_abc', 'سلام', array(array('نمایش', 'zs:products')));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(!is_wp_error($result) && $result['ok'] === true, 'Rubika canonical send response');
zsb_test_assert(isset($payload['inline_keypad']['rows'][0]['buttons'][0]['id']) && !isset($payload['reply_markup']), 'Rubika keypad translation');

zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'm-payment-link')));
$result = $rubika->telegram_call('sendMessage', array(
    'chat_id' => 'rubika_abc',
    'text' => 'Choose a WooCommerce payment method.',
    'reply_markup' => array('inline_keyboard' => array(array(array('text' => 'Pay with store gateway', 'url' => 'https://shop.example.test/pay?order=7&sig=abc')))),
));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
$link_part = array_values(array_filter($payload['metadata']['meta_data_parts'] ?? array(), function($part) { return ($part['type'] ?? '') === 'Link'; }));
zsb_test_assert(!is_wp_error($result) && strpos($payload['text'] ?? '', 'Pay with store gateway') !== false && ($link_part[0]['link_url'] ?? '') === 'https://shop.example.test/pay?order=7&sig=abc' && empty($payload['inline_keypad']), 'Rubika WooCommerce payment URLs use documented Link metadata, not an undocumented URL keypad field');

zsb_test_response(array('status' => 'OK', 'data' => array()));
$commands = array(array('command' => 'start', 'description' => 'شروع فروشگاه'), array('command' => 'invalid/name', 'description' => 'نادیده گرفته شود'));
$result = $rubika->telegram_call('setMyCommands', array('commands' => $commands));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(strpos($last[0], '/setCommands') !== false, 'Rubika command menu maps to setCommands');
zsb_test_assert(count($payload['bot_commands'] ?? array()) === 1 && ($payload['bot_commands'][0]['command'] ?? '') === 'start', 'Rubika command names are validated');
zsb_test_assert(!is_wp_error($result) && $result['ok'] === true, 'Rubika command registration response');

zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'm2')));
$rubika->telegram_call('sendMessage', array('chat_id' => 'rubika_abc', 'text' => '🙂<b>x</b>'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
$part = $payload['metadata']['meta_data_parts'][0] ?? array();
zsb_test_assert(($part['from_index'] ?? null) === 2 && ($part['length'] ?? null) === 1, 'Rubika metadata uses UTF-16 units for emoji');
zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'm-entity')));
$rubika->telegram_call('sendMessage', array('chat_id' => 'rubika_abc', 'text' => '&lt;b&gt;literal&lt;/b&gt;'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(($payload['text'] ?? '') === 'literal' && empty($payload['metadata']), 'Rubika strips entity-escaped markup instead of formatting user text');
zsb_test_response(array('status' => 'OK', 'data' => array('upload_url' => 'https://files.example.test/upload')));
zsb_test_response(array('data' => array('file_id' => 'file-photo-1')));
zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'photo-1')));
$rubika->telegram_call('sendPhoto', array('chat_id' => 'rubika_abc', 'photo' => 'https://shop.example.test/product.jpg', 'caption' => '<b>Bold caption</b>'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(($last[0] ?? '') === 'https://botapi.rubika.ir/v3/test-secret/sendFile' && ($payload['text'] ?? '') === 'Bold caption' && !isset($payload['metadata']), 'Rubika photo captions are sent as plain text without undocumented metadata');

$before_edit_transport = count($GLOBALS['zsb_test_requests']);
$GLOBALS['zsb_test_responses'][] = new WP_Error('http_request_failed', 'Connection timed out');
$edit_result = $rubika->telegram_call('editMessageText', array('chat_id' => 'rubika_abc', 'message_id' => 'm-timeout', 'text' => 'Updated page'));
zsb_test_assert(is_wp_error($edit_result) && count($GLOBALS['zsb_test_requests']) === $before_edit_transport + 1, 'Rubika edit transport failure is not retried as a duplicate sendMessage');

$before_edit_rejection = count($GLOBALS['zsb_test_requests']);
zsb_test_response(array('status' => 'ERROR', 'error_code' => 'message_not_found'));
zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'm-edit-fallback')));
$edit_result = $rubika->telegram_call('editMessageText', array('chat_id' => 'rubika_abc', 'message_id' => 'm-missing', 'text' => 'Replacement page'));
zsb_test_assert(!is_wp_error($edit_result) && count($GLOBALS['zsb_test_requests']) === $before_edit_rejection + 2 && strpos(end($GLOBALS['zsb_test_requests'])[0], '/sendMessage') !== false, 'Rubika replaces a page only after an explicit provider rejection');

$before_keypad_failure = count($GLOBALS['zsb_test_requests']);
zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'm-edited')));
zsb_test_response(array('status' => 'ERROR', 'error_code' => 'invalid_input'));
$edit_result = $rubika->telegram_call('editMessageText', array('chat_id' => 'rubika_abc', 'message_id' => 'm-existing', 'text' => 'Text already edited', 'reply_markup' => array('inline_keyboard' => array(array(array('text' => 'Home', 'callback_data' => '/home'))))));
zsb_test_assert(is_wp_error($edit_result) && count($GLOBALS['zsb_test_requests']) === $before_keypad_failure + 2, 'Rubika keypad edit failure does not send a duplicate after text edit committed');

$many_entities = str_repeat('<b>x</b>', 31);
zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'm3')));
$rubika->telegram_call('sendMessage', array('chat_id' => 'rubika_abc', 'text' => $many_entities));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(count($payload['metadata']['meta_data_parts'] ?? array()) <= 30, 'Rubika metadata cap prevents provider rejection');

zsb_test_response(array('status' => 'ERROR', 'error_code' => 'invalid_input'));
zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'm4')));
$result = $rubika->telegram_call('sendMessage', array('chat_id' => 'rubika_abc', 'text' => '<b>Hello</b>', 'reply_markup' => array('inline_keyboard' => array(array(array('text' => 'Home', 'callback_data' => '/home'))))));
$retry = end($GLOBALS['zsb_test_requests']);
$retry_payload = json_decode($retry[1]['body'], true);
zsb_test_assert(!is_wp_error($result) && !isset($retry_payload['metadata']) && isset($retry_payload['inline_keypad']), 'Rubika retries explicit invalid_input without metadata while preserving documented keypad');

zsb_test_response(array('status' => 'ERROR', 'error_code' => 'invalid_input'));
zsb_test_response(array('status' => 'ERROR', 'error_code' => 'invalid_input'));
zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'm5')));
$result = $rubika->telegram_call('sendMessage', array('chat_id' => 'rubika_abc', 'text' => '<b>Plain fallback</b>', 'reply_markup' => array('inline_keyboard' => array(array(array('text' => 'Home', 'callback_data' => '/home'))))));
$retry = end($GLOBALS['zsb_test_requests']);
$retry_payload = json_decode($retry[1]['body'], true);
zsb_test_assert(!is_wp_error($result) && array_keys($retry_payload) === array('chat_id', 'text'), 'Rubika falls back to documented minimal text payload after keypad rejection');

// Use an official-shaped Rubika GUID fixture to catch prefixing/truncation in the outbound boundary.
$official_chat_id = 'b0QFtabc1I02214b529f1d60c9ce5b08';
$official_text = 'سلام 🙂';
zsb_test_response(array('status' => 'ERROR', 'error_code' => 'invalid_input'));
zsb_test_response(array('status' => 'ERROR', 'error_code' => 'invalid_input'));
$before = count($GLOBALS['zsb_test_requests']);
$result = $rubika->telegram_call('sendMessage', array(
    'chat_id' => 'rubika_' . $official_chat_id,
    'text' => $official_text,
    'reply_markup' => array('inline_keyboard' => array(array(array('text' => 'محصولات', 'callback_data' => 'zs:products')))),
));
$official_initial = json_decode($GLOBALS['zsb_test_requests'][$before][1]['body'], true);
$official_minimal = json_decode($GLOBALS['zsb_test_requests'][$before + 1][1]['body'], true);
zsb_test_assert(is_wp_error($result) && ($official_initial['chat_id'] ?? '') === $official_chat_id, 'Rubika strips only the internal platform namespace from official-shaped chat IDs');
zsb_test_assert(array_keys($official_minimal) === array('chat_id', 'text') && ($official_minimal['chat_id'] ?? '') === $official_chat_id && ($official_minimal['text'] ?? '') === $official_text, 'Rubika terminal fallback preserves official chat_id and text exactly');
$diagnostics = array_values(array_filter($GLOBALS['zsb_test_channel_logs'], function($entry) { return $entry[0] === 'rubika_sendmessage_invalid_input'; }));
$last_diagnostics = array_slice($diagnostics, -2);
zsb_test_assert(count($last_diagnostics) === 2 && ($last_diagnostics[0][1]['stage'] ?? '') === 'initial' && ($last_diagnostics[1][1]['stage'] ?? '') === 'minimal_text', 'Rubika rejection diagnostics identify initial and terminal fallback attempts');
$log_blob = json_encode($last_diagnostics);
zsb_test_assert(strpos($log_blob, $official_chat_id) === false && strpos($log_blob, $official_text) === false, 'Rubika rejection diagnostics omit raw chat ID and message text');

zsb_test_response(array('ok' => true, 'result' => array('message_id' => 11)));
$result = $bale->send('bale_123', 'سلام', array(array('نمایش', 'zs:products')));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(!is_wp_error($result) && $result['ok'] === true, 'Bale canonical send response');
zsb_test_assert(isset($payload['reply_markup']['inline_keyboard'][0][0]['callback_data']), 'Bale markup preservation');

zsb_test_response(array('ok' => true, 'result' => array('message_id' => 12)));
$bale->telegram_call('sendMessage', array('chat_id' => 'bale_123', 'text' => '<b>Bold</b> &lt;b&gt;literal&lt;/b&gt;', 'parse_mode' => 'HTML'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(($payload['text'] ?? '') === '*Bold* \\<b\\>literal\\</b\\>' && !isset($payload['parse_mode']), 'Bale maps HTML emphasis to documented Markdown and protects escaped tag text');

zsb_test_response(array('ok' => true, 'result' => array('message_id' => 13)));
$bale->telegram_call('sendPhoto', array('chat_id' => 'bale_123', 'photo' => 'photo-id', 'caption' => '<b>Bold caption</b>', 'parse_mode' => 'HTML'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(($payload['caption'] ?? '') === '*Bold caption*' && !isset($payload['parse_mode']), 'Bale photo captions are converted rather than sent as HTML');

zsb_test_response(array('ok' => true, 'result' => array('message_id' => 22)));
$result = $bale->telegram_call('sendVideo', array('chat_id' => 'bale_123', 'video' => 'https://cdn.example.test/product.mp4', 'caption' => 'Demo'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(strpos($last[0], '/sendVideo') !== false && ($payload['video'] ?? '') === 'https://cdn.example.test/product.mp4', 'Bale native video method mapping');
zsb_test_assert(!is_wp_error($result) && $result['ok'] === true, 'Bale video canonical response');

zsb_test_response(array('ok' => true, 'result' => array(array('message_id' => 23), array('message_id' => 24))));
$result = $bale->telegram_call('sendMediaGroup', array('chat_id' => 'bale_123', 'media' => array(array('type' => 'photo', 'media' => 'photo-id'), array('type' => 'video', 'media' => 'video-id'))));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(strpos($last[0], '/sendMediaGroup') !== false && count($payload['media'] ?? array()) === 2, 'Bale native media-group method mapping');
zsb_test_assert(!is_wp_error($result) && $result['ok'] === true, 'Bale media-group canonical response');

$requests_before = count($GLOBALS['zsb_test_requests']);
$result = $rubika->telegram_call('sendMediaGroup', array('chat_id' => 'rubika_abc', 'media' => array(array('type' => 'photo', 'media' => 'image'), array('type' => 'video', 'media' => 'video'))));
zsb_test_assert(is_wp_error($result) && count($GLOBALS['zsb_test_requests']) === $requests_before, 'Rubika rejects undocumented mixed media groups without sending URLs as text');

$GLOBALS['zsb_test_responses'][] = new WP_Error('http_request_failed', 'Connection failed');
$result = $bale->request('getMe');
zsb_test_assert(is_wp_error($result) && $result->get_error_code() === 'zsb_api_transport', 'Transport failure');
zsb_test_assert(strpos($result->get_error_message(), 'test-secret') === false, 'Do not expose API token in errors');

zsb_test_response(array('ok' => true), 503);
$result = $bale->request('getMe');
zsb_test_assert(is_wp_error($result) && $result->get_error_code() === 'zsb_api_response', 'HTTP status validation');

$unsupported = new \ZarinShopBot\Channel_API('telegram', 'test-secret');
$result = $unsupported->request('getMe');
zsb_test_assert(is_wp_error($result) && $result->get_error_code() === 'zsb_api_config', 'Platform allowlist');

$normalize = new \ReflectionMethod('\\ZarinShopBot\\Channels', 'normalize_update');
if (PHP_VERSION_ID < 80100) $normalize->setAccessible(true);
$started = $normalize->invoke(null, 'rubika', array('update' => array('type' => 'StartedBot', 'chat_id' => 'chat-7', 'start_id' => 'campaign', 'new_message' => array())), 'chat-7');
zsb_test_assert(($started['message']['text'] ?? '') === '/start campaign', 'Official Rubika StartedBot webhook enters the shared bot as /start');
$bale_contact = $normalize->invoke(null, 'bale', array('update_id' => 81, 'message' => array('message_id' => 4, 'from' => array('id' => 812), 'chat' => array('id' => 812, 'type' => 'private'), 'contact' => array('user_id' => 812, 'phone_number' => '+989121234567'))), '812');
zsb_test_assert(($bale_contact['message']['text'] ?? '') === '+989121234567', 'Bale self-shared contact is passed into the common checkout phone flow');
$bale_mismatched_contact = $normalize->invoke(null, 'bale', array('update_id' => 82, 'message' => array('message_id' => 5, 'from' => array('id' => 812), 'chat' => array('id' => 812, 'type' => 'private'), 'contact' => array('user_id' => 913, 'phone_number' => '+989129999999'))), '812');
zsb_test_assert(($bale_mismatched_contact['message']['text'] ?? '') === '', 'Bale contact belonging to another user is never accepted as the sender phone');
$extract = new \ReflectionMethod('\\ZarinShopBot\\Channels', 'extract_message');
if (PHP_VERSION_ID < 80100) $extract->setAccessible(true);
$extract_bale_contact = $extract->invoke(null, 'bale', array('message' => array('from' => array('id' => 812), 'chat' => array('id' => 812), 'contact' => array('user_id' => 812, 'phone_number' => '+989121234567'))));
zsb_test_assert(($extract_bale_contact['text'] ?? '') === '+989121234567', 'Bale direct message dispatch also extracts only identity-verified contacts');
$inline = $extract->invoke(null, 'rubika', array('inline_message' => array('chat_id' => 'chat-7', 'text' => '', 'aux_data' => array('button_id' => 'zs:products'))));
zsb_test_assert(($inline['chat_id'] ?? '') === 'chat-7' && ($inline['text'] ?? '') === 'zs:products', 'Official Rubika inline keypad webhook dispatches the button id');
$inline_update = $normalize->invoke(null, 'rubika', array('inline_message' => array('chat_id' => 'chat-7', 'sender_id' => 'user-8', 'message_id' => 'm-9', 'text' => '', 'aux_data' => array('button_id' => 'zs:products'))), 'chat-7');
zsb_test_assert(($inline_update['callback_query']['data'] ?? '') === 'zs:products', 'Rubika inline keypad callback is normalized for the common bot engine');
$opaque_update = $normalize->invoke(null, 'rubika', array('update' => array('type' => 'NewMessage', 'chat_id' => 'chat-7', 'new_message' => array('message_id' => 'msg_Ab-19', 'sender_id' => 'user-8', 'text' => 'x'))), 'chat-7');
zsb_test_assert(($opaque_update['message']['message_id'] ?? '') === 'msg_Ab-19', 'Rubika opaque message_id stays a string in normalized NewMessage');
$opaque_inline = $normalize->invoke(null, 'rubika', array('inline_message' => array('chat_id' => 'chat-7', 'sender_id' => 'user-8', 'message_id' => 'inline_X-2', 'aux_data' => array('button_id' => 'zs:cart'))), 'chat-7');
zsb_test_assert(($opaque_inline['callback_query']['message']['message_id'] ?? '') === 'inline_X-2', 'Rubika opaque inline message_id stays a string');
$reply_context_method = new \ReflectionMethod('\\ZarinShopBot\\Channels', 'channel_reply_context');
if (PHP_VERSION_ID < 80100) $reply_context_method->setAccessible(true);
$reply_context = $reply_context_method->invoke(null, 'rubika', array('update' => array('type' => 'NewMessage', 'chat_id' => 'chat-7', 'new_message' => array('sender_id' => 'user-8'))), 'chat-7');
zsb_test_assert(($reply_context['reply_chat_id'] ?? '') === 'chat-7' && ($reply_context['reply_sender_id'] ?? '') === 'user-8', 'Rubika webhook keeps conversation chat_id separate from sender_id');
$start_reply_context = $reply_context_method->invoke(null, 'rubika', array('update' => array('type' => 'StartedBot', 'chat_id' => 'chat-7')), 'chat-7');
zsb_test_assert(($start_reply_context['reply_chat_id'] ?? '') === 'chat-7' && ($start_reply_context['reply_sender_id'] ?? '') === 'chat-7', 'Rubika StartedBot without new_message falls back to its conversation ID');
$bale_group_body = array('message' => array('chat' => array('id' => '-100group', 'type' => 'group'), 'from' => array('id' => 8)));
$bale_reply_context = $reply_context_method->invoke(null, 'bale', $bale_group_body, '-100group');
zsb_test_assert(($bale_reply_context['reply_chat_id'] ?? '') === '-100group' && ($bale_reply_context['reply_sender_id'] ?? '') === '8', 'Bale group reply context keeps conversation chat_id separate from sender_id');
$dispatch_context_method = new \ReflectionMethod('\\ZarinShopBot\\Channels', 'channel_dispatch_context');
if (PHP_VERSION_ID < 80100) $dispatch_context_method->setAccessible(true);
$bale_dispatch_context = $dispatch_context_method->invoke(null, 'bale', $bale_group_body, '-100group');
zsb_test_assert(($bale_dispatch_context['reply_chat_id'] ?? '') === '8' && ($bale_dispatch_context['cart_owner_id'] ?? '') === '8', 'Direct Bale group actions reply privately and keep carts per sender');
$rubika_dispatch_context = $dispatch_context_method->invoke(null, 'rubika', array('update' => array('chat_id' => 'chat-7', 'new_message' => array('sender_id' => 'user-8'))), 'chat-7');
zsb_test_assert(($rubika_dispatch_context['reply_chat_id'] ?? '') === 'chat-7' && ($rubika_dispatch_context['cart_owner_id'] ?? '') === 'user-8', 'Rubika direct actions preserve conversation replies and sender-owned carts');
$GLOBALS['zarinshopbot_channel_context'] = array('platform' => 'bale', 'token' => 'bale-test-token', 'reply_chat_id' => '-100group', 'reply_sender_id' => '8', 'private_group_reply' => true);
zsb_test_response(array('ok' => true, 'result' => array('message_id' => 1)));
\ZarinShopBot\Channels::telegram_api_call('sendMessage', array('chat_id' => 'bale_8', 'text' => 'group reply'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(($payload['chat_id'] ?? '') === '8', 'Bale sender-addressed reply uses the private sender chat');
zsb_test_response(array('ok' => true, 'result' => array('message_id' => 2)));
\ZarinShopBot\Channels::telegram_api_call('sendMessage', array('chat_id' => 'bale_-100group', 'text' => 'private group-event response'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(($payload['chat_id'] ?? '') === '8', 'Bale shared-engine group destination is remapped to the human sender');
$requests_before_private_edit = count($GLOBALS['zsb_test_requests']);
$group_edit = \ZarinShopBot\Channels::telegram_api_call('editMessageText', array('chat_id' => 'bale_-100group', 'message_id' => 44, 'text' => 'private cart details'));
zsb_test_assert(is_wp_error($group_edit) && count($GLOBALS['zsb_test_requests']) === $requests_before_private_edit, 'Bale group source messages are never overwritten with a user-specific page');
$group_delete = \ZarinShopBot\Channels::telegram_api_call('deleteMessage', array('chat_id' => 'bale_-100group', 'message_id' => 44));
zsb_test_assert(!is_wp_error($group_delete) && count($GLOBALS['zsb_test_requests']) === $requests_before_private_edit, 'Bale shared group callback source is not deleted through a private-chat ID');
zsb_test_response(array('ok' => true, 'result' => array('message_id' => 3)));
\ZarinShopBot\Channels::telegram_api_call('sendMessage', array('chat_id' => 'bale_admin-9', 'text' => 'admin'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(($payload['chat_id'] ?? '') === 'admin-9', 'Bale reply mapping does not redirect an unrelated admin destination');
$GLOBALS['zarinshopbot_channel_context'] = array('platform' => 'rubika', 'token' => 'rubika-test-token', 'reply_chat_id' => 'chat-7', 'reply_sender_id' => 'user-8');
zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'reply-1')));
\ZarinShopBot\Channels::telegram_api_call('sendMessage', array('chat_id' => 'rubika_user-8', 'text' => 'reply'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(($payload['chat_id'] ?? '') === 'chat-7', 'Rubika shared-engine reply is sent to chat_id rather than sender_id');
zsb_test_response(array('status' => 'OK', 'data' => array('message_id' => 'admin-1')));
\ZarinShopBot\Channels::telegram_api_call('sendMessage', array('chat_id' => 'rubika_admin-9', 'text' => 'admin'));
$last = end($GLOBALS['zsb_test_requests']);
$payload = json_decode($last[1]['body'], true);
zsb_test_assert(($payload['chat_id'] ?? '') === 'admin-9', 'Rubika sender/chat remapping does not redirect an unrelated admin destination');
unset($GLOBALS['zarinshopbot_channel_context']);
$log_events = array_column($GLOBALS['zsb_test_channel_logs'], 0);
zsb_test_assert(in_array('channel_api_success', $log_events, true) && in_array('channel_api_transport_error', $log_events, true), 'Credential-free per-channel API outcome diagnostics are recorded');
$log_blob = json_encode($GLOBALS['zsb_test_channel_logs']);
zsb_test_assert(strpos($log_blob, 'test-secret') === false && strpos($log_blob, 'rubika_abc') === false, 'Channel diagnostics never store provider tokens or chat ids');

echo 'Channel API contract smoke tests passed (63 checks).' . PHP_EOL;
