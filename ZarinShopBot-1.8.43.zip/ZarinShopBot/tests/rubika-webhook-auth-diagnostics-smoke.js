const fs = require('fs');
const assert = require('assert');
const channels = fs.readFileSync('includes/class-zarinshopbot-channels.php', 'utf8');

assert(channels.includes("$reason = ($stored === '' && $registered_digest === '') ? 'stored_key_missing'"), 'Rubika webhook authentication reports missing current and registered route state distinctly');
assert(channels.includes("return new \\WP_REST_Response(array('ok' => false), 403)"), 'a secret mismatch remains fail-closed rather than accepting unauthenticated Rubika traffic');
assert(channels.includes("$rubika_route_state === 'missing'") && channels.includes('درخواست‌هایی که کلید مسیرشان با تنظیم فعلی یکی نباشد با پاسخ 403 رد می‌شوند'), 'Rubika settings explain that a missing route verifier causes 403 responses and require re-registration');
assert(channels.includes("'ثبت وب‌هوک همین ربات'") && channels.includes("'previous'"), 'settings point administrators to re-register stale Rubika endpoints');
assert(channels.includes("persist_registered_route_digest('rubika'") && channels.includes("'channel_webhook_route_verifier_saved'"), 'successful Rubika endpoint registration persists and logs its verifier');
console.log('Rubika webhook-auth diagnostics smoke checks passed (5 checks).');
