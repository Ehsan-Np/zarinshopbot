<?php
/** Offline contract checks for Telegram Rich Message routing/payload rules. */
$GLOBALS['zsb_rich_options'] = array('telegram_rich_messages' => '0');
function zarincode_option($key) { return $GLOBALS['zsb_rich_options'][$key] ?? null; }
function absint($value) { return abs((int) $value); }
require dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/TelegramTrait.php';

class Zsb_Rich_Message_Test_Bot {
    use \ZarinShopBot\Core\Bot\TelegramTrait;
    public static function getLanguage() { return 'fa'; }
    public static function enabled(array $params) { return self::telegramRichMessagesEnabled($params); }
    public static function payload(array $params) { return self::buildRichMessageParams($params); }
    public static function fallback($response) { return self::isDeterministicRichMessageRejection($response); }
}
class Zsb_Rich_Test_Response {
    public $ok = false;
    private $data;
    public function __construct($code) { $this->data = array('error_code' => $code); }
    public function getRawData() { return $this->data; }
}
function zsb_rich_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}

$params = array('chat_id' => '12345', 'text' => '<b>سلام</b>', 'reply_markup' => array('inline_keyboard' => array()));
zsb_rich_assert(!Zsb_Rich_Message_Test_Bot::enabled($params), 'Rich Messages default to disabled');
$GLOBALS['zsb_rich_options']['telegram_rich_messages'] = '1';
zsb_rich_assert(Zsb_Rich_Message_Test_Bot::enabled($params), 'Opt-in enables regular Telegram chat');
zsb_rich_assert(!Zsb_Rich_Message_Test_Bot::enabled(array('chat_id' => 'bale_123', 'text' => 'x')), 'Namespaced Bale chats never use Telegram Rich API');
$GLOBALS['zarinshopbot_channel_context'] = array('platform' => 'rubika');
zsb_rich_assert(!Zsb_Rich_Message_Test_Bot::enabled($params), 'Rubika context never uses Telegram Rich API');
unset($GLOBALS['zarinshopbot_channel_context']);
$payload = Zsb_Rich_Message_Test_Bot::payload($params);
zsb_rich_assert(($payload['rich_message']['html'] ?? '') === '<b>سلام</b>' && !empty($payload['rich_message']['is_rtl']), 'Rich payload preserves HTML and sets RTL');
zsb_rich_assert(isset($payload['reply_markup']), 'Rich payload preserves the inline keyboard');
zsb_rich_assert(Zsb_Rich_Message_Test_Bot::fallback(new Zsb_Rich_Test_Response(400)), 'Explicit API 400 may use legacy fallback');
zsb_rich_assert(Zsb_Rich_Message_Test_Bot::fallback(new Zsb_Rich_Test_Response(404)), 'Explicit API 404 may use legacy fallback');
zsb_rich_assert(!Zsb_Rich_Message_Test_Bot::fallback(new Zsb_Rich_Test_Response(500)), 'Server error never triggers fallback resend');
echo 'Telegram Rich Message smoke tests passed (8 checks).' . PHP_EOL;
