<?php
/** Offline regression test for WooCommerce cart initialization during bot webhooks. */
namespace {
    if (!defined('ABSPATH')) { define('ABSPATH', __DIR__ . '/'); }

    class ZSB_FakeCart {
        public function add_to_cart($product_id, $quantity, $variation_id = 0, $variation = array()) {
            $GLOBALS['zsb_cart_add_calls'][] = array($product_id, $quantity, $variation_id, $variation);
            return true;
        }
        public function calculate_shipping() { $GLOBALS['zsb_shipping_calculated'] = true; }
        public function needs_shipping() { return true; }
        public function show_shipping() { return false; }
        public function empty_cart($clear_persistent_cart = true) { $GLOBALS['zsb_cart_emptied'] = true; }
        public function get_cart_from_session() { $GLOBALS['zsb_cart_restored'] = true; }
    }
    class ZSB_FakeCustomer {
        public function set_shipping_country($value) { $GLOBALS['zsb_customer_country'] = $value; }
        public function calculated_shipping($value) { $GLOBALS['zsb_customer_calculated'] = $value; }
        public function set_shipping_state($value) { $GLOBALS['zsb_customer_state'] = $value; }
        public function set_shipping_city($value) { $GLOBALS['zsb_customer_city'] = $value; }
        public function set_shipping_postcode($value) { $GLOBALS['zsb_customer_postcode'] = $value; }
        public function set_shipping_address_1($value) { $GLOBALS['zsb_customer_address'] = $value; }
        public function set_shipping_address_2($value) { $GLOBALS['zsb_customer_address_2'] = $value; }
    }
    class ZSB_FakeCountries {
        public function get_base_country() { return 'IR'; }
    }
    class ZSB_FakeRate {
        public function get_id() { return 'flat_rate:7'; }
        public function get_label() { return 'Local delivery'; }
        public function get_cost() { return 125.0; }
    }
    class ZSB_FakeShipping {
        public function get_packages() { return array(array('rates' => array('flat_rate:7' => new ZSB_FakeRate()))); }
    }
    class ZSB_FakeSession {
        private $values = array('cart' => array('store-item' => array('product_id' => 99)), 'applied_coupons' => array('SAVE'), 'chosen_shipping_methods' => array('flat_rate:2'));
        public function get($key) { return $this->values[$key] ?? null; }
        public function set($key, $value) { $this->values[$key] = $value; }
    }
    class ZSB_FakeProduct {
        public function needs_shipping() { return true; }
        public function is_downloadable() { return false; }
    }
    class ZSB_FakeWooCommerce {
        public $cart = null;
        public $customer = null;
        public $countries = null;
        public $shipping = null;
        public $session = null;
        public function countries() {
            $this->countries = new ZSB_FakeCountries();
            return $this->countries;
        }
        public function shipping() {
            $this->shipping = new ZSB_FakeShipping();
            return $this->shipping;
        }
    }

    $GLOBALS['zsb_fake_woocommerce'] = new ZSB_FakeWooCommerce();
    $GLOBALS['zsb_fake_woocommerce']->session = new ZSB_FakeSession();
    $GLOBALS['zsb_cart_add_calls'] = array();
    $GLOBALS['zsb_wc_load_calls'] = 0;
    $GLOBALS['zsb_cart_emptied'] = false;
    $GLOBALS['zsb_cart_restored'] = false;
    $GLOBALS['zsb_shipping_calculated'] = false;
    $GLOBALS['zsb_wc_load_should_fail'] = false;
    $GLOBALS['zsb_test_logs'] = array();

    function WC() { return $GLOBALS['zsb_fake_woocommerce']; }
    function wc_load_cart() {
        $GLOBALS['zsb_wc_load_calls']++;
        if ($GLOBALS['zsb_wc_load_should_fail']) { throw new \RuntimeException('simulated load failure'); }
        $GLOBALS['zsb_fake_woocommerce']->cart = new ZSB_FakeCart();
        $GLOBALS['zsb_fake_woocommerce']->customer = new ZSB_FakeCustomer();
    }
    function apply_filters($tag, $value) { return $value; }
    function get_post_status($product_id) { return 'publish'; }
    function wc_get_product($product_id) { return (int) $product_id === 321 ? new ZSB_FakeProduct() : null; }
    function absint($value) { return abs((int) $value); }
    function zsb_assert($condition, $label) {
        if (!$condition) {
            fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL);
            exit(1);
        }
    }
}

namespace ZarinShopBot\Core\Bot {
    require_once dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/WooCommerceTrait.php';
    class ZSB_WooCommerceTraitHarness {
        use WooCommerceTrait;
        public static function getOrderData() { return array('state' => 'THR', 'city' => 'Tehran', 'zip' => '1234567890', 'address' => 'Main street'); }
        public static function getCart() { return array(321 => 2); }
        public static function normalizeCartPayload($cart) { return $cart; }
        public static function productNeedsShipping($product) { return $product && $product->needs_shipping(); }
        public static function log($message) { $GLOBALS['zsb_test_logs'][] = $message; }
    }
}

namespace {
    use ZarinShopBot\Core\Bot\ZSB_WooCommerceTraitHarness;

    $shipping = ZSB_WooCommerceTraitHarness::wooGetShipping();
    zsb_assert(isset($shipping[base64_encode('flat_rate:7')]) && $shipping[base64_encode('flat_rate:7')]['label'] === 'Local delivery' && $shipping[base64_encode('flat_rate:7')]['cost'] === 125.0, 'configured WooCommerce rates are surfaced even when show_shipping() hides the storefront control');
    zsb_assert($GLOBALS['zsb_wc_load_calls'] === 1, 'cart is lazily loaded once when absent in the webhook context');
    zsb_assert(count($GLOBALS['zsb_cart_add_calls']) === 1 && $GLOBALS['zsb_cart_add_calls'][0][0] === 321, 'bot item is added only after cart initialization');
    zsb_assert($GLOBALS['zsb_shipping_calculated'] && $GLOBALS['zsb_cart_emptied'] && $GLOBALS['zsb_cart_restored'], 'shipping calculation completes and the original session cart is restored');
    zsb_assert($GLOBALS['zsb_customer_postcode'] === '1234567890' && $GLOBALS['zsb_customer_address'] === 'Main street', 'postcode and address are applied to the WooCommerce shipping customer');
    zsb_assert($GLOBALS['zsb_customer_country'] === 'IR', 'countries service is initialized before reading the store base country');

    $GLOBALS['zsb_fake_woocommerce']->cart = null;
    $GLOBALS['zsb_wc_load_calls'] = 0;
    $GLOBALS['zsb_cart_add_calls'] = array();
    $result = ZSB_WooCommerceTraitHarness::wooAdd2Cart(654, 1);
    zsb_assert($result === true && $GLOBALS['zsb_wc_load_calls'] === 1, 'direct wooAdd2Cart call also safely initializes a missing cart');

    $GLOBALS['zsb_fake_woocommerce']->cart = null;
    $GLOBALS['zsb_wc_load_calls'] = 0;
    $GLOBALS['zsb_wc_load_should_fail'] = true;
    $result = ZSB_WooCommerceTraitHarness::wooAdd2Cart(654, 1);
    zsb_assert($result === false, 'cart initialization failure returns safely instead of fataling on null');
    zsb_assert(count($GLOBALS['zsb_test_logs']) > 0, 'cart initialization failure is recorded for diagnosis');

    echo "WooCommerce cart bootstrap and shipping-rate smoke tests passed (9 checks).\n";
}
