'use strict';
const fs = require('fs');
const assert = require('assert');

const core = fs.readFileSync('vendor/zarinshopbot-core/Bot/CoreTrait.php', 'utf8');
const menu = fs.readFileSync('vendor/zarinshopbot-core/Bot/MenuTrait.php', 'utf8');
const settings = fs.readFileSync('panel/settings.php', 'utf8');
const bootstrap = fs.readFileSync('zarinshopbot.php', 'utf8');

assert(core.includes("'type' => 'web_app'") && core.includes("'web_app' => ['url' => $webapp_url]"), 'Telegram chat menu is configured as a Web App when Mini App is enabled');
assert(core.includes("'menu_button' => $menu_button") && core.includes("'commands_enabled' => $commands_enabled"), 'menu synchronization signature tracks app URL/button and command-toggle state');
assert(core.includes('isSecureTelegramWebAppUrl($webapp_url)') && core.includes("setChatMenuButton', ['menu_button' => $menu_button]"), 'only HTTPS Mini App URLs are sent through Telegram setChatMenuButton');
assert(menu.includes("set_url_scheme($base_url, 'https')"), 'plugin-generated Mini App links use HTTPS');
assert(core.includes("zarincode_option('feature_webapp_enable') !== '0'"), 'Mini App configuration sync runs even when bot commands are disabled');
assert(bootstrap.includes('does not match this token') && bootstrap.includes('Select the token owner in BotFather'), 'getMe connection diagnostic detects a saved username/token mismatch');
assert(settings.includes('select the same bot shown by Test Bot Connection (getMe)') && settings.includes('separate t.me/bot/short-name launch link'), 'BotFather setup guidance distinguishes the HTTPS app URL from Telegram launch deep link');

console.log('Telegram Mini App/BotFather configuration smoke tests passed (7 checks).');
