'use strict';
const assert = require('assert');
const fs = require('fs');
const panel = fs.readFileSync('panel/settings.php', 'utf8');
const channels = fs.readFileSync('includes/class-zarinshopbot-channels.php', 'utf8');
const saveBar = fs.readFileSync('panel/partials/settings-save-bar.php', 'utf8');
const css = fs.readFileSync('assets/css/admin-settings.css', 'utf8');
const js = fs.readFileSync('assets/js/admin-settings.js', 'utf8');

// Both option forms use the same presentational and semantic save component.
assert(panel.includes("require __DIR__ . '/partials/settings-save-bar.php'"));
assert(channels.includes("require dirname(__DIR__) . '/panel/partials/settings-save-bar.php'"));
assert(saveBar.includes("esc_html_e('Save Changes', 'zarinshopbot')"));
assert(saveBar.includes("esc_html_e('طراحی و پشتیبانی:', 'zarinshopbot')"));
assert(saveBar.includes('form="<?php echo esc_attr($save_bar_form); ?>"'));
assert(saveBar.includes('data-channel-save="<?php echo esc_attr($save_bar_platform); ?>"'));
assert(channels.includes("'class' => 'zarin-channel-save-bar'"));
assert(channels.includes("'form' => 'zarinshopbot_' . $platform . '_settings_form'"));
assert(channels.includes("'platform' => $platform"));
assert(channels.includes("'hint' => sprintf(__('این دکمه فقط تنظیمات کانال %s را ذخیره می‌کند"));
assert(!channels.includes('ذخیرهٔ مستقل کانال'));

// Saving a channel remains a WordPress Settings API operation, separate from Telegram/shared options.
assert(channels.includes("register_setting('zarinshopbot_channels_group', self::OPTION"));
assert(channels.includes("settings_fields('zarinshopbot_channels_group')"));
assert(channels.includes("admin_url('options.php')"));
assert(channels.includes("'sanitize_callback' => array(__CLASS__, 'sanitize_options')"));
assert(channels.includes('$clean = $old;'), 'the other channel values and secret state must be retained');
assert(channels.includes("foreach (array('bale', 'rubika') as $platform)"));
assert(channels.includes("wp_nonce_field('zarinshopbot_test_channel_' . $platform)"));
assert(channels.includes("wp_nonce_field('zarinshopbot_register_channel_webhooks')"));
assert(panel.indexOf('</form>\n                <?php foreach (array(\'bale\', \'rubika\')') > panel.indexOf('id="zarin_settings_form"'), 'channel tabs must be outside the main settings form');

// Ensure every editable channel field has an implementation/sanitizer path.
for (const key of [
    'bale_enabled', 'rubika_enabled', 'bale_token', 'rubika_token',
    'bale_username', 'rubika_username', 'bale_admin_chat_id', 'rubika_admin_chat_id',
    'bale_post_chat_id', 'rubika_post_chat_id', 'bale_post_title', 'rubika_post_title',
    'bale_notify_customer_new_order', 'bale_notify_admin_new_order',
    'rubika_notify_customer_new_order', 'rubika_notify_admin_new_order',
    'bale_miniapp_enabled', 'bale_wallet_enabled', 'bale_provider_token', 'bale_irr_per_store_unit',
]) {
    assert(channels.includes(key), `Missing channel runtime/sanitize field ${key}`);
}
assert.match(css, /\.zarin-footer-bar\s*\{[\s\S]*?position:\s*sticky/);
assert(js.includes("$('.zarin-footer-bar').not('.zarin-channel-save-bar').toggleClass('is-hidden', isChannelTab)"));
assert(js.includes("$bar.insertBefore($mainFooter)"));
assert(panel.includes('توکن ذخیره شده؛ این نشانگر به‌تنهایی اتصال زنده را ثابت نمی‌کند'));
console.log('Bale/Rubika independent settings save-path static checks passed.');
