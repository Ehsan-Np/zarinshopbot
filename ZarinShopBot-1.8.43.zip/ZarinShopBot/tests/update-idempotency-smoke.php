<?php
/**
 * Offline smoke test for bot update deduplication and WordPress GUID preservation.
 * Run with: php tests/update-idempotency-smoke.php
 */
if (!defined('ABSPATH')) { define('ABSPATH', __DIR__ . '/'); }

class WP_Error {
    private $code;
    public function __construct($code = '') { $this->code = $code; }
    public function get_error_code() { return $this->code; }
}
function is_wp_error($value) { return $value instanceof WP_Error; }
function wp_insert_post($post, $wp_error = false) {
    $id = ++$GLOBALS['zsb_next_post_id'];
    $GLOBALS['zsb_test_posts'][$id] = (object) array_merge(array('ID' => $id, 'guid' => 'https://store.test/?p=' . $id), $post);
    return $id;
}
function wp_update_post($post, $wp_error = false) {
    $post = (array) $post;
    $id = (int) ($post['ID'] ?? 0);
    if (!$id || empty($GLOBALS['zsb_test_posts'][$id])) { return new WP_Error('missing_post'); }
    foreach ($post as $key => $value) { $GLOBALS['zsb_test_posts'][$id]->$key = $value; }
    return $id;
}
function update_post_meta($id, $key, $value) { $GLOBALS['zsb_test_meta'][$id][$key] = $value; return true; }
function get_post_meta($id, $key, $single = false) { return $GLOBALS['zsb_test_meta'][$id][$key] ?? ''; }

$GLOBALS['zsb_next_post_id'] = 0;
$GLOBALS['zsb_test_posts'] = array();
$GLOBALS['zsb_test_meta'] = array();

require dirname(__DIR__) . '/vendor/zarinshopbot-core/Bot/UserSessionTrait.php';
class Zsb_Update_Test_Bot {
    use \ZarinShopBot\Core\Bot\UserSessionTrait;
    public static $chat_id = 'bale_12345';
    public static $first_name = 'Test';
    public static $last_name = '';
    public static $user_username = '';
    public static $group_chat_id = '';
    public static $group_title = '';
    public static $command = '/start';
    public static function fixPersianChar($value) { return (string) $value; }
    public static function getUser() {
        foreach ($GLOBALS['zsb_test_posts'] as $post) {
            if (($post->post_type ?? '') === 'zarincode_user' && ($post->post_title ?? '') === self::$chat_id) { return $post; }
        }
        return array();
    }
    public static function log($message) {}
}
function zsb_update_assert($condition, $label) {
    if (!$condition) { fwrite(STDERR, 'FAILED: ' . $label . PHP_EOL); exit(1); }
}

$status = Zsb_Update_Test_Bot::updateUser(9001);
$post = Zsb_Update_Test_Bot::getUser();
zsb_update_assert($status === 'processed' && $post, 'Create channel user');
$original_guid = $post->guid;
zsb_update_assert($original_guid === 'https://store.test/?p=' . $post->ID, 'New post gets a WordPress GUID');
zsb_update_assert(get_post_meta($post->ID, 'zarinshopbot_last_update_id', true) === '9001', 'Provider update ID is stored as metadata');
zsb_update_assert(Zsb_Update_Test_Bot::updateUser(9001) === 'duplicate', 'Repeated provider update is acknowledged as duplicate');
zsb_update_assert(Zsb_Update_Test_Bot::updateUser(9002) === 'processed', 'A later update is accepted');
$post = Zsb_Update_Test_Bot::getUser();
zsb_update_assert($post->guid === $original_guid, 'Subsequent updates do not mutate WordPress GUID');

echo 'Update idempotency smoke tests passed (6 checks).' . PHP_EOL;
