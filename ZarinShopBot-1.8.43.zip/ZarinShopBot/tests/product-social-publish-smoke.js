'use strict';
const assert = require('assert');
const fs = require('fs');
const editor = fs.readFileSync('custom-post-types.php', 'utf8');
const bootstrap = fs.readFileSync('zarinshopbot.php', 'utf8');
const script = fs.readFileSync('assets/js/admin-social-publish.js', 'utf8');
const css = fs.readFileSync('assets/css/admin-social-publish.css', 'utf8');

assert.match(editor, /add_meta_box\([\s\S]*?zarinshopbot_social_publish/);
for (const platform of ['telegram', 'bale', 'rubika']) {
    assert(editor.includes("'" + platform + "' => array("), `${platform} destination readiness is checked independently`);
    assert(editor.includes(`data-zsb-platform-row="<?php echo esc_attr($platform); ?>"`), `${platform} has a distinct product-editor row`);
}
assert.match(editor, /data-zsb-social-publish="<\?php echo esc_attr\(\$platform\); \?>"/);
assert.match(editor, /add_action\('wp_ajax_zarincode_publish_product_social'/);
assert.match(editor, /check_ajax_referer\('zarincode_social_publish_' \. \$product_id, 'nonce'\)/);
assert.match(editor, /current_user_can\('edit_post', \$product_id\)/);
assert.match(editor, /get_post_status\(\$product_id\) !== 'publish'/);
assert.match(bootstrap, /zarinshopbot-admin-social-publish/);
assert.match(script, /action: 'zarincode_publish_product_social'/);
assert.match(script, /button\.disabled = true/);
assert.match(script, /showMessage\(\$feedback, message \|\| cfg\.failed, false\)/);
assert.match(css, /\.zsb-social-platform-list/);
assert.match(css, /@media \(max-width: 782px\)/);
console.log('Per-platform product publishing smoke tests passed (15 checks).');
