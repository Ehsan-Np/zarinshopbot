<?php
/* Modified 2026-10-23 by Ehsan NaderiPanah / Zarincode.com. Derived code remains under GPL-2.0-or-later; upstream notices are retained. */
if (!defined('ABSPATH')) exit;

// Keep ZarinShopBot\Core post types managed within the ZarinShopBot\Core Dashboard,
// without cluttering or polluting the main WordPress admin sidebar menu.
add_filter('register_post_type_args', function ($args, $post_type) {
    if (in_array($post_type, ['zarincode_user', 'zarincode_group', 'telegram_commands'], true)) {
        $args['show_in_menu'] = false;
    }
    return $args;
}, 10, 2);

add_action('init', function() {
    $labels_user = [
        'name'               => _x('Subscribed users', 'Post Type General Name', 'zarinshopbot'),
        'singular_name'      => _x('User', 'Post Type Singular Name', 'zarinshopbot'),
        'menu_name'          => __('Telegram', 'zarinshopbot'),
        'name_admin_bar'     => __('Users', 'zarinshopbot'),
        'parent_item_colon'  => __('Parent Item:', 'zarinshopbot'),
        'all_items'          => __('Subscribed users', 'zarinshopbot'),
        'add_new_item'       => __('Add New Item', 'zarinshopbot'),
        'add_new'            => __('Add New', 'zarinshopbot'),
        'new_item'           => __('New Item', 'zarinshopbot'),
        'edit_item'          => __('Edit Item', 'zarinshopbot'),
        'update_item'        => __('Update Item', 'zarinshopbot'),
        'view_item'          => __('View Item', 'zarinshopbot'),
        'search_items'       => __('Search Item', 'zarinshopbot'),
        'not_found'          => __('Not found', 'zarinshopbot'),
        'not_found_in_trash' => __('Not found in Trash', 'zarinshopbot'),
    ];

    $args_user = [
        'label'               => __('Subscriber', 'zarinshopbot'),
        'description'         => __('Post Type Description', 'zarinshopbot'),
        'labels'              => $labels_user,
        'taxonomies'          => ['zarincode_group'],
        'supports'            => ['title', 'editor', 'custom-fields'],
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false,
        'show_in_nav_menus'   => false,
        'can_export'          => false,
        'has_archive'         => false,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'rewrite'             => false,
        'capability_type'     => 'post',
    ];

    if (defined('WP_DEBUG') && false === WP_DEBUG) {
        $args_user['capabilities'] = ['create_posts' => 'do_not_allow'];
        $args_user['map_meta_cap'] = false;
    }

    $args_user = apply_filters('zarincode_user_register_capabilities', $args_user);
    register_post_type('zarincode_user', $args_user);

    $labels_group = [
        'name'               => _x('Subscribed groups', 'Post Type General Name', 'zarinshopbot'),
        'singular_name'      => _x('Group', 'Post Type Singular Name', 'zarinshopbot'),
        'menu_name'          => __('Telegram', 'zarinshopbot'),
        'name_admin_bar'     => __('Groups', 'zarinshopbot'),
        'parent_item_colon'  => __('Parent Item:', 'zarinshopbot'),
        'all_items'          => __('Subscribed groups', 'zarinshopbot'),
        'add_new_item'       => __('Add New Item', 'zarinshopbot'),
        'add_new'            => __('Add New', 'zarinshopbot'),
        'new_item'           => __('New Item', 'zarinshopbot'),
        'edit_item'          => __('Edit Item', 'zarinshopbot'),
        'update_item'        => __('Update Item', 'zarinshopbot'),
        'view_item'          => __('View Item', 'zarinshopbot'),
        'search_items'       => __('Search Item', 'zarinshopbot'),
        'not_found'          => __('Not found', 'zarinshopbot'),
        'not_found_in_trash' => __('Not found in Trash', 'zarinshopbot'),
    ];

    $args_group = [
        'label'               => __('Groups', 'zarinshopbot'),
        'description'         => __('Post Type Description', 'zarinshopbot'),
        'labels'              => $labels_group,
        'taxonomies'          => ['zarincode_group'],
        'supports'            => ['title', 'editor', 'custom-fields'],
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false,
        'show_in_nav_menus'   => false,
        'can_export'          => false,
        'has_archive'         => false,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'rewrite'             => false,
        'capability_type'     => 'post',
    ];

    if (defined('WP_DEBUG') && false === WP_DEBUG) {
        $args_group['capabilities'] = ['create_posts' => 'do_not_allow'];
        $args_group['map_meta_cap'] = false;
    }

    $args_group = apply_filters('zarincode_group_register_capabilities', $args_group);
    register_post_type('zarincode_group', $args_group);
});

add_action('post_submitbox_misc_actions', function ($post) {
    if (!is_object($post) || get_post_type($post) !== 'product') {
        return;
    }
    wp_nonce_field('zarincode_product_misc_save', 'zarincode_product_misc_nonce');

    $is_scheduled = false;
    if (get_post_meta($post->ID, 'telegram_future_publish', true)) {
        $is_scheduled = true;
    }
    $target = (int) zarincode_option('target');
    ?>
    <div class="misc-pub-section misc-pub-section-last">
        <span id="timestamp">
            <label>
                <input type="checkbox" value="1" <?php checked($is_scheduled, true); ?> name="zarincode_m_send" id="zarincode_m_send" />
                <?php echo esc_html__('Telegram: send a product notification to its bot audience', 'zarinshopbot'); ?>
                <img src="<?php echo esc_url(plugins_url('assets/icons/telegram.svg', __FILE__)); ?>" style="width:16px;position:absolute;padding:0 5px;" alt="telegram" />
                <?php if ($is_scheduled): ?>
                    - <b><?php echo esc_html__('scheduled', 'zarinshopbot'); ?></b>
                <?php endif; ?>
            </label>
            <div id="zarincode_m">
                <small>
                    <?php esc_html_e('Send to:', 'zarinshopbot'); ?>
                    <select name="zarincode_m_send_target">
                        <option value="0" <?php selected($target, 0); ?>><?php esc_html_e('Users, Groups, Channel', 'zarinshopbot'); ?></option>
                        <option value="1" <?php selected($target, 1); ?>><?php esc_html_e('Users', 'zarinshopbot'); ?></option>
                        <option value="2" <?php selected($target, 2); ?>><?php esc_html_e('Groups', 'zarinshopbot'); ?></option>
                        <option value="3" <?php selected($target, 3); ?>><?php esc_html_e('Users, Groups', 'zarinshopbot'); ?></option>
                        <option value="4" <?php selected($target, 4); ?>><?php esc_html_e('Channel', 'zarinshopbot'); ?></option>
                    </select>
                </small>
            </div>
            <?php
            $last_sent = get_post_meta($post->ID, 'zarincode_last_sent', true);
            if (!empty($last_sent)) {
                echo '<br><small>' . esc_html__('Last sent on: ', 'zarinshopbot') . esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), (int)$last_sent)) . '</small>';
            }
            ?>
        </span>
    </div>
    <?php
});

/** Dedicated per-platform product publishing controls for WooCommerce's product editor. */
add_action('add_meta_boxes_product', function () {
    add_meta_box(
        'zarinshopbot_social_publish',
        __('انتشار مستقل محصول در پیام‌رسان‌ها', 'zarinshopbot'),
        'zarincode_render_social_publish_metabox',
        'product',
        'side',
        'high'
    );
});

function zarincode_render_social_publish_metabox($post) {
    if (!is_object($post) || empty($post->ID) || !current_user_can('edit_post', $post->ID)) return;

    $channel_options = class_exists(\ZarinShopBot\Channels::class) ? \ZarinShopBot\Channels::options() : array();
    $destinations = array(
        'telegram' => array(
            'label' => 'Telegram',
            'configured' => function_exists('zarincode_telegram_enabled') && zarincode_telegram_enabled() && trim((string) zarincode_option('channelusername')) !== '',
        ),
        'bale' => array(
            'label' => 'Bale',
            'configured' => !empty($channel_options['bale_enabled']) && !empty($channel_options['bale_token']) && trim((string) ($channel_options['bale_post_chat_id'] ?? '')) !== '',
        ),
        'rubika' => array(
            'label' => 'Rubika',
            'configured' => !empty($channel_options['rubika_enabled']) && !empty($channel_options['rubika_token']) && trim((string) ($channel_options['rubika_post_chat_id'] ?? '')) !== '',
        ),
    );
    $is_published = get_post_status($post) === 'publish';
    ?>
    <div class="zsb-social-publish-metabox" dir="rtl">
        <?php wp_nonce_field('zarincode_product_misc_save', 'zarincode_product_misc_nonce'); ?>
        <p class="description"><?php esc_html_e('هر کانال دکمهٔ ارسال فوری و مقصد مستقل دارد. برای ارسال، محصول باید منتشر شده باشد.', 'zarinshopbot'); ?></p>
        <label class="zsb-social-on-save"><input type="checkbox" name="zarincode_m_send_social" value="1"> <?php esc_html_e('ارسال به کانال‌های انتخاب‌شده هنگام ذخیره/به‌روزرسانی محصول', 'zarinshopbot'); ?></label>
        <div class="zsb-social-platform-list">
            <?php foreach ($destinations as $platform => $destination) :
                $last_sent = (int) get_post_meta($post->ID, '_zsb_social_post_sent_' . $platform, true);
                $button_disabled = !$destination['configured'] || !$is_published;
            ?>
                <div class="zsb-social-platform" data-zsb-platform-row="<?php echo esc_attr($platform); ?>">
                    <label class="zsb-social-platform-select">
                        <input type="checkbox" name="zarincode_m_send_social_platforms[]" value="<?php echo esc_attr($platform); ?>" <?php disabled(!$destination['configured']); ?> />
                        <img src="<?php echo esc_url(plugins_url('assets/icons/' . $platform . '.svg', __FILE__)); ?>" width="20" height="20" alt="" aria-hidden="true" />
                        <strong><?php echo esc_html($destination['label']); ?></strong>
                    </label>
                    <button type="button" class="button button-secondary zsb-social-publish-now" data-zsb-social-publish="<?php echo esc_attr($platform); ?>" data-post-id="<?php echo esc_attr($post->ID); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('zarincode_social_publish_' . absint($post->ID))); ?>" <?php disabled($button_disabled); ?>>
                        <span class="dashicons dashicons-megaphone" aria-hidden="true"></span><?php esc_html_e('ارسال همین محصول', 'zarinshopbot'); ?>
                    </button>
                    <small class="zsb-social-platform-status" data-zsb-social-status="<?php echo esc_attr($platform); ?>" aria-live="polite">
                        <?php if (!$destination['configured']) : ?><?php esc_html_e('ربات یا مقصد این کانال در تنظیمات خودش کامل نشده است.', 'zarinshopbot'); ?>
                        <?php elseif (!$is_published) : ?><?php esc_html_e('ابتدا محصول را منتشر/ذخیره کنید؛ سپس ارسال فوری فعال می‌شود.', 'zarinshopbot'); ?>
                        <?php elseif ($last_sent > 0) : ?><?php echo esc_html(sprintf(__('آخرین ارسال موفق: %s', 'zarinshopbot'), date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $last_sent))); ?>
                        <?php else : ?><?php esc_html_e('آمادهٔ ارسال مستقل به این کانال.', 'zarinshopbot'); ?><?php endif; ?>
                    </small>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="zsb-social-publish-feedback" data-zsb-social-feedback role="status" aria-live="polite" hidden></div>
        <p class="description zsb-social-publish-note"><?php esc_html_e('این دکمه‌ها پست محصول را فقط به مقصد همان پیام‌رسان می‌فرستند. گزینهٔ قدیمی «ارسال اعلان به مخاطبان ربات» در جعبهٔ انتشار وردپرس، عملکرد جداگانهٔ اعلان Telegram است.', 'zarinshopbot'); ?></p>
    </div>
    <?php
}

add_action('wp_ajax_zarincode_publish_product_social', function () {
    $product_id = isset($_POST['post_id']) ? absint(wp_unslash($_POST['post_id'])) : 0;
    $platform = isset($_POST['platform']) ? sanitize_key(wp_unslash($_POST['platform'])) : '';
    if (!$product_id || !in_array($platform, array('telegram', 'bale', 'rubika'), true)) {
        wp_send_json_error(array('message' => __('درخواست ارسال معتبر نیست.', 'zarinshopbot')), 400);
    }
    check_ajax_referer('zarincode_social_publish_' . $product_id, 'nonce');
    if (!current_user_can('edit_post', $product_id)) {
        wp_send_json_error(array('message' => __('اجازهٔ ارسال این محصول را ندارید.', 'zarinshopbot')), 403);
    }
    if (get_post_type($product_id) !== 'product' || get_post_status($product_id) !== 'publish') {
        wp_send_json_error(array('message' => __('برای ارسال، ابتدا محصول را منتشر کنید.', 'zarinshopbot')), 400);
    }
    $sent = function_exists('zarincode_send_social_product_post') && zarincode_send_social_product_post($product_id, $platform);
    if (!$sent) {
        wp_send_json_error(array('message' => __('ارسال انجام نشد؛ وضعیت اتصال ربات، مقصد همان کانال و دسترسی ارسال را بررسی کنید.', 'zarinshopbot')), 422);
    }
    $sent_at = current_time('timestamp');
    wp_send_json_success(array(
        'message' => sprintf(__('محصول با موفقیت به %s ارسال شد.', 'zarinshopbot'), ucfirst($platform)),
        'status' => sprintf(__('آخرین ارسال موفق: %s', 'zarinshopbot'), date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $sent_at)),
    ));
});
