<?php
/**
 * Shared sticky save bar for the main options form and independently saved channels.
 * Expects $settings_save_bar as a sanitized view-model array.
 */
if (!defined('ABSPATH')) { exit; }
$save_bar = isset($settings_save_bar) && is_array($settings_save_bar) ? $settings_save_bar : array();
$save_bar_class = trim('zarin-footer-bar ' . (isset($save_bar['class']) ? (string) $save_bar['class'] : ''));
$save_bar_form = isset($save_bar['form']) ? (string) $save_bar['form'] : '';
$save_bar_hint = isset($save_bar['hint']) ? (string) $save_bar['hint'] : '';
$save_bar_hidden = !empty($save_bar['hidden']);
$save_bar_platform = isset($save_bar['platform']) ? (string) $save_bar['platform'] : '';
$save_bar_aria = isset($save_bar['aria']) ? (string) $save_bar['aria'] : '';
?>
<footer class="<?php echo esc_attr($save_bar_class . ($save_bar_hidden ? ' is-hidden' : '')); ?>"<?php if ($save_bar_platform !== '') : ?> data-channel-save="<?php echo esc_attr($save_bar_platform); ?>"<?php endif; ?><?php if ($save_bar_aria !== '') : ?> aria-label="<?php echo esc_attr($save_bar_aria); ?>"<?php endif; ?>>
    <div class="zarin-footer-left">
        <button type="submit" form="<?php echo esc_attr($save_bar_form); ?>" class="zarin-btn-primary zarin-btn-save">
            <span class="dashicons dashicons-saved" aria-hidden="true"></span>
            <?php esc_html_e('Save Changes', 'zarinshopbot'); ?>
        </button>
        <span class="zarin-save-hint"><?php echo esc_html($save_bar_hint); ?></span>
    </div>
    <div class="zarin-footer-right">
        <span class="zarin-footer-brand">
            <?php esc_html_e('طراحی و پشتیبانی:', 'zarinshopbot'); ?>
            <a href="https://zarincode.com" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Zarincode.com', 'zarinshopbot'); ?></a>
        </span>
    </div>
</footer>
