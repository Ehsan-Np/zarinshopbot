<?php
/* Modified 2026-10-23 by Ehsan NaderiPanah (Zarincode.com). Derived code remains under GPL-2.0-or-later; bundled notices and compatibility identifiers are retained. */
if (!defined('ABSPATH')) exit;
// Included by zarincode_render_settings_panel(); these are view-local variables.
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

if (defined('ZARINCODE_SETTINGS_PANEL_LOADED')) {
    return;
}
define('ZARINCODE_SETTINGS_PANEL_LOADED', true);

zarincode_footer_text_call();

$tabs = array(
    'basic'         => array('name' => __('تنظیمات Telegram', 'zarinshopbot'), 'icon' => 'dashicons-admin-generic', 'desc' => __('اتصال، Mini App، اعلان، پروکسی، پرداخت و همهٔ قابلیت‌های اختصاصی تلگرام در یک بخش', 'zarinshopbot')),
    'bale'          => array('name' => __('ربات Bale', 'zarinshopbot'), 'icon' => 'dashicons-format-chat', 'desc' => __('توکن، Mini App، کیف‌پول، اعلان و انتشار مستقل', 'zarinshopbot')),
    'rubika'        => array('name' => __('ربات Rubika', 'zarinshopbot'), 'icon' => 'dashicons-share', 'desc' => __('توکن، وب‌هوک، اعلان و مقصد انتشار مستقل', 'zarinshopbot')),
    'menu'          => array('name' => __('منوی فروشگاه', 'zarinshopbot'), 'icon' => 'dashicons-menu', 'desc' => __('چیدمان دکمه‌ها و اقدام‌های سفارشی', 'zarinshopbot')),
    'search'        => array('name' => __('جستجو و فیلترها', 'zarinshopbot'), 'icon' => 'dashicons-search', 'desc' => __('شناسه، قیمت، موجودی و ترتیب', 'zarinshopbot')),
    'display'       => array('name' => __('کاتالوگ و محصولات', 'zarinshopbot'), 'icon' => 'dashicons-layout', 'desc' => __('نمایش مشترک محصولات در ربات‌ها', 'zarinshopbot')),
    'order'         => array('name' => __('سبد و تسویه‌حساب', 'zarinshopbot'), 'icon' => 'dashicons-cart', 'desc' => __('قواعد مشترک WooCommerce و سفارش', 'zarinshopbot')),
    'card-transfer' => array('name' => __('کارت‌به‌کارت', 'zarinshopbot'), 'icon' => 'dashicons-money-alt', 'desc' => __('حساب‌های بانکی و دریافت رسید پرداخت', 'zarinshopbot')),
    'membership'    => array('name' => __('عضویت اجباری', 'zarinshopbot'), 'icon' => 'dashicons-groups', 'desc' => __('قواعد دسترسی؛ فقط APIهای پشتیبانی‌شده', 'zarinshopbot')),
    'marketing'     => array('name' => __('بازاریابی و پشتیبان‌گیری', 'zarinshopbot'), 'icon' => 'dashicons-awards', 'desc' => __('ارجاع و کمپین‌های مشترک فروشگاه و انتقال تنظیمات', 'zarinshopbot')),
    'messages'      => array('name' => __('پیام‌ها و ترجمه‌ها', 'zarinshopbot'), 'icon' => 'dashicons-format-chat', 'desc' => __('متن‌های مشترک با بازنویسی اختیاری هر پلتفرم', 'zarinshopbot')),
    'accounts'      => array('name' => __('حساب مشتری و تأیید تلفن', 'zarinshopbot'), 'icon' => 'dashicons-admin-users', 'desc' => __('سیاست عضویت، شماره یکتا و OTP پیامکی', 'zarinshopbot')),
    'checkout-fields' => array('name' => __('فیلدهای سفارش', 'zarinshopbot'), 'icon' => 'dashicons-feedback', 'desc' => __('پروفایل جداگانهٔ سبد دانلودی و فیزیکی/ترکیبی', 'zarinshopbot')),
    'webapp-branding' => array('name' => __('ظاهر Mini App', 'zarinshopbot'), 'icon' => 'dashicons-art', 'desc' => __('لوگو و رنگ‌های اختصاصی فروشگاه', 'zarinshopbot')),
    'commands'      => array('name' => __('فرمان‌ها و منوهای ربات', 'zarinshopbot'), 'icon' => 'dashicons-editor-help', 'desc' => __('فرمان‌های مشترک؛ نمایش اختصاصی هر پیام‌رسان', 'zarinshopbot')),
    'diagnostics'   => array('name' => __('گزارش‌ها و تشخیص', 'zarinshopbot'), 'icon' => 'dashicons-visibility', 'desc' => __('ثبت رخدادها و نگهداری گزارش مشترک همهٔ کانال‌ها', 'zarinshopbot'))
);

// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only tab navigation; no state is changed.
$requested_tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : '';
// Legacy Telegram subsection links now open the single consolidated Telegram tab.
if (in_array($requested_tab, array('webapp', 'notifications', 'proxy', 'telegram-features'), true)) { $requested_tab = 'basic'; }
$is_channel_tab = in_array($requested_tab, array('bale', 'rubika'), true);
$current = $is_channel_tab ? '__channel__' : (isset($tabs[$requested_tab]) ? $requested_tab : 'basic');
$active_tab = $is_channel_tab ? $requested_tab : $current;
$options = get_option('zarincode_settings', array());
$card_transfer_settings = class_exists(\ZarinShopBot\Card_Transfer::class) ? array_merge(\ZarinShopBot\Card_Transfer::defaults(), \ZarinShopBot\Card_Transfer::settings()) : array();
$telegram_enabled = function_exists('zarincode_telegram_enabled') ? zarincode_telegram_enabled() : (array_key_exists('telegram_enabled', $options) ? (string) $options['telegram_enabled'] === '1' : !empty($options['token']));
$channel_options = class_exists(\ZarinShopBot\Channels::class) ? \ZarinShopBot\Channels::options() : array();
$channel_label = $active_tab === 'bale' ? __('بله', 'zarinshopbot') : __('روبیکا', 'zarinshopbot');
$telegram_token_for_status = function_exists('zarincode_get_telegram_token') ? trim(zarincode_get_telegram_token($options)) : (isset($options['token']) ? trim((string) $options['token']) : '');
$bot_token = $is_channel_tab ? trim((string) ($channel_options[$active_tab . '_token'] ?? '')) : $telegram_token_for_status;
$bot_username = $is_channel_tab ? trim((string) ($channel_options[$active_tab . '_username'] ?? '')) : (isset($options['username']) ? trim($options['username']) : '');
$is_test_mode = !$is_channel_tab && isset($options['testmod']) && $options['testmod'] === 'yes';
$ssl_active = is_ssl();
$platform_cards = array(
    'basic' => array(
        'platform' => 'telegram', 'label' => 'Telegram',
        'enabled' => $telegram_enabled && $telegram_token_for_status !== '',
        'detail' => __('ربات اصلی، Mini App، پرداخت‌ها و تنظیمات اختصاصی Telegram', 'zarinshopbot'),
        'tab' => 'basic',
    ),
    'bale' => array(
        'platform' => 'bale', 'label' => 'Bale',
        'enabled' => !empty($channel_options['bale_enabled']) && !empty($channel_options['bale_token']),
        'detail' => __('ربات مستقل Bale، Mini App، کیف‌پول و مقصد انتشار', 'zarinshopbot'),
        'tab' => 'bale',
    ),
    'rubika' => array(
        'platform' => 'rubika', 'label' => 'Rubika',
        'enabled' => !empty($channel_options['rubika_enabled']) && !empty($channel_options['rubika_token']),
        'detail' => __('ربات مستقل Rubika، وب‌هوک، checkout ووکامرس و مقصد انتشار', 'zarinshopbot'),
        'tab' => 'rubika',
    ),
);
?>

<div class="wrap zarin-settings-wrap" dir="rtl">
    <!-- Header Branding -->
    <header class="zarin-header">
        <div class="zarin-header-main">
            <div class="zarin-brand-badge">
                <div class="zarin-logo-icon" style="background:transparent;padding:0;display:flex;align-items:center;justify-content:center;">
                    <img src="<?php echo esc_url(plugins_url('img/zarinshopbot-icon.svg', dirname(__DIR__) . '/zarinshopbot.php')); ?>" width="34" height="34" alt="ZarinShopBot" style="border-radius:8px;box-shadow:0 3px 10px rgba(253, 208, 91, 0.35);display:block;">
                </div>
                <div class="zarin-brand-titles">
                    <div class="zarin-title-row">
                        <h1 class="zarin-plugin-title"><?php esc_html_e('ربات زرین شاپ | ZarinShopBot', 'zarinshopbot'); ?></h1>
                        <span class="zarin-version-badge"><?php // translators: %s: Plugin version number
printf(esc_html__('Version %s', 'zarinshopbot'), defined('ZARINSHOPBOT_VERSION') ? ZARINSHOPBOT_VERSION : '1.8.43'); ?></span>
                        <a href="https://zarincode.com" target="_blank" class="zarin-domain-badge"><?php esc_html_e('Zarincode.com', 'zarinshopbot'); ?></a>
                    </div>
                    <p class="zarin-subtitle"><?php echo esc_html($is_channel_tab ? sprintf(__('تنظیمات مستقل کانال %s و اتصال آن به WooCommerce', 'zarinshopbot'), $channel_label) : __('مدیریت مستقل Telegram، Bale و Rubika به‌همراه تنظیمات مشترک فروشگاه WooCommerce', 'zarinshopbot')); ?></p>
                </div>
            </div>

            <div class="zarin-header-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_zarinshopbot')); ?>" class="zarin-btn-ghost">
                    <span class="dashicons dashicons-dashboard"></span>
                    <?php esc_html_e('Dashboard', 'zarinshopbot'); ?>
                </a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_guide')); ?>" class="zarin-btn-ghost zarin-btn-accent">
                    <span class="dashicons dashicons-book"></span>
                    <?php esc_html_e('راهنمای افزونه', 'zarinshopbot'); ?>
                </a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_send')); ?>" class="zarin-btn-ghost zarin-btn-accent">
                    <span class="dashicons dashicons-megaphone"></span>
                    <?php esc_html_e('Broadcast Message', 'zarinshopbot'); ?>
                </a>
                <a href="https://zarincode.com" target="_blank" class="zarin-btn-ghost">
                    <span class="dashicons dashicons-external"></span>
                    <?php esc_html_e('Support Website', 'zarinshopbot'); ?>
                </a>
            </div>
        </div>

        <!-- Quick Status Bar -->
        <div class="zarin-status-bar">
            <div class="zarin-status-item">
                <span class="zarin-status-label"><?php echo esc_html($is_channel_tab ? sprintf(__('Bot Token Status (%s):', 'zarinshopbot'), $channel_label) : __('Bot Token Status:', 'zarinshopbot')); ?></span>
                <?php if (!empty($bot_token)): ?>
                    <span class="zarin-pill zarin-pill-warning">
                        <span class="zarin-indicator"></span> <?php esc_html_e('توکن ذخیره شده؛ این نشانگر به‌تنهایی اتصال زنده را ثابت نمی‌کند', 'zarinshopbot'); ?>
                        <?php if (!empty($bot_username)): ?>(@<?php echo esc_html($bot_username); ?>)<?php endif; ?>
                    </span>
                <?php else: ?>
                    <span class="zarin-pill zarin-pill-danger">
                        <span class="zarin-indicator"></span> <?php esc_html_e('No Token Entered', 'zarinshopbot'); ?>
                    </span>
                <?php endif; ?>
            </div>

            <div class="zarin-status-item">
                <span class="zarin-status-label"><?php esc_html_e('Server SSL Status:', 'zarinshopbot'); ?></span>
                <?php if ($ssl_active): ?>
                    <span class="zarin-pill zarin-pill-success"><span class="zarin-indicator"></span> <?php esc_html_e('Active (Direct Webhook Ready)', 'zarinshopbot'); ?></span>
                <?php else: ?>
                    <span class="zarin-pill zarin-pill-warning"><span class="zarin-indicator"></span> <?php esc_html_e('Inactive (Direct webhook needs valid HTTPS)', 'zarinshopbot'); ?></span>
                <?php endif; ?>
            </div>

            <div class="zarin-status-item">
                <?php if ($is_channel_tab): ?>
                    <span class="zarin-status-label"><?php echo esc_html(sprintf(__('وضعیت کانال %s:', 'zarinshopbot'), $channel_label)); ?></span>
                    <?php if (!empty($channel_options[$active_tab . '_enabled'])): ?>
                        <span class="zarin-pill zarin-pill-success"><span class="zarin-indicator"></span> <?php esc_html_e('فعال', 'zarinshopbot'); ?></span>
                    <?php else: ?>
                        <span class="zarin-pill zarin-pill-neutral"><?php esc_html_e('غیرفعال', 'zarinshopbot'); ?></span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="zarin-status-label"><?php esc_html_e('Test Mode:', 'zarinshopbot'); ?></span>
                    <?php if ($is_test_mode): ?>
                        <span class="zarin-pill zarin-pill-warning"><span class="zarin-indicator"></span> <?php esc_html_e('Enabled (Full Logging)', 'zarinshopbot'); ?></span>
                    <?php else: ?>
                        <span class="zarin-pill zarin-pill-neutral"><?php esc_html_e('Disabled', 'zarinshopbot'); ?></span>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <div class="zarin-status-item zarin-status-item-right">
                <span class="zarin-status-label"><?php esc_html_e('Reference Website:', 'zarinshopbot'); ?></span>
                <a href="https://zarincode.com" target="_blank" class="zarin-status-link"><?php esc_html_e('Zarincode.com', 'zarinshopbot'); ?></a>
            </div>
        </div>
    </header>

    <!-- Three-platform control center: platform status and independent settings entry points. -->
    <section class="zarin-platform-hub" aria-labelledby="zarin-platform-hub-title">
        <div class="zarin-platform-hub-heading">
            <div>
                <span class="zarin-platform-kicker"><?php esc_html_e('مرکز تنظیمات چندکاناله', 'zarinshopbot'); ?></span>
                <h2 id="zarin-platform-hub-title"><?php esc_html_e('هر پیام‌رسان، تنظیمات و مقصد مستقل خودش را دارد', 'zarinshopbot'); ?></h2>
                <p><?php esc_html_e('از کارت هر پلتفرم وارد بخش اتصال، قابلیت‌ها، پرداخت‌ها، اعلان‌ها و انتشار همان کانال شوید؛ تنظیمات مشترک فروشگاه در گروه بعدی قرار دارند.', 'zarinshopbot'); ?></p>
            </div>
            <span class="zarin-scope-pill"><span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span><?php esc_html_e('Telegram · Bale · Rubika', 'zarinshopbot'); ?></span>
        </div>
        <div class="zarin-platform-grid">
            <?php foreach ($platform_cards as $card_key => $platform_card) :
                $platform_url = add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => $platform_card['tab']), admin_url('admin.php'));
                $platform_icon = zarincode_get_plugin_uri() . 'assets/icons/' . $platform_card['platform'] . '.svg';
            ?>
                <a class="zarin-platform-card <?php echo $active_tab === $platform_card['tab'] ? 'is-current' : ''; ?>" href="<?php echo esc_url($platform_url); ?>" aria-current="<?php echo $active_tab === $platform_card['tab'] ? 'page' : 'false'; ?>">
                    <div class="zarin-platform-card-top">
                        <img src="<?php echo esc_url($platform_icon); ?>" width="30" height="30" alt="" aria-hidden="true">
                        <span class="zarin-platform-status <?php echo $platform_card['enabled'] ? 'is-ready' : 'is-setup'; ?>"><i></i><?php echo esc_html($platform_card['enabled'] ? __('فعال و دارای توکن', 'zarinshopbot') : __('نیازمند راه‌اندازی', 'zarinshopbot')); ?></span>
                    </div>
                    <strong><?php echo esc_html($platform_card['label']); ?></strong>
                    <span class="zarin-platform-card-detail"><?php echo esc_html($platform_card['detail']); ?></span>
                    <span class="zarin-platform-card-action"><?php esc_html_e('مدیریت تنظیمات مستقل', 'zarinshopbot'); ?><span aria-hidden="true">←</span></span>
                </a>
            <?php endforeach; ?>
        </div>
        <div class="zarin-settings-scope-note">
            <span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
            <p><strong><?php esc_html_e('مرزبندی تنظیمات:', 'zarinshopbot'); ?></strong> <?php esc_html_e('توکن، مقصد انتشار، شناسه مدیر، پرداخت بومی، Mini App و اعلان‌های هر کانال مستقل‌اند. کاتالوگ، موجودی، مالیات، حمل‌ونقل و قواعد سبد WooCommerce عمداً مشترک هستند تا هر سه ربات یک فروشگاه و یک دفتر سفارش را نمایش دهند.', 'zarinshopbot'); ?></p>
        </div>
        <details class="zarin-capability-details">
            <summary><?php esc_html_e('مقایسهٔ قابلیت‌های واقعی و مرز پشتیبانی هر پلتفرم', 'zarinshopbot'); ?></summary>
            <div class="zarin-capability-table-wrap">
                <table class="zarin-capability-table">
                    <thead><tr><th scope="col"><?php esc_html_e('قابلیت', 'zarinshopbot'); ?></th><th scope="col">Telegram</th><th scope="col">Bale</th><th scope="col">Rubika</th></tr></thead>
                    <tbody>
                        <tr><th scope="row"><?php esc_html_e('فروشگاه و سفارش', 'zarinshopbot'); ?></th><td><?php esc_html_e('بات و Mini App؛ موتور سفارش مشترک WooCommerce', 'zarinshopbot'); ?></td><td><?php esc_html_e('بات و Mini App بله؛ موتور سفارش مشترک WooCommerce', 'zarinshopbot'); ?></td><td><?php esc_html_e('بات و checkout وب امن WooCommerce؛ Mini App در این افزونه ارائه نشده', 'zarinshopbot'); ?></td></tr>
                        <tr><th scope="row"><?php esc_html_e('پرداخت داخل پیام‌رسان', 'zarinshopbot'); ?></th><td><?php esc_html_e('Provider invoice؛ Stars برای کالاهای دیجیتال در مسیر پشتیبانی‌شده', 'zarinshopbot'); ?></td><td><?php esc_html_e('کیف‌پول بله و صورتحساب مستند؛ Mini App از createInvoiceLink/openInvoice', 'zarinshopbot'); ?></td><td><?php esc_html_e('در Bot API عمومی بررسی‌شده پشتیبانی native تأیید نشده؛ استفاده از درگاه‌های WooCommerce', 'zarinshopbot'); ?></td></tr>
                        <tr><th scope="row"><?php esc_html_e('انتشار محصول و اعلان سفارش', 'zarinshopbot'); ?></th><td><?php esc_html_e('مقصد و قالب عنوان مستقل؛ اعلان‌های Telegram', 'zarinshopbot'); ?></td><td><?php esc_html_e('مقصد، عنوان و سوئیچ‌های اعلان مستقل Bale', 'zarinshopbot'); ?></td><td><?php esc_html_e('مقصد، عنوان و سوئیچ‌های اعلان مستقل Rubika', 'zarinshopbot'); ?></td></tr>
                        <tr><th scope="row"><?php esc_html_e('عضویت اجباری', 'zarinshopbot'); ?></th><td><?php esc_html_e('استعلام عضو با API رسمی؛ بات باید مدیر مقصد باشد', 'zarinshopbot'); ?></td><td><?php esc_html_e('getChatMember رسمی؛ بات باید مدیر مقصد باشد', 'zarinshopbot'); ?></td><td><?php esc_html_e('گزینهٔ بررسی عضویت نمایش داده نمی‌شود؛ استعلام عضو در API عمومی بررسی‌شده مستند نیست', 'zarinshopbot'); ?></td></tr>
                        <tr><th scope="row"><?php esc_html_e('ثبت منوی فرمان', 'zarinshopbot'); ?></th><td><?php esc_html_e('با روش‌های رسمی Telegram؛ توضیح/تنظیم در بخش فرمان‌ها', 'zarinshopbot'); ?></td><td><?php esc_html_e('فرمان‌ها در موتور فروشگاه پشتیبانی می‌شوند؛ ثبت خودکار فهرست منو ادعا نمی‌شود', 'zarinshopbot'); ?></td><td><?php echo sprintf(esc_html__('متد رسمی %1$s هنگام ثبت وب‌هوک، با رعایت گزینهٔ منوی فرمان', 'zarinshopbot'), '<code>setCommands</code>'); ?></td></tr>
                    </tbody>
                </table>
            </div>
            <div class="zarin-official-doc-links">
                <strong><?php esc_html_e('مستندات رسمی مبنای این تفکیک:', 'zarinshopbot'); ?></strong>
                <a href="https://core.telegram.org/bots/api" target="_blank" rel="noopener noreferrer">Telegram Bot API</a>
                <a href="https://core.telegram.org/bots/webapps" target="_blank" rel="noopener noreferrer">Telegram Mini Apps</a>
                <a href="https://core.telegram.org/bots/payments" target="_blank" rel="noopener noreferrer">Telegram Payments</a>
                <a href="https://docs.bale.ai/" target="_blank" rel="noopener noreferrer">Bale Bot API</a>
                <a href="https://rubika.ir/botapi" target="_blank" rel="noopener noreferrer">Rubika Bot API</a>
                <a href="https://rubika.ir/botapi/methods" target="_blank" rel="noopener noreferrer"><?php esc_html_e('فهرست متدهای روبیکا', 'zarinshopbot'); ?></a>
                <a href="https://developer.wordpress.org/plugins/settings/settings-api/" target="_blank" rel="noopener noreferrer"><?php esc_html_e('WordPress Settings API', 'zarinshopbot'); ?></a>
                <a href="https://developer.woocommerce.com/docs/extensions/settings-and-config/extend-wc-settings-page/" target="_blank" rel="noopener noreferrer"><?php esc_html_e('WooCommerce Settings API', 'zarinshopbot'); ?></a>
                <a href="<?php echo esc_url(zarincode_get_plugin_uri() . 'docs/settings-panel-audit-fa.md'); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('مشاهدهٔ نقشه و ممیزی تنظیمات افزونه', 'zarinshopbot'); ?></a>
            </div>
            <p class="zarin-capability-disclaimer"><?php esc_html_e('وضعیت «توکن ذخیره شده» فقط وضعیت پیکربندی را نشان می‌دهد، نه موفقیت اتصال زنده. آزمون API فقط با دکمهٔ آزمایش همان کانال انجام می‌شود. قابلیت‌های نمایش‌داده‌نشده به‌عنوان پشتیبانی‌شده فرض نمی‌شوند.', 'zarinshopbot'); ?></p>
        </details>
    </section>

    <!-- Notices & Alerts -->
    <?php
    if ($is_test_mode) {
        echo '<div class="zarin-alert zarin-alert-warning">
            <span class="dashicons dashicons-warning"></span>
            <div><strong>' . esc_html__('Bot test mode is active:', 'zarinshopbot') . '</strong> ' . esc_html__('In this mode, error logging is enabled and performance may experience delays. Please disable it when testing is complete.', 'zarinshopbot') . '</div>
        </div>';
    }

    if (!$is_channel_tab) {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WordPress supplies this read-only settings status flag.
        if (isset($_GET['settings-updated']) && sanitize_key(wp_unslash($_GET['settings-updated'])) !== '') {
            echo '<div class="zarin-alert zarin-alert-success"><span class="dashicons dashicons-saved"></span><div>' . esc_html__('Setting updated.', 'zarinshopbot') . '</div></div>';
            $sync = (array) get_option('zarincode_webhook_sync_status', []);
            if ($sync) echo '<p>' . esc_html__('Webhook Result:', 'zarinshopbot') . ' ' . esc_html(!empty($sync['ok']) ? 'OK' : 'Failed') . ' — ' . esc_html($sync['checked_at'] ?? '') . '</p>';
        }
        settings_errors('zarincode_settings');
        echo '<p><a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=zarincode_register_webhook'), 'zarincode_register_webhook')) . '">' . esc_html__('Register webhook again', 'zarinshopbot') . '</a></p>';
    }
    ?>

    <!-- Keep Import outside the settings form; nested forms prevent Save from submitting. -->
    <form id="zarincode_import_settings_form" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin.php?page=zarincode_zarinshopbot_setting')); ?>"></form>

    <div class="zarin-layout">
            <!-- Sidebar Navigation Tabs -->
            <aside class="zarin-sidebar">
                <nav class="zarin-tabs-nav" role="navigation" aria-label="Settings sections">
                    <?php foreach ($tabs as $key => $tab):
                        if ($key === 'basic') : ?><div class="zarin-nav-group-title"><?php esc_html_e('تنظیمات مستقل پلتفرم‌ها', 'zarinshopbot'); ?></div><?php endif;
                        if ($key === 'menu') : ?><div class="zarin-nav-group-title is-shared"><?php esc_html_e('تنظیمات مشترک فروشگاه', 'zarinshopbot'); ?></div><?php endif;
                        $active = ($key === $active_tab);
                        $channel_link = in_array($key, array('bale', 'rubika'), true);
                        $tab_url = add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => $key), admin_url('admin.php'));
                    ?>
                        <?php if ($channel_link): ?>
                        <a href="<?php echo esc_url($tab_url); ?>" class="zarin-tab-btn <?php echo $active ? 'is-active' : ''; ?>" data-page-link="1" data-channel-tab="<?php echo esc_attr($key); ?>" aria-current="<?php echo $active ? 'page' : 'false'; ?>">
                        <?php else: ?>
                        <button type="button" class="zarin-tab-btn <?php echo $active ? 'is-active' : ''; ?>" data-tab="<?php echo esc_attr($key); ?>" role="tab" aria-selected="<?php echo $active ? 'true' : 'false'; ?>">
                        <?php endif; ?>
                            <?php if ($channel_link): ?>
                                <img class="zarin-platform-logo zarin-tab-icon" src="<?php echo esc_url(zarincode_get_plugin_uri() . 'assets/icons/' . $key . '.svg'); ?>" alt="" aria-hidden="true" />
                            <?php elseif ($key === 'basic'): ?>
                                <img class="zarin-platform-logo zarin-tab-icon" src="<?php echo esc_url(zarincode_get_plugin_uri() . 'assets/icons/telegram.svg'); ?>" alt="" aria-hidden="true" />
                            <?php else: ?>
                                <span class="dashicons <?php echo esc_attr($tab['icon']); ?> zarin-tab-icon"></span>
                            <?php endif; ?>
                            <span class="zarin-tab-info">
                                <span class="zarin-tab-title"><?php echo esc_html($tab['name']); ?></span>
                                <span class="zarin-tab-desc"><?php echo esc_html($tab['desc']); ?></span>
                            </span>
                        <?php if ($channel_link): ?></a><?php else: ?></button><?php endif; ?>
                    <?php endforeach; ?>
                </nav>

                <div class="zarin-sidebar-card">
                    <div class="zarin-sidebar-card-title">
                        <span class="dashicons dashicons-admin-site-alt3"></span>
                        <?php esc_html_e('Reference & Support', 'zarinshopbot'); ?>
                    </div>
                    <p class="zarin-sidebar-card-desc"><?php esc_html_e('Dedicated Telegram bot site and latest WooCommerce updates & plugins', 'zarinshopbot'); ?></p>
                    <a href="https://zarincode.com" target="_blank" class="zarin-link-btn"><?php esc_html_e('Visit Zarincode.com &rarr;', 'zarinshopbot'); ?></a>
                </div>
            </aside>

            <!-- Main Content Area -->
            <main class="zarin-content">
                <form method="post" action="options.php" id="zarin_settings_form" class="zarin-form">
                    <?php settings_fields('zarincode_settings_options'); ?>
                    <input type="hidden" id="zarincode_settings_referer" name="_wp_http_referer" value="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => $is_channel_tab ? 'basic' : $current), admin_url('admin.php'))); ?>">
                <!-- ========================================================================= -->
                <!-- TAB 1: BASIC SETTINGS -->
                <!-- ========================================================================= -->
                <section class="zarin-tab-pane <?php echo ($current === 'basic') ? 'is-active' : ''; ?>" id="tab-basic" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-admin-generic zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('تنظیمات اختصاصی Telegram', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('تمام تنظیمات اختصاصی Telegram شامل اتصال، Mini App، اعلان، پروکسی، پرداخت و قابلیت‌های پیام‌رسانی در همین تب جمع شده‌اند. تنظیمات مشترک فروشگاه و صفحات مستقل Bale/Rubika جدا هستند.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>

                        <div class="zarin-card-body">
                            <!-- Bot Token -->
                            <div class="zarin-field-group">
                                <div class="zarin-field-header">
                                    <label for="token" class="zarin-label"><?php esc_html_e('Bot Token', 'zarinshopbot'); ?><?php if ($bot_token === ''): ?> <span class="zarin-required">*</span><?php endif; ?></label>
                                    <span class="zarin-badge zarin-badge-secret"><?php esc_html_e('Keep confidential', 'zarinshopbot'); ?></span>
                                </div>
                                <div class="zarin-input-addon-wrap">
                                    <input id="token"
                                           type="password"
                                           name="zarincode_settings[token]"
                                           value=""
                                           placeholder="<?php echo esc_attr($bot_token !== '' ? '•••••••••••••••• (configured; leave blank to keep)' : '123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ...'); ?>"
                                           class="zarin-input zarin-ltr"
                                           autocomplete="off" />
                                    <button type="button" class="zarin-addon-btn zarin-toggle-token" title="<?php esc_attr_e('Show/Hide token', 'zarinshopbot'); ?>">
                                        <span class="dashicons dashicons-visibility"></span>
                                    </button>
                                </div>
                                <p class="zarin-help-text">
                                    <?php // translators: %s: Link to @BotFather
echo wp_kses_post(sprintf(__('Get the Telegram bot connection token from %s and enter it here.', 'zarinshopbot'), '<a href="https://t.me/BotFather" target="_blank" rel="noopener noreferrer" class="zarin-link">@BotFather</a>')); ?>
                                </p>
                                <label class="zarin-checkbox-row"><input type="hidden" name="zarincode_settings[telegram_enabled]" value="0" /><input type="checkbox" name="zarincode_settings[telegram_enabled]" value="1" <?php checked($telegram_enabled, true); ?> /> <span><?php esc_html_e('Enable Telegram bot', 'zarinshopbot'); ?></span></label>
                                <p class="zarin-help-text"><?php echo esc_html($bot_token !== '' ? __('Leave blank to retain the saved token.', 'zarinshopbot') : __('Enter the token from BotFather.', 'zarinshopbot')); ?></p>
                                <?php if ($bot_token !== ''): ?><label class="zarin-checkbox-row"><input type="checkbox" name="zarincode_settings[clear_telegram_token]" value="1" /> <span><?php esc_html_e('Clear the saved Telegram token', 'zarinshopbot'); ?></span></label><?php endif; ?>
                                <p class="zarin-help-text"><?php esc_html_e('Turn Telegram on or off without changing its token. This switch does not affect Bale or Rubika.', 'zarinshopbot'); ?></p>
                            </div>

                            <!-- Bot Username -->
                            <div class="zarin-field-group">
                                <label for="bot_username_input" class="zarin-label"><?php esc_html_e('Bot Username', 'zarinshopbot'); ?> <span class="zarin-required">*</span></label>
                                <div class="zarin-input-addon-wrap">
                                    <span class="zarin-addon-prefix">@</span>
                                    <input id="bot_username_input"
                                           type="text"
                                           name="zarincode_settings[username]"
                                           value="<?php echo isset($options['username']) ? esc_attr($options['username']) : ''; ?>"
                                           placeholder="zarinshopbot"
                                           class="zarin-input zarin-ltr" />
                                </div>
                                <p class="zarin-help-text"><?php // translators: %s: Example username code snippet
echo wp_kses_post(sprintf(__('Telegram bot username without @ sign (e.g. %s)', 'zarinshopbot'), '<code>zarinshopbot</code>')); ?></p>
                            </div>

                            <!-- Channel Username -->
                            <div class="zarin-field-group">
                                <label for="channelusername" class="zarin-label"><?php esc_html_e('Channel Username', 'zarinshopbot'); ?></label>
                                <div class="zarin-input-addon-wrap">
                                    <span class="zarin-addon-prefix">@</span>
                                    <input id="channelusername"
                                           type="text"
                                           name="zarincode_settings[channelusername]"
                                           value="<?php echo isset($options['channelusername']) ? esc_attr($options['channelusername']) : ''; ?>"
                                           placeholder="my_channel"
                                           class="zarin-input zarin-ltr" />
                                </div>
                                <p class="zarin-help-text">
                                    <?php esc_html_e('Your shop channel ID (optional). To send products or broadcasts automatically, the bot must be a channel Administrator.', 'zarinshopbot'); ?>
                                </p>
                            </div>

                            <div class="zarin-field-group">
                                <label for="telegram_post_title" class="zarin-label"><?php esc_html_e('عنوان انتشار محصول در کانال Telegram', 'zarinshopbot'); ?></label>
                                <div class="zsb-message-editor-row zsb-message-title-row"><div><input id="telegram_post_title" type="text" name="zarincode_settings[telegram_post_title]" value="<?php echo esc_attr($options['telegram_post_title'] ?? 'محصول جدید: %product%'); ?>" class="zarin-input" /></div><?php \ZarinShopBot\Message_Editor::renderVariables('telegram_post_title', 'product'); ?></div>
                                <p class="zarin-help-text"><?php esc_html_e('این عنوان فقط در انتشار مستقیم محصول به مقصد Telegram کاربرد دارد؛ مقصد از فیلد Channel Username خوانده می‌شود.', 'zarinshopbot'); ?></p>
                            </div>

                            <!-- Connection Mode -->
                            <div class="zarin-field-group">
                                <label class="zarin-label"><?php esc_html_e('Connection Mode', 'zarinshopbot'); ?></label>
                                <div class="zarin-radio-cards">
                                    <!-- Option 0: Direct Webhook -->
                                    <label class="zarin-radio-card <?php echo (!$ssl_active ? 'is-disabled' : ''); ?> <?php echo (isset($options['mode']) && $options['mode'] == 0 && $ssl_active) ? 'is-selected' : ''; ?>">
                                        <input type="radio"
                                               name="zarincode_settings[mode]"
                                               value="0"
                                               <?php if (!$ssl_active) echo 'disabled'; ?>
                                               <?php echo (isset($options['mode']) && $options['mode'] == 0 && $ssl_active) ? 'checked="checked"' : ''; ?>>
                                        <div class="zarin-radio-card-content">
                                            <div class="zarin-radio-card-title">
                                                <span class="dashicons dashicons-rest-api"></span>
                                                <?php esc_html_e('وب‌هوک مستقیم تلگرام (Direct Webhook)', 'zarinshopbot'); ?>
                                                <?php if ($ssl_active): ?>
                                                    <span class="zarin-chip zarin-chip-success"><?php esc_html_e('پیشنهادی', 'zarinshopbot'); ?></span>
                                                <?php else: ?>
                                                    <span class="zarin-chip zarin-chip-danger"><?php esc_html_e('نیازمند SSL', 'zarinshopbot'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <p class="zarin-radio-card-desc"><?php esc_html_e('اتصال مستقیم تلگرام به وب‌سایت شما با بیشترین سرعت. نیازمند گواهی معتبر SSL (HTTPS) بر روی دامنه سایت است.', 'zarinshopbot'); ?></p>
                                        </div>
                                    </label>

                                    <div class="zarin-notice zarin-notice-warning">
                                        <strong><?php esc_html_e('وب‌هوک مستقیم تنها روش پشتیبانی‌شده است.', 'zarinshopbot'); ?></strong>
                                        <?php esc_html_e('برای اتصال ربات تلگرام باید HTTPS معتبر فعال باشد؛ از سرویس واسط خارجی استفاده نمی‌شود.', 'zarinshopbot'); ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Target Broadcast -->
                            <div class="zarin-field-group">
                                <label for="broadcast_target" class="zarin-label"><?php esc_html_e('Default content broadcast', 'zarinshopbot'); ?></label>
                                <select id="broadcast_target" name="zarincode_settings[target]" class="zarin-select">
                                    <option value="0" <?php echo (isset($options['target']) && $options['target'] == 0) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Users, Groups, Channel', 'zarinshopbot'); ?> <?php esc_html_e('(همه)', 'zarinshopbot'); ?></option>
                                    <option value="1" <?php echo (isset($options['target']) && $options['target'] == 1) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Users', 'zarinshopbot'); ?> <?php esc_html_e('(کاربران)', 'zarinshopbot'); ?></option>
                                    <option value="2" <?php echo (isset($options['target']) && $options['target'] == 2) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Groups', 'zarinshopbot'); ?> <?php esc_html_e('(گروه‌ها)', 'zarinshopbot'); ?></option>
                                    <option value="3" <?php echo (isset($options['target']) && $options['target'] == 3) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Users, Groups', 'zarinshopbot'); ?> <?php esc_html_e('(کاربران و گروه‌ها)', 'zarinshopbot'); ?></option>
                                    <option value="4" <?php echo (!isset($options['target']) || $options['target'] == 4) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Channel', 'zarinshopbot'); ?> <?php esc_html_e('(فقط کانال)', 'zarinshopbot'); ?></option>
                                </select>
                                <p class="zarin-help-text"><?php esc_html_e('Default destination when broadcasting posts and products.', 'zarinshopbot'); ?></p>
                            </div>

                            <!-- Enable in groups -->
                            <div class="zarin-field-group zarin-field-inline">
                                <div>
                                    <label class="zarin-label"><?php esc_html_e('Bot enabled in groups', 'zarinshopbot'); ?></label>
                                    <p class="zarin-help-text"><?php esc_html_e('Allow users to add the bot to Telegram groups?', 'zarinshopbot'); ?></p>
                                </div>
                                <div class="zarin-toggle-wrapper">
                                    <label class="zarin-switch">
                                        <input type="radio" name="zarincode_settings[enabledingroups]" value="1" <?php echo (isset($options['enabledingroups']) && $options['enabledingroups'] == 1) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-toggle-opt"><?php esc_html_e('Yes', 'zarinshopbot'); ?></span>
                                    </label>
                                    <label class="zarin-switch">
                                        <input type="radio" name="zarincode_settings[enabledingroups]" value="0" <?php echo (!isset($options['enabledingroups']) || $options['enabledingroups'] == 0) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-toggle-opt"><?php esc_html_e('No', 'zarinshopbot'); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Test Mode -->
                            <div class="zarin-field-group zarin-field-inline">
                                <div>
                                    <label class="zarin-label"><?php esc_html_e('Bot test mode', 'zarinshopbot'); ?></label>
                                    <p class="zarin-help-text"><?php esc_html_e('For testing send and receive message. After testing please off it.', 'zarinshopbot'); ?></p>
                                </div>
                                <div class="zarin-toggle-wrapper">
                                    <label class="zarin-switch">
                                        <input type="radio" name="zarincode_settings[testmod]" value="yes" <?php echo ($is_test_mode) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-toggle-opt zarin-toggle-opt-warn"><?php esc_html_e('On', 'zarinshopbot'); ?></span>
                                    </label>
                                    <label class="zarin-switch">
                                        <input type="radio" name="zarincode_settings[testmod]" value="no" <?php echo (!$is_test_mode) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-toggle-opt"><?php esc_html_e('Off', 'zarinshopbot'); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Webhook Secret Token -->
                            <div class="zarin-field-group">
                                <div class="zarin-field-header">
                                    <label for="webhook_secret_token" class="zarin-label"><?php esc_html_e('Webhook Secret Token', 'zarinshopbot'); ?></label>
                                    <span class="zarin-badge zarin-badge-secret"><?php esc_html_e('High Security', 'zarinshopbot'); ?></span>
                                </div>
                                <div class="zarin-input-addon-wrap">
                                    <input id="webhook_secret_token"
                                           type="text"
                                           name="zarincode_settings[webhook_secret_token]"
                                           value="<?php echo isset($options['webhook_secret_token']) ? esc_attr($options['webhook_secret_token']) : ''; ?>"
                                           placeholder="a-z A-Z 0-9 _-"
                                           class="zarin-input zarin-ltr" />
                                    <button type="button" class="zarin-btn-ghost zarin-btn-sm" id="btn_generate_secret">
                                        <?php esc_html_e('Generate Secret', 'zarinshopbot'); ?>
                                    </button>
                                </div>
                                <p class="zarin-help-text">
                                    <?php esc_html_e('Secret token sent by Telegram in X-Telegram-Bot-Api-Secret-Token header. Protects webhook from spoofing.', 'zarinshopbot'); ?>
                                </p>
                            </div>

                            <!-- Rate Limiting -->
                            <div class="zarin-field-group zarin-field-inline">
                                <div>
                                    <label class="zarin-label"><?php esc_html_e('Flood & Rate Limiting Protection', 'zarinshopbot'); ?></label>
                                    <p class="zarin-help-text"><?php esc_html_e('Prevent spam, bot attacks and server overload by throttling user requests.', 'zarinshopbot'); ?></p>
                                </div>
                                <div class="zarin-toggle-wrapper">
                                    <label class="zarin-switch">
                                        <input type="radio" name="zarincode_settings[security_rate_limit_enable]" value="1" <?php checked(isset($options['security_rate_limit_enable']) ? $options['security_rate_limit_enable'] : 1, 1); ?>>
                                        <span class="zarin-toggle-opt zarin-toggle-opt-accent"><?php esc_html_e('Enabled', 'zarinshopbot'); ?></span>
                                    </label>
                                    <label class="zarin-switch">
                                        <input type="radio" name="zarincode_settings[security_rate_limit_enable]" value="0" <?php checked(isset($options['security_rate_limit_enable']) ? $options['security_rate_limit_enable'] : 1, 0); ?>>
                                        <span class="zarin-toggle-opt"><?php esc_html_e('Disabled', 'zarinshopbot'); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Connection Testing Tools -->
                            <div class="zarin-field-group" style="background: var(--surface-subtle); padding: 16px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
                                <label class="zarin-label" style="margin-bottom: 8px;"><?php esc_html_e('Connection Diagnostics & Health Check', 'zarinshopbot'); ?></label>
                                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                                    <button type="button" class="zarin-btn-ghost" id="btn_test_telegram_connection">
                                        <span class="dashicons dashicons-yes-alt"></span>
                                        <?php esc_html_e('Test Bot Connection (getMe)', 'zarinshopbot'); ?>
                                    </button>
                                    <button type="button" class="zarin-btn-ghost" id="btn_test_telegram_webhook">
                                        <span class="dashicons dashicons-cloud"></span>
                                        <?php esc_html_e('Test Webhook Status (getWebhookInfo)', 'zarinshopbot'); ?>
                                    </button>
                                    <button type="button" class="zarin-btn-ghost" id="btn_run_system_tests">
                                        <span class="dashicons dashicons-shield"></span>
                                        <?php esc_html_e('Run System Unit Tests', 'zarinshopbot'); ?>
                                    </button>
                                </div>
                                <div id="zarin_diag_result" style="display: none; margin-top: 12px; padding: 12px; border-radius: var(--radius-sm); font-size: 13px;"></div>
                            </div>


                        </div>
                    </div>

                    <section class="zarin-platform-settings-group" aria-labelledby="telegram-miniapp-group">
                        <h3 id="telegram-miniapp-group">Mini App تلگرام</h3>
                                            <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-smartphone zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Telegram Mini App (Web App)', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Interactive storefront inside Telegram with modern product grid, search, live cart, and checkout.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <input type="hidden" name="zarincode_settings[feature_webapp_enable]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[feature_webapp_enable]" value="1" <?php checked(isset($options['feature_webapp_enable']) ? $options['feature_webapp_enable'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('Enable Telegram Mini App', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Allow customers to open the interactive web app inside Telegram.', 'zarinshopbot'); ?></small></span>
                            </label>

                            <div class="zarin-field-group">
                                <label class="zarin-label"><?php esc_html_e('Mini App Direct URL', 'zarinshopbot'); ?></label>
                                <div class="zarin-input-addon-wrap">
                                    <input type="text" readonly value="<?php echo esc_url(\ZarinShopBot\Core\WooBot::getWebAppUrl()); ?>" class="zarin-input zarin-ltr" id="zarin_webapp_url_input" />
                                    <button type="button" class="zarin-btn-ghost zarin-btn-sm" onclick="navigator.clipboard.writeText(document.getElementById('zarin_webapp_url_input').value); alert('Copied!');">
                                        <?php esc_html_e('Copy URL', 'zarinshopbot'); ?>
                                    </button>
                                </div>
                                <p class="zarin-help-text">
                                    <?php // translators: %s: Command code snippet
echo wp_kses_post(sprintf(__('In @BotFather, use %s, select the same bot shown by Test Bot Connection (getMe), and paste this HTTPS website URL as the app URL. BotFather then creates a separate t.me/bot/short-name launch link. When the Mini App switch is on, the plugin also sets the chat menu button to this app on the next bot update.', 'zarinshopbot'), '<code>/newapp</code>')); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    </section>

                    <section class="zarin-platform-settings-group" aria-labelledby="telegram-notifications-group">
                        <h3 id="telegram-notifications-group">اعلان‌ها و هشدارهای Telegram</h3>
                                            <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-bell zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Automated Notifications & Alerts', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Configure customer and admin Telegram alerts for orders, stock, price drops, and abandoned carts.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <input type="hidden" name="zarincode_settings[notify_customer_new_order]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[notify_customer_new_order]" value="1" <?php checked(isset($options['notify_customer_new_order']) ? $options['notify_customer_new_order'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('Send Order Confirmation to Customer', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Instantly notify the customer via Telegram with order number and tracking button.', 'zarinshopbot'); ?></small></span>
                            </label>

                            <input type="hidden" name="zarincode_settings[notify_status_change]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[notify_status_change]" value="1" <?php checked(isset($options['notify_status_change']) ? $options['notify_status_change'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('Notify Customer on Order Status Changes', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Send updates when order status changes to Processing, Completed, Cancelled, etc.', 'zarinshopbot'); ?></small></span>
                            </label>

                            <input type="hidden" name="zarincode_settings[notify_admin_new_order]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[notify_admin_new_order]" value="1" <?php checked(isset($options['notify_admin_new_order']) ? $options['notify_admin_new_order'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('Send New Order Alert to Admin', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Send instant notification to store administrator Telegram chat upon every new order.', 'zarinshopbot'); ?></small></span>
                            </label>

                            <div class="zarin-field-group" id="telegram-admin-chat-id">
                                <label for="admin_notification_chat_id" class="zarin-label"><?php esc_html_e('شناسهٔ گفت‌وگوی خصوصی مدیر در Telegram', 'zarinshopbot'); ?></label>
                                <input id="admin_notification_chat_id"
                                       type="text"
                                       name="zarincode_settings[admin_notification_chat_id]"
                                       value="<?php echo isset($options['admin_notification_chat_id']) ? esc_attr($options['admin_notification_chat_id']) : ''; ?>"
                                       placeholder="123456789"
                                       class="zarin-input zarin-ltr" />
                                <p class="zarin-help-text"><?php echo sprintf(esc_html__('این مقدار شناسهٔ chat.id پیام خصوصی خود مدیر است، نه توکن ربات. مدیر ابتدا در گفت‌وگوی خصوصی ربات Telegram گزینهٔ Start یا %1$s را بزند؛ سپس در پنل اصلی افزونه ← مخاطبان و گروه‌ها ← کاربران، ردیف Telegram خود را با نام کاربری پیدا کند و مقدار ستون Chat ID را در این فیلد وارد و ذخیره کند. این مقصد هم اعلان سفارش و هم رسید کارت‌به‌کارت و دکمه‌های تأیید/رد را دریافت می‌کند.', 'zarinshopbot'), '<code>/start</code>'); ?></p>
                            </div>

                            <input type="hidden" name="zarincode_settings[feature_abandoned_cart]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[feature_abandoned_cart]" value="1" <?php checked(isset($options['feature_abandoned_cart']) ? $options['feature_abandoned_cart'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('Abandoned Cart Reminder (Scheduled Task)', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Schedule a friendly reminder if a customer leaves items in their cart without completing payment; Action Scheduler or WordPress Cron must run on the site.', 'zarinshopbot'); ?></small></span>
                            </label>

                            <div class="zarin-field-group">
                                <label for="abandoned_cart_delay_hours" class="zarin-label"><?php esc_html_e('Abandoned Cart Delay (Hours)', 'zarinshopbot'); ?></label>
                                <input id="abandoned_cart_delay_hours"
                                       type="number"
                                       name="zarincode_settings[abandoned_cart_delay_hours]"
                                       value="<?php echo isset($options['abandoned_cart_delay_hours']) ? esc_attr($options['abandoned_cart_delay_hours']) : 3; ?>"
                                       min="1"
                                       max="72"
                                       class="zarin-input zarin-ltr"
                                       style="width: 80px;" />
                            </div>
                        </div>
                    </div>
                    </section>

                    <section class="zarin-platform-settings-group" aria-labelledby="telegram-proxy-group">
                        <h3 id="telegram-proxy-group">اتصال شبکه و پروکسی Telegram</h3>
                                            <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-shield zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Proxy settings', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('تنظیمات پروکسی در صورتی که سرور هاست شما به تلگرام دسترسی ندارد', 'zarinshopbot'); ?></p>
                            </div>
                        </div>

                        <div class="zarin-card-body">
                            <!-- Proxy Status -->
                            <?php $proxy_active = isset($options['proxy_status']) && $options['proxy_status'] == 1; ?>
                            <div class="zarin-field-group zarin-field-inline">
                                <div>
                                    <label class="zarin-label"><?php esc_html_e('Proxy status', 'zarinshopbot'); ?></label>
                                    <p class="zarin-help-text"><?php esc_html_e('Enable proxy if your hosting server is restricted from accessing Telegram.', 'zarinshopbot'); ?></p>
                                </div>
                                <div class="zarin-toggle-wrapper">
                                    <label class="zarin-switch">
                                        <input type="radio" name="zarincode_settings[proxy_status]" value="1" id="proxy_status_enable" <?php echo $proxy_active ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-toggle-opt"><?php esc_html_e('Enable', 'zarinshopbot'); ?></span>
                                    </label>
                                    <label class="zarin-switch">
                                        <input type="radio" name="zarincode_settings[proxy_status]" value="0" id="proxy_status_disable" <?php echo !$proxy_active ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-toggle-opt"><?php esc_html_e('Disable', 'zarinshopbot'); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Proxy Configuration Container -->
                            <div id="zarin_proxy_fields" class="zarin-proxy-container <?php echo !$proxy_active ? 'is-collapsed' : ''; ?>">

                                <!-- Proxy Type -->
                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Proxy type', 'zarinshopbot'); ?></label>
                                    <div class="zarin-segmented-group">
                                        <?php
                                        $p_type = isset($options['proxy_type']) ? $options['proxy_type'] : 'http';
                                        $p_types = array('http' => 'HTTP', 'https' => 'HTTPS', 'socks4' => 'SOCKS 4', 'socks5' => 'SOCKS 5');
                                        foreach ($p_types as $pt_k => $pt_lbl):
                                        ?>
                                            <label class="zarin-segmented-item">
                                                <input type="radio" name="zarincode_settings[proxy_type]" value="<?php echo esc_attr($pt_k); ?>" <?php echo ($p_type === $pt_k) ? 'checked="checked"' : ''; ?>>
                                                <span class="zarin-segmented-label"><?php echo esc_html($pt_lbl); ?></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <div class="zarin-grid-2">
                                    <!-- Proxy Address -->
                                    <div class="zarin-field-group">
                                        <label for="proxy_address" class="zarin-label"><?php esc_html_e('Proxy address', 'zarinshopbot'); ?></label>
                                        <input id="proxy_address"
                                               type="text"
                                               name="zarincode_settings[proxy_address]"
                                               value="<?php echo isset($options['proxy_address']) ? esc_attr($options['proxy_address']) : ''; ?>"
                                               placeholder="<?php esc_attr_e('127.0.0.1 or proxy.example.com', 'zarinshopbot'); ?>"
                                               class="zarin-input zarin-ltr" />
                                    </div>

                                    <!-- Proxy Port -->
                                    <div class="zarin-field-group">
                                        <label for="proxy_port" class="zarin-label"><?php esc_html_e('Proxy port', 'zarinshopbot'); ?></label>
                                        <input id="proxy_port"
                                               type="text"
                                               name="zarincode_settings[proxy_port]"
                                               value="<?php echo isset($options['proxy_port']) ? esc_attr($options['proxy_port']) : ''; ?>"
                                               placeholder="<?php esc_attr_e('1080 or 8080', 'zarinshopbot'); ?>"
                                               class="zarin-input zarin-ltr" />
                                    </div>
                                </div>

                                <div class="zarin-grid-2">
                                    <!-- Proxy Username -->
                                    <div class="zarin-field-group">
                                        <label for="proxy_username" class="zarin-label"><?php esc_html_e('Proxy username', 'zarinshopbot'); ?></label>
                                        <input id="proxy_username"
                                               type="text"
                                               name="zarincode_settings[proxy_username]"
                                               value="<?php echo isset($options['proxy_username']) ? esc_attr($options['proxy_username']) : ''; ?>"
                                               placeholder="<?php esc_attr_e('Leave blank to keep current password', 'zarinshopbot'); ?>"
                                               class="zarin-input zarin-ltr" />
                                    </div>

                                    <!-- Proxy Password -->
                                    <div class="zarin-field-group">
                                        <label for="proxy_password" class="zarin-label"><?php esc_html_e('Proxy password', 'zarinshopbot'); ?></label>
                                        <input id="proxy_password"
                                               type="password"
                                               name="zarincode_settings[proxy_password]"
                                               value=""
                                               placeholder="<?php esc_attr_e('Optional', 'zarinshopbot'); ?>"
                                               class="zarin-input zarin-ltr" />
                                    </div>
                                </div>

                                <div class="zarin-field-group" style="background: var(--surface-subtle); padding: 14px; border-radius: var(--radius-md);">
                                    <label class="zarin-label"><?php esc_html_e('Fallback proxy', 'zarinshopbot'); ?></label>
                                    <p class="zarin-help-text"><?php esc_html_e('If the primary proxy cannot connect, ZarinShopBot tries this proxy automatically.', 'zarinshopbot'); ?></p>
                                    <div class="zarin-grid-2">
                                        <label class="zarin-label"><input type="hidden" name="zarincode_settings[proxy_status_fallback]" value="0" /><input type="checkbox" name="zarincode_settings[proxy_status_fallback]" value="1" <?php checked($options['proxy_status_fallback'] ?? 0, 1); ?> /> <?php esc_html_e('Enable fallback', 'zarinshopbot'); ?></label>
                                        <select name="zarincode_settings[proxy_type_fallback]" class="zarin-select">
                                            <?php foreach ($p_types as $pt_k => $pt_lbl): ?><option value="<?php echo esc_attr($pt_k); ?>" <?php selected($options['proxy_type_fallback'] ?? 'http', $pt_k); ?>><?php echo esc_html($pt_lbl); ?></option><?php endforeach; ?>
                                        </select>
                                        <input type="text" name="zarincode_settings[proxy_address_fallback]" value="<?php echo esc_attr($options['proxy_address_fallback'] ?? ''); ?>" placeholder="fallback.example.com" class="zarin-input zarin-ltr" />
                                        <input type="number" min="1" max="65535" name="zarincode_settings[proxy_port_fallback]" value="<?php echo esc_attr($options['proxy_port_fallback'] ?? 8080); ?>" placeholder="8080" class="zarin-input zarin-ltr" />
                                        <input type="text" name="zarincode_settings[proxy_username_fallback]" value="<?php echo esc_attr($options['proxy_username_fallback'] ?? ''); ?>" placeholder="<?php esc_attr_e('Username (optional)', 'zarinshopbot'); ?>" class="zarin-input zarin-ltr" />
                                        <input type="password" name="zarincode_settings[proxy_password_fallback]" value="" placeholder="<?php esc_attr_e('Password (leave blank to keep)', 'zarinshopbot'); ?>" class="zarin-input zarin-ltr" />
                                    </div>
                                </div>

                                <?php $proxy_health = class_exists(\ZarinShopBot\Core\Http\ProxyManager::class) ? \ZarinShopBot\Core\Http\ProxyManager::health() : []; ?>
                                <div class="zarin-field-group" style="background: var(--surface-subtle); padding: 14px; border-radius: var(--radius-md);">
                                    <label class="zarin-label"><?php esc_html_e('Proxy health', 'zarinshopbot'); ?></label>
                                    <?php if (empty($proxy_health)): ?>
                                        <p class="zarin-help-text"><?php esc_html_e('No proxy test has been recorded yet.', 'zarinshopbot'); ?></p>
                                    <?php else: foreach ($proxy_health as $health_name => $health): ?>
                                        <p class="zarin-help-text"><strong><?php echo esc_html(ucfirst($health_name)); ?>:</strong> <?php echo !empty($health['ok']) ? esc_html__('Online', 'zarinshopbot') : esc_html__('Failed', 'zarinshopbot'); ?> — <?php echo esc_html($health['last_check'] ?? ''); ?><?php if (!empty($health['error'])): ?> — <?php echo esc_html($health['error']); ?><?php endif; ?></p>
                                    <?php endforeach; endif; ?>
                                    <button type="button" class="zarin-btn-ghost" id="btn_test_telegram_proxy"><span class="dashicons dashicons-shield"></span> <?php esc_html_e('Test Proxy & Failover', 'zarinshopbot'); ?></button>
                                </div>

                                <div class="zarin-field-group" style="background: var(--surface-subtle); padding: 14px; border-radius: var(--radius-md);">
                                    <label class="zarin-label"><?php esc_html_e('تنظیم مهلت و تلاش مجدد اتصال Telegram', 'zarinshopbot'); ?></label>
                                    <div class="zarin-grid-2">
                                        <label class="zarin-label"><?php esc_html_e('Request timeout (seconds)', 'zarinshopbot'); ?><input type="number" min="5" max="20" name="zarincode_settings[telegram_http_timeout]" value="<?php echo esc_attr($options['telegram_http_timeout'] ?? 6); ?>" class="zarin-input zarin-ltr" /></label>
                                        <label class="zarin-label"><?php esc_html_e('Retry count', 'zarinshopbot'); ?><select name="zarincode_settings[telegram_api_retries]" class="zarin-select"><option value="0" <?php selected($options['telegram_api_retries'] ?? 0, 0); ?>>0</option><option value="1" <?php selected($options['telegram_api_retries'] ?? 0, 1); ?>>1</option><option value="2" <?php selected($options['telegram_api_retries'] ?? 0, 2); ?>>2</option></select></label>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    </section>

                    <section class="zarin-platform-settings-group" aria-labelledby="telegram-features-group">
                        <h3 id="telegram-features-group">پرداخت و قابلیت‌های اختصاصی Telegram</h3>
                                            <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-admin-site-alt3 zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('قابلیت‌های اختصاصی Telegram', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('تنظیمات این صفحه فقط روی Telegram اثر می‌گذارند. پرداخت Bale در تب Bale و Rubika از درگاه‌های WooCommerce استفاده می‌کند؛ گزینهٔ پرداخت بومی Rubika وجود ندارد.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <p class="zarin-help-text"><?php esc_html_e('فعال بودن گزینه به‌تنهایی تضمین‌کنندهٔ پشتیبانی کشور، ارز، ارائه‌دهندهٔ پرداخت یا حساب ربات نیست؛ ابتدا در محیط آزمایشی همان پلتفرم بررسی کنید.', 'zarinshopbot'); ?></p>
                        </div>
                    </div>
                    <!-- Customer Feedback & Post-Purchase Rating -->
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-star-filled zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Post-Purchase Rating & Feedback', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Prompt customers for 1-5 star feedback when orders are completed', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <div class="zarin-form-group">
                                <label class="zarin-toggle-wrap">
                                    <input type="checkbox" name="zarincode_settings[enable_order_rating]" value="1" <?php checked(isset($options['enable_order_rating']) ? $options['enable_order_rating'] : '1', '1'); ?>>
                                    <span class="zarin-toggle-slider"></span>
                                    <span class="zarin-toggle-label"><?php esc_html_e('Enable Post-Purchase Rating Survey', 'zarinshopbot'); ?></span>
                                </label>
                                <p class="zarin-help-text"><?php esc_html_e('Sends the Telegram rating prompt when the order status changes to Completed; this is intentionally configured in the Telegram-only settings group.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Telegram native in-app provider payments -->
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-cart zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Telegram In-App Payments', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Collect supported fiat payments inside Telegram chat and Mini App using Telegram Payments; no WooCommerce payment-page redirect is used for this route.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <label class="zarin-toggle-wrap">
                                <input type="hidden" name="zarincode_settings[telegram_invoice_enable]" value="0" />
                                <input type="checkbox" name="zarincode_settings[telegram_invoice_enable]" value="1" <?php checked(isset($options['telegram_invoice_enable']) ? $options['telegram_invoice_enable'] : 0, 1); ?> />
                                <span class="zarin-toggle-slider"></span>
                                <span class="zarin-toggle-label"><?php esc_html_e('Enable native Telegram invoice payments', 'zarinshopbot'); ?></span>
                            </label>
                            <div class="zarin-form-group">
                                <label class="zarin-form-label" for="telegram_provider_token"><?php esc_html_e('Telegram Payments Provider Token', 'zarinshopbot'); ?></label>
                                <input id="telegram_provider_token" type="password" autocomplete="new-password" name="zarincode_settings[telegram_provider_token]" value="" class="zarin-input zarin-ltr" placeholder="<?php echo esc_attr(!empty($options['telegram_provider_token_enc']) ? '•••••••••••••••• (configured; leave blank to keep)' : ''); ?>" />
                                <?php if (!empty($options['telegram_provider_token_enc'])) : ?><label><input type="checkbox" name="zarincode_settings[clear_telegram_provider_token]" value="1" /> <?php esc_html_e('Clear saved provider token', 'zarinshopbot'); ?></label><?php endif; ?>
                                <p class="zarin-help-text"><?php esc_html_e('Get this token from BotFather → Payments. The store currency and WooCommerce-calculated order total are used; Telegram/provider support for that currency is required. Test with the provider test token before enabling live payments.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Telegram Stars Payments -->
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-star-filled zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Telegram Stars Payments', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Use Telegram Stars for fully digital products sold inside Telegram.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <label class="zarin-toggle-wrap">
                                <input type="hidden" name="zarincode_settings[telegram_stars_enable]" value="0" />
                                <input type="checkbox" name="zarincode_settings[telegram_stars_enable]" value="1" <?php checked(isset($options['telegram_stars_enable']) ? $options['telegram_stars_enable'] : 0, 1); ?> />
                                <span class="zarin-toggle-slider"></span>
                                <span class="zarin-toggle-label"><?php esc_html_e('Enable Telegram Stars for digital products', 'zarinshopbot'); ?></span>
                            </label>
                            <div class="zarin-form-group">
                                <label class="zarin-form-label"><?php esc_html_e('Stars per store currency unit', 'zarinshopbot'); ?></label>
                                <input type="number" min="0" step="0.000001" name="zarincode_settings[telegram_stars_per_currency_unit]" value="<?php echo esc_attr(isset($options['telegram_stars_per_currency_unit']) ? $options['telegram_stars_per_currency_unit'] : 0); ?>" class="zarin-input zarin-ltr" />
                                <p class="zarin-help-text"><?php esc_html_e('Set the conversion rate carefully. Leave 0 to keep Stars disabled. Physical or mixed carts always use the normal WooCommerce payment flow.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Telegram Bot API 10.1+ Rich Messages -->
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-format-status zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Telegram Rich Messages (Bot API 10.1+)', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('ارتقای اختیاری پیام‌های متنی Telegram با قالب‌بندی Rich و جهت راست‌به‌چپ', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <label class="zarin-toggle-wrap">
                                <input type="hidden" name="zarincode_settings[telegram_rich_messages]" value="0" />
                                <input type="checkbox" name="zarincode_settings[telegram_rich_messages]" value="1" <?php checked(isset($options['telegram_rich_messages']) ? $options['telegram_rich_messages'] : 0, 1); ?> />
                                <span class="zarin-toggle-slider"></span>
                                <span class="zarin-toggle-label"><?php esc_html_e('Use Rich Messages for Telegram text replies', 'zarinshopbot'); ?></span>
                            </label>
                            <p class="zarin-help-text"><?php esc_html_e('Disabled by default. Applies only to Telegram text messages; Bale and Rubika continue using their own API adapters. If Telegram explicitly rejects Rich Messages with HTTP/API 400 or 404, the plugin falls back to sendMessage. It deliberately does not retry after timeouts, rate limits, or server errors to avoid duplicate deliveries. Test on a staging bot before enabling.', 'zarinshopbot'); ?></p>
                        </div>
                    </div>

                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-editor-code zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('رفتار ناوبری Telegram', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('این تنظیم فقط برای رابط چت Telegram است و بر Bale و Rubika اثر ندارد.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <input type="hidden" name="zarincode_settings[compact_navigation]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[compact_navigation]" value="1" <?php checked(isset($options['compact_navigation']) ? $options['compact_navigation'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('ناوبری کم‌حجم Telegram', 'zarinshopbot'); ?></strong><small><?php esc_html_e('هنگام پیمایش با دکمه‌ها، صفحهٔ قبلی ربات را جایگزین می‌کند تا گفتگو کوتاه‌تر بماند.', 'zarinshopbot'); ?></small></span>
                            </label>
                        </div>
                    </div>
                    </section>
                </section>

                <!-- ========================================================================= -->
                <!-- TAB: REQUIRED MEMBERSHIP                                                   -->
                <!-- ========================================================================= -->
                <section class="zarin-tab-pane <?php echo ($current === 'membership') ? 'is-active' : ''; ?>" id="tab-membership" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-groups zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Required Membership', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Require membership in configured Telegram and Bale channels or groups before using the store. Rubika membership checks are not available through its published Bot API.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <div class="zarin-membership-intro">
                                <span class="dashicons dashicons-lock"></span>
                                <div>
                                    <strong><?php esc_html_e('A professional access gate for your community', 'zarinshopbot'); ?></strong>
                                    <p><?php esc_html_e('Telegram and Bale membership are checked through each platform’s getChatMember API. The bot must be an administrator in the required channel/group. Configure separate IDs and join links for Telegram and Bale. Rubika membership gating is disabled because its published Bot API v3 does not document getChatMember.', 'zarinshopbot'); ?></p>
                                </div>
                            </div>

                            <input type="hidden" name="zarincode_settings[membership_enabled]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[membership_enabled]" value="1" <?php checked($options['membership_enabled'] ?? 0, 1); ?> />
                                <span><strong><?php esc_html_e('Enable required membership', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Users who have not joined all enabled channels/groups will see the join screen instead of the store.', 'zarinshopbot'); ?></small></span>
                            </label>

                            <input type="hidden" name="zarincode_settings[membership_apply_to_admins]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[membership_apply_to_admins]" value="1" <?php checked($options['membership_apply_to_admins'] ?? 1, 1); ?> />
                                <span><strong><?php esc_html_e('Apply to administrators too', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Administrators of the required Telegram/Bale destinations must also pass the check. This option does not identify WordPress administrators.', 'zarinshopbot'); ?></small></span>
                            </label>

                            <div class="zarin-membership-list" id="zarincode_membership_list">
                                <?php
                                $membership_rows = is_array($options['membership_requirements'] ?? null) ? $options['membership_requirements'] : [];
                                if (!$membership_rows) $membership_rows = [['enabled' => '0', 'type' => 'channel', 'title' => '', 'chat_id' => '', 'url' => '']];
                                foreach ($membership_rows as $index => $requirement):
                                    $index = (int) $index;
                                ?>
                                    <div class="zarin-membership-row" data-membership-row>
                                        <div class="zarin-membership-row-head">
                                            <span class="zarin-membership-number"><?php echo esc_html($index + 1); ?></span>
                                            <strong><?php esc_html_e('Required destination', 'zarinshopbot'); ?></strong>
                                            <button type="button" class="button-link-delete zarin-remove-membership" <?php echo count($membership_rows) <= 1 ? 'style="display:none"' : ''; ?>><?php esc_html_e('Remove', 'zarinshopbot'); ?></button>
                                        </div>
                                        <div class="zarin-membership-fields">
                                            <label class="zarin-label"><?php esc_html_e('Title', 'zarinshopbot'); ?><input type="text" name="zarincode_settings[membership_requirements][<?php echo esc_attr($index); ?>][title]" value="<?php echo esc_attr($requirement['title'] ?? ''); ?>" placeholder="<?php esc_attr_e('Main channel', 'zarinshopbot'); ?>" class="zarin-input" /></label>
                                            <label class="zarin-label"><?php esc_html_e('Type', 'zarinshopbot'); ?><select name="zarincode_settings[membership_requirements][<?php echo esc_attr($index); ?>][type]" class="zarin-select"><option value="channel" <?php selected($requirement['type'] ?? 'channel', 'channel'); ?>><?php esc_html_e('Channel', 'zarinshopbot'); ?></option><option value="group" <?php selected($requirement['type'] ?? '', 'group'); ?>><?php esc_html_e('Group', 'zarinshopbot'); ?></option></select></label>
                                            <label class="zarin-label"><?php esc_html_e('Telegram username or chat ID', 'zarinshopbot'); ?><input type="text" name="zarincode_settings[membership_requirements][<?php echo esc_attr($index); ?>][chat_id]" value="<?php echo esc_attr($requirement['chat_id'] ?? ''); ?>" placeholder="@my_channel or -1001234567890" class="zarin-input zarin-ltr" /></label>
                                            <label class="zarin-label zarin-membership-url"><?php esc_html_e('Telegram join URL', 'zarinshopbot'); ?><input type="url" name="zarincode_settings[membership_requirements][<?php echo esc_attr($index); ?>][url]" value="<?php echo esc_attr($requirement['url'] ?? ''); ?>" placeholder="https://t.me/my_channel" class="zarin-input zarin-ltr" /></label>
                                            <label class="zarin-label"><?php esc_html_e('Bale username or chat ID', 'zarinshopbot'); ?><input type="text" name="zarincode_settings[membership_requirements][<?php echo esc_attr($index); ?>][bale_chat_id]" value="<?php echo esc_attr($requirement['bale_chat_id'] ?? ''); ?>" placeholder="@my_channel or Bale chat ID" class="zarin-input zarin-ltr" /></label>
                                            <label class="zarin-label zarin-membership-url"><?php esc_html_e('Bale join URL', 'zarinshopbot'); ?><input type="url" name="zarincode_settings[membership_requirements][<?php echo esc_attr($index); ?>][bale_url]" value="<?php echo esc_attr($requirement['bale_url'] ?? ''); ?>" placeholder="https://ble.ir/my_channel" class="zarin-input zarin-ltr" /></label>
                                        </div>
                                        <label class="zarin-membership-enabled"><input type="hidden" name="zarincode_settings[membership_requirements][<?php echo esc_attr($index); ?>][enabled]" value="0" /><input type="checkbox" name="zarincode_settings[membership_requirements][<?php echo esc_attr($index); ?>][enabled]" value="1" <?php checked($requirement['enabled'] ?? 0, 1); ?> /> <?php esc_html_e('Enable this destination', 'zarinshopbot'); ?></label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <button type="button" class="button" id="zarincode_add_membership"><span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e('Add channel or group', 'zarinshopbot'); ?></button>
                            <p class="zarin-help-text"><?php esc_html_e('For a public channel, enter its @username. For a private channel or group, enter the numeric Chat ID and provide an invite URL.', 'zarinshopbot'); ?></p>
                        </div>
                    </div>
                </section>

                <!-- ========================================================================= -->
                <!-- TAB 2: MESSAGES SETTINGS -->
                <!-- ========================================================================= -->
                <section class="zarin-tab-pane <?php echo ($current === 'messages') ? 'is-active' : ''; ?>" id="tab-messages" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-format-chat zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Messages settings', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Automated message texts, menus, descriptions and bot signature', 'zarinshopbot'); ?></p>
                            </div>
                        </div>

                        <div class="zarin-card-body">
                            <div class="zarin-message-editor-notice"><span class="dashicons dashicons-edit"></span><span><?php esc_html_e('برای همهٔ پیام‌های قابل‌ویرایش از ویرایشگر دیداری استفاده کنید. متغیرهای پویا کنار همان کادر قرار دارند. قالب‌بندی به امکانات متنی هر پیام‌رسان تبدیل می‌شود؛ رنگ متن در Telegram، Bale و Rubika قابل نمایش نیست.', 'zarinshopbot'); ?></span></div>

                            <!-- Language settings -->
                            <div class="zarin-field-group">
                                <label for="default_language" class="zarin-label"><?php esc_html_e('Default bot language', 'zarinshopbot'); ?></label>
                                <select id="default_language" name="zarincode_settings[default_language]" class="zarin-input">
                                    <?php
                                    $language_options = [
                                        'fa' => __('Persian (فارسی)', 'zarinshopbot'),
                                        'en' => __('English', 'zarinshopbot'),
                                        'de' => __('German (Deutsch)', 'zarinshopbot'),
                                        'es' => __('Spanish (Español)', 'zarinshopbot'),
                                        'fr' => __('French (Français)', 'zarinshopbot'),
                                        'it' => __('Italian (Italiano)', 'zarinshopbot'),
                                        'pt' => __('Portuguese (Português)', 'zarinshopbot'),
                                        'tr' => __('Turkish (Türkçe)', 'zarinshopbot'),
                                        'ar' => __('Arabic (العربية)', 'zarinshopbot'),
                                        'ru' => __('Russian (Русский)', 'zarinshopbot'),
                                        'zh' => __('Chinese (中文)', 'zarinshopbot'),
                                        'ja' => __('Japanese (日本語)', 'zarinshopbot'),
                                        'ur' => __('Urdu (اردو)', 'zarinshopbot'),
                                    ];
                                    $default_language = isset($options['default_language']) ? (string) $options['default_language'] : 'fa';
                                    foreach ($language_options as $language_code => $language_label) :
                                        ?>
                                        <option value="<?php echo esc_attr($language_code); ?>" <?php selected($default_language, $language_code); ?>><?php echo esc_html($language_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="zarin-help-text"><?php esc_html_e('Used for new Telegram users until they choose another language.', 'zarinshopbot'); ?></p>
                            </div>

                            <div class="zarin-field-group">
                                <label class="zarin-checkbox-label">
                                    <input type="hidden" name="zarincode_settings[wpml_language_sync]" value="0" />
                                    <input type="checkbox" name="zarincode_settings[wpml_language_sync]" value="1" <?php checked((string) ($options['wpml_language_sync'] ?? '1'), '1'); ?> />
                                    <?php esc_html_e('Synchronize the bot language with the active WPML language', 'zarinshopbot'); ?>
                                </label>
                                <p class="zarin-help-text"><?php esc_html_e('When enabled, WPML can translate dynamic bot messages. A user-selected Telegram language still has priority.', 'zarinshopbot'); ?></p>
                            </div>

                            <!-- Start Message -->
                            <div class="zarin-field-group">
                                <label for="zsb_msg_start" class="zarin-label"><?php esc_html_e('Start Message', 'zarinshopbot'); ?> <code><?php echo esc_html('/start'); ?></code></label>
                                <?php \ZarinShopBot\Message_Editor::render('zsb_msg_start', 'zarincode_settings[wmuser]', (string) ($options['wmuser'] ?? ''), 5); ?>
                                <p class="zarin-help-text"><?php esc_html_e('Message displayed to the user after clicking Start.', 'zarinshopbot'); ?></p>
                            </div>

                            <!-- Bye Message -->
                            <div class="zarin-field-group">
                                <label for="zsb_msg_bye" class="zarin-label"><?php esc_html_e('Bye Message', 'zarinshopbot'); ?> <code><?php echo esc_html('/stop'); ?></code></label>
                                <?php \ZarinShopBot\Message_Editor::render('zsb_msg_bye', 'zarincode_settings[bmuser]', (string) ($options['bmuser'] ?? ''), 4); ?>
                                <p class="zarin-help-text"><?php esc_html_e('Goodbye message when a user leaves or unsubscribes.', 'zarinshopbot'); ?></p>
                            </div>

                            <!-- Home Message -->
                            <div class="zarin-field-group">
                                <label for="zsb_msg_home" class="zarin-label"><?php esc_html_e('Home message', 'zarinshopbot'); ?> <code><?php echo esc_html('/home'); ?></code></label>
                                <?php \ZarinShopBot\Message_Editor::render('zsb_msg_home', 'zarincode_settings[messagehome]', (string) ($options['messagehome'] ?? ''), 4); ?>
                                <p class="zarin-help-text"><?php esc_html_e('Message when returning to the home screen and main menu.', 'zarinshopbot'); ?></p>
                            </div>

                            <!-- Contact Us -->
                            <div class="zarin-field-group">
                                <label for="zsb_msg_contact" class="zarin-label"><?php esc_html_e('Contact us', 'zarinshopbot'); ?> <?php esc_html_e('(متن ارتباط با ما)', 'zarinshopbot'); ?></label>
                                <?php \ZarinShopBot\Message_Editor::render('zsb_msg_contact', 'zarincode_settings[contactuspage]', (string) ($options['contactuspage'] ?? ''), 4); ?>

                                <div class="zarin-subfield" style="margin-top: 10px;">
                                    <label for="contactuspageurl" class="zarin-label-sub"><?php esc_html_e('Link to site', 'zarinshopbot'); ?> <?php esc_html_e('(لینک وب‌سایت در صفحه تماس)', 'zarinshopbot'); ?></label>
                                    <input id="contactuspageurl"
                                           type="url"
                                           name="zarincode_settings[contactuspageurl]"
                                           value="<?php echo isset($options['contactuspageurl']) ? esc_attr($options['contactuspageurl']) : 'https://zarincode.com'; ?>"
                                           class="zarin-input zarin-ltr"
                                           placeholder="https://zarincode.com" />
                                </div>
                            </div>

                            <div class="zarin-field-group">
                                <label for="zsb_msg_help" class="zarin-label"><?php esc_html_e('متن سفارشی راهنما', 'zarinshopbot'); ?> <code>/help</code></label>
                                <?php \ZarinShopBot\Message_Editor::render('zsb_msg_help', 'zarincode_settings[help_message]', (string) ($options['help_message'] ?? ''), 5); ?>
                                <p class="zarin-help-text"><?php esc_html_e('اگر خالی باشد، راهنمای پیش‌فرض فرمان‌ها نمایش داده می‌شود.', 'zarinshopbot'); ?></p>
                            </div>
                            <div class="zarin-field-group">
                                <label for="zsb_msg_about" class="zarin-label"><?php esc_html_e('متن دربارهٔ ما', 'zarinshopbot'); ?> <code>/about</code></label>
                                <?php \ZarinShopBot\Message_Editor::render('zsb_msg_about', 'zarincode_settings[aboutuspage]', (string) ($options['aboutuspage'] ?? ''), 5); ?>
                            </div>
                            <section class="zarin-message-overrides" aria-labelledby="zarin-message-overrides-title">
                                <div class="zarin-message-overrides-header">
                                    <div>
                                        <h3 id="zarin-message-overrides-title"><?php esc_html_e('پیام‌های اختصاصی هر پیام‌رسان', 'zarinshopbot'); ?></h3>
                                        <p><?php esc_html_e('این بخش همیشه در دسترس است؛ لازم نیست چیزی را باز کنید. برای هر پیام‌رسان می‌توانید متن جداگانه بنویسید. کادر خالی یعنی استفاده از متن مشترک بالای صفحه.', 'zarinshopbot'); ?></p>
                                    </div>
                                    <span class="zarin-message-overrides-badge"><?php esc_html_e('اختیاری', 'zarinshopbot'); ?></span>
                                </div>
                                <?php
                                $message_override_labels = array('start' => __('پیام شروع ربات', 'zarinshopbot'), 'bye' => __('پیام خداحافظی', 'zarinshopbot'), 'home' => __('پیام صفحهٔ اصلی', 'zarinshopbot'), 'contact' => __('پیام تماس با ما', 'zarinshopbot'), 'help' => __('پیام راهنما', 'zarinshopbot'), 'about' => __('پیام دربارهٔ ما', 'zarinshopbot'));
                                $message_overrides = isset($options['message_overrides']) && is_array($options['message_overrides']) ? $options['message_overrides'] : array();
                                $message_platform_labels = array('telegram' => 'Telegram', 'bale' => 'Bale', 'rubika' => 'Rubika');
                                foreach ($message_platform_labels as $message_platform => $message_platform_label):
                                ?>
                                    <section class="zarin-message-platform" aria-labelledby="zarin-message-platform-<?php echo esc_attr($message_platform); ?>">
                                        <div class="zarin-message-platform-heading">
                                            <h4 id="zarin-message-platform-<?php echo esc_attr($message_platform); ?>"><?php echo esc_html($message_platform_label); ?></h4>
                                            <span><?php esc_html_e('بازنویسی برای همین پیام‌رسان', 'zarinshopbot'); ?></span>
                                        </div>
                                        <div class="zarin-message-platform-grid">
                                            <?php foreach ($message_override_labels as $message_key => $message_label):
                                                $field_id = 'msg-' . $message_platform . '-' . $message_key;
                                                $override_value = (string) ($message_overrides[$message_platform][$message_key] ?? '');
                                            ?>
                                                <div class="zarin-message-override-field">
                                                    <label class="zarin-label" for="<?php echo esc_attr($field_id); ?>"><?php echo esc_html($message_label); ?></label>
                                                    <?php \ZarinShopBot\Message_Editor::render($field_id, 'zarincode_settings[message_overrides][' . $message_platform . '][' . $message_key . ']', $override_value, 4, 'customer', 'zarin-message-override'); ?>
                                                    <div class="zarin-message-override-footer">
                                                        <p class="zarin-help-text"><?php esc_html_e('خالی بگذارید تا متن مشترک استفاده شود.', 'zarinshopbot'); ?></p>
                                                        <button type="button" class="button zarin-message-use-shared" data-target="<?php echo esc_attr($field_id); ?>" <?php disabled(trim($override_value) === ''); ?>><?php esc_html_e('استفاده از متن مشترک', 'zarinshopbot'); ?></button>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </section>
                                <?php endforeach; ?>
                            </section>

                            <!-- Bot Signature -->
                            <div class="zarin-field-group">
                                <label for="zsb_msg_signature" class="zarin-label"><?php esc_html_e('Message signature', 'zarinshopbot'); ?> <?php esc_html_e('(امضای انتهای پیام‌ها)', 'zarinshopbot'); ?></label>
                                <?php \ZarinShopBot\Message_Editor::render('zsb_msg_signature', 'zarincode_settings[botsign]', (string) ($options['botsign'] ?? ''), 3); ?>
                                <p class="zarin-help-text"><?php esc_html_e('This text is appended to bot replies. Edit it freely or leave the field blank to disable the signature.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="zarin-tab-pane <?php echo ($current === 'webapp-branding') ? 'is-active' : ''; ?>" id="tab-webapp-branding" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header"><span class="dashicons dashicons-art zarin-card-icon"></span><div><h2 class="zarin-card-title"><?php esc_html_e('ظاهر Mini App', 'zarinshopbot'); ?></h2><p class="zarin-card-subtitle"><?php esc_html_e('لوگو و رنگ‌های برند برای Telegram و Bale Mini App؛ رنگ‌های پیش‌فرض پلتفرم در صورت خالی‌بودن حفظ می‌شوند.', 'zarinshopbot'); ?></p></div></div>
                        <div class="zarin-card-body">
                            <?php $brand_logo_id = absint($options['miniapp_brand_logo_id'] ?? 0); $brand_logo_url = $brand_logo_id ? wp_get_attachment_image_url($brand_logo_id, 'medium') : ''; ?>
                            <div class="zarin-field-group">
                                <label class="zarin-label"><?php esc_html_e('لوگوی فروشگاه', 'zarinshopbot'); ?></label>
                                <input type="hidden" id="miniapp_brand_logo_id" name="zarincode_settings[miniapp_brand_logo_id]" value="<?php echo esc_attr($brand_logo_id); ?>">
                                <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
                                    <img id="miniapp_brand_logo_preview" src="<?php echo esc_url($brand_logo_url ?: ''); ?>" alt="" style="<?php echo $brand_logo_url ? '' : 'display:none;'; ?>width:72px;height:72px;object-fit:contain;border:1px solid #ddd;border-radius:12px;padding:4px;background:#fff">
                                    <button type="button" class="button" id="miniapp_brand_logo_select"><?php esc_html_e('انتخاب/بارگذاری لوگو', 'zarinshopbot'); ?></button>
                                    <button type="button" class="button" id="miniapp_brand_logo_remove" <?php disabled(!$brand_logo_id); ?>><?php esc_html_e('حذف لوگو', 'zarinshopbot'); ?></button>
                                </div>
                                <p class="zarin-help-text"><?php esc_html_e('فایل تصویر از کتابخانهٔ رسانهٔ وردپرس انتخاب می‌شود؛ تصویر دوربری یا بازنویسی نمی‌شود.', 'zarinshopbot'); ?></p>
                            </div>
                            <?php
                            $brand_colors = array(
                                'miniapp_brand_primary' => array(__('رنگ اصلی و دکمه‌ها', 'zarinshopbot'), '#0284c7'),
                                'miniapp_brand_accent' => array(__('رنگ تأکیدی', 'zarinshopbot'), '#0ea5e9'),
                                'miniapp_brand_background' => array(__('پس‌زمینه', 'zarinshopbot'), '#ffffff'),
                                'miniapp_brand_text' => array(__('متن', 'zarinshopbot'), '#111827'),
                            );
                            foreach ($brand_colors as $brand_key => $brand_spec):
                                $brand_value = sanitize_hex_color((string) ($options[$brand_key] ?? '')) ?: $brand_spec[1];
                                ?>
                                <div class="zarin-field-group"><label class="zarin-label" for="<?php echo esc_attr($brand_key); ?>"><?php echo esc_html($brand_spec[0]); ?></label><div style="display:flex;align-items:center;gap:10px"><input type="color" id="<?php echo esc_attr($brand_key); ?>" name="zarincode_settings[<?php echo esc_attr($brand_key); ?>]" value="<?php echo esc_attr($brand_value); ?>"><code><?php echo esc_html($brand_value); ?></code></div></div>
                            <?php endforeach; ?>
                            <p class="zarin-help-text"><?php esc_html_e('تغییرات در Header، دکمه‌ها، کارت‌ها و اجزای اصلی Mini App اعمال می‌شوند. رنگ‌های تم خود Telegram/Bale برای نواحی سیستم همچنان رعایت می‌شوند.', 'zarinshopbot'); ?></p>
                        </div>
                    </div>
                </section>

                <section class="zarin-tab-pane <?php echo ($current === 'accounts') ? 'is-active' : ''; ?>" id="tab-accounts" role="tabpanel">
                    <div class="zarin-card"><div class="zarin-card-header"><span class="dashicons dashicons-admin-users zarin-card-icon"></span><div><h2 class="zarin-card-title"><?php esc_html_e('حساب مشتری و تأیید شماره', 'zarinshopbot'); ?></h2><p class="zarin-card-subtitle"><?php esc_html_e('سیاست ثبت‌نام برای سفارش وب، ربات و Mini App', 'zarinshopbot'); ?></p></div></div><div class="zarin-card-body">
                        <div class="zarin-field-group"><label class="zarin-label" for="customer_account_policy"><?php esc_html_e('سیاست حساب مشتری', 'zarinshopbot'); ?></label><select class="zarin-input" id="customer_account_policy" name="zarincode_settings[customer_account_policy]"><option value="guest" <?php selected($options['customer_account_policy'] ?? 'optional', 'guest'); ?>><?php esc_html_e('فقط مهمان؛ ساخت حساب نکن', 'zarinshopbot'); ?></option><option value="optional" <?php selected($options['customer_account_policy'] ?? 'optional', 'optional'); ?>><?php esc_html_e('مهمان مجاز؛ حساب موجود را تطبیق بده', 'zarinshopbot'); ?></option><option value="account" <?php selected($options['customer_account_policy'] ?? 'optional', 'account'); ?>><?php esc_html_e('حساب لازم؛ ساخت/تطبیق حساب پس از احراز هویت', 'zarinshopbot'); ?></option></select><p class="zarin-help-text"><?php esc_html_e('تنظیم WooCommerce برای ثبت‌نام در checkout سایت نیز باید با این سیاست سازگار باشد. حساب موجود با ایمیل یا تلفن تأییدشده تطبیق داده می‌شود.', 'zarinshopbot'); ?></p></div>
                        <div class="zarin-field-group"><label class="zarin-label" for="customer_login_identifier"><?php esc_html_e('روش ورود/تطبیق حساب', 'zarinshopbot'); ?></label><select class="zarin-input" id="customer_login_identifier" name="zarincode_settings[customer_login_identifier]"><option value="email" <?php selected($options['customer_login_identifier'] ?? 'email', 'email'); ?>><?php esc_html_e('ایمیل', 'zarinshopbot'); ?></option><option value="phone" <?php selected($options['customer_login_identifier'] ?? 'email', 'phone'); ?>><?php esc_html_e('تلفن تأییدشده', 'zarinshopbot'); ?></option><option value="either" <?php selected($options['customer_login_identifier'] ?? 'email', 'either'); ?>><?php esc_html_e('ایمیل یا تلفن تأییدشده', 'zarinshopbot'); ?></option></select></div>
                        <div class="zarin-field-group"><label class="zarin-checkbox-label"><input type="hidden" name="zarincode_settings[phone_sms_verification]" value="0"><input type="checkbox" name="zarincode_settings[phone_sms_verification]" value="1" <?php checked((string) ($options['phone_sms_verification'] ?? '0'), '1'); ?>><?php esc_html_e('پیش از ایجاد/اتصال حساب و ثبت سفارش، تأیید OTP شماره تلفن را اجباری کن', 'zarinshopbot'); ?></label><p class="zarin-help-text"><?php esc_html_e('برای استفادهٔ واقعی، OTP در محیط staging با حساب ارائه‌دهنده آزمایش شود؛ شمارهٔ تأییدنشده به حساب موجود متصل نمی‌شود.', 'zarinshopbot'); ?></p></div>
                        <div class="zarin-field-group"><label class="zarin-label" for="sms_provider"><?php esc_html_e('ارائه‌دهندهٔ پیامک OTP', 'zarinshopbot'); ?></label><select class="zarin-input" id="sms_provider" name="zarincode_settings[sms_provider]"><option value="kavenegar" <?php selected($options['sms_provider'] ?? 'kavenegar', 'kavenegar'); ?>>Kavenegar</option><option value="melipayamak" <?php selected($options['sms_provider'] ?? 'kavenegar', 'melipayamak'); ?>>Melipayamak</option></select></div>
                        <h3>Kavenegar</h3><div class="zarin-field-group"><label class="zarin-label" for="sms_kavenegar_api_key_new"><?php esc_html_e('API Key', 'zarinshopbot'); ?></label><input class="zarin-input zarin-ltr" type="password" autocomplete="new-password" id="sms_kavenegar_api_key_new" name="zarincode_settings[sms_kavenegar_api_key_new]" value="" placeholder="<?php echo !empty($options['sms_kavenegar_api_key_enc']) ? esc_attr__('تنظیم شده؛ برای حفظ مقدار فعلی خالی بگذارید', 'zarinshopbot') : esc_attr__('فقط در این فیلد امن وارد شود', 'zarinshopbot'); ?>"></div><div class="zarin-field-group"><label class="zarin-label" for="sms_kavenegar_template"><?php esc_html_e('نام قالب VerifyLookup', 'zarinshopbot'); ?></label><input class="zarin-input zarin-ltr" type="text" id="sms_kavenegar_template" name="zarincode_settings[sms_kavenegar_template]" value="<?php echo esc_attr($options['sms_kavenegar_template'] ?? ''); ?>"></div>
                        <h3>Melipayamak</h3><div class="zarin-field-group"><label class="zarin-label" for="sms_melipayamak_username_new"><?php esc_html_e('نام کاربری پنل', 'zarinshopbot'); ?></label><input class="zarin-input zarin-ltr" type="password" autocomplete="new-password" id="sms_melipayamak_username_new" name="zarincode_settings[sms_melipayamak_username_new]" value="" placeholder="<?php echo !empty($options['sms_melipayamak_username_enc']) ? esc_attr__('تنظیم شده؛ برای حفظ مقدار فعلی خالی بگذارید', 'zarinshopbot') : ''; ?>"></div><div class="zarin-field-group"><label class="zarin-label" for="sms_melipayamak_password_new"><?php esc_html_e('رمز عبور پنل', 'zarinshopbot'); ?></label><input class="zarin-input zarin-ltr" type="password" autocomplete="new-password" id="sms_melipayamak_password_new" name="zarincode_settings[sms_melipayamak_password_new]" value="" placeholder="<?php echo !empty($options['sms_melipayamak_password_enc']) ? esc_attr__('تنظیم شده؛ برای حفظ مقدار فعلی خالی بگذارید', 'zarinshopbot') : ''; ?>"></div><div class="zarin-field-group"><label class="zarin-label" for="sms_melipayamak_body_id"><?php esc_html_e('شناسهٔ الگوی پیامک (Body ID)', 'zarinshopbot'); ?></label><input class="zarin-input zarin-ltr" type="text" id="sms_melipayamak_body_id" name="zarincode_settings[sms_melipayamak_body_id]" value="<?php echo esc_attr($options['sms_melipayamak_body_id'] ?? ''); ?>"></div>
                        <p class="zarin-help-text"><?php esc_html_e('کلیدها و رمزها هرگز دوباره در فرم نمایش داده نمی‌شوند. درخواست ذخیرهٔ خالی، مقدار رمزگذاری‌شدهٔ قبلی را حفظ می‌کند.', 'zarinshopbot'); ?></p>
                    </div></div>
                </section>

                <section class="zarin-tab-pane <?php echo ($current === 'checkout-fields') ? 'is-active' : ''; ?>" id="tab-checkout-fields" role="tabpanel">
                    <div class="zarin-card"><div class="zarin-card-header"><span class="dashicons dashicons-feedback zarin-card-icon"></span><div><h2 class="zarin-card-title"><?php esc_html_e('پروفایل فیلدهای سفارش', 'zarinshopbot'); ?></h2><p class="zarin-card-subtitle"><?php esc_html_e('فعال/نمایش و اجباری‌بودن مستقل برای سبد دانلودی و سبد فیزیکی/ترکیبی', 'zarinshopbot'); ?></p></div></div><div class="zarin-card-body">
                        <p class="zarin-help-text"><?php esc_html_e('در این مرحله تنظیمات شامل فیلدهای پایهٔ WooCommerce است. نام فیلدهای افزونه‌های دیگر ممکن است به فیلتر اختصاصی نیاز داشته باشد.', 'zarinshopbot'); ?></p>
                        <?php
                        $wc_field_labels = array(
                            'billing_first_name' => __('Billing first name', 'zarinshopbot'), 'billing_last_name' => __('Billing last name', 'zarinshopbot'), 'billing_company' => __('Billing company', 'zarinshopbot'), 'billing_country' => __('Billing country', 'zarinshopbot'), 'billing_state' => __('Billing state / province', 'zarinshopbot'), 'billing_city' => __('Billing city', 'zarinshopbot'), 'billing_address_1' => __('Billing address line 1', 'zarinshopbot'), 'billing_address_2' => __('Billing address line 2', 'zarinshopbot'), 'billing_postcode' => __('Billing postcode', 'zarinshopbot'), 'billing_phone' => __('Billing phone', 'zarinshopbot'), 'billing_email' => __('Billing email', 'zarinshopbot'), 'shipping_first_name' => __('Shipping first name', 'zarinshopbot'), 'shipping_last_name' => __('Shipping last name', 'zarinshopbot'), 'shipping_company' => __('Shipping company', 'zarinshopbot'), 'shipping_country' => __('Shipping country', 'zarinshopbot'), 'shipping_state' => __('Shipping state / province', 'zarinshopbot'), 'shipping_city' => __('Shipping city', 'zarinshopbot'), 'shipping_address_1' => __('Shipping address line 1', 'zarinshopbot'), 'shipping_address_2' => __('Shipping address line 2', 'zarinshopbot'), 'shipping_postcode' => __('Shipping postcode', 'zarinshopbot'), 'order_comments' => __('Order notes', 'zarinshopbot'));
                        $wc_profile_defaults = array('billing_first_name' => array('1','1'), 'billing_last_name' => array('1','0'), 'billing_phone' => array('1','1'), 'billing_email' => array('1','1'), 'billing_company' => array('1','0'), 'billing_country' => array('1','0'), 'billing_state' => array('1','0'), 'billing_city' => array('1','0'), 'billing_address_1' => array('1','0'), 'billing_address_2' => array('1','0'), 'billing_postcode' => array('1','0'), 'order_comments' => array('1','0'), 'shipping_first_name' => array('1','0'), 'shipping_last_name' => array('1','0'), 'shipping_company' => array('1','0'), 'shipping_country' => array('1','0'), 'shipping_state' => array('1','0'), 'shipping_city' => array('1','0'), 'shipping_address_1' => array('1','0'), 'shipping_address_2' => array('1','0'), 'shipping_postcode' => array('1','0'));
                        foreach (array('downloadable' => __('سفارش دانلودی', 'zarinshopbot'), 'physical' => __('سفارش فیزیکی یا ترکیبی', 'zarinshopbot')) as $wc_profile => $wc_profile_label):
                            echo '<details class="zarin-card" open><summary class="zarin-card-title">' . esc_html($wc_profile_label) . '</summary><table class="widefat striped"><thead><tr><th>' . esc_html__('WooCommerce field', 'zarinshopbot') . '</th><th>' . esc_html__('نمایش/فعال', 'zarinshopbot') . '</th><th>' . esc_html__('اجباری', 'zarinshopbot') . '</th></tr></thead><tbody>';
                            foreach ($wc_field_labels as $wc_field => $wc_label) {
                                $defaults = $wc_profile_defaults[$wc_field] ?? array('0','0');
                                if ($wc_profile === 'downloadable' && !in_array($wc_field, array('billing_first_name', 'billing_last_name', 'billing_phone', 'billing_email'), true)) $defaults = array('0','0');
                                if ($wc_profile === 'physical' && strpos($wc_field, 'shipping_') === 0) $defaults = array('1','0');
                                $saved = $options['wc_checkout_fields'][$wc_profile][$wc_field] ?? array();
                                $enabled = isset($saved['enabled']) ? (string)$saved['enabled'] : $defaults[0];
                                $required = isset($saved['required']) ? (string)$saved['required'] : $defaults[1];
                                echo '<tr><td>' . esc_html($wc_label) . '</td><td><input type="hidden" name="zarincode_settings[wc_checkout_fields][' . esc_attr($wc_profile) . '][' . esc_attr($wc_field) . '][enabled]" value="0"><input type="checkbox" name="zarincode_settings[wc_checkout_fields][' . esc_attr($wc_profile) . '][' . esc_attr($wc_field) . '][enabled]" value="1" ' . checked($enabled, '1', false) . '></td><td><input type="hidden" name="zarincode_settings[wc_checkout_fields][' . esc_attr($wc_profile) . '][' . esc_attr($wc_field) . '][required]" value="0"><input type="checkbox" name="zarincode_settings[wc_checkout_fields][' . esc_attr($wc_profile) . '][' . esc_attr($wc_field) . '][required]" value="1" ' . checked($required, '1', false) . '></td></tr>';
                            }
                            echo '</tbody></table></details>';
                        endforeach;
                        ?>
                        <div class="zarin-field-group"><label class="zarin-label" for="custom_checkout_fields_json"><?php esc_html_e('فیلدهای سفارشی مدیر (JSON)', 'zarinshopbot'); ?></label><textarea class="zarin-textarea zarin-ltr" rows="8" id="custom_checkout_fields_json" name="zarincode_settings[custom_checkout_fields_json]" placeholder='[{"key":"vat_id","label":"کد اقتصادی","type":"text","profiles":["physical"],"required":false}]'><?php echo esc_textarea((string) ($options['custom_checkout_fields_json'] ?? '')); ?></textarea><p class="zarin-help-text"><?php esc_html_e('قالب هر فیلد: key (حروف لاتین/عدد/underscore)، label، type (text/email/tel/textarea/select), profiles (downloadable/physical) و required. فیلدهای سفارشی تا زمان اعتبارسنجی ذخیره می‌شوند.', 'zarinshopbot'); ?></p></div>
                    </div></div>
                </section>

                <!-- ========================================================================= -->
                <!-- TAB 3: DISPLAY SETTINGS -->
                <!-- ========================================================================= -->
                <section class="zarin-tab-pane <?php echo ($current === 'display') ? 'is-active' : ''; ?>" id="tab-display" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-layout zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Display settings', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Layout of products, photos, texts and purchase buttons in Telegram', 'zarinshopbot'); ?></p>
                            </div>
                        </div>

                        <div class="zarin-card-body">

                            <!-- Sub-section: Catalog & Categories -->
                            <h3 class="zarin-section-title"><span class="dashicons dashicons-category"></span> <?php esc_html_e('Catalog & Category Layout', 'zarinshopbot'); ?></h3>

                            <div class="zarin-grid-2">
                                <!-- Products per page -->
                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Product per page', 'zarinshopbot'); ?></label>
                                    <div class="zarin-number-input">
                                        <input type="number"
                                               name="zarincode_settings[display_productsperpage]"
                                               min="1"
                                               max="50"
                                               value="<?php echo isset($options['display_productsperpage']) ? intval($options['display_productsperpage']) : 5; ?>"
                                               class="zarin-input" />
                                        <span class="zarin-input-unit"><?php esc_html_e('products per page', 'zarinshopbot'); ?></span>
                                    </div>
                                    <p class="zarin-help-text"><?php esc_html_e('Number of products displayed per page with next/previous buttons.', 'zarinshopbot'); ?></p>
                                </div>

                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Newest products sorting', 'zarinshopbot'); ?></label>
                                    <?php $newest_order = isset($options['newest_orderby']) ? $options['newest_orderby'] : 'date'; ?>
                                    <select name="zarincode_settings[newest_orderby]" class="zarin-select">
                                        <option value="date" <?php selected($newest_order, 'date'); ?>><?php esc_html_e('Newest published', 'zarinshopbot'); ?></option>
                                        <option value="modified" <?php selected($newest_order, 'modified'); ?>><?php esc_html_e('Recently updated', 'zarinshopbot'); ?></option>
                                        <option value="popularity" <?php selected($newest_order, 'popularity'); ?>><?php esc_html_e('Most popular', 'zarinshopbot'); ?></option>
                                        <option value="price" <?php selected($newest_order, 'price'); ?>><?php esc_html_e('Lowest price', 'zarinshopbot'); ?></option>
                                    </select>
                                    <p class="zarin-help-text"><?php esc_html_e('Controls the order used by the New Products button.', 'zarinshopbot'); ?></p>
                                </div>

                                <!-- Category display columns -->
                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Category display', 'zarinshopbot'); ?></label>
                                    <div class="zarin-segmented-group">
                                        <?php
                                        $cat_cols = isset($options['display_categories']) ? intval($options['display_categories']) : 1;
                                        $cols_options = array(
                                            1 => __('1 Column', 'zarinshopbot'),
                                            2 => __('2 Columns', 'zarinshopbot'),
                                            3 => __('3 Columns', 'zarinshopbot'),
                                            4 => __('List View', 'zarinshopbot')
                                        );
                                        foreach ($cols_options as $val => $lbl): ?>
                                            <label class="zarin-segmented-item">
                                                <input type="radio" name="zarincode_settings[display_categories]" value="<?php echo esc_attr($val); ?>" <?php echo ($cat_cols == $val) ? 'checked="checked"' : ''; ?>>
                                                <span class="zarin-segmented-label"><?php echo esc_html($lbl); ?></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                    <p class="zarin-help-text"><?php esc_html_e('Number of category button columns in Telegram keyboard.', 'zarinshopbot'); ?></p>
                                </div>
                            </div>

                            <!-- Category & Catalog toggles grid -->
                            <div class="zarin-toggles-grid">
                                <div class="zarin-toggle-card">
                                    <div class="zarin-toggle-card-info">
                                        <div class="zarin-toggle-card-title"><?php esc_html_e('Display category count', 'zarinshopbot'); ?></div>
                                        <div class="zarin-toggle-card-desc"><?php esc_html_e('Show available count next to category title', 'zarinshopbot'); ?></div>
                                    </div>
                                    <label class="zarin-switch-ios">
                                        <input type="checkbox" name="zarincode_settings[display_categorycount]" value="1" <?php echo (isset($options['display_categorycount']) && $options['display_categorycount'] == 1) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-slider-ios"></span>
                                    </label>
                                </div>

                                <div class="zarin-toggle-card">
                                    <div class="zarin-toggle-card-info">
                                        <div class="zarin-toggle-card-title"><?php esc_html_e('Hide empty category', 'zarinshopbot'); ?></div>
                                        <div class="zarin-toggle-card-desc"><?php esc_html_e('Do not display categories that have no products', 'zarinshopbot'); ?></div>
                                    </div>
                                    <label class="zarin-switch-ios">
                                        <input type="checkbox" name="zarincode_settings[display_hideemptycategory]" value="1" <?php echo (isset($options['display_hideemptycategory']) && $options['display_hideemptycategory'] == 1) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-slider-ios"></span>
                                    </label>
                                </div>

                                <div class="zarin-toggle-card">
                                    <div class="zarin-toggle-card-info">
                                        <div class="zarin-toggle-card-title"><?php esc_html_e('Hide products if subcategory exist', 'zarinshopbot'); ?></div>
                                        <div class="zarin-toggle-card-desc"><?php esc_html_e('Hide products if subcategory exist', 'zarinshopbot'); ?></div>
                                    </div>
                                    <label class="zarin-switch-ios">
                                        <input type="checkbox" name="zarincode_settings[hide_products_edge_subcategory]" value="1" <?php echo (isset($options['hide_products_edge_subcategory']) && $options['hide_products_edge_subcategory'] == 1) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-slider-ios"></span>
                                    </label>
                                </div>

                                <div class="zarin-toggle-card">
                                    <div class="zarin-toggle-card-info">
                                        <div class="zarin-toggle-card-title"><?php esc_html_e('Only display instock products', 'zarinshopbot'); ?></div>
                                        <div class="zarin-toggle-card-desc"><?php esc_html_e('Only show products in the bot that are in stock', 'zarinshopbot'); ?></div>
                                    </div>
                                    <label class="zarin-switch-ios">
                                        <input type="checkbox" name="zarincode_settings[only_display_instock_products]" value="1" <?php echo (isset($options['only_display_instock_products']) && $options['only_display_instock_products'] == 1) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-slider-ios"></span>
                                    </label>
                                </div>

                                <div class="zarin-toggle-card">
                                    <div class="zarin-toggle-card-info">
                                        <div class="zarin-toggle-card-title"><?php esc_html_e('Enable product wishlist', 'zarinshopbot'); ?></div>
                                        <div class="zarin-toggle-card-desc"><?php esc_html_e('Show the wishlist button and the customer wishlist screen; price-drop alerts use saved wishlist items.', 'zarinshopbot'); ?></div>
                                    </div>
                                    <label class="zarin-switch-ios">
                                        <input type="hidden" name="zarincode_settings[feature_wishlist]" value="0" />
                                        <input type="checkbox" name="zarincode_settings[feature_wishlist]" value="1" <?php checked(isset($options['feature_wishlist']) ? $options['feature_wishlist'] : 1, 1); ?> />
                                        <span class="zarin-slider-ios"></span>
                                    </label>
                                </div>

                                <div class="zarin-toggle-card">
                                    <div class="zarin-toggle-card-info">
                                        <div class="zarin-toggle-card-title"><?php esc_html_e('Display alert in bot', 'zarinshopbot'); ?></div>
                                        <div class="zarin-toggle-card-desc"><?php esc_html_e('Display alert in bot', 'zarinshopbot'); ?></div>
                                    </div>
                                    <label class="zarin-switch-ios">
                                        <input type="checkbox" name="zarincode_settings[display_alert_in_bot]" value="1" <?php echo (isset($options['display_alert_in_bot']) && $options['display_alert_in_bot'] == 1) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-slider-ios"></span>
                                    </label>
                                </div>
                            </div>

                            <hr class="zarin-divider" />

                            <!-- Sub-section: Product Card Design -->
                            <h3 class="zarin-section-title"><span class="dashicons dashicons-format-image"></span> <?php esc_html_e('ظاهر کارت محصول و تصاویر', 'zarinshopbot'); ?></h3>

                            <!-- Product display mode -->
                            <div class="zarin-field-group">
                                <label class="zarin-label"><?php esc_html_e('Product display', 'zarinshopbot'); ?></label>
                                <div class="zarin-segmented-group">
                                    <?php
                                    $p_disp = isset($options['display_product']) ? intval($options['display_product']) : 1;
                                    ?>
                                    <label class="zarin-segmented-item">
                                        <input type="radio" name="zarincode_settings[display_product]" value="1" <?php echo ($p_disp == 1) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-segmented-label"><span class="dashicons dashicons-format-image"></span> <?php esc_html_e('تصویر و متن', 'zarinshopbot'); ?></span>
                                    </label>
                                    <label class="zarin-segmented-item">
                                        <input type="radio" name="zarincode_settings[display_product]" value="2" <?php echo ($p_disp == 2) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-segmented-label"><span class="dashicons dashicons-editor-paragraph"></span> <?php esc_html_e('Display text', 'zarinshopbot'); ?></span>
                                    </label>
                                    <label class="zarin-segmented-item">
                                        <input type="radio" name="zarincode_settings[display_product]" value="3" <?php echo ($p_disp == 3) ? 'checked="checked"' : ''; ?>>
                                        <span class="zarin-segmented-label"><span class="dashicons dashicons-arrow-down-alt"></span> <?php esc_html_e('تصویر در انتهای پیام', 'zarinshopbot'); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Photo size & Link type -->
                            <div class="zarin-grid-2">
                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Photo size', 'zarinshopbot'); ?></label>
                                    <div class="zarin-segmented-group">
                                        <?php
                                        $photo_size = isset($options['display_photosize']) ? intval($options['display_photosize']) : 2;
                                        ?>
                                        <label class="zarin-segmented-item">
                                            <input type="radio" name="zarincode_settings[display_photosize]" value="1" <?php echo ($photo_size == 1) ? 'checked="checked"' : ''; ?>>
                                            <span class="zarin-segmented-label"><?php esc_html_e('Thumbnail', 'zarinshopbot'); ?></span>
                                        </label>
                                        <label class="zarin-segmented-item">
                                            <input type="radio" name="zarincode_settings[display_photosize]" value="2" <?php echo ($photo_size == 2) ? 'checked="checked"' : ''; ?>>
                                            <span class="zarin-segmented-label"><?php esc_html_e('Medium', 'zarinshopbot'); ?></span>
                                        </label>
                                        <label class="zarin-segmented-item">
                                            <input type="radio" name="zarincode_settings[display_photosize]" value="3" <?php echo ($photo_size == 3) ? 'checked="checked"' : ''; ?>>
                                            <span class="zarin-segmented-label"><?php esc_html_e('Large', 'zarinshopbot'); ?></span>
                                        </label>
                                    </div>
                                </div>

                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Product card details', 'zarinshopbot'); ?></label>
                                    <label class="zarin-checkbox-row"><input type="hidden" name="zarincode_settings[display_product_sku]" value="0" /><input type="checkbox" name="zarincode_settings[display_product_sku]" value="1" <?php checked(isset($options['display_product_sku']) ? $options['display_product_sku'] : 1, 1); ?> /> <span><?php esc_html_e('Show SKU', 'zarinshopbot'); ?></span></label>
                                    <label class="zarin-checkbox-row"><input type="hidden" name="zarincode_settings[display_sale_badge]" value="0" /><input type="checkbox" name="zarincode_settings[display_sale_badge]" value="1" <?php checked(isset($options['display_sale_badge']) ? $options['display_sale_badge'] : 1, 1); ?> /> <span><?php esc_html_e('Show discount badge', 'zarinshopbot'); ?></span></label>
                                </div>

                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Product link', 'zarinshopbot'); ?></label>
                                    <div class="zarin-segmented-group">
                                        <?php
                                        $link_type = isset($options['display_product_link_type']) ? intval($options['display_product_link_type']) : 1;
                                        ?>
                                        <label class="zarin-segmented-item">
                                            <input type="radio" name="zarincode_settings[display_product_link_type]" value="1" <?php echo ($link_type == 1) ? 'checked="checked"' : ''; ?>>
                                            <span class="zarin-segmented-label"><?php esc_html_e('Simple Link', 'zarinshopbot'); ?></span>
                                        </label>
                                        <label class="zarin-segmented-item">
                                            <input type="radio" name="zarincode_settings[display_product_link_type]" value="2" <?php echo ($link_type == 2) ? 'checked="checked"' : ''; ?>>
                                            <span class="zarin-segmented-label"><?php esc_html_e('WordPress Permalink', 'zarinshopbot'); ?></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <!-- Description mode & length -->
                            <div class="zarin-grid-2">
                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Product display description', 'zarinshopbot'); ?></label>
                                    <select name="zarincode_settings[display_product_excerpt]" class="zarin-select">
                                        <?php $desc_m = isset($options['display_product_excerpt']) ? intval($options['display_product_excerpt']) : 0; ?>
                                        <option value="1" <?php echo ($desc_m == 1) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Short description', 'zarinshopbot'); ?> <?php esc_html_e('(توضیح کوتاه ووکامرس)', 'zarinshopbot'); ?></option>
                                        <option value="2" <?php echo ($desc_m == 2) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Description limited', 'zarinshopbot'); ?> <?php esc_html_e('(محدود به تعداد کلمه)', 'zarinshopbot'); ?></option>
                                        <option value="3" <?php echo ($desc_m == 3) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Description full', 'zarinshopbot'); ?> <?php esc_html_e('(متن کامل توضیحات)', 'zarinshopbot'); ?></option>
                                        <option value="0" <?php echo ($desc_m == 0) ? 'selected="selected"' : ''; ?>><?php esc_html_e('No', 'zarinshopbot'); ?> <?php esc_html_e('(عدم نمایش توضیحات)', 'zarinshopbot'); ?></option>
                                    </select>
                                </div>

                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Description limited length', 'zarinshopbot'); ?></label>
                                    <div class="zarin-number-input">
                                        <input type="number"
                                               name="zarincode_settings[display_product_excerpt_length]"
                                               min="5"
                                               max="500"
                                               value="<?php echo isset($options['display_product_excerpt_length']) ? intval($options['display_product_excerpt_length']) : 55; ?>"
                                               class="zarin-input" />
                                        <span class="zarin-input-unit"><?php esc_html_e('words', 'zarinshopbot'); ?></span>
                                    </div>
                                </div>
                            </div>

                            <!-- Search mode & Stock display -->
                            <div class="zarin-grid-2">
                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Product search', 'zarinshopbot'); ?></label>
                                    <select name="zarincode_settings[display_search]" class="zarin-select">
                                        <?php $search_m = isset($options['display_search']) ? intval($options['display_search']) : 1; ?>
                                        <option value="1" <?php echo ($search_m == 1) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Only title', 'zarinshopbot'); ?> <?php esc_html_e('(فقط عنوان محصول)', 'zarinshopbot'); ?></option>
                                        <option value="2" <?php echo ($search_m == 2) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Title and text', 'zarinshopbot'); ?> <?php esc_html_e('(عنوان و متن توضیحات)', 'zarinshopbot'); ?></option>
                                        <option value="0" <?php echo ($search_m == 0) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Off', 'zarinshopbot'); ?> <?php esc_html_e('(غیرفعال)', 'zarinshopbot'); ?></option>
                                    </select>
                                </div>

                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('Show product qty in stock', 'zarinshopbot'); ?></label>
                                    <select name="zarincode_settings[display_showqty]" class="zarin-select">
                                        <?php $qty_m = isset($options['display_showqty']) ? intval($options['display_showqty']) : 0; ?>
                                        <option value="1" <?php echo ($qty_m == 1) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Show number', 'zarinshopbot'); ?> <?php esc_html_e('(نمایش عدد موجودی انبار)', 'zarinshopbot'); ?></option>
                                        <option value="2" <?php echo ($qty_m == 2) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Only show in stock or not', 'zarinshopbot'); ?> <?php esc_html_e('(فقط نمایش موجود/ناموجود)', 'zarinshopbot'); ?></option>
                                        <option value="0" <?php echo ($qty_m == 0) ? 'selected="selected"' : ''; ?>><?php esc_html_e('Not show', 'zarinshopbot'); ?> <?php esc_html_e('(عدم نمایش وضعیت موجودی)', 'zarinshopbot'); ?></option>
                                    </select>
                                </div>
                            </div>

                            <hr class="zarin-divider" />

                            <!-- Sub-section: Elements Matrix -->
                            <h3 class="zarin-section-title"><span class="dashicons dashicons-visibility"></span> <?php esc_html_e('محل نمایش دکمه‌ها، قیمت و المان‌ها', 'zarinshopbot'); ?></h3>
                            <p class="zarin-help-text" style="margin-bottom: 15px;"><?php esc_html_e('مشخص کنید هر یک از المان‌ها در داخل ربات تلگرام یا در پیام‌های ارسالی به کانال و گروه‌ها نمایش داده شوند.', 'zarinshopbot'); ?></p>

                            <div class="zarin-matrix-wrap">
                                <table class="zarin-matrix-table">
                                    <thead>
                                        <tr>
                                            <th><?php esc_html_e('Element / Button', 'zarinshopbot'); ?></th>
                                            <th class="zarin-th-check">
                                                <span class="dashicons dashicons-smartphone"></span>
                                                <?php esc_html_e('Display in Bot', 'zarinshopbot'); ?>
                                            </th>
                                            <th class="zarin-th-check">
                                                <span class="dashicons dashicons-megaphone"></span>
                                                <?php esc_html_e('Display in Broadcast (Channel, Groups, Users)', 'zarinshopbot'); ?>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $matrix_items = array(
                                            'display_price_discounted' => __('Discounted Sale Price', 'zarinshopbot'),
                                            'display_price'            => __('Regular Price', 'zarinshopbot'),
                                            'display_linkbuyonsite'    => __('Online Purchase Link', 'zarinshopbot'),
                                            'display_linkquickbuy'     => __('Quick Buy Link', 'zarinshopbot'),
                                            'display_buttonorder'      => __('Order Button', 'zarinshopbot'),
                                            'display_buttonviewonsite' => __('View on Website Button', 'zarinshopbot')
                                        );

                                        foreach ($matrix_items as $f_key => $f_title):
                                            $val_arr = (isset($options[$f_key]) && is_array($options[$f_key])) ? $options[$f_key] : array();
                                            $in_checked = in_array('in', $val_arr);
                                            $out_checked = in_array('out', $val_arr);
                                        ?>
                                            <tr>
                                                <td class="zarin-td-title">
                                                    <strong><?php echo esc_html($f_title); ?></strong>
                                                    <span style="display:none;"><input type="checkbox" name="zarincode_settings[<?php echo esc_attr($f_key); ?>][]" value="test" checked="checked"></span>
                                                </td>
                                                <td class="zarin-td-check">
                                                    <label class="zarin-custom-checkbox">
                                                        <input type="checkbox" name="zarincode_settings[<?php echo esc_attr($f_key); ?>][]" value="in" <?php echo $in_checked ? 'checked="checked"' : ''; ?>>
                                                        <span class="zarin-checkmark"></span>
                                                    </label>
                                                </td>
                                                <td class="zarin-td-check">
                                                    <label class="zarin-custom-checkbox">
                                                        <input type="checkbox" name="zarincode_settings[<?php echo esc_attr($f_key); ?>][]" value="out" <?php echo $out_checked ? 'checked="checked"' : ''; ?>>
                                                        <span class="zarin-checkmark"></span>
                                                    </label>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- How to get quantity -->
                            <div class="zarin-field-group" style="margin-top: 20px;">
                                <label for="display_howgetqty" class="zarin-label"><?php esc_html_e('How to get the order number', 'zarinshopbot'); ?></label>
                                <textarea id="display_howgetqty"
                                          name="zarincode_settings[display_howgetqty]"
                                          rows="3"
                                          class="zarin-textarea zarin-ltr"
                                          placeholder="1 2 3 4 5&#10;6 7 8 9 10"><?php echo isset($options['display_howgetqty']) ? esc_textarea($options['display_howgetqty']) : "1 2 3 4 5\n6 7 8 9 10"; ?></textarea>
                                <p class="zarin-help-text">
                                    <?php esc_html_e('دکمه‌های انتخاب سریع تعداد توسط مشتری (اعداد را با فاصله و هر سطر را با اینتر جدا کنید). اگر می‌خواهید کاربر خودش عدد را تایپ کند این فیلد را خالی بگذارید.', 'zarinshopbot'); ?>
                                </p>
                            </div>

                        </div>
                    </div>
                </section>

                <!-- ========================================================================= -->
                <!-- TAB 4: ORDER SETTINGS -->
                <!-- ========================================================================= -->
                <section class="zarin-tab-pane <?php echo ($current === 'order') ? 'is-active' : ''; ?>" id="tab-order" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-cart zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('تنظیمات مشترک سبد و سفارش WooCommerce', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('قواعد عمومی سفارش برای Telegram، Bale و Rubika؛ checkout وب از فیلدها و درگاه‌های خود WooCommerce پیروی می‌کند.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>

                        <div class="zarin-card-body">
                            <!-- Order mode -->
                            <div class="zarin-field-group">
                                <label class="zarin-label"><?php esc_html_e('Ordering & Purchase Flow', 'zarinshopbot'); ?></label>
                                <div class="zarin-radio-cards">
                                    <?php $cart_status = isset($options['order_cart_status']) ? intval($options['order_cart_status']) : 1; ?>

                                    <label class="zarin-radio-card <?php echo ($cart_status == 1) ? 'is-selected' : ''; ?>">
                                        <input type="radio" name="zarincode_settings[order_cart_status]" value="1" <?php echo ($cart_status == 1) ? 'checked="checked"' : ''; ?>>
                                        <div class="zarin-radio-card-content">
                                            <div class="zarin-radio-card-title">
                                                <span class="dashicons dashicons-cart"></span>
                                                <?php esc_html_e('Multi-Item Shopping Cart (Recommended)', 'zarinshopbot'); ?>
                                                <span class="zarin-chip zarin-chip-success"><?php esc_html_e('Standard', 'zarinshopbot'); ?></span>
                                            </div>
                                            <p class="zarin-radio-card-desc"><?php esc_html_e('مشتری می‌تواند چند کالا را به سبد خرید اضافه کند و تمام آنها را با هم در یک فاکتور تسویه نماید.', 'zarinshopbot'); ?></p>
                                        </div>
                                    </label>

                                    <label class="zarin-radio-card <?php echo ($cart_status == 0) ? 'is-selected' : ''; ?>">
                                        <input type="radio" name="zarincode_settings[order_cart_status]" value="0" <?php echo ($cart_status == 0) ? 'checked="checked"' : ''; ?>>
                                        <div class="zarin-radio-card-content">
                                            <div class="zarin-radio-card-title">
                                                <span class="dashicons dashicons-yes"></span>
                                                <?php esc_html_e('Direct Single-Product Order', 'zarinshopbot'); ?>
                                            </div>
                                            <p class="zarin-radio-card-desc"><?php esc_html_e('با کلیک روی سفارش، بلافاصله فرایند تسویه‌حساب همان تک‌محصول آغاز می‌شود.', 'zarinshopbot'); ?></p>
                                        </div>
                                    </label>
                                </div>
                            </div>

                            <hr class="zarin-divider" />

                            <h3 class="zarin-section-title"><span class="dashicons dashicons-id-alt"></span> <?php esc_html_e('فیلدهای مورد نیاز در فرایند ثبت سفارش', 'zarinshopbot'); ?></h3>
                            <p class="zarin-help-text" style="margin-bottom: 15px;"><?php esc_html_e('نام و ایمیل بر اساس تنظیمات این پروفایل دریافت می‌شوند؛ روش دریافت شماره تلفن در بخش جداگانهٔ زیر توسط مدیر تعیین می‌شود. اگر حساب اجباری یا OTP فعال باشد، موبایل همچنان الزامی است.', 'zarinshopbot'); ?></p>

                            <!-- Checkout Fields Toggles Grid -->
                            <div class="zarin-toggles-grid">
                                <?php
                                $checkout_toggles = array(
                                    'register_req_qty'        => array('title' => __('Get quantity in add to cart process', 'zarinshopbot'), 'desc' => __('Quantity requested by buyer', 'zarinshopbot')),
                                    'register_req_name'       => array('title' => __('Get name in order process', 'zarinshopbot'), 'desc' => __('Buyer full name for invoice', 'zarinshopbot')),
                                    'register_req_email'      => array('title' => __('Get email in order process', 'zarinshopbot'), 'desc' => __('For sending invoices and order notifications', 'zarinshopbot')),
                                    'register_req_state'      => array('title' => __('Get state in order process', 'zarinshopbot'), 'desc' => __('Select state for shipping calculation', 'zarinshopbot')),
                                    'register_req_city'       => array('title' => __('Get city in order process', 'zarinshopbot'), 'desc' => __('Destination city for order delivery', 'zarinshopbot')),
                                    'register_req_address'    => array('title' => __('Get address in order process', 'zarinshopbot'), 'desc' => __('Street, alley, and house number for delivery', 'zarinshopbot')),
                                    'register_req_zip'        => array('title' => __('Get postal code in order process', 'zarinshopbot'), 'desc' => __('Postal code for delivery location', 'zarinshopbot')),
                                    'register_req_shipping'   => array('title' => __('Get shipping method in order process', 'zarinshopbot'), 'desc' => __('Select from WooCommerce shipping methods', 'zarinshopbot')),
                                    'register_req_payment'    => array('title' => __('Get payment method in order process', 'zarinshopbot'), 'desc' => __('Payment gateway or payment method for order', 'zarinshopbot')),
                                    'register_req_ordernote'  => array('title' => __('Get order note in order process', 'zarinshopbot'), 'desc' => __('Optional customer notes or instructions', 'zarinshopbot'))
                                );

                                foreach ($checkout_toggles as $f_name => $f_info):
                                    $is_mandatory = in_array($f_name, array('register_req_name', 'register_req_email'), true);
                                    $is_checked = $is_mandatory || (isset($options[$f_name]) && $options[$f_name] == 1);
                                ?>
                                    <div class="zarin-toggle-card">
                                        <div class="zarin-toggle-card-info">
                                            <div class="zarin-toggle-card-title"><?php echo esc_html($f_info['title']); ?></div>
                                            <div class="zarin-toggle-card-desc"><?php echo esc_html($f_info['desc']); ?></div>
                                        </div>
                                        <label class="zarin-switch-ios">
                                            <?php if ($is_mandatory): ?><input type="hidden" name="zarincode_settings[<?php echo esc_attr($f_name); ?>]" value="1"><?php endif; ?>
                                            <input type="checkbox" name="zarincode_settings[<?php echo esc_attr($f_name); ?>]" value="1" <?php echo $is_checked ? 'checked="checked"' : ''; ?> <?php disabled($is_mandatory); ?>>
                                            <span class="zarin-slider-ios"></span>
                                        </label>
                                        <?php if ($is_mandatory): ?><small class="zarin-help-text"><?php esc_html_e('همیشه الزامی', 'zarinshopbot'); ?></small><?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Phone collection mode: site administrators choose the request mode. -->
                            <?php
                            $phone_m_saved = isset($options['register_req_phone']) && is_scalar($options['register_req_phone']) ? (int) $options['register_req_phone'] : 3;
                            if (!in_array($phone_m_saved, array(0, 1, 2, 3), true)) $phone_m_saved = 3;
                            $phone_m = $phone_m_saved;
                            $phone_mode_labels = array(
                                1 => __('موبایل یا تلفن ثابت', 'zarinshopbot'),
                                3 => __('فقط موبایل', 'zarinshopbot'),
                                2 => __('فقط تلفن ثابت', 'zarinshopbot'),
                                0 => __('دریافت نشود', 'zarinshopbot'),
                            );
                            $phone_mode_locked = ((string) ($options['phone_sms_verification'] ?? '0') === '1') || (($options['customer_account_policy'] ?? 'optional') === 'account');
                            if ($phone_mode_locked) $phone_m = 3;
                            ?>
                            <div class="zarin-field-group" style="margin-top: 25px;">
                                <label class="zarin-label"><?php esc_html_e('Get phone in order process', 'zarinshopbot'); ?></label>
                                <div class="zarin-segmented-group" role="radiogroup" aria-label="<?php esc_attr_e('Phone collection mode', 'zarinshopbot'); ?>">
                                    <?php if ($phone_mode_locked): ?><input type="hidden" name="zarincode_settings[register_req_phone]" value="<?php echo esc_attr($phone_m_saved); ?>" /><?php endif; ?>
                                    <?php foreach (array(
                                        1 => __('Mobile or Landline', 'zarinshopbot'),
                                        3 => __('Mobile Only', 'zarinshopbot'),
                                        2 => __('Landline Only', 'zarinshopbot'),
                                        0 => __('Do Not Collect', 'zarinshopbot'),
                                    ) as $phone_value => $phone_label): ?>
                                        <label class="zarin-segmented-item <?php echo $phone_m === $phone_value ? 'is-selected ' : ''; ?><?php echo $phone_mode_locked ? 'is-locked' : ''; ?>" aria-disabled="<?php echo $phone_mode_locked ? 'true' : 'false'; ?>">
                                            <input type="radio" name="zarincode_settings[register_req_phone]" value="<?php echo esc_attr($phone_value); ?>" <?php checked($phone_m, $phone_value); ?> <?php disabled($phone_mode_locked); ?> />
                                            <span class="zarin-segmented-label"><?php echo esc_html($phone_label); ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                                <p class="zarin-help-text" id="register-req-phone-help"><?php esc_html_e('این تنظیم برای فرایند سفارش ربات است: انتخاب‌های ۱، ۲ و ۳ دریافت شماره را فعال می‌کنند؛ ۰ یعنی شماره درخواست نشود. اگر OTP پیامکی روشن باشد یا سیاست «حساب لازم» انتخاب شده باشد، فقط دریافت موبایل مجاز است تا تطبیق حساب و احراز هویت امن بماند.', 'zarinshopbot'); ?></p>
                                <p class="zarin-help-text"><?php esc_html_e('برای تنظیم جداگانهٔ سفارش دانلودی و فیزیکی، انتخاب تلفن هر پروفایل را در تب «فیلدهای سفارش» تنظیم کنید. تنظیمات checkout وب‌سایت نیز جداگانه از پروفایل WooCommerce پیروی می‌کند.', 'zarinshopbot'); ?></p>
                            </div>

                            <?php
                            $checkout_field_labels = array(
                                'name' => __('نام و نام خانوادگی', 'zarinshopbot'),
                                'email' => __('ایمیل', 'zarinshopbot'),
                                'state' => __('استان', 'zarinshopbot'),
                                'city' => __('شهر', 'zarinshopbot'),
                                'address' => __('نشانی', 'zarinshopbot'),
                                'zip' => __('کد پستی', 'zarinshopbot'),
                                'ordernote' => __('یادداشت سفارش', 'zarinshopbot'),
                                'shipping' => __('انتخاب روش ارسال WooCommerce', 'zarinshopbot'),
                            );
                            $checkout_profile_specs = array(
                                'digital' => array(
                                    'title' => __('فیلدهای محصول دانلودی', 'zarinshopbot'),
                                    'description' => __('نام و ایمیل بر اساس پروفایل دریافت می‌شوند؛ تلفن از تنظیم کلی پیروی می‌کند مگر آن‌که برای این سبد override شود. OTP یا سیاست حساب لازم، دریافت موبایل را اجباری می‌کند. نشانی و ارسال به‌صورت پیش‌فرض خاموش است؛ پرداخت کالای پولی اجباری می‌ماند.', 'zarinshopbot'),
                                    'defaults' => array('name' => 1, 'phone' => 'global', 'email' => 1, 'state' => 0, 'city' => 0, 'address' => 0, 'zip' => 0, 'ordernote' => 0, 'shipping' => 0),
                                    'fields' => array('name', 'email', 'state', 'city', 'address', 'zip', 'ordernote'),
                                ),
                                'physical' => array(
                                    'title' => __('فیلدهای محصول فیزیکی و سبد ترکیبی', 'zarinshopbot'),
                                    'description' => __('برای سبد ترکیبی همین پروفایل استفاده می‌شود؛ اقلام دانلودی از محاسبهٔ ارسال حذف می‌شوند. مقادیر اولیه از تنظیمات عمومی قبلی گرفته شده‌اند.', 'zarinshopbot'),
                                    'defaults' => array(
                                        'name' => 1,
                                        'phone' => 'global',
                                        'email' => 1,
                                        'state' => !empty($options['register_req_state']) ? 1 : 0,
                                        'city' => !empty($options['register_req_city']) ? 1 : 0,
                                        'address' => !empty($options['register_req_address']) ? 1 : 0,
                                        'zip' => !empty($options['register_req_zip']) ? 1 : 0,
                                        'ordernote' => !empty($options['register_req_ordernote']) ? 1 : 0,
                                        'shipping' => !empty($options['register_req_shipping']) ? 1 : 0,
                                    ),
                                    'fields' => array('name', 'email', 'state', 'city', 'address', 'zip', 'ordernote', 'shipping'),
                                ),
                            );
                            foreach ($checkout_profile_specs as $profile_name => $spec):
                                $profile_option_key = 'checkout_fields_' . $profile_name;
                                $saved_fields = isset($options[$profile_option_key]) && is_array($options[$profile_option_key]) ? $options[$profile_option_key] : array();
                                $field_value = function($field) use ($saved_fields, $spec, $phone_m, $phone_mode_locked) {
                                    if (in_array($field, array('name', 'email'), true)) return 1;
                                    if ($field === 'phone') {
                                        if ($phone_mode_locked) return '3';
                                        $value = array_key_exists('phone', $saved_fields) && is_scalar($saved_fields['phone']) ? (string) $saved_fields['phone'] : 'global';
                                        return in_array($value, array('global', '0', '1', '2', '3'), true) ? $value : 'global';
                                    }
                                    return array_key_exists($field, $saved_fields) ? (int) $saved_fields[$field] : (int) ($spec['defaults'][$field] ?? 0);
                                };
                            ?>
                                <section class="zarin-card" style="margin-top:18px;">
                                    <div class="zarin-card-header">
                                        <span class="dashicons <?php echo $profile_name === 'digital' ? 'dashicons-download' : 'dashicons-car'; ?> zarin-card-icon" aria-hidden="true"></span>
                                        <div><h3 class="zarin-card-title"><?php echo esc_html($spec['title']); ?></h3><p class="zarin-help-text"><?php echo esc_html($spec['description']); ?></p></div>
                                    </div>
                                    <div class="zarin-toggles-grid">
                                        <?php foreach ($spec['fields'] as $field): ?>
                                            <div class="zarin-toggle-card">
                                                <div class="zarin-toggle-card-info"><div class="zarin-toggle-card-title"><?php echo esc_html($checkout_field_labels[$field]); ?></div></div>
                                                <label class="zarin-switch-ios">
                                                    <input type="hidden" name="zarincode_settings[<?php echo esc_attr($profile_option_key); ?>][<?php echo esc_attr($field); ?>]" value="0">
                                                    <?php $mandatory_profile_field = in_array($field, array('name', 'email'), true); ?>
                                                    <?php if ($mandatory_profile_field): ?><input type="hidden" name="zarincode_settings[<?php echo esc_attr($profile_option_key); ?>][<?php echo esc_attr($field); ?>]" value="1"><?php endif; ?>
                                                    <input type="checkbox" name="zarincode_settings[<?php echo esc_attr($profile_option_key); ?>][<?php echo esc_attr($field); ?>]" value="1" <?php checked($field_value($field) === 1); ?> <?php disabled($mandatory_profile_field); ?>>
                                                    <span class="zarin-slider-ios"></span>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                        <div class="zarin-field-group" style="margin:12px;">
                                            <label class="zarin-label" for="checkout-phone-<?php echo esc_attr($profile_name); ?>"><?php esc_html_e('تلفن', 'zarinshopbot'); ?></label>
                                            <?php if ($phone_mode_locked): ?>
                                                <?php $preserved_phone_mode = isset($saved_fields['phone']) && is_scalar($saved_fields['phone']) && in_array((string) $saved_fields['phone'], array('global', '0', '1', '2', '3'), true) ? (string) $saved_fields['phone'] : 'global'; ?>
                                                <input type="hidden" name="zarincode_settings[<?php echo esc_attr($profile_option_key); ?>][phone]" value="<?php echo esc_attr($preserved_phone_mode); ?>">
                                            <?php endif; ?>
                                            <select class="regular-text" id="checkout-phone-<?php echo esc_attr($profile_name); ?>" name="zarincode_settings[<?php echo esc_attr($profile_option_key); ?>][phone]" <?php disabled($phone_mode_locked); ?> aria-describedby="checkout-phone-help-<?php echo esc_attr($profile_name); ?>">
                                                <?php foreach (array(
                                                    'global' => sprintf(__('تنظیم کلی: %s', 'zarinshopbot'), $phone_mode_labels[$phone_m] ?? __('فقط موبایل', 'zarinshopbot')),
                                                    '0' => __('دریافت نشود', 'zarinshopbot'),
                                                    '1' => __('موبایل یا تلفن ثابت', 'zarinshopbot'),
                                                    '3' => __('فقط موبایل', 'zarinshopbot'),
                                                    '2' => __('فقط تلفن ثابت', 'zarinshopbot'),
                                                ) as $phone_value => $phone_label): ?>
                                                    <option value="<?php echo esc_attr($phone_value); ?>" <?php selected((string) $field_value('phone'), (string) $phone_value); ?>><?php echo esc_html($phone_label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <p class="zarin-help-text" id="checkout-phone-help-<?php echo esc_attr($profile_name); ?>"><?php if ($phone_mode_locked) { esc_html_e('به‌دلیل فعال‌بودن OTP یا اجباری‌بودن حساب، دریافت موبایل اجباری است.', 'zarinshopbot'); } else { esc_html_e('این انتخاب فقط برای فرایند سفارش ربات در این نوع سبد اعمال می‌شود و بر اساس مقدار ذخیره‌شدهٔ مدیر نمایش داده می‌شود.', 'zarinshopbot'); } ?></p>
                                        </div>
                                    </div>
                                </section>
                            <?php endforeach; ?>

                            <div class="zarin-digital-policy" role="note">
                                <div class="zarin-digital-policy-heading"><span class="dashicons dashicons-download" aria-hidden="true"></span><div><strong><?php esc_html_e('قواعد پرداخت و دسترسی محصولات دانلودی', 'zarinshopbot'); ?></strong><small><?php esc_html_e('دریافت تلفن برای ربات از تنظیم کلی یا پروفایل انتخابی پیروی می‌کند؛ اگر حساب اجباری یا OTP روشن باشد، موبایل اجباری است. دسترسی دانلود فقط با مجوز WooCommerce و پس از پرداخت معتبر (یا سفارش رایگان) صادر می‌شود.', 'zarinshopbot'); ?></small></div></div>
                                <ul>
                                    <li><?php esc_html_e('دانلودیِ رایگان: پیش‌فرض نام و تلفن؛ اگر مبلغ نهایی صفر باشد، سفارش WooCommerce تکمیل و لینک مجاز دانلود تحویل می‌شود.', 'zarinshopbot'); ?></li>
                                    <li><?php esc_html_e('دانلودیِ پولی: علاوه بر نام، موبایل و ایمیل، فیلدهای انتخابی پروفایل دانلودی؛ پرداخت معتبر اجباری است و کارت‌به‌کارت فقط پس از تأیید مدیر دسترسی می‌دهد.', 'zarinshopbot'); ?></li>
                                    <li><?php esc_html_e('دانلودی حتی اگر Virtual نباشد، از shipping خارج می‌شود؛ در سبد ترکیبی، روش ارسال برای کالای فیزیکی باقی می‌ماند.', 'zarinshopbot'); ?></li>
                                    <li><?php esc_html_e('فیلدهای انتخاب‌شده در billing سفارش ثبت می‌شوند. این پروفایل‌ها برای checkout ربات Telegram، Bale و Rubika است؛ checkout وب نیز نام، موبایل و ایمیل را اجباری می‌کند.', 'zarinshopbot'); ?></li>
                                </ul>
                                <div class="zarin-digital-policy-links"><a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=products&section=downloadable')); ?>"><?php esc_html_e('تنظیمات دانلودهای WooCommerce', 'zarinshopbot'); ?></a><a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=shipping')); ?>"><?php esc_html_e('روش‌های ارسال WooCommerce', 'zarinshopbot'); ?></a><a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout')); ?>"><?php esc_html_e('پرداخت‌های WooCommerce', 'zarinshopbot'); ?></a></div>
                            </div>

                        </div>
                    </div>
                </section>

                <!-- ========================================================================= -->
                <!-- TAB: CARD TRANSFER SETTINGS -->
                <!-- ========================================================================= -->
                <section class="zarin-tab-pane zarin-card-transfer-pane <?php echo ($current === 'card-transfer') ? 'is-active' : ''; ?>" id="tab-card-transfer" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-money-alt zarin-card-icon" aria-hidden="true"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('تنظیمات پرداخت کارت‌به‌کارت', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('حساب‌های بانکی مقصد، نمایش اطلاعات به مشتری و بررسی رسید پرداخت', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <?php if (!class_exists(\ZarinShopBot\Card_Transfer::class) || !class_exists('WC_Payment_Gateway')) : ?>
                                <div class="notice notice-error"><p><?php esc_html_e('برای تنظیم کارت‌به‌کارت، ووکامرس باید نصب و فعال باشد.', 'zarinshopbot'); ?></p></div>
                            <?php else : ?>
                                <?php
                                $transfer_enabled = (($card_transfer_settings['enabled'] ?? 'no') === 'yes');
                                $telegram_private_admin_ready = trim((string) ($options['admin_notification_chat_id'] ?? '')) !== '';
                                $bale_private_admin_ready = trim((string) ($channel_options['bale_admin_chat_id'] ?? '')) !== '';
                                $rubika_private_admin_ready = trim((string) ($channel_options['rubika_admin_chat_id'] ?? '')) !== '';
                                $telegram_admin_url = add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => 'basic'), admin_url('admin.php')) . '#telegram-admin-chat-id';
                                $bale_admin_url = add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => 'bale'), admin_url('admin.php')) . '#bale-admin-chat-id';
                                $rubika_admin_url = add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => 'rubika'), admin_url('admin.php')) . '#rubika-admin-chat-id';
                                $audience_users_url = add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'subscribers', 'view' => 'users'), admin_url('admin.php'));
                                ?>
                                <section class="zsb-private-admin-guide" aria-labelledby="zsb-private-admin-guide-title">
                                    <div class="zsb-private-admin-guide-head">
                                        <span class="dashicons dashicons-email-alt" aria-hidden="true"></span>
                                        <div>
                                            <h3 id="zsb-private-admin-guide-title"><?php esc_html_e('پیام خصوصی مدیر برای بررسی رسید', 'zarinshopbot'); ?></h3>
                                            <p><?php esc_html_e('برای دریافت خصوصی رسید و دکمه‌های تأیید/رد، شناسهٔ گفت‌وگوی خصوصی مدیر را در تنظیمات همان پیام‌رسان ثبت کنید.', 'zarinshopbot'); ?></p>
                                        </div>
                                    </div>
                                    <ol class="zsb-private-admin-steps">
                                        <li><?php echo sprintf(esc_html__('مدیر ابتدا گفت‌وگوی خصوصی ربات همان پلتفرم را باز کند و Start یا %1$s را بزند.', 'zarinshopbot'), '<code>/start</code>'); ?></li>
                                        <li><?php echo sprintf(esc_html__('برای یافتن شناسه، پس از %1$s به پنل اصلی افزونه ← مخاطبان و گروه‌ها ← کاربران بروید؛ ردیف خود را با نام کاربری پیدا کنید و مقدار ستون Chat ID را کپی کنید. برای هر پیام‌رسان شناسهٔ همان پلتفرم را بردارید.', 'zarinshopbot'), '<code>/start</code>'); ?></li>
                                        <li><?php esc_html_e('شناسه را در لینک تنظیمات پیام‌رسان زیر وارد و ذخیره کنید.', 'zarinshopbot'); ?></li>
                                        <li><?php esc_html_e('اگر شناسه تنظیم نشود، اعلان خصوصی ارسال نمی‌شود؛ رسید همچنان در سفارش WooCommerce برای بازبینی مدیر باقی می‌ماند.', 'zarinshopbot'); ?></li>
                                    </ol>
                                    <p class="zsb-private-admin-source"><a href="<?php echo esc_url($audience_users_url); ?>"><?php esc_html_e('باز کردن فهرست کاربران برای پیدا کردن Chat ID', 'zarinshopbot'); ?> ←</a></p>
                                    <div class="zsb-private-admin-platforms">
                                        <a class="zsb-private-admin-platform" href="<?php echo esc_url($telegram_admin_url); ?>">
                                            <strong>Telegram</strong><span class="<?php echo $telegram_private_admin_ready ? 'is-ready' : 'is-missing'; ?>"><?php echo esc_html($telegram_private_admin_ready ? __('شناسه وارد شده', 'zarinshopbot') : __('نیاز به تنظیم شناسه', 'zarinshopbot')); ?></span><em><?php esc_html_e('رفتن به تنظیمات اعلان‌ها و گفت‌وگوی خصوصی', 'zarinshopbot'); ?> ←</em>
                                        </a>
                                        <a class="zsb-private-admin-platform" href="<?php echo esc_url($bale_admin_url); ?>">
                                            <strong>Bale</strong><span class="<?php echo $bale_private_admin_ready ? 'is-ready' : 'is-missing'; ?>"><?php echo esc_html($bale_private_admin_ready ? __('شناسه وارد شده', 'zarinshopbot') : __('نیاز به تنظیم شناسه', 'zarinshopbot')); ?></span><em><?php esc_html_e('رفتن به تنظیمات ربات بله', 'zarinshopbot'); ?> ←</em>
                                        </a>
                                        <a class="zsb-private-admin-platform" href="<?php echo esc_url($rubika_admin_url); ?>">
                                            <strong>Rubika</strong><span class="<?php echo $rubika_private_admin_ready ? 'is-ready' : 'is-missing'; ?>"><?php echo esc_html($rubika_private_admin_ready ? __('شناسه وارد شده', 'zarinshopbot') : __('نیاز به تنظیم شناسه', 'zarinshopbot')); ?></span><em><?php esc_html_e('رفتن به تنظیمات ربات روبیکا', 'zarinshopbot'); ?> ←</em>
                                        </a>
                                    </div>
                                </section>
                                <div class="zarin-field-group">
                                    <label class="zarin-checkbox-label">
                                        <input type="hidden" name="<?php echo esc_attr(\ZarinShopBot\Card_Transfer::OPTION_KEY); ?>[enabled]" value="no">
                                        <input type="checkbox" name="<?php echo esc_attr(\ZarinShopBot\Card_Transfer::OPTION_KEY); ?>[enabled]" value="yes" <?php checked($transfer_enabled); ?>>
                                        <?php esc_html_e('فعال‌سازی پرداخت کارت‌به‌کارت در تسویه‌حساب ووکامرس', 'zarinshopbot'); ?>
                                    </label>
                                    <p class="zarin-help-text"><?php esc_html_e('پس از فعال‌سازی و ثبت دست‌کم یک حساب معتبر، این روش درگاه ووکامرس و پرداخت‌های مینی‌اپ نمایش داده می‌شود. تأیید رسید همچنان دستی است.', 'zarinshopbot'); ?></p>
                                </div>

                                <div class="zarin-field-group">
                                    <label class="zarin-label" for="zsb_transfer_title"><?php esc_html_e('عنوان روش پرداخت', 'zarinshopbot'); ?></label>
                                    <p class="zarin-help-text"><?php esc_html_e('اگر عنوان قبلی خالی یا فقط فاصله باشد، عنوان پیش‌فرض «پرداخت کارت‌به‌کارت» نمایش داده می‌شود.', 'zarinshopbot'); ?></p>
                                    <input class="zarin-input" id="zsb_transfer_title" type="text" dir="auto" name="<?php echo esc_attr(\ZarinShopBot\Card_Transfer::OPTION_KEY); ?>[title]" value="<?php echo esc_attr(\ZarinShopBot\Card_Transfer::customerTitle()); ?>">
                                </div>
                                <div class="zarin-field-group">
                                    <label class="zarin-label" for="zsb_transfer_description"><?php esc_html_e('توضیحات پرداخت برای مشتری', 'zarinshopbot'); ?></label>
                                    <?php \ZarinShopBot\Message_Editor::render('zsb_transfer_description', \ZarinShopBot\Card_Transfer::OPTION_KEY . '[description]', \ZarinShopBot\Card_Transfer::customerDescription(), 6, 'none'); ?>
                                    <p class="zarin-help-text"><?php esc_html_e('اگر متن ذخیره‌شده خالی، فقط فاصله یا قالب خالی ویرایشگر باشد، متن پیش‌فرض این بخش بازمی‌گردد؛ این نوشته در درگاه و Mini App پیش از انتخاب حساب مقصد نمایش داده می‌شود.', 'zarinshopbot'); ?></p>
                                </div>
                                <div class="zarin-field-group">
                                    <label class="zarin-label" for="zsb_transfer_instructions"><?php esc_html_e('راهنمای بارگذاری رسید', 'zarinshopbot'); ?></label>
                                    <?php \ZarinShopBot\Message_Editor::render('zsb_transfer_instructions', \ZarinShopBot\Card_Transfer::OPTION_KEY . '[instructions]', \ZarinShopBot\Card_Transfer::customerInstructions(), 8, 'none'); ?>
                                    <p class="zarin-help-text"><?php esc_html_e('اگر این متن خالی باشد، راهنمای پیش‌فرض بازمی‌گردد. متن در تسویه‌حساب، Mini App و صفحهٔ سفارش کنار بخش بارگذاری رسید نمایش داده می‌شود.', 'zarinshopbot'); ?></p>
                                </div>

                                <div class="zarin-field-group">
                                    <label class="zarin-label"><?php esc_html_e('حساب‌های بانکی مقصد', 'zarinshopbot'); ?></label>
                                    <p class="zarin-help-text"><?php esc_html_e('برای هر حساب، نام صاحب حساب و شماره کارت را وارد کنید. شماره حساب و شبا اختیاری‌اند و هرکدام دکمهٔ کپی جداگانه خواهند داشت.', 'zarinshopbot'); ?></p>
                                    <?php echo \ZarinShopBot\Card_Transfer::renderAccountsEditor(\ZarinShopBot\Card_Transfer::OPTION_KEY . '[accounts]', $card_transfer_settings['accounts'] ?? ''); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                </div>

                                <div class="zarin-field-group">
                                    <label class="zarin-label" for="zsb_transfer_allowed_extensions"><?php esc_html_e('پسوندهای مجاز رسید', 'zarinshopbot'); ?></label>
                                    <input class="zarin-input zarin-ltr" id="zsb_transfer_allowed_extensions" type="text" dir="ltr" name="<?php echo esc_attr(\ZarinShopBot\Card_Transfer::OPTION_KEY); ?>[allowed_extensions]" value="<?php echo esc_attr($card_transfer_settings['allowed_extensions'] ?? 'jpg,jpeg,png,webp,pdf'); ?>">
                                    <p class="zarin-help-text"><?php esc_html_e('پسوندها را با ویرگول جدا کنید؛ فایل اجرایی یا اسکریپت حتی با افزودن به این فهرست پذیرفته نمی‌شود.', 'zarinshopbot'); ?></p>
                                </div>
                                <div class="zarin-field-group">
                                    <label class="zarin-label" for="zsb_transfer_custom_mimes"><?php esc_html_e('تصویرهای سفارشی (اختیاری)', 'zarinshopbot'); ?></label>
                                    <textarea class="zarin-textarea zarin-ltr" id="zsb_transfer_custom_mimes" rows="3" dir="ltr" name="<?php echo esc_attr(\ZarinShopBot\Card_Transfer::OPTION_KEY); ?>[custom_mimes]"><?php echo esc_textarea($card_transfer_settings['custom_mimes'] ?? ''); ?></textarea>
                                    <p class="zarin-help-text"><?php esc_html_e('هر سطر با قالب پسوند|نوع‌رسانه؛ فقط نوع‌های تصویر پذیرفته می‌شوند، مانند heic|image/heic.', 'zarinshopbot'); ?></p>
                                </div>
                                <div class="zarin-field-group">
                                    <label class="zarin-label" for="zsb_transfer_max_upload_mb"><?php esc_html_e('حداکثر حجم رسید (مگابایت)', 'zarinshopbot'); ?></label>
                                    <input class="zarin-input" id="zsb_transfer_max_upload_mb" type="number" min="0.1" max="20" step="0.1" name="<?php echo esc_attr(\ZarinShopBot\Card_Transfer::OPTION_KEY); ?>[max_upload_mb]" value="<?php echo esc_attr($card_transfer_settings['max_upload_mb'] ?? '2'); ?>">
                                    <p class="zarin-help-text"><?php esc_html_e('محدودهٔ مجاز از ۰٫۱ تا ۲۰ مگابایت است و محدودیت سرور نیز رعایت می‌شود.', 'zarinshopbot'); ?></p>
                                </div>
                                <div class="zarin-notice zarin-notice-info">
                                    <strong><?php esc_html_e('ذخیره و نمایش درگاه', 'zarinshopbot'); ?></strong>
                                    <?php esc_html_e('این صفحه مستقیماً تنظیمات ذخیره‌شدهٔ درگاه ووکامرس را به‌روزرسانی می‌کند و داده‌های حساب‌های قبلی را نگه می‌دارد. در صفحهٔ درگاه‌های ووکامرس، روش کارت‌به‌کارت را نیز فعال نگه دارید.', 'zarinshopbot'); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>

                <!-- ========================================================================= -->
                <!-- TAB 5: PROXY SETTINGS -->
                <!-- ========================================================================= -->


                <!-- ========================================================================= -->
                <!-- TAB: MAIN MENU & BUTTONS -->
                <!-- ========================================================================= -->
                <section class="zarin-tab-pane <?php echo ($current === 'menu') ? 'is-active' : ''; ?>" id="tab-menu" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-menu zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Main Menu & Button Customization', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Toggle buttons, customize multilingual titles, rearrange order, and add custom buttons.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <?php
                            $menu_items = \ZarinShopBot\Core\WooBot::getActiveMenuItems();
                            $menu_local_icons = array(
                                'cat' => 'layers-3.svg', 'new' => 'star.svg', 'search' => 'search.svg',
                                'cart' => 'shopping-cart.svg', 'orders' => 'clipboard-list.svg', 'wishlist' => 'heart.svg',
                                'settings' => 'settings.svg', 'contact' => 'phone.svg', 'help' => 'circle-help.svg',
                                'webapp' => 'smartphone.svg',
                            );
                            $menu_emoji_prefixes = array('📦', '⭐', '🔍', '🛒', '❤️', '🌐', '📞', 'ℹ️', '📱');
                            ?>
                            <div class="zarin-field-group">
                                <label class="zarin-label"><?php esc_html_e('Core Menu Buttons', 'zarinshopbot'); ?></label>
                                <p class="zarin-help-text"><?php esc_html_e('آیکون‌های کنار نام هر گزینه از فایل‌های محلی افزونه بارگذاری می‌شوند؛ متن داخل کادرها همان عنوانی است که به پیام‌رسان ارسال می‌شود.', 'zarinshopbot'); ?></p>
                                <div class="zsb-menu-items">
                                    <?php foreach ($menu_items as $m_key => $m_item):
                                        $m_key = sanitize_key((string) $m_key);
                                        $menu_icon_file = isset($menu_local_icons[$m_key]) ? $menu_local_icons[$m_key] : 'menu.svg';
                                        $menu_preview_title = (string) ($m_item['title_fa'] ?? '');
                                        foreach ($menu_emoji_prefixes as $emoji_prefix) {
                                            if (strpos($menu_preview_title, $emoji_prefix) === 0) {
                                                $menu_preview_title = ltrim(substr($menu_preview_title, strlen($emoji_prefix)));
                                                break;
                                            }
                                        }
                                        if ($menu_preview_title === '') $menu_preview_title = (string) ($m_item['title_fa'] ?? '');
                                    ?>
                                        <div class="zsb-menu-item-row" data-menu-item="<?php echo esc_attr($m_key); ?>">
                                            <div class="zsb-menu-item-preview">
                                                <input type="hidden" name="zarincode_settings[main_menu_items][<?php echo esc_attr($m_key); ?>][enabled]" value="0" />
                                                <label class="zsb-menu-enabled-label">
                                                    <input type="checkbox" name="zarincode_settings[main_menu_items][<?php echo esc_attr($m_key); ?>][enabled]" value="1" <?php checked(!empty($m_item['enabled']), 1); ?> />
                                                    <img class="zsb-menu-item-icon" src="<?php echo esc_url(zarincode_get_plugin_uri() . 'assets/icons/ui/' . $menu_icon_file); ?>" width="22" height="22" alt="" aria-hidden="true" />
                                                    <strong><?php echo esc_html($menu_preview_title); ?></strong>
                                                </label>
                                            </div>
                                            <div class="zsb-menu-title-fields">
                                                <input type="text" name="zarincode_settings[main_menu_items][<?php echo esc_attr($m_key); ?>][title_fa]" value="<?php echo esc_attr($m_item['title_fa'] ?? ''); ?>" placeholder="<?php esc_attr_e('Persian title', 'zarinshopbot'); ?>" class="zarin-input" />
                                                <input type="text" name="zarincode_settings[main_menu_items][<?php echo esc_attr($m_key); ?>][title_en]" value="<?php echo esc_attr($m_item['title_en'] ?? ''); ?>" placeholder="English title" class="zarin-input zarin-ltr" />
                                            </div>
                                            <label class="zsb-menu-priority">
                                                <span><?php esc_html_e('Priority:', 'zarinshopbot'); ?></span>
                                                <input type="number" name="zarincode_settings[main_menu_items][<?php echo esc_attr($m_key); ?>][order]" value="<?php echo esc_attr($m_item['order'] ?? 0); ?>" min="0" step="1" class="zarin-input zarin-ltr" />
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <input type="hidden" name="zarincode_settings[feature_menu_commands]" value="0" />
                            <label class="zarin-checkbox-row" style="margin-top: 14px;">
                                <input type="checkbox" name="zarincode_settings[feature_menu_commands]" value="1" <?php checked(isset($options['feature_menu_commands']) ? $options['feature_menu_commands'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('ثبت منوی فرمان در پلتفرم‌های پشتیبانی‌شده', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Telegram و Rubika فهرست فرمان را با API مخصوص خود ثبت می‌کنند؛ Bale در افزونه از ثبت خودکار منو پشتیبانی نمی‌کند.', 'zarinshopbot'); ?></small></span>
                            </label>
                        </div>
                    </div>
                </section>

                <!-- ========================================================================= -->
                <!-- TAB: SEARCH & FILTERS -->
                <!-- ========================================================================= -->
                <section class="zarin-tab-pane <?php echo ($current === 'search') ? 'is-active' : ''; ?>" id="tab-search" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-search zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Advanced Search & Filtering', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Configure search behavior, SKU lookups, price filters, stock filtering, and sorting.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <input type="hidden" name="zarincode_settings[feature_live_search]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[feature_live_search]" value="1" <?php checked(isset($options['feature_live_search']) ? $options['feature_live_search'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('Enable Advanced Product Search', 'zarinshopbot'); ?></strong><small><?php echo sprintf(esc_html__('Keep product search available via %1$s and interactive search hub.', 'zarinshopbot'), '<code>/search</code>'); ?></small></span>
                            </label>

                            <input type="hidden" name="zarincode_settings[search_sku_enable]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[search_sku_enable]" value="1" <?php checked(isset($options['search_sku_enable']) ? $options['search_sku_enable'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('Direct Search by Product SKU', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Allow customers to find products instantly by typing or scanning SKU codes.', 'zarinshopbot'); ?></small></span>
                            </label>

                            <input type="hidden" name="zarincode_settings[search_price_filter_enable]" value="0" />
                            <label class="zarin-checkbox-row">
                                <input type="checkbox" name="zarincode_settings[search_price_filter_enable]" value="1" <?php checked(isset($options['search_price_filter_enable']) ? $options['search_price_filter_enable'] : 1, 1); ?> />
                                <span><strong><?php esc_html_e('Price Range Filtering for Integrations', 'zarinshopbot'); ?></strong><small><?php esc_html_e('Allow min/max price parameters from compatible integrations. The built-in chat does not currently ask customers to enter a numeric price range.', 'zarinshopbot'); ?></small></span>
                            </label>

                            <div class="zarin-field-group">
                                <label for="search_default_sort" class="zarin-label"><?php esc_html_e('Default Product Sorting Order', 'zarinshopbot'); ?></label>
                                <select id="search_default_sort" name="zarincode_settings[search_default_sort]" class="zarin-select">
                                    <option value="date" <?php selected(isset($options['search_default_sort']) ? $options['search_default_sort'] : 'date', 'date'); ?>><?php esc_html_e('Newest First', 'zarinshopbot'); ?></option>
                                    <option value="popularity" <?php selected(isset($options['search_default_sort']) ? $options['search_default_sort'] : 'date', 'popularity'); ?>><?php esc_html_e('Best Selling (Popularity)', 'zarinshopbot'); ?></option>
                                    <option value="price_asc" <?php selected(isset($options['search_default_sort']) ? $options['search_default_sort'] : 'date', 'price_asc'); ?>><?php esc_html_e('Price: Low to High', 'zarinshopbot'); ?></option>
                                    <option value="price_desc" <?php selected(isset($options['search_default_sort']) ? $options['search_default_sort'] : 'date', 'price_desc'); ?>><?php esc_html_e('Price: High to Low', 'zarinshopbot'); ?></option>
                                    <option value="on_sale" <?php selected(isset($options['search_default_sort']) ? $options['search_default_sort'] : 'date', 'on_sale'); ?>><?php esc_html_e('Discounted Products First', 'zarinshopbot'); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ========================================================================= -->
                <!-- TAB: NOTIFICATIONS -->
                <!-- ========================================================================= -->


                <!-- ========================================================================= -->
                <!-- TAB: TELEGRAM-ONLY PAYMENTS AND FEATURES -->
                <!-- ========================================================================= -->


                <!-- ========================================================================= -->
                <!-- TAB: TELEGRAM MINI APP -->
                <!-- ========================================================================= -->


                <!-- TAB: MARKETING & BACKUP SETTINGS -->
                <!-- ========================================================================= -->
                <section class="zarin-tab-pane <?php echo ($current === 'marketing') ? 'is-active' : ''; ?>" id="tab-marketing" role="tabpanel">
                    <!-- Referral & Invite System -->
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-share-alt2 zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Referral & Invitation Program', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php echo sprintf(esc_html__('Empower your customers to invite friends via %1$s and track referral statistics', 'zarinshopbot'), '<code>/start ref_XXXX</code>'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <div class="zarin-form-group">
                                <input type="hidden" name="zarincode_settings[feature_referrals]" value="no" />
                                <label class="zarin-toggle-wrap">
                                    <input type="checkbox" name="zarincode_settings[feature_referrals]" value="yes" <?php checked(isset($options['feature_referrals']) ? $options['feature_referrals'] : 'yes', 'yes'); ?>>
                                    <span class="zarin-toggle-slider"></span>
                                    <span class="zarin-toggle-label"><?php esc_html_e('Enable Referral & Invitation System', 'zarinshopbot'); ?></span>
                                </label>
                                <p class="zarin-help-text"><?php esc_html_e('Generates personal invite links for bot subscribers; attribution uses the active platform context and shared WooCommerce customer/order data.', 'zarinshopbot'); ?></p>
                            </div>

                        </div>
                    </div>

                    <!-- Flash Sale & Time-Limited Campaigns -->
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-megaphone zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Time-Limited Campaigns & Flash Sales', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('Display an urgent promotional banner across bot menus and catalog views', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <div class="zarin-form-group">
                                <label class="zarin-toggle-wrap">
                                    <input type="checkbox" name="zarincode_settings[enable_campaign_banner]" value="yes" <?php checked(isset($options['enable_campaign_banner']) ? $options['enable_campaign_banner'] : 'no', 'yes'); ?>>
                                    <span class="zarin-toggle-slider"></span>
                                    <span class="zarin-toggle-label"><?php esc_html_e('Enable Promotional Campaign Banner', 'zarinshopbot'); ?></span>
                                </label>
                            </div>

                            <div class="zarin-form-group">
                                <label class="zarin-form-label"><?php esc_html_e('Campaign Banner Announcement', 'zarinshopbot'); ?></label>
                                <?php \ZarinShopBot\Message_Editor::render('zsb_campaign_banner', 'zarincode_settings[campaign_banner_text]', (string) ($options['campaign_banner_text'] ?? ''), 4); ?>
                                <p class="zarin-help-text"><?php esc_html_e('Example: Special festival discount! Use code FLASH20 at checkout for 20% off.', 'zarinshopbot'); ?></p>
                            </div>

                        </div>
                    </div>

                    <!-- Settings Backup (Export / Import) -->
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-database-export zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('Backup & Migration (Export / Import Settings)', 'zarinshopbot'); ?></h2>
                                    <p class="zarin-card-subtitle"><?php esc_html_e('Export all ZarinShopBot configurations to JSON or import settings from another site', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <div class="zarin-grid-2">
                                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px;">
                                    <h4 style="margin: 0 0 8px; color: #0f172a;"><?php esc_html_e('Export Settings', 'zarinshopbot'); ?></h4>
                                    <p style="font-size: 13px; color: #64748b; margin-bottom: 14px;"><?php esc_html_e('Download a complete JSON file containing your tokens, menu structure, and bot preferences.', 'zarinshopbot'); ?></p>
                                    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?action=zarincode_export_settings'), 'zarincode_export_settings_nonce')); ?>" class="button button-primary">
                                        <span class="dashicons dashicons-download" style="vertical-align: middle;"></span>
                                        <?php esc_html_e('Download Settings JSON', 'zarinshopbot'); ?>
                                    </a>
                                </div>

                                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px;">
                                    <h4 style="margin: 0 0 8px; color: #0f172a;"><?php esc_html_e('Import Settings', 'zarinshopbot'); ?></h4>
                                    <p style="font-size: 13px; color: #64748b; margin-bottom: 14px;"><?php esc_html_e('Upload a valid ZarinShopBot JSON backup file to overwrite current settings safely.', 'zarinshopbot'); ?></p>
                                    <div>
                                        <input type="hidden" name="zarincode_import_nonce" value="<?php echo esc_attr(wp_create_nonce('zarincode_import_settings_nonce')); ?>" form="zarincode_import_settings_form" />
                                        <input type="hidden" name="zarincode_import_settings_action" value="1" form="zarincode_import_settings_form" />
                                        <input type="file" name="zarincode_import_file" accept=".json" required style="margin-bottom: 10px; font-size: 12px;" form="zarincode_import_settings_form" />
                                        <div>
                                            <button type="submit" form="zarincode_import_settings_form" class="button button-secondary" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to overwrite current settings with this file?', 'zarinshopbot')); ?>');">
                                                <span class="dashicons dashicons-upload" style="vertical-align: middle;"></span>
                                                <?php esc_html_e('Restore / Import Settings', 'zarinshopbot'); ?>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                <!-- Shared diagnostic and log-retention settings -->
                <section class="zarin-tab-pane <?php echo ($current === 'diagnostics') ? 'is-active' : ''; ?>" id="tab-diagnostics" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-visibility zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('گزارش‌ها و تشخیص همهٔ کانال‌ها', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('تنظیمات گزارش برای رخدادهای افزونه و همهٔ کانال‌های فعال مشترک است؛ اطلاعات حساس از خروجی گزارش پاک‌سازی می‌شود.', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <div class="zarin-field-group" style="background: var(--surface-subtle); padding: 14px; border-radius: var(--radius-md);">
                                <label class="zarin-label"><?php esc_html_e('سطح و نگهداری گزارش', 'zarinshopbot'); ?></label>
<label class="zarin-checkbox-row"><input type="hidden" name="zarincode_settings[zarincode_logging_enabled]" value="0" /><input type="checkbox" name="zarincode_settings[zarincode_logging_enabled]" value="1" <?php checked($options['zarincode_logging_enabled'] ?? 1, 1); ?> /> <span><?php esc_html_e('Enable detailed bot, button, API and proxy logs', 'zarinshopbot'); ?></span></label>
                                    <label><?php esc_html_e('Log level', 'zarinshopbot'); ?>
                                        <select name="zarincode_settings[zarincode_log_level]">
                                            <option value="errors" <?php selected($options['zarincode_log_level'] ?? 'all', 'errors'); ?>><?php esc_html_e('Errors only', 'zarinshopbot'); ?></option>
                                            <option value="all" <?php selected($options['zarincode_log_level'] ?? 'all', 'all'); ?>><?php esc_html_e('All events', 'zarinshopbot'); ?></option>
                                        </select>
                                    </label>
                                    <label><?php esc_html_e('Log retention (days)', 'zarinshopbot'); ?> <input type="number" min="1" max="30" name="zarincode_settings[zarincode_log_retention_days]" value="<?php echo esc_attr($options['zarincode_log_retention_days'] ?? 7); ?>" /></label>
                                    <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=zarincode_download_logs'), 'zarincode_download_logs')); ?>"><?php esc_html_e('Download sanitized logs', 'zarinshopbot'); ?></a>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- TAB 7: COMMANDS SETTINGS -->
                <section class="zarin-tab-pane <?php echo ($current === 'commands') ? 'is-active' : ''; ?>" id="tab-commands" role="tabpanel">
                    <div class="zarin-card">
                        <div class="zarin-card-header">
                            <span class="dashicons dashicons-editor-help zarin-card-icon"></span>
                            <div>
                                <h2 class="zarin-card-title"><?php esc_html_e('فرمان‌های ربات‌ها', 'zarinshopbot'); ?></h2>
                                <p class="zarin-card-subtitle"><?php esc_html_e('فهرست یکپارچهٔ فرمان‌ها، نام‌های جایگزین و روش نمایش آن‌ها در هر پیام‌رسان', 'zarinshopbot'); ?></p>
                            </div>
                        </div>
                        <div class="zarin-card-body">
                            <div class="zarin-notice zarin-notice-info" style="margin:0 0 18px;padding:14px 16px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;color:#1e3a8a">
                                <strong><?php esc_html_e('شناسه‌های فرمان ثابت‌اند:', 'zarinshopbot'); ?></strong>
                                <?php esc_html_e('شناسه‌های انگلیسی فرمان‌ها ثابت‌اند و ترجمه نمی‌شوند؛ فقط توضیح کنار آن‌ها قابل ترجمه است. این فرمان‌ها در dispatcher مشترک افزونه برای Telegram، Bale و Rubika پردازش می‌شوند.', 'zarinshopbot'); ?>
                            </div>

                            <h3><?php esc_html_e('فرمان‌های اصلی', 'zarinshopbot'); ?></h3>
                            <div style="overflow-x:auto">
                                <table class="widefat striped" style="min-width:640px">
                                    <thead><tr><th><?php esc_html_e('فرمان ثابت', 'zarinshopbot'); ?></th><th><?php esc_html_e('نام‌های جایگزین', 'zarinshopbot'); ?></th><th><?php esc_html_e('کاربرد / شرط', 'zarinshopbot'); ?></th></tr></thead>
                                    <tbody>
                                        <tr><td><code>/start</code></td><td>—</td><td><?php esc_html_e('شروع ربات و نمایش منوی اصلی', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/shop</code></td><td><code>/home</code></td><td><?php esc_html_e('نمایش فروشگاه و منوی محصولات', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/search</code></td><td>—</td><td><?php esc_html_e('جست‌وجوی محصولات', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/category</code></td><td><code>/categories</code>، <code>/cats</code></td><td><?php esc_html_e('مرور دسته‌بندی‌ها', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/newproducts</code></td><td><code>/new</code></td><td><?php esc_html_e('نمایش محصولات جدید', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/cart</code></td><td>—</td><td><?php esc_html_e('مشاهده و مدیریت سبد خرید', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/orders</code></td><td><code>/tracking</code></td><td><?php esc_html_e('نمایش و پیگیری سفارش‌ها', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/wishlist</code></td><td>—</td><td><?php esc_html_e('نمایش علاقه‌مندی‌ها؛ وابسته به فعال بودن قابلیت', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/settings</code></td><td><code>/language</code></td><td><?php esc_html_e('تنظیم زبان ربات', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/contactus</code></td><td>—</td><td><?php esc_html_e('اطلاعات تماس فروشگاه', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/help</code></td><td>—</td><td><?php esc_html_e('راهنمای استفاده از ربات', 'zarinshopbot'); ?></td></tr>
                                    </tbody>
                                </table>
                            </div>

                            <details class="zarin-command-registration" style="margin-top:16px">
                                <summary><?php esc_html_e('متن آمادهٔ ثبت فرمان‌های اصلی در Telegram (همان فهرست بالا)', 'zarinshopbot'); ?></summary>
                                <div class="zarin-code-block" style="margin-top:10px">
                                    <div class="zarin-code-block-header">
                                        <span><?php esc_html_e('برای @BotFather؛ نام فرمان‌ها ثابت و انگلیسی است', 'zarinshopbot'); ?></span>
                                        <button type="button" class="zarin-btn-copy" id="zarin_copy_commands"><span class="dashicons dashicons-admin-page"></span><?php esc_html_e('کپی فهرست', 'zarinshopbot'); ?></button>
                                    </div>
                                    <?php
                                    $telegram_command_descriptions = array(
                                        'start' => __('شروع و نمایش منوی فروشگاه', 'zarinshopbot'),
                                        'shop' => __('نمایش فروشگاه و محصولات', 'zarinshopbot'),
                                        'search' => __('جست‌وجوی محصول با نام یا کد', 'zarinshopbot'),
                                        'category' => __('نمایش دسته‌بندی محصولات', 'zarinshopbot'),
                                        'newproducts' => __('نمایش محصولات جدید', 'zarinshopbot'),
                                        'cart' => __('مشاهده و مدیریت سبد خرید', 'zarinshopbot'),
                                        'orders' => __('پیگیری سفارش‌ها', 'zarinshopbot'),
                                        'wishlist' => __('نمایش علاقه‌مندی‌ها', 'zarinshopbot'),
                                        'settings' => __('تنظیم زبان ربات', 'zarinshopbot'),
                                        'contactus' => __('تماس با فروشگاه', 'zarinshopbot'),
                                        'help' => __('راهنمای ربات', 'zarinshopbot'),
                                    );
                                    $telegram_command_lines = array();
                                    foreach ($telegram_command_descriptions as $command_name => $command_description) {
                                        $telegram_command_lines[] = $command_name . ' - ' . $command_description;
                                    }
                                    ?>
                                    <textarea id="zarin_commands_text" readonly class="zarin-code-content" rows="11"><?php echo esc_textarea(implode("\n", $telegram_command_lines)); ?></textarea>
                                </div>
                            </details>

                            <h3 style="margin-top:22px"><?php esc_html_e('فرمان‌های تکمیلی و وابسته به قابلیت', 'zarinshopbot'); ?></h3>
                            <div style="overflow-x:auto">
                                <table class="widefat striped" style="min-width:600px">
                                    <thead><tr><th><?php esc_html_e('فرمان ثابت', 'zarinshopbot'); ?></th><th><?php esc_html_e('کاربرد / شرط', 'zarinshopbot'); ?></th></tr></thead>
                                    <tbody>
                                        <tr><td><code>/referral</code></td><td><?php esc_html_e('دعوت از دوستان؛ وابسته به فعال بودن قابلیت ارجاع', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/suggest</code>، <code>/foryou</code></td><td><?php esc_html_e('پیشنهادهای شخصی‌سازی‌شده', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/bestsellers</code></td><td><?php esc_html_e('محصولات پرفروش', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/onsale</code></td><td><?php esc_html_e('محصولات حراج/تخفیف‌دار', 'zarinshopbot'); ?></td></tr>
                                        <tr><td><code>/stop</code></td><td><?php esc_html_e('توقف تعامل و خالی‌کردن سبد خرید؛ فقط در صورت تمایل این فرمان را در منو قرار دهید', 'zarinshopbot'); ?></td></tr>
                                    </tbody>
                                </table>
                            </div>

                            <h3 style="margin-top:22px"><?php esc_html_e('ثبت و نمایش منو در پیام‌رسان‌ها', 'zarinshopbot'); ?></h3>
                            <ul class="zarin-command-platform-notes">
                                <li><strong><?php esc_html_e('Telegram:', 'zarinshopbot'); ?></strong> <?php esc_html_e('افزونه فهرست اصلی را با API تلگرام همگام می‌کند؛ در صورت نیاز، همین متن را در BotFather و دستور', 'zarinshopbot'); ?> <code>/setcommands</code> <?php esc_html_e('نیز ثبت کنید.', 'zarinshopbot'); ?></li>
                                <li><strong><?php esc_html_e('Bale:', 'zarinshopbot'); ?></strong> <?php esc_html_e('فرمان‌ها در dispatcher مشترک کار می‌کنند؛ ثبت خودکار منوی فرمان از سوی افزونه پشتیبانی نمی‌شود و باید از رابط خود Bale انجام شود.', 'zarinshopbot'); ?></li>
                                <li><strong><?php esc_html_e('Rubika:', 'zarinshopbot'); ?></strong> <?php esc_html_e('با فعال‌بودن گزینهٔ منوی فرمان، فهرست اصلی پس از ثبت وب‌هوک با API رسمی', 'zarinshopbot'); ?> <code>setCommands</code> <?php esc_html_e('همگام می‌شود.', 'zarinshopbot'); ?></li>
                            </ul>
                        </div>
                    </div>
                </section>

                </form>
                <?php foreach (array('bale', 'rubika') as $channel_tab) : ?>
                    <section class="zarin-tab-pane <?php echo ($active_tab === $channel_tab) ? 'is-active' : ''; ?>" id="tab-<?php echo esc_attr($channel_tab); ?>" role="tabpanel" data-channel-pane="<?php echo esc_attr($channel_tab); ?>" aria-busy="false">
                        <?php if ($is_channel_tab && $active_tab === $channel_tab) : ?>
                            <?php \ZarinShopBot\Channels::render_settings_content($channel_tab); ?>
                        <?php else : ?>
                            <div class="zarin-card zarin-channel-loading" role="status"><span class="dashicons dashicons-update spin" aria-hidden="true"></span> <?php esc_html_e('Loading channel settings…', 'zarinshopbot'); ?></div>
                        <?php endif; ?>
                    </section>
                <?php endforeach; ?>
            </main>
        </div>

        <!-- Sticky Footer Action Bar; the same partial is used by Bale and Rubika. -->
        <?php
        $settings_save_bar = array(
            'form' => 'zarin_settings_form',
            'hint' => __('All changes across all tabs will be saved with this button.', 'zarinshopbot'),
            'hidden' => $is_channel_tab,
        );
        require __DIR__ . '/partials/settings-save-bar.php';
        unset($settings_save_bar);
        ?>
</div>
