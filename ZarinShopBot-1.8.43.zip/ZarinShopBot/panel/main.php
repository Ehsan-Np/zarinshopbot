<?php
/* Modified 2026-10-23 by Ehsan NaderiPanah (Zarincode.com). Derived code remains under GPL-2.0-or-later; bundled notices and compatibility identifiers are retained. */
if (!defined('ABSPATH')) exit;
// Included by zarincode_render_main_panel(); template locals are renderer-scoped.
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

if (defined('ZARINCODE_MAIN_PANEL_LOADED')) {
    return;
}
define('ZARINCODE_MAIN_PANEL_LOADED', true);

if (!current_user_can('manage_options')) {
    wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'zarinshopbot'));
}

zarincode_footer_text_call();

global $wpdb;

// -------------------------------------------------------------
// Auto-deduplication of legacy duplicate records
// -------------------------------------------------------------
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$dup_user_ids = $wpdb->get_col("
    SELECT p1.ID
    FROM {$wpdb->posts} p1
    INNER JOIN {$wpdb->posts} p2 ON p1.post_title = p2.post_title 
        AND p1.post_type = p2.post_type 
        AND p1.ID < p2.ID
    WHERE p1.post_type = 'zarincode_user'
");
if (!empty($dup_user_ids)) {
    foreach ($dup_user_ids as $did) {
        wp_delete_post((int)$did, true);
    }
}

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$dup_grp_ids = $wpdb->get_col("
    SELECT p1.ID
    FROM {$wpdb->posts} p1
    INNER JOIN {$wpdb->posts} p2 ON p1.post_title = p2.post_title 
        AND p1.post_type = p2.post_type 
        AND p1.ID < p2.ID
    WHERE p1.post_type = 'zarincode_group'
");
if (!empty($dup_grp_ids)) {
    foreach ($dup_grp_ids as $did) {
        wp_delete_post((int)$did, true);
    }
}

// -------------------------------------------------------------
// Actions Processing (Delete user, Clear logs, Send broadcast)
// -------------------------------------------------------------
$notice = null;

// 1. Delete single subscriber
if (isset($_GET['action']) && sanitize_key(wp_unslash($_GET['action'])) === 'delete_user' && isset($_GET['user_id'])) {
    $user_id = absint(wp_unslash($_GET['user_id']));
    if (check_admin_referer('delete_user_' . $user_id)) {
        wp_delete_post($user_id, true);
        $notice = [
            'type'    => 'success',
            'message' => __('Subscriber was successfully deleted.', 'zarinshopbot')
        ];
    }
}

// 2. Delete single group
if (isset($_GET['action']) && sanitize_key(wp_unslash($_GET['action'])) === 'delete_group' && isset($_GET['group_id'])) {
    $group_id = absint(wp_unslash($_GET['group_id']));
    if (check_admin_referer('delete_group_' . $group_id)) {
        wp_delete_post($group_id, true);
        $notice = [
            'type'    => 'success',
            'message' => __('Group was successfully deleted.', 'zarinshopbot')
        ];
    }
}

// 3. Clear logs
if (isset($_GET['action']) && sanitize_key(wp_unslash($_GET['action'])) === 'clear_logs') {
    if (check_admin_referer('clear_bot_logs')) {
        delete_option('wp_zarincode_log');
        delete_option('wp_zarincode_structured_logs');
        delete_option('wp_zarincode_activity_log');
        $notice = [
            'type'    => 'success',
            'message' => __('All activity logs have been cleared.', 'zarinshopbot')
        ];
    }
}

// 4. Handle Broadcast Message POST
if (isset($_SERVER['REQUEST_METHOD']) && sanitize_key(wp_unslash($_SERVER['REQUEST_METHOD'])) === 'POST' && isset($_POST['telegram_new_message'])) {
    if (check_admin_referer('zarincode_broadcast_action', 'zarincode_broadcast_nonce')) {
        $message = class_exists(\ZarinShopBot\Message_Editor::class)
            ? \ZarinShopBot\Message_Editor::sanitize(wp_unslash($_POST['telegram_new_message']))
            : wp_kses_post(wp_unslash($_POST['telegram_new_message']));
        $target  = isset($_POST['telegram_target']) ? absint(wp_unslash($_POST['telegram_target'])) : 0;
        
        $platforms_present = !empty($_POST['broadcast_platforms_present']);
        $platforms = $platforms_present
            ? (isset($_POST['broadcast_platforms']) ? array_map('sanitize_key', array_filter((array) wp_unslash($_POST['broadcast_platforms']), 'is_scalar')) : array())
            : 'all';
        $enabled_platforms = zarincode_normalize_broadcast_platforms($platforms);
        if (empty(trim($message))) {
            $notice = array('type' => 'error', 'message' => __('Message content cannot be empty.', 'zarinshopbot'));
        } elseif (empty($enabled_platforms)) {
            $notice = array('type' => 'error', 'message' => __('Select at least one configured and enabled messaging platform.', 'zarinshopbot'));
        } elseif ($target === 4 && !in_array('telegram', $enabled_platforms, true)) {
            $notice = array('type' => 'error', 'message' => __('Telegram Channel target requires Telegram to be enabled and selected.', 'zarinshopbot'));
        } else {
            $queue_available = function_exists('as_enqueue_async_action') && !defined('ZARINCODE_PROCESSING_BROADCAST');
            $sent_count = zarincode_sendmessage_touser_switch($target, $message, 0, $enabled_platforms);
            if ($sent_count === false) {
                $notice = array('type' => 'error', 'message' => __('The broadcast could not be queued. Please check Action Scheduler.', 'zarinshopbot'));
            } elseif ($queue_available) {
                $notice = array('type' => 'success', 'message' => __('Broadcast queued for delivery. Provider acceptance will be recorded separately when available.', 'zarinshopbot'));
            } else {
                $notice = array(
                    'type' => 'success',
                    // translators: %d: Recipient delivery attempts
                    'message' => sprintf(esc_html__('Delivery attempts were made for %d recipient(s); this count does not confirm provider acceptance.', 'zarinshopbot'), (int) $sent_count)
                );
            }
        }
    }
}

// -------------------------------------------------------------
// Data & Metrics Aggregation
// -------------------------------------------------------------
$options        = get_option('zarincode_settings', array());
$bot_token      = function_exists('zarincode_get_telegram_token') ? trim(zarincode_get_telegram_token($options)) : (isset($options['token']) ? trim($options['token']) : '');
$bot_username   = isset($options['username']) ? trim($options['username']) : '';
$channel_user   = isset($options['channelusername']) ? trim($options['channelusername']) : '';
$is_test_mode   = isset($options['testmod']) && $options['testmod'] === 'yes';
$telegram_enabled = function_exists('zarincode_telegram_enabled') && zarincode_telegram_enabled();
$broadcast_channel_options = class_exists(\ZarinShopBot\Channels::class) ? \ZarinShopBot\Channels::options() : array();
$broadcast_platform_availability = array(
    'telegram' => function_exists('zarincode_telegram_enabled') && zarincode_telegram_enabled(),
    'bale' => !empty($broadcast_channel_options['bale_enabled']) && !empty($broadcast_channel_options['bale_token']),
    'rubika' => !empty($broadcast_channel_options['rubika_enabled']) && !empty($broadcast_channel_options['rubika_token']),
);
$ssl_active     = is_ssl();

// Distinct Subscribers & Groups Counts
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$sub_count = (int)$wpdb->get_var("
    SELECT COUNT(DISTINCT post_title) FROM {$wpdb->posts}
    WHERE post_type = 'zarincode_user' AND post_status != 'trash'
");

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$grp_count = (int)$wpdb->get_var("
    SELECT COUNT(DISTINCT post_title) FROM {$wpdb->posts}
    WHERE post_type = 'zarincode_group' AND post_status != 'trash'
");

// Multi-platform WooCommerce sales (HPOS-compatible via WooBot Repository)
if (class_exists(\ZarinShopBot\Core\WooBot::class) && method_exists(\ZarinShopBot\Core\WooBot::class, 'getBotSalesStats')) {
    $sales_data       = \ZarinShopBot\Core\WooBot::getBotSalesStats();
    $bot_orders_count = isset($sales_data['total_orders']) ? (int)$sales_data['total_orders'] : 0;
    $bot_revenue      = isset($sales_data['total_revenue']) ? (float)$sales_data['total_revenue'] : 0.0;
    $today_sales      = isset($sales_data['today_sales']) ? (float)$sales_data['today_sales'] : 0.0;
    $month_sales      = isset($sales_data['month_sales']) ? (float)$sales_data['month_sales'] : 0.0;
    $payment_methods  = isset($sales_data['payment_methods']) && is_array($sales_data['payment_methods']) ? $sales_data['payment_methods'] : [];
    $conversion_rate  = isset($sales_data['conversion_rate']) ? (float)$sales_data['conversion_rate'] : 0.0;
    $platform_sales = isset($sales_data['platform_sales']) && is_array($sales_data['platform_sales']) ? $sales_data['platform_sales'] : array();
    $currency_totals = isset($sales_data['currency_totals']) && is_array($sales_data['currency_totals']) ? $sales_data['currency_totals'] : array();
    $top_products     = method_exists(\ZarinShopBot\Core\WooBot::class, 'getBotTopProducts') ? \ZarinShopBot\Core\WooBot::getBotTopProducts(5) : \ZarinShopBot\Core\WooBot::getTelegramTopProducts(5);
} else {
    $bot_orders_count = 0;
    $bot_revenue      = 0.0;
    $today_sales      = 0.0;
    $month_sales      = 0.0;
    $payment_methods  = [];
    $conversion_rate  = 0.0;
    $platform_sales   = array();
    $currency_totals  = array();
    $top_products     = [];
}

$empty_platform_sales = array('orders' => 0, 'revenue' => 0.0, 'today_revenue' => 0.0, 'month_revenue' => 0.0);
foreach (array('telegram', 'bale', 'rubika') as $sales_platform) {
    $platform_sales[$sales_platform] = array_merge($empty_platform_sales, isset($platform_sales[$sales_platform]) && is_array($platform_sales[$sales_platform]) ? $platform_sales[$sales_platform] : array());
    if (!isset($platform_sales[$sales_platform]['currencies']) || !is_array($platform_sales[$sales_platform]['currencies'])) { $platform_sales[$sales_platform]['currencies'] = array(); }
}

/** Format dashboard revenue as amount then currency symbol, independent of WooCommerce currency_pos. */
if (!function_exists('zarincode_format_revenue_amount')) {
    function zarincode_format_revenue_amount($amount, $currency = '') {
        $currency = strtoupper(sanitize_text_field((string) $currency));
        if ($currency === '' && function_exists('get_woocommerce_currency')) $currency = (string) get_woocommerce_currency();
        $currency = strtoupper($currency);
        $symbol = function_exists('get_woocommerce_currency_symbol') ? (string) get_woocommerce_currency_symbol($currency) : $currency;
        $symbol = html_entity_decode(wp_strip_all_tags($symbol), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8');
        $formatted = function_exists('wc_price') ? wc_price((float) $amount, array('currency' => $currency)) : '';
        if ($formatted !== '') {
            $number = html_entity_decode(wp_strip_all_tags($formatted), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8');
            $number = preg_replace('/[\\x{200E}\\x{200F}\\x{202A}-\\x{202E}\\x{2066}-\\x{2069}]/u', '', $number);
            if ($symbol !== '') $number = str_replace($symbol, '', $number);
            $nbsp = html_entity_decode('&nbsp;', ENT_QUOTES, 'UTF-8');
            $nnbsp = html_entity_decode('&#8239;', ENT_QUOTES, 'UTF-8');
            $number = trim(preg_replace('/\\s+/u', ' ', str_replace(array($nbsp, $nnbsp), ' ', $number)));
        } else {
            $decimals = function_exists('wc_get_price_decimals') ? (int) wc_get_price_decimals() : 2;
            $decimal_sep = function_exists('wc_get_price_decimal_separator') ? wc_get_price_decimal_separator() : get_option('woocommerce_price_decimal_sep', '.');
            $thousand_sep = function_exists('wc_get_price_thousand_separator') ? wc_get_price_thousand_separator() : get_option('woocommerce_price_thousand_sep', ',');
            $number = number_format((float) $amount, max(0, $decimals), (string) $decimal_sep, (string) $thousand_sep);
        }
        if ($symbol === '') $symbol = $currency;
        return ' ' . trim($number) . ' ' . trim($symbol) . ' ';
    }
}

if (!function_exists('zarincode_revenue_value_markup')) {
    function zarincode_revenue_value_markup($amount, $currency = '') {
        return '<bdi class="zarin-revenue-value" dir="ltr">' . esc_html(zarincode_format_revenue_amount($amount, $currency)) . '</bdi>';
    }
}

if (!function_exists('zarincode_revenue_with_label_markup')) {
    function zarincode_revenue_with_label_markup($label, $amount, $currency = '') {
        $safe_markup = zarincode_revenue_value_markup($amount, $currency);
        return wp_kses(sprintf((string) $label, $safe_markup), array('bdi' => array('class' => true, 'dir' => true)));
    }
}

// Normalize legacy Telegram-only records with structured cross-platform activity.
require_once dirname(__DIR__) . '/includes/class-zarinshopbot-activity-logs.php';
$log_source = isset($_GET['source']) ? sanitize_key(wp_unslash($_GET['source'])) : 'all';
$log_data = ZarinShopBot_Activity_Logs::query($log_source);
$logs = $log_data['entries'];
$log_counts = $log_data['counts'];
$log_source = $log_data['source'];
$logs_count = count($logs);
$proxy_health = class_exists(\ZarinShopBot\Core\Http\ProxyManager::class) ? \ZarinShopBot\Core\Http\ProxyManager::health() : [];
$proxy_profiles = class_exists(\ZarinShopBot\Core\Http\ProxyManager::class) ? \ZarinShopBot\Core\Http\ProxyManager::profiles() : [];

// Active Tab
$current_tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'overview';
$tabs = array(
    'overview'    => array('name' => __('Overview & Stats', 'zarinshopbot'), 'icon' => 'dashicons-dashboard'),
    'broadcast'   => array('name' => __('Broadcast Message', 'zarinshopbot'), 'icon' => 'dashicons-megaphone'),
    'subscribers' => array('name' => __('Subscribers & Groups', 'zarinshopbot'), 'icon' => 'dashicons-admin-users'),
    'logs'        => array('name' => __('Activity Logs', 'zarinshopbot'), 'icon' => 'dashicons-list-view'),
);

if (!isset($tabs[$current_tab])) {
    $current_tab = 'overview';
}

// Active Audience Sub-tab (Users vs Groups)
$audience_subtab = isset($_GET['view']) && sanitize_key(wp_unslash($_GET['view'])) === 'groups' ? 'groups' : 'users';
?>

<div class="wrap zarin-hub-wrap" dir="rtl">
    <!-- Hub Header -->
    <header class="zarin-hub-header">
        <div class="zarin-hub-header-main">
            <div class="zarin-hub-brand">
                <div class="zarin-hub-logo-icon" style="background:transparent;padding:0;display:flex;align-items:center;justify-content:center;">
                    <img src="<?php echo esc_url(plugins_url('img/zarinshopbot-icon.svg', dirname(__DIR__) . '/zarinshopbot.php')); ?>" width="38" height="38" alt="ZarinShopBot" style="border-radius:9px;box-shadow:0 4px 12px rgba(253, 208, 91, 0.35);display:block;">
                </div>
                <div class="zarin-hub-brand-text">
                    <div class="zarin-hub-title-row">
                        <h1><?php esc_html_e('ربات زرین شاپ | ZarinShopBot', 'zarinshopbot'); ?></h1>
                        <span class="zarin-hub-version-badge">v<?php echo esc_html(defined('ZARINSHOPBOT_VERSION') ? ZARINSHOPBOT_VERSION : '1.8.43'); ?></span>
                    </div>
                    <p class="zarin-hub-subtitle"><?php esc_html_e('Centralized hub for Telegram, Bale and Rubika sales, audiences, broadcasts and activity.', 'zarinshopbot'); ?></p>
                </div>
            </div>

            <!-- Bot Quick Meta -->
            <div class="zarin-hub-quick-meta">
                <?php if (!empty($bot_username)): ?>
                    <a href="https://t.me/<?php echo esc_attr($bot_username); ?>" target="_blank" class="zarin-hub-bot-badge" title="<?php esc_attr_e('Open Bot in Telegram', 'zarinshopbot'); ?>">
                        <span class="dashicons dashicons-external"></span>
                        @<?php echo esc_html($bot_username); ?>
                    </a>
                <?php endif; ?>

                <?php if ($telegram_enabled): ?>
                    <span class="zarin-hub-status-pill online">
                        <span class="zarin-pulse-dot"></span>
                        <?php esc_html_e('Telegram enabled; API/webhook not verified', 'zarinshopbot'); ?>
                    </span>
                <?php elseif (!empty($bot_token)): ?>
                    <span class="zarin-hub-status-pill offline"><?php esc_html_e('Telegram is disabled in settings', 'zarinshopbot'); ?></span>
                <?php else: ?>
                    <span class="zarin-hub-status-pill offline"><?php esc_html_e('Telegram token not configured', 'zarinshopbot'); ?></span>
                <?php endif; ?>

                <a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_zarinshopbot_setting')); ?>" class="zarin-btn-hub-settings">
                    <span class="dashicons dashicons-admin-generic"></span>
                    <?php esc_html_e('Settings', 'zarinshopbot'); ?>
                </a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_guide')); ?>" class="zarin-btn-hub-settings">
                    <span class="dashicons dashicons-book"></span>
                    <?php esc_html_e('راهنمای افزونه', 'zarinshopbot'); ?>
                </a>
            </div>
        </div>

        <!-- Navigation Tabs -->
        <nav class="zarin-hub-tabs">
            <?php foreach ($tabs as $key => $tab): 
                $is_active = ($current_tab === $key);
                $tab_url = add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => $key), admin_url('admin.php'));
            ?>
                <a href="<?php echo esc_url($tab_url); ?>" class="zarin-hub-tab-item <?php echo $is_active ? 'active' : ''; ?>">
                    <span class="dashicons <?php echo esc_attr($tab['icon']); ?>"></span>
                    <span class="zarin-hub-tab-text"><?php echo esc_html($tab['name']); ?></span>
                    <?php if ($key === 'subscribers' && ($sub_count + $grp_count) > 0): ?>
                        <span class="zarin-hub-tab-badge"><?php echo esc_html(number_format_i18n($sub_count + $grp_count)); ?></span>
                    <?php elseif ($key === 'logs' && $logs_count > 0): ?>
                        <span class="zarin-hub-tab-badge neutral"><?php echo esc_html(number_format_i18n($logs_count)); ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>
    </header>

    <!-- Notices -->
    <?php if ($notice): ?>
        <div class="zarin-hub-notice zarin-hub-notice-<?php echo esc_attr($notice['type']); ?>">
            <span class="dashicons <?php echo $notice['type'] === 'success' ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>"></span>
            <div class="zarin-hub-notice-content">
                <?php echo esc_html($notice['message']); ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Tab Contents -->
    <main class="zarin-hub-body">

        <?php if ($current_tab === 'overview'): ?>
            <!-- ========================================================= -->
            <!-- TAB 1: OVERVIEW & STATS                                   -->
            <!-- ========================================================= -->
            <div class="zarin-overview-grid">
                
                <!-- KPI Stat Cards -->
                <div class="zarin-kpi-card">
                    <div class="zarin-kpi-icon-wrap blue">
                        <span class="dashicons dashicons-admin-users"></span>
                    </div>
                    <div class="zarin-kpi-info">
                        <span class="zarin-kpi-label"><?php esc_html_e('Registered Bot Subscribers', 'zarinshopbot'); ?></span>
                        <h3 class="zarin-kpi-value"><?php echo esc_html(number_format_i18n($sub_count)); ?></h3>
                        <a href="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'subscribers', 'view' => 'users'), admin_url('admin.php'))); ?>" class="zarin-kpi-link">
                            <?php esc_html_e('View all subscribers &rarr;', 'zarinshopbot'); ?>
                        </a>
                    </div>
                </div>

                <div class="zarin-kpi-card">
                    <div class="zarin-kpi-icon-wrap purple">
                        <span class="dashicons dashicons-groups"></span>
                    </div>
                    <div class="zarin-kpi-info">
                        <span class="zarin-kpi-label"><?php esc_html_e('Registered Bot Groups', 'zarinshopbot'); ?></span>
                        <h3 class="zarin-kpi-value"><?php echo esc_html(number_format_i18n($grp_count)); ?></h3>
                        <a href="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'subscribers', 'view' => 'groups'), admin_url('admin.php'))); ?>" class="zarin-kpi-link">
                            <?php esc_html_e('View all groups &rarr;', 'zarinshopbot'); ?>
                        </a>
                    </div>
                </div>

                <div class="zarin-kpi-card">
                    <div class="zarin-kpi-icon-wrap green">
                        <span class="dashicons dashicons-cart"></span>
                    </div>
                    <div class="zarin-kpi-info">
                        <span class="zarin-kpi-label"><?php esc_html_e('Orders Across All Platforms', 'zarinshopbot'); ?></span>
                        <h3 class="zarin-kpi-value"><?php echo esc_html(number_format_i18n($bot_orders_count)); ?></h3>
                        <span class="zarin-kpi-subtext"><?php esc_html_e('Revenue is shown by platform and currency below.', 'zarinshopbot'); ?></span>
                    </div>
                </div>

                <div class="zarin-kpi-card">
                    <div class="zarin-kpi-icon-wrap orange">
                        <span class="dashicons dashicons-shield"></span>
                    </div>
                    <div class="zarin-kpi-info">
                        <span class="zarin-kpi-label"><?php esc_html_e('Connection Health', 'zarinshopbot'); ?></span>
                        <h3 class="zarin-kpi-value"><?php echo esc_html($ssl_active ? __('Secure (SSL)', 'zarinshopbot') : __('Non-SSL', 'zarinshopbot')); ?></h3>
                        <span class="zarin-kpi-subtext">
                            <?php echo $is_test_mode ? '<span style="color:#ef4444;">' . esc_html__('Test Mode Active', 'zarinshopbot') . '</span>' : esc_html__('Production Ready', 'zarinshopbot'); ?>
                        </span>
                    </div>
                </div>

            </div>

            <section class="zarin-card zarin-platform-sales-panel" aria-labelledby="zarin-platform-sales-title">
                <div class="zarin-card-header">
                    <div class="zarin-card-header-title">
                        <span class="dashicons dashicons-chart-bar" aria-hidden="true"></span>
                        <h3 id="zarin-platform-sales-title"><?php esc_html_e('Sales by Platform', 'zarinshopbot'); ?></h3>
                    </div>
                    <p class="zarin-platform-sales-note"><?php esc_html_e('Orders are attributed by the platform that created them, not by the payment gateway. Only processing and completed WooCommerce orders are included.', 'zarinshopbot'); ?></p>
                </div>
                <div class="zarin-platform-sales-grid">
                    <?php
                    $sales_platform_labels = array(
                        'telegram' => __('Telegram', 'zarinshopbot'),
                        'bale' => __('Bale', 'zarinshopbot'),
                        'rubika' => __('Rubika', 'zarinshopbot'),
                    );
                    foreach ($sales_platform_labels as $sales_platform => $sales_platform_label):
                        $channel_sales = $platform_sales[$sales_platform];
                        $sales_icon = plugins_url('assets/icons/' . $sales_platform . '.svg', dirname(__DIR__) . '/zarinshopbot.php');
                    ?>
                        <article class="zarin-platform-sales-card zarin-platform-sales-<?php echo esc_attr($sales_platform); ?>">
                            <header class="zarin-platform-sales-brand">
                                <img src="<?php echo esc_url($sales_icon); ?>" width="30" height="30" alt="" aria-hidden="true">
                                <strong><?php echo esc_html($sales_platform_label); ?></strong>
                            </header>
                            <div class="zarin-platform-sales-metric">
                                <span><?php esc_html_e('Processing + Completed Orders', 'zarinshopbot'); ?></span>
                                <b><?php echo esc_html(number_format_i18n((int) $channel_sales['orders'])); ?></b>
                            </div>
                            <?php if (!empty($channel_sales['currencies'])): foreach ($channel_sales['currencies'] as $currency_code => $currency_sales): $currency_code = strtoupper(sanitize_text_field((string) $currency_code)); ?>
                                <div class="zarin-platform-sales-metric is-revenue">
                                    <span><?php echo esc_html(sprintf(__('Revenue (%s)', 'zarinshopbot'), $currency_code)); ?></span>
                                    <b><?php echo zarincode_revenue_value_markup((float) $currency_sales['revenue'], $currency_code); ?></b>
                                </div>
                                <div class="zarin-platform-sales-periods">
                                    <span><?php echo zarincode_revenue_with_label_markup(__('Today: %s', 'zarinshopbot'), (float) $currency_sales['today_revenue'], $currency_code); ?></span>
                                    <span><?php echo zarincode_revenue_with_label_markup(__('This Month: %s', 'zarinshopbot'), (float) $currency_sales['month_revenue'], $currency_code); ?></span>
                                </div>
                            <?php endforeach; else: ?>
                                <p class="zarin-platform-sales-empty"><?php esc_html_e('No paid order revenue for this platform yet.', 'zarinshopbot'); ?></p>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Overview Two Columns: Health & Quick Operations -->
            <div class="zarin-split-grid">
                
                <!-- System Health & Connection Details -->
                <div class="zarin-card">
                    <div class="zarin-card-header">
                        <div class="zarin-card-header-title">
                            <span class="dashicons dashicons-admin-generic"></span>
                            <h3><?php esc_html_e('Platform Configuration Status', 'zarinshopbot'); ?></h3>
                        </div>
                    </div>
                    <div class="zarin-card-body">
                        <div class="zarin-health-list">
                            <div class="zarin-health-item">
                                <span class="zarin-health-label"><?php esc_html_e('Telegram Bot Token', 'zarinshopbot'); ?></span>
                                <span class="zarin-health-val">
                                    <?php if (!empty($bot_token) && $telegram_enabled): ?>
                                        <span class="zarin-tag success"><?php esc_html_e('Enabled · configured; not live-tested', 'zarinshopbot'); ?></span>
                                    <?php elseif (!empty($bot_token)): ?>
                                        <span class="zarin-tag warning"><?php esc_html_e('Configured but disabled', 'zarinshopbot'); ?></span>
                                    <?php else: ?>
                                        <span class="zarin-tag error"><?php esc_html_e('Not set', 'zarinshopbot'); ?></span>
                                    <?php endif; ?>
                                </span>
                            </div>
                            <?php foreach (array('bale' => __('Bale', 'zarinshopbot'), 'rubika' => __('Rubika', 'zarinshopbot')) as $health_platform => $health_label):
                                $health_configured = !empty($broadcast_platform_availability[$health_platform]); ?>
                                <div class="zarin-health-item">
                                    <span class="zarin-health-label"><?php echo esc_html($health_label); ?></span>
                                    <span class="zarin-health-val"><span class="zarin-tag <?php echo $health_configured ? 'success' : 'warning'; ?>"><?php echo esc_html($health_configured ? __('Enabled and token configured; not live-tested', 'zarinshopbot') : __('Disabled or not configured', 'zarinshopbot')); ?></span></span>
                                </div>
                            <?php endforeach; ?>

                            <div class="zarin-health-item">
                                <span class="zarin-health-label"><?php esc_html_e('Bot Username', 'zarinshopbot'); ?></span>
                                <span class="zarin-health-val">
                                    <?php if (!empty($bot_username)): ?>
                                        <a href="https://t.me/<?php echo esc_attr($bot_username); ?>" target="_blank" class="zarin-tg-link">@<?php echo esc_html($bot_username); ?></a>
                                    <?php else: ?>
                                        <span class="zarin-text-muted">—</span>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <div class="zarin-health-item">
                                <span class="zarin-health-label"><?php esc_html_e('Telegram Proxy', 'zarinshopbot'); ?></span>
                                <span class="zarin-health-val">
                                    <?php if (empty($proxy_profiles)): ?>
                                        <span class="zarin-tag success"><?php esc_html_e('No proxy configured; direct requests are used', 'zarinshopbot'); ?></span>
                                    <?php else: ?>
                                        <?php $proxy_ok = false; foreach ($proxy_health as $proxy_state) { if (!empty($proxy_state['ok'])) { $proxy_ok = true; break; } } ?>
                                        <span class="zarin-tag <?php echo $proxy_ok ? 'success' : 'warning'; ?>"><?php echo $proxy_ok ? esc_html__('Last recorded proxy test passed', 'zarinshopbot') : esc_html__('No successful proxy test recorded', 'zarinshopbot'); ?></span>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <div class="zarin-health-item">
                                <span class="zarin-health-label"><?php esc_html_e('Telegram webhook URL (local route)', 'zarinshopbot'); ?></span>
                                <span class="zarin-health-val">
                                    <?php if ((string) zarincode_option('mode') === '0' && (string) zarincode_option('testmod') !== 'yes'): ?><code style="font-size:11px;"><?php echo esc_html(home_url('/?' . rawurlencode((string) get_option('zarincode_webhook_key')) . '=1')); ?></code><?php else: ?><span class="zarin-tag warning"><?php esc_html_e('Webhook URL unavailable in the selected mode. A displayed local route does not verify remote registration or delivery.', 'zarinshopbot'); ?></span><?php endif; ?>
                                </span>
                            </div>

                            <div class="zarin-health-item">
                                <span class="zarin-health-label"><?php esc_html_e('Store Channel', 'zarinshopbot'); ?></span>
                                <span class="zarin-health-val">
                                    <?php if (!empty($channel_user)): ?>
                                        <strong><?php echo esc_html($channel_user); ?></strong>
                                    <?php else: ?>
                                        <span class="zarin-text-muted"><?php esc_html_e('Optional', 'zarinshopbot'); ?></span>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                        <p class="description"><?php esc_html_e('These indicators describe saved configuration only. They do not make live API calls or verify webhook delivery.', 'zarinshopbot'); ?></p>
                    </div>
                </div>

                <!-- Navigation Hub: All Options & Modules -->
                <div class="zarin-card">
                    <div class="zarin-card-header">
                        <div class="zarin-card-header-title">
                            <span class="dashicons dashicons-screenoptions"></span>
                            <h3><?php esc_html_e('All Options & Modules', 'zarinshopbot'); ?></h3>
                        </div>
                    </div>
                    <div class="zarin-card-body">
                        <div class="zarin-shortcuts-grid">
                            <a href="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'subscribers', 'view' => 'users'), admin_url('admin.php'))); ?>" class="zarin-shortcut-card">
                                <span class="dashicons dashicons-admin-users"></span>
                                <div class="zarin-shortcut-text">
                                    <strong><?php esc_html_e('Subscribers', 'zarinshopbot'); ?> (<?php echo esc_html(number_format_i18n($sub_count)); ?>)</strong>
                                    <small><?php esc_html_e('View and filter unique subscribers and groups', 'zarinshopbot'); ?></small>
                                </div>
                            </a>

                            <a href="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'subscribers', 'view' => 'groups'), admin_url('admin.php'))); ?>" class="zarin-shortcut-card">
                                <span class="dashicons dashicons-groups"></span>
                                <div class="zarin-shortcut-text">
                                    <strong><?php esc_html_e('Groups', 'zarinshopbot'); ?> (<?php echo esc_html(number_format_i18n($grp_count)); ?>)</strong>
                                    <small><?php esc_html_e('Connected Telegram groups and channels', 'zarinshopbot'); ?></small>
                                </div>
                            </a>

                            <a href="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'broadcast'), admin_url('admin.php'))); ?>" class="zarin-shortcut-card">
                                <span class="dashicons dashicons-megaphone"></span>
                                <div class="zarin-shortcut-text">
                                    <strong><?php esc_html_e('Broadcast Message', 'zarinshopbot'); ?></strong>
                                    <small><?php esc_html_e('Compose and send messages with live Telegram preview', 'zarinshopbot'); ?></small>
                                </div>
                            </a>

                            <a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_zarinshopbot_setting')); ?>" class="zarin-shortcut-card">
                                <span class="dashicons dashicons-admin-settings"></span>
                                <div class="zarin-shortcut-text">
                                    <strong><?php esc_html_e('Settings', 'zarinshopbot'); ?></strong>
                                    <small><?php esc_html_e('Appearance, checkout fields, proxy and bot commands', 'zarinshopbot'); ?></small>
                                </div>
                            </a>

                            <a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_zarinshopbot_setting&tab=webapp')); ?>" class="zarin-shortcut-card">
                                <span class="dashicons dashicons-smartphone"></span>
                                <div class="zarin-shortcut-text">
                                    <strong><?php esc_html_e('Mini App', 'zarinshopbot'); ?></strong>
                                    <small><?php esc_html_e('Telegram Web App settings', 'zarinshopbot'); ?></small>
                                </div>
                            </a>

                            <a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_zarinshopbot_setting&tab=menu')); ?>" class="zarin-shortcut-card">
                                <span class="dashicons dashicons-menu"></span>
                                <div class="zarin-shortcut-text">
                                    <strong><?php esc_html_e('Main Menu', 'zarinshopbot'); ?></strong>
                                    <small><?php esc_html_e('Buttons & Custom Actions', 'zarinshopbot'); ?></small>
                                </div>
                            </a>

                            <a href="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'logs'), admin_url('admin.php'))); ?>" class="zarin-shortcut-card">
                                <span class="dashicons dashicons-list-view"></span>
                                <div class="zarin-shortcut-text">
                                    <strong><?php esc_html_e('Activity Logs', 'zarinshopbot'); ?></strong>
                                    <small><?php esc_html_e('Inspect events, orders and error diagnostics', 'zarinshopbot'); ?></small>
                                </div>
                            </a>

                            <a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_zarinshopbot_setting&tab=proxy')); ?>" class="zarin-shortcut-card">
                                <span class="dashicons dashicons-shield"></span>
                                <div class="zarin-shortcut-text">
                                    <strong><?php esc_html_e('Proxy', 'zarinshopbot'); ?></strong>
                                    <small><?php esc_html_e('Connection Proxy Settings', 'zarinshopbot'); ?></small>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Top Selling Products via Telegram, Bale and Rubika -->
            <div class="zarin-card" style="margin-top: 24px;">
                <div class="zarin-card-header">
                    <div class="zarin-card-header-title">
                        <span class="dashicons dashicons-star-filled"></span>
                        <h3><?php esc_html_e('پرفروش‌ترین محصولات در ربات‌ها', 'zarinshopbot'); ?></h3>
                    </div>
                    <?php if (!empty($currency_totals)): ?>
                        <div class="zarin-card-header-extra zarin-sales-currency-summary">
                            <?php foreach ($currency_totals as $currency_code => $currency_summary): $currency_code = strtoupper(sanitize_text_field((string) $currency_code)); ?>
                                <span><code><?php echo esc_html($currency_code); ?></code> · <?php echo zarincode_revenue_with_label_markup(__('Today: %s', 'zarinshopbot'), (float) $currency_summary['today_revenue'], $currency_code); ?> · <?php echo zarincode_revenue_with_label_markup(__('This Month: %s', 'zarinshopbot'), (float) $currency_summary['month_revenue'], $currency_code); ?></span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="zarin-card-body" style="padding: 0;">
                    <?php if (!empty($top_products)): ?>
                        <table class="wp-list-table widefat fixed striped" style="border: none; box-shadow: none;">
                            <thead>
                                <tr>
                                    <th style="width: 60px;"><?php esc_html_e('Image', 'zarinshopbot'); ?></th>
                                    <th><?php esc_html_e('Product Name', 'zarinshopbot'); ?></th>
                                    <th><?php esc_html_e('Price', 'zarinshopbot'); ?></th>
                                    <th><?php esc_html_e('فروش از ربات', 'zarinshopbot'); ?></th>
                                    <th style="width: 100px;"><?php esc_html_e('Action', 'zarinshopbot'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_products as $p): ?>
                                    <tr>
                                        <td>
                                            <?php if (!empty($p['image'])): ?>
                                                <img src="<?php echo esc_url($p['image']); ?>" width="40" height="40" style="border-radius: 6px; object-fit: cover;">
                                            <?php else: ?>
                                                <span class="dashicons dashicons-format-image" style="font-size: 32px; color: #cbd5e1;"></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?php echo esc_html($p['name']); ?></strong>
                                        </td>
                                        <td><?php echo wp_kses_post($p['price']); ?></td>
                                        <td>
                                            <span class="zarin-tag success">
                                                <?php // translators: %d: Units sold count
echo esc_html(sprintf(__('%d Units Sold', 'zarinshopbot'), (int)$p['sales'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url(get_edit_post_link($p['id'])); ?>" class="button button-small">
                                                <?php esc_html_e('Edit', 'zarinshopbot'); ?>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div style="padding: 32px; text-align: center; color: #64748b;">
                            <span class="dashicons dashicons-cart" style="font-size: 36px; height: 36px; margin-bottom: 8px;"></span>
                            <p><?php esc_html_e('هنوز فروش پرداخت‌شده‌ای از بات‌ها ثبت نشده است.', 'zarinshopbot'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="zarin-card" style="margin-top:24px">
                <div class="zarin-card-header">
                    <div class="zarin-card-header-title"><span class="dashicons dashicons-money-alt"></span><h3><?php esc_html_e('فروش ثبت‌شده بر اساس روش پرداخت', 'zarinshopbot'); ?></h3></div>
                </div>
                <div class="zarin-card-body" style="padding:0">
                    <?php if (!empty($payment_methods)) : ?>
                        <table class="wp-list-table widefat fixed striped" style="border:0;box-shadow:none">
                            <thead><tr><th><?php esc_html_e('Platform', 'zarinshopbot'); ?></th><th><?php esc_html_e('روش پرداخت ووکامرس', 'zarinshopbot'); ?></th><th><?php esc_html_e('شناسه روش', 'zarinshopbot'); ?></th><th><?php esc_html_e('سفارش‌های پرداخت‌شده', 'zarinshopbot'); ?></th><th><?php esc_html_e('Currency', 'zarinshopbot'); ?></th><th><?php esc_html_e('جمع مبالغ سفارش', 'zarinshopbot'); ?></th></tr></thead>
                            <tbody><?php foreach ($payment_methods as $payment_method) : ?>
                                <tr>
                                    <td><?php echo esc_html(array('telegram' => 'Telegram', 'bale' => 'Bale', 'rubika' => 'Rubika')[$payment_method['platform'] ?? ''] ?? __('Unknown', 'zarinshopbot')); ?></td>
                                    <td><strong><?php echo esc_html($payment_method['title'] ?? ''); ?></strong></td>
                                    <td><code dir="ltr"><?php echo esc_html($payment_method['id'] ?? 'unknown'); ?></code></td>
                                    <td><?php echo esc_html(number_format_i18n((int) ($payment_method['orders'] ?? 0))); ?></td>
                                    <td><code dir="ltr"><?php echo esc_html($payment_method['currency'] ?? ''); ?></code></td>
                                    <td><?php echo zarincode_revenue_value_markup((float) ($payment_method['amount'] ?? 0), $payment_method['currency'] ?? ''); ?></td>
                                </tr>
                            <?php endforeach; ?></tbody>
                        </table>
                    <?php else : ?>
                        <p style="padding:20px"><?php esc_html_e('هنوز پرداخت تکمیل‌شده‌ای برای سفارش‌های بات ثبت نشده است.', 'zarinshopbot'); ?></p>
                    <?php endif; ?>
                    <p class="description" style="padding:0 20px 14px"><?php esc_html_e('گزارش از سفارش‌های تلگرام، بله و روبیکا با وضعیت پردازش/تکمیل‌شده و روش پرداخت ثبت‌شده در ووکامرس ساخته می‌شود. مبلغ تراکنش، شناسهٔ پرداخت و وضعیت نهایی هر سفارش در پروندهٔ همان سفارش نگهداری می‌شود؛ بازپرداخت‌ها را در گزارش‌های استاندارد ووکامرس نیز بررسی کنید.', 'zarinshopbot'); ?></p>
                </div>
            </div>

        <?php elseif ($current_tab === 'broadcast'): ?>
            <!-- ========================================================= -->
            <!-- TAB 2: BROADCAST STUDIO (Interactive Composer & Live Mockup)-->
            <!-- ========================================================= -->
            <div class="zarin-broadcast-studio">
                
                <!-- Left: Composer Form -->
                <div class="zarin-card zarin-composer-card">
                    <div class="zarin-card-header">
                        <div class="zarin-card-header-title">
                            <span class="dashicons dashicons-megaphone"></span>
                            <h3><?php esc_html_e('Compose Broadcast Message', 'zarinshopbot'); ?></h3>
                        </div>
                    </div>
                    <div class="zarin-card-body">
                        <form method="post" id="zarin-broadcast-form">
                            <?php wp_nonce_field('zarincode_broadcast_action', 'zarincode_broadcast_nonce'); ?>

                            <input type="hidden" name="broadcast_platforms_present" value="1">
                            <div class="zarin-form-group">
                                <label class="zarin-form-label"><?php esc_html_e('Send through', 'zarinshopbot'); ?></label>
                                <p class="description"><?php esc_html_e('Choose one or more enabled bots. Subscriber and group IDs are filtered by their source platform; the Telegram channel target is Telegram-only.', 'zarinshopbot'); ?></p>
                                <div class="zarin-target-grid zarin-platform-target-grid">
                                    <?php foreach (array('telegram' => 'Telegram', 'bale' => 'Bale', 'rubika' => 'Rubika') as $broadcast_platform => $broadcast_label): $broadcast_enabled = !empty($broadcast_platform_availability[$broadcast_platform]); $broadcast_icon = plugins_url('assets/icons/' . $broadcast_platform . '.svg', dirname(__DIR__) . '/zarinshopbot.php'); ?>
                                        <label class="zarin-target-card<?php echo $broadcast_enabled ? '' : ' is-disabled'; ?>">
                                            <input type="checkbox" name="broadcast_platforms[]" value="<?php echo esc_attr($broadcast_platform); ?>" <?php checked($broadcast_enabled); ?> <?php disabled(!$broadcast_enabled); ?>>
                                            <div class="zarin-target-content">
                                                <img class="zarin-platform-target-icon" src="<?php echo esc_url($broadcast_icon); ?>" width="24" height="24" alt="" aria-hidden="true">
                                                <strong class="zarin-target-title"><?php echo esc_html($broadcast_label); ?></strong>
                                                <div class="zarin-target-desc"><?php echo esc_html($broadcast_enabled ? __('Enabled', 'zarinshopbot') : __('Configure and enable this bot in settings', 'zarinshopbot')); ?></div>
                                            </div>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <!-- Target Selection -->
                            <div class="zarin-form-group">
                                <label class="zarin-form-label"><?php esc_html_e('Select Target Audience', 'zarinshopbot'); ?></label>
                                <div class="zarin-target-grid">
                                    <label class="zarin-target-card">
                                        <input type="radio" name="telegram_target" value="0" checked="checked">
                                        <div class="zarin-target-content">
                                            <span class="dashicons dashicons-networking"></span>
                                            <div class="zarin-target-title"><?php esc_html_e('All Audience', 'zarinshopbot'); ?></div>
                                            <div class="zarin-target-desc"><?php esc_html_e('Selected platforms: users and groups; Telegram channel when selected', 'zarinshopbot'); ?></div>
                                        </div>
                                    </label>

                                    <label class="zarin-target-card">
                                        <input type="radio" name="telegram_target" value="1">
                                        <div class="zarin-target-content">
                                            <span class="dashicons dashicons-admin-users"></span>
                                            <div class="zarin-target-title"><?php esc_html_e('Subscribers Only', 'zarinshopbot'); ?></div>
                                            <div class="zarin-target-desc"><?php // translators: %d: Registered user count
echo esc_html(sprintf(__('%d registered users', 'zarinshopbot'), (int)$sub_count)); ?></div>
                                        </div>
                                    </label>

                                    <label class="zarin-target-card">
                                        <input type="radio" name="telegram_target" value="2">
                                        <div class="zarin-target-content">
                                            <span class="dashicons dashicons-groups"></span>
                                            <div class="zarin-target-title"><?php esc_html_e('Groups Only', 'zarinshopbot'); ?></div>
                                            <div class="zarin-target-desc"><?php // translators: %d: Registered group count
echo esc_html(sprintf(__('%d registered groups', 'zarinshopbot'), (int)$grp_count)); ?></div>
                                        </div>
                                    </label>

                                    <label class="zarin-target-card">
                                        <input type="radio" name="telegram_target" value="4" <?php disabled(empty($broadcast_platform_availability['telegram'])); ?>>
                                        <div class="zarin-target-content">
                                            <span class="dashicons dashicons-megaphone"></span>
                                            <div class="zarin-target-title"><?php esc_html_e('Telegram Channel', 'zarinshopbot'); ?></div>
                                            <div class="zarin-target-desc"><?php echo !empty($channel_user) ? esc_html($channel_user) : esc_html__('Not set', 'zarinshopbot'); ?></div>
                                        </div>
                                    </label>
                                </div>
                            </div>

                            <!-- Visual broadcast composer -->
                            <div class="zarin-form-group">
                                <label class="zarin-form-label" for="telegram_new_message"><?php esc_html_e('Message Content', 'zarinshopbot'); ?></label>
                                <?php \ZarinShopBot\Message_Editor::render('telegram_new_message', 'telegram_new_message', '', 8, 'customer'); ?>
                                <div class="zarin-composer-footer">
                                    <div class="zarin-char-counter"><span id="zarin-char-count">0</span> / 4096 <?php esc_html_e('characters', 'zarinshopbot'); ?></div>
                                    <p class="zarin-help-text"><?php esc_html_e('متغیرهای نام و شناسه برای پیام‌های خصوصی/گروهی جایگزین می‌شوند؛ برای ارسال به کانال، اطلاعات فردی وجود ندارد.', 'zarinshopbot'); ?></p>
                                </div>
                            </div>

                            <!-- Send Action -->
                            <div class="zarin-form-actions">
                                <button type="submit" class="zarin-btn-primary zarin-btn-lg" id="zarin-send-btn">
                                    <span class="dashicons dashicons-controls-play"></span>
                                    <?php esc_html_e('Send Broadcast Now', 'zarinshopbot'); ?>
                                </button>
                                <span class="zarin-help-text" style="margin-right:15px;">
                                    <?php esc_html_e('Messages will be dispatched in background queue.', 'zarinshopbot'); ?>
                                </span>
                            </div>

                        </form>
                    </div>
                </div>

                <!-- Right: Telegram Live Mobile Mockup -->
                <div class="zarin-preview-container">
                    <div class="zarin-telegram-phone">
                        <!-- Phone Notch / Speaker -->
                        <div class="zarin-phone-notch">
                            <span class="zarin-phone-speaker"></span>
                        </div>

                        <!-- Telegram Chat Header -->
                        <div class="zarin-telegram-header">
                            <div class="zarin-tg-back"><span class="dashicons dashicons-arrow-right-alt2"></span></div>
                            <div class="zarin-tg-avatar">
                                <img src="<?php echo esc_url(plugins_url('assets/icons/telegram.svg', dirname(__DIR__) . '/zarinshopbot.php')); ?>" width="22" height="22" alt="" aria-hidden="true">
                            </div>
                            <div class="zarin-tg-info">
                                <div class="zarin-tg-title"><?php echo !empty($bot_username) ? esc_html($bot_username) : esc_html__('ZarinShopBot Shop Bot', 'zarinshopbot'); ?></div>
                                <div class="zarin-tg-status"><?php esc_html_e('bot', 'zarinshopbot'); ?></div>
                            </div>
                            <div class="zarin-tg-actions">
                                <span class="dashicons dashicons-ellipsis"></span>
                            </div>
                        </div>

                        <!-- Telegram Chat Screen -->
                        <div class="zarin-telegram-canvas">
                            <div class="zarin-tg-date-badge"><?php esc_html_e('Today', 'zarinshopbot'); ?></div>

                            <!-- Dynamic Chat Bubble -->
                            <div class="zarin-tg-bubble">
                                <div class="zarin-tg-message-text" id="zarin-tg-live-preview">
                                    <?php esc_html_e('Your live message preview will appear here in real time as you type...', 'zarinshopbot'); ?>
                                </div>
                                <div class="zarin-tg-meta">
                                    <span class="zarin-tg-time" id="zarin-tg-live-time"><?php echo esc_html(gmdate('H:i')); ?></span>
                                    <span class="zarin-tg-checks">✓✓</span>
                                </div>
                            </div>
                        </div>

                        <!-- Bottom Home Bar -->
                        <div class="zarin-phone-home-bar"></div>
                    </div>
                    <p class="zarin-preview-hint"><?php esc_html_e('Real-time Telegram phone preview with Markdown parsing', 'zarinshopbot'); ?></p>
                </div>

            </div>

        <?php elseif ($current_tab === 'subscribers'): ?>
            <!-- ========================================================= -->
            <!-- TAB 3: SUBSCRIBERS & GROUPS (Audience Manager)            -->
            <!-- ========================================================= -->
            <div class="zarin-card">
                <div class="zarin-card-header">
                    <div class="zarin-card-header-title">
                        <span class="dashicons dashicons-admin-users"></span>
                        <h3><?php esc_html_e('Audience Management', 'zarinshopbot'); ?></h3>
                    </div>

                    <!-- Sub-navigation: Users vs Groups -->
                    <div class="zarin-sub-pills">
                        <a href="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'subscribers', 'view' => 'users'), admin_url('admin.php'))); ?>" class="zarin-pill <?php echo $audience_subtab === 'users' ? 'active' : ''; ?>">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php esc_html_e('Subscribers', 'zarinshopbot'); ?> (<?php echo esc_html(number_format_i18n($sub_count)); ?>)
                        </a>
                        <a href="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'subscribers', 'view' => 'groups'), admin_url('admin.php'))); ?>" class="zarin-pill <?php echo $audience_subtab === 'groups' ? 'active' : ''; ?>">
                            <span class="dashicons dashicons-groups"></span>
                            <?php esc_html_e('Groups', 'zarinshopbot'); ?> (<?php echo esc_html(number_format_i18n($grp_count)); ?>)
                        </a>
                        <a href="<?php echo esc_url(admin_url($audience_subtab === 'users' ? 'edit.php?post_type=zarincode_user' : 'edit.php?post_type=zarincode_group')); ?>" class="zarin-pill" style="border: 1px dashed #cbd5e1; background: #f8fafc; color: #64748b;" target="_blank" title="<?php esc_attr_e('View in WordPress list table', 'zarinshopbot'); ?>">
                            <span class="dashicons dashicons-external"></span>
                            <?php esc_html_e('Advanced WordPress View', 'zarinshopbot'); ?>
                        </a>
                    </div>
                    
                    <!-- Search Filter -->
                    <div class="zarin-search-box">
                        <span class="dashicons dashicons-search"></span>
                        <input type="text" id="zarin-audience-search" placeholder="<?php esc_attr_e('Search by Name, Username or Chat ID...', 'zarinshopbot'); ?>">
                    </div>
                </div>

                <div class="zarin-card-body p-0">
                    <?php if ($audience_subtab === 'users'): ?>
                        <!-- Unique Subscribers List -->
                        <?php
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$all_subscribers = $wpdb->get_results("
                            SELECT p.ID, p.post_title, p.post_date,
                                   m1.meta_value as first_name,
                                   m2.meta_value as last_name,
                                   m3.meta_value as username
                            FROM {$wpdb->posts} p
                            LEFT JOIN {$wpdb->postmeta} m1 ON p.ID = m1.post_id AND m1.meta_key = 'telegram_first_name'
                            LEFT JOIN {$wpdb->postmeta} m2 ON p.ID = m2.post_id AND m2.meta_key = 'telegram_last_name'
                            LEFT JOIN {$wpdb->postmeta} m3 ON p.ID = m3.post_id AND m3.meta_key = 'telegram_username'
                            WHERE p.post_type = 'zarincode_user' AND p.post_status != 'trash'
                            GROUP BY p.post_title
                            ORDER BY p.ID DESC
                        ");

                        if (!empty($all_subscribers)):
                        ?>
                            <div class="zarin-table-responsive">
                                <table class="zarin-data-table" id="zarin-subscribers-table">
                                    <thead>
                                        <tr>
                                            <th style="width: 50px;"><?php esc_html_e('Avatar', 'zarinshopbot'); ?></th>
                                            <th><?php esc_html_e('Platform', 'zarinshopbot'); ?></th>
                                            <th><?php esc_html_e('Full Name', 'zarinshopbot'); ?></th>
                                            <th><?php esc_html_e('Username', 'zarinshopbot'); ?></th>
                                            <th><?php esc_html_e('Chat ID', 'zarinshopbot'); ?></th>
                                            <th><?php esc_html_e('Subscribe Date', 'zarinshopbot'); ?></th>
                                            <th style="text-align: left; width: 90px;"><?php esc_html_e('Action', 'zarinshopbot'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($all_subscribers as $sub):
                                            $cid        = (string) $sub->post_title;
                                            $source_platform = strpos($cid, 'bale_') === 0 ? 'bale' : (strpos($cid, 'rubika_') === 0 ? 'rubika' : 'telegram');
                                            $source_label = array('telegram' => __('Telegram', 'zarinshopbot'), 'bale' => __('Bale', 'zarinshopbot'), 'rubika' => __('Rubika', 'zarinshopbot'))[$source_platform];
                                            $source_icon = plugins_url('assets/icons/' . $source_platform . '.svg', dirname(__DIR__) . '/zarinshopbot.php');
                                            $public_chat_id = preg_replace('/\A(?:bale_|rubika_)/', '', $cid);
                                            $full_name  = trim(($sub->first_name ?? '') . ' ' . ($sub->last_name ?? ''));
                                            if (empty($full_name)) $full_name = __('Bot User', 'zarinshopbot');
                                            $uname      = ltrim((string) ($sub->username ?? ''), '@');
                                            $profile_base = $source_platform === 'bale' ? 'https://ble.ir/' : ($source_platform === 'rubika' ? 'https://rubika.ir/' : 'https://t.me/');
                                            $delete_url = wp_nonce_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'subscribers', 'view' => 'users', 'action' => 'delete_user', 'user_id' => $sub->ID), admin_url('admin.php')), 'delete_user_' . $sub->ID);
                                        ?>
                                            <tr class="zarin-audience-row">
                                                <td>
                                                    <div class="zarin-avatar-circle">
                                                        <?php echo esc_html(preg_match('/^./us', $full_name, $avatar_initial) ? $avatar_initial[0] : substr($full_name, 0, 1)); ?>
                                                    </div>
                                                </td>
                                                <td class="col-platform"><img src="<?php echo esc_url($source_icon); ?>" width="20" height="20" alt="" aria-hidden="true"> <?php echo esc_html($source_label); ?></td>
                                                <td class="col-name">
                                                    <strong><?php echo esc_html($full_name); ?></strong>
                                                </td>
                                                <td class="col-username">
                                                    <?php if (!empty($uname)): ?>
                                                        <a href="<?php echo esc_url($profile_base . rawurlencode($uname)); ?>" target="_blank" rel="noopener noreferrer" class="zarin-tg-link">
                                                            @<?php echo esc_html($uname); ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <span class="zarin-text-muted">—</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="col-chatid">
                                                    <code class="zarin-chatid-tag" title="<?php esc_attr_e('Click to copy', 'zarinshopbot'); ?>"><?php echo esc_html($public_chat_id); ?></code>
                                                </td>
                                                <td class="col-date">
                                                    <?php echo esc_html(mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $sub->post_date)); ?>
                                                </td>
                                                <td style="text-align: left;">
                                                    <a href="<?php echo esc_url($delete_url); ?>" class="zarin-btn-action-delete" onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete this subscriber?', 'zarinshopbot'); ?>');" title="<?php esc_attr_e('Delete', 'zarinshopbot'); ?>">
                                                        <span class="dashicons dashicons-trash"></span>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="zarin-empty-state">
                                <span class="dashicons dashicons-admin-users"></span>
                                <h3><?php esc_html_e('No Subscribers Found', 'zarinshopbot'); ?></h3>
                                <p><?php esc_html_e('When visitors interact with your bot, they will be registered here automatically.', 'zarinshopbot'); ?></p>
                            </div>
                        <?php endif; ?>

                    <?php else: ?>
                        <!-- Unique Groups List -->
                        <?php
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$all_groups = $wpdb->get_results("
                            SELECT p.ID, p.post_title, p.post_date,
                                   m1.meta_value as group_title
                            FROM {$wpdb->posts} p
                            LEFT JOIN {$wpdb->postmeta} m1 ON p.ID = m1.post_id AND m1.meta_key = 'telegram_group_title'
                            WHERE p.post_type = 'zarincode_group' AND p.post_status != 'trash'
                            GROUP BY p.post_title
                            ORDER BY p.ID DESC
                        ");

                        if (!empty($all_groups)):
                        ?>
                            <div class="zarin-table-responsive">
                                <table class="zarin-data-table" id="zarin-groups-table">
                                    <thead>
                                        <tr>
                                            <th style="width: 50px;"><?php esc_html_e('Icon', 'zarinshopbot'); ?></th>
                                            <th><?php esc_html_e('Platform', 'zarinshopbot'); ?></th>
                                            <th><?php esc_html_e('Group Name', 'zarinshopbot'); ?></th>
                                            <th><?php esc_html_e('Group Chat ID', 'zarinshopbot'); ?></th>
                                            <th><?php esc_html_e('Subscribe Date', 'zarinshopbot'); ?></th>
                                            <th style="text-align: left; width: 90px;"><?php esc_html_e('Action', 'zarinshopbot'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($all_groups as $grp):
                                            $cid         = (string) $grp->post_title;
                                            $source_platform = strpos($cid, 'bale_') === 0 ? 'bale' : (strpos($cid, 'rubika_') === 0 ? 'rubika' : 'telegram');
                                            $source_label = array('telegram' => __('Telegram', 'zarinshopbot'), 'bale' => __('Bale', 'zarinshopbot'), 'rubika' => __('Rubika', 'zarinshopbot'))[$source_platform];
                                            $source_icon = plugins_url('assets/icons/' . $source_platform . '.svg', dirname(__DIR__) . '/zarinshopbot.php');
                                            $public_chat_id = preg_replace('/\A(?:bale_|rubika_)/', '', $cid);
                                            $group_title = !empty($grp->group_title) ? $grp->group_title : __('Bot Group', 'zarinshopbot');
                                            $delete_url  = wp_nonce_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'subscribers', 'view' => 'groups', 'action' => 'delete_group', 'group_id' => $grp->ID), admin_url('admin.php')), 'delete_group_' . $grp->ID);
                                        ?>
                                            <tr class="zarin-audience-row">
                                                <td>
                                                    <div class="zarin-avatar-circle" style="background:#8b5cf6;">
                                                        <span class="dashicons dashicons-groups" style="color:#fff;font-size:18px;margin-top:2px;"></span>
                                                    </div>
                                                </td>
                                                <td class="col-platform"><img src="<?php echo esc_url($source_icon); ?>" width="20" height="20" alt="" aria-hidden="true"> <?php echo esc_html($source_label); ?></td>
                                                <td class="col-name">
                                                    <strong><?php echo esc_html($group_title); ?></strong>
                                                </td>
                                                <td class="col-chatid">
                                                    <code class="zarin-chatid-tag" title="<?php esc_attr_e('Click to copy', 'zarinshopbot'); ?>"><?php echo esc_html($public_chat_id); ?></code>
                                                </td>
                                                <td class="col-date">
                                                    <?php echo esc_html(mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $grp->post_date)); ?>
                                                </td>
                                                <td style="text-align: left;">
                                                    <a href="<?php echo esc_url($delete_url); ?>" class="zarin-btn-action-delete" onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete this group?', 'zarinshopbot'); ?>');" title="<?php esc_attr_e('Delete', 'zarinshopbot'); ?>">
                                                        <span class="dashicons dashicons-trash"></span>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="zarin-empty-state">
                                <span class="dashicons dashicons-groups"></span>
                                <h3><?php esc_html_e('No Groups Found', 'zarinshopbot'); ?></h3>
                                <p><?php esc_html_e('When the bot is added to Telegram groups, they will be listed here.', 'zarinshopbot'); ?></p>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ($current_tab === 'logs'): ?>
            <!-- ========================================================= -->
            <!-- TAB 4: ACTIVITY LOGS & DIAGNOSTICS                       -->
            <!-- ========================================================= -->
            <div class="zarin-card">
                <div class="zarin-card-header">
                    <div class="zarin-card-header-title">
                        <span class="dashicons dashicons-list-view"></span>
                        <h3><?php esc_html_e('System Activity & Logs', 'zarinshopbot'); ?></h3>
                    </div>

                    <div class="zarin-card-header-actions">
                        <?php
                            $activity_txt_url = wp_nonce_url(
                                add_query_arg(array('action' => 'zarincode_download_activity_txt', 'source' => $log_source), admin_url('admin-post.php')),
                                'zarincode_download_activity_txt'
                            );
                        ?>
                        <a href="<?php echo esc_url($activity_txt_url); ?>" class="zarin-btn-primary">
                            <span class="dashicons dashicons-download" aria-hidden="true"></span>
                            <?php esc_html_e('Download TXT', 'zarinshopbot'); ?>
                        </a>
                        <?php if (!empty($logs)):
                            $clear_url = wp_nonce_url(add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'logs', 'action' => 'clear_logs'), admin_url('admin.php')), 'clear_bot_logs');
                        ?>
                            <a href="<?php echo esc_url($clear_url); ?>" class="zarin-btn-danger" onclick="return confirm('<?php esc_attr_e('Are you sure you want to clear all activity logs?', 'zarinshopbot'); ?>');">
                                <span class="dashicons dashicons-trash"></span>
                                <?php esc_html_e('Clear All Logs', 'zarinshopbot'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="zarin-log-filterbar" role="navigation" aria-label="<?php esc_attr_e('Filter activity logs by platform', 'zarinshopbot'); ?>">
                    <?php
                    $log_filters = array(
                        'all' => array(__('All Events', 'zarinshopbot'), 'dashicons-list-view'),
                        'telegram' => array(__('Telegram', 'zarinshopbot'), 'dashicons-format-chat'),
                        'bale' => array(__('Bale', 'zarinshopbot'), 'dashicons-format-chat'),
                        'rubika' => array(__('Rubika', 'zarinshopbot'), 'dashicons-share'),
                        'system' => array(__('Plugin / System', 'zarinshopbot'), 'dashicons-admin-generic'),
                    );
                    foreach ($log_filters as $filter_key => $filter_meta):
                        $filter_url = add_query_arg(array('page' => 'zarincode_zarinshopbot', 'tab' => 'logs', 'source' => $filter_key), admin_url('admin.php'));
                    ?>
                        <a class="zarin-log-filter <?php echo $log_source === $filter_key ? 'is-active' : ''; ?>" href="<?php echo esc_url($filter_url); ?>" aria-current="<?php echo $log_source === $filter_key ? 'page' : 'false'; ?>">
                            <?php if (in_array($filter_key, array('telegram', 'bale', 'rubika'), true)): ?>
                                <img class="zarin-log-filter-brand" src="<?php echo esc_url(zarincode_get_plugin_uri() . 'assets/icons/' . $filter_key . '.svg'); ?>" alt="" aria-hidden="true" />
                            <?php else: ?>
                                <span class="dashicons <?php echo esc_attr($filter_meta[1]); ?>" aria-hidden="true"></span>
                            <?php endif; ?>
                            <span><?php echo esc_html($filter_meta[0]); ?></span>
                            <b><?php echo esc_html(number_format_i18n((int) ($log_counts[$filter_key] ?? 0))); ?></b>
                        </a>
                    <?php endforeach; ?>
                    <p class="zarin-log-filter-help"><?php esc_html_e('Legacy log records remain under Telegram; structured events without a platform label appear under Plugin / System. New channel events show their source.', 'zarinshopbot'); ?></p>
                </div>

                <div class="zarin-card-body p-0">
                    <?php if (!empty($logs)): ?>
                        <div class="zarin-table-responsive">
                            <table class="zarin-data-table zarin-activity-table">
                                <thead>
                                    <tr>
                                        <th style="width: 110px;"><?php esc_html_e('Source', 'zarinshopbot'); ?></th>
                                        <th style="width: 150px;"><?php esc_html_e('Event Type', 'zarinshopbot'); ?></th>
                                        <th style="width: 160px;"><?php esc_html_e('Date & Time', 'zarinshopbot'); ?></th>
                                        <th style="width: 140px;"><?php esc_html_e('Chat ID', 'zarinshopbot'); ?></th>
                                        <th><?php esc_html_e('Description', 'zarinshopbot'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($logs as $log):
                                        $source = sanitize_key($log['platform'] ?? 'system');
                                        $source_label = $log_filters[$source][0] ?? __('Plugin / System', 'zarinshopbot');
                                        $type = (string) ($log['event'] ?? 'event');
                                        $date = (string) ($log['time'] ?? '');
                                        $cid = (string) ($log['chat_id'] ?? '');
                                        $desc = (string) ($log['description'] ?? '');
                                    ?>
                                        <tr>
                                            <td><span class="zarin-log-source zarin-log-source-<?php echo esc_attr($source); ?>"><?php echo esc_html($source_label); ?></span></td>
                                            <td><span class="zarin-log-badge <?php echo esc_attr(strtolower($type)); ?>"><?php echo esc_html($type); ?></span></td>
                                            <td><?php echo esc_html($date); ?></td>
                                            <td><?php if ($cid !== ''): ?><code><?php echo esc_html($cid); ?></code><?php else: ?><span class="zarin-text-muted">—</span><?php endif; ?></td>
                                            <td class="zarin-log-description"><?php echo esc_html($desc); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="zarin-empty-state">
                            <span class="dashicons dashicons-list-view" style="color:#8b6a18;"></span>
                            <h3><?php esc_html_e('No events for this source yet', 'zarinshopbot'); ?></h3>
                            <p><?php esc_html_e('Once logging is enabled and the selected platform receives an event, it will appear here.', 'zarinshopbot'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php endif; ?>

    </main>
</div>

