<?php
/* Modified 2026-10-23 by Ehsan NaderiPanah / Zarincode.com. Derived code remains under GPL-2.0-or-later; upstream notices are retained. */
if (!defined('ABSPATH')) exit;

function zarincode_user_columns($columns) {
    $columns['first_name'] = __('First Name', 'zarinshopbot');
    $columns['last_name']  = __('Last Name', 'zarinshopbot');
    $columns['username']   = __('Username', 'zarinshopbot');
    $columns['sdate']      = __('Subscribe Date', 'zarinshopbot');
    unset($columns['cb'], $columns['date']);
    if (defined('WP_DEBUG') && false === WP_DEBUG) {
        unset($columns['title']);
    }
    return apply_filters('zarincode_manage_user_columns', $columns);
}
add_filter('manage_edit-zarincode_user_columns', 'zarincode_user_columns');

function zarincode_group_columns($columns) {
    $columns['name']  = __('Group Name', 'zarinshopbot');
    $columns['sdate'] = __('Subscribe Date', 'zarinshopbot');
    unset($columns['cb'], $columns['date']);
    if (defined('WP_DEBUG') && false === WP_DEBUG) {
        unset($columns['title']);
    }
    return apply_filters('zarincode_manage_group_columns', $columns);
}
add_filter('manage_edit-zarincode_group_columns', 'zarincode_group_columns');

add_filter('bulk_actions-edit-zarincode_user', function($actions) {
    unset($actions['edit']);
    return apply_filters('zarincode_bulk_actions_user', $actions);
});

add_filter('bulk_actions-edit-zarincode_group', function($actions) {
    unset($actions['edit']);
    return apply_filters('zarincode_bulk_actions_group', $actions);
});

add_action('manage_zarincode_user_posts_custom_column', 'zarincode_manage_columns', 10, 2);
add_action('manage_zarincode_group_posts_custom_column', 'zarincode_manage_columns', 10, 2);

function zarincode_manage_columns($column, $post_id) {
    switch ($column) {
        case 'name':
            echo esc_html((string) get_post_meta($post_id, 'telegram_group_title', true));
            break;
        case 'first_name':
            echo esc_html((string) get_post_meta($post_id, 'telegram_first_name', true));
            break;
        case 'last_name':
            echo esc_html((string) get_post_meta($post_id, 'telegram_last_name', true));
            break;
        case 'username':
            echo esc_html((string) get_post_meta($post_id, 'telegram_username', true));
            break;
        case 'sdate':
            echo esc_html((string) get_the_date('', $post_id));
            break;
        default:
            break;
    }
}
