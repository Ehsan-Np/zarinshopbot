<?php
/*
Plugin Name:  ربات زرین شاپ
Description:  فروش چندکاناله محصولات ووکامرس از طریق تلگرام، بله و روبیکا؛ محصول زرین‌کد.
Plugin URI:   https://zarincode.com/product/zarinshopbot
Requires at least: 5.8
Requires PHP: 7.4
Requires Plugins: woocommerce
Version:      1.8.43
Author:       Ehsan NaderiPanah
Author URI:   https://zarincode.com
License:      GPL-2.0-or-later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  zarinshopbot
Domain Path:  /languages
*/

/* Modified 2026-10-30 by Ehsan NaderiPanah (Zarincode.com). Derived code remains under GPL-2.0-or-later; bundled notices and compatibility identifiers are retained. */

if (!defined('ABSPATH')) exit;

if (!defined('ZARINSHOPBOT_VERSION')) {
    define('ZARINSHOPBOT_VERSION', '1.8.43');
}
$zarincode_version = ZARINSHOPBOT_VERSION;

/** Prevent an empty bundled/third-party MO translation from erasing plugin UI text. */
if (!function_exists('zarincode_fallback_empty_plugin_translation')) {
    function zarincode_fallback_empty_plugin_translation($translation, $source_text, $domain = 'zarinshopbot') {
        if ($domain === 'zarinshopbot' && $translation === '' && is_string($source_text)) {
            return $source_text;
        }
        return $translation;
    }
}
add_filter('gettext_zarinshopbot', 'zarincode_fallback_empty_plugin_translation', 10, 3);

function zarincode_environment_check() {
    $minimum_php = '7.4.0';
    if (version_compare(phpversion(), $minimum_php, '<')) {
        // translators: 1: Minimum required PHP version, 2: Current PHP version.
        $message = __('ZarinShopBot requires PHP version %1$s or higher. You are running %2$s.', 'zarinshopbot');
        return sprintf($message, $minimum_php, phpversion());
    }
    $recommended_extensions = ['curl', 'mbstring'];
    $missing_extensions = array_values(array_filter($recommended_extensions, function($extension) {
        return !extension_loaded($extension);
    }));
    if (!empty($missing_extensions)) {
        return sprintf(
            // translators: %s: Comma-separated list of missing PHP extensions.
            __('ZarinShopBot recommends these PHP extensions: %s. Please enable them for full functionality.', 'zarinshopbot'),
            implode(', ', $missing_extensions)
        );
    }
    return false;
}

function zarincode_admin_notices($message, $class = 'notice notice-warning is-dismissible') {
    if (strpos($class, 'is-dismissible') === false) {
        $class .= ' is-dismissible';
    }
    echo "<div class='" . esc_attr($class) . "'><p>" . wp_kses($message, ['a' => ['href' => [], 'target' => [], 'rel' => []]]) . "</p></div>";
}

add_action('plugins_loaded', function() {
    load_plugin_textdomain('zarinshopbot', false, dirname(plugin_basename(__FILE__)) . '/languages');

    if (($message = zarincode_environment_check())) {
        add_action('admin_notices', function() use ($message) {
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($screen && !in_array($screen->id, ['plugins', 'toplevel_page_zarincode_zarinshopbot', 'zarincode_zarinshopbot_page_zarincode_zarinshopbot_setting', 'telenexa_page_zarincode_settings', 'woocommerce_page_zarincode_zarinshopbot', 'woocommerce_page_zarincode_zarinshopbot_setting', 'zarincode_zarinshopbot_page_zarinshopbot_bale', 'zarincode_zarinshopbot_page_zarinshopbot_rubika'], true)) {
                return;
            }
            zarincode_admin_notices($message, 'notice notice-warning is-dismissible');
        });
    }

    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($screen && !in_array($screen->id, ['plugins', 'toplevel_page_zarincode_zarinshopbot', 'zarincode_zarinshopbot_page_zarincode_zarinshopbot_setting', 'telenexa_page_zarincode_settings'], true)) {
                return;
            }
            zarincode_admin_notices(
                __('ZarinShopBot requires WooCommerce to be installed and active.', 'zarinshopbot'),
                'notice notice-warning is-dismissible'
            );
        });
    }
});

// Do not abort plugin loading when an optional PHP extension is missing. The
// Telegram adapter uses WordPress HTTP and can use its stream transport; the
// admin notice above still reports the recommended extensions.

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/includes/class-zarinshopbot-telegram-secrets.php';
require_once __DIR__ . '/includes/class-zarinshopbot-message-editor.php';
require_once __DIR__ . '/settings-management.php';
require_once __DIR__ . '/includes/class-zarinshopbot-channels.php';
require_once __DIR__ . '/includes/class-zarinshopbot-bale-payments.php';
require_once __DIR__ . '/includes/class-zarinshopbot-card-transfer.php';
require_once __DIR__ . '/includes/class-zarinshopbot-phone-accounts.php';
require_once __DIR__ . '/includes/class-zarinshopbot-digital-checkout.php';
require_once __DIR__ . '/includes/class-zarinshopbot-invoice.php';
\ZarinShopBot\Channels::boot();
\ZarinShopBot\Invoice::boot();

// Load only the selected Bale/Rubika settings fragment; keep the settings shell and its other tabs intact.
add_action('wp_ajax_zarincode_load_channel_tab', function() {
    check_ajax_referer('zarincode_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('دسترسی مجاز نیست.', 'zarinshopbot')), 403);
    }
    $platform = isset($_POST['platform']) ? sanitize_key(wp_unslash($_POST['platform'])) : '';
    if (!in_array($platform, array('bale', 'rubika'), true) || !class_exists(\ZarinShopBot\Channels::class)) {
        wp_send_json_error(array('message' => __('کانال نامعتبر است.', 'zarinshopbot')), 400);
    }
    ob_start();
    \ZarinShopBot\Channels::render_settings_content($platform);
    $html = ob_get_clean();
    wp_send_json_success(array('html' => $html));
});

/**
 * Register administrator-provided bot content in WPML String Translation.
 *
 * gettext can extract strings from source files, but it cannot discover text
 * entered later in the settings page. WPML needs these values registered at
 * runtime so translators can find them under the "ZarinShopBot" context.
 */
function zarincode_register_wpml_strings() {
    if (!function_exists('has_action') || !has_action('wpml_register_single_string')) {
        return;
    }

    $options = get_option('zarincode_settings', []);
    if (!is_array($options)) {
        return;
    }

    $strings = [];
    $dynamic_strings = [
        'setting.wmuser'        => $options['wmuser'] ?? '',
        'setting.bmuser'        => $options['bmuser'] ?? '',
        'setting.messagehome'   => $options['messagehome'] ?? '',
        'setting.contactuspage' => $options['contactuspage'] ?? '',
        'setting.help_message'  => $options['help_message'] ?? '',
        'setting.aboutuspage'   => $options['aboutuspage'] ?? '',
        'setting.botsign'       => $options['botsign'] ?? '',
        'setting.campaign_banner_text' => $options['campaign_banner_text'] ?? '',
    ];
    foreach ($dynamic_strings as $name => $value) {
        if (is_scalar($value) && (string) $value !== '') {
            $strings[$name] = (string) $value;
        }
    }
    $message_overrides = isset($options['message_overrides']) && is_array($options['message_overrides']) ? $options['message_overrides'] : [];
    foreach (['telegram', 'bale', 'rubika'] as $message_platform) {
        foreach (['start', 'home', 'bye', 'contact', 'help', 'about'] as $message_key) {
            $value = $message_overrides[$message_platform][$message_key] ?? '';
            if (is_scalar($value) && trim((string) $value) !== '') {
                $strings['setting.override.' . $message_platform . '.' . $message_key] = (string) $value;
            }
        }
    }

    $menu_items = $options['main_menu_items'] ?? [];
    if (is_array($menu_items)) {
        foreach ($menu_items as $key => $item) {
            if (!is_array($item)) {
                continue;
            }
            foreach (['title_fa', 'title_en'] as $field) {
                if (!empty($item[$field])) {
                    $strings['menu.' . sanitize_key($key) . '.' . substr($field, 6)] = (string) $item[$field];
                }
            }
        }
    }

    $custom_buttons = $options['custom_menu_buttons'] ?? [];
    if (is_string($custom_buttons)) {
        $custom_buttons = json_decode($custom_buttons, true);
    }
    if (is_array($custom_buttons)) {
        foreach ($custom_buttons as $index => $button) {
            if (!is_array($button)) {
                continue;
            }
            foreach (['title_fa', 'title_en'] as $field) {
                if (!empty($button[$field])) {
                    $strings['menu.custom.' . (int) $index . '.' . substr($field, 6)] = (string) $button[$field];
                }
            }
            foreach (['value_fa', 'value_en'] as $field) {
                if (!empty($button[$field])) {
                    $strings['menu.custom.' . (int) $index . '.value.' . substr($field, 6)] = (string) $button[$field];
                }
            }
        }
    }

    // WPML stores registered strings; avoid repeating its DB work on every front-end request.
    $signature = hash('sha256', (string) wp_json_encode($strings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    if (get_option('zarincode_wpml_strings_hash', '') === $signature) {
        return;
    }
    foreach ($strings as $name => $value) {
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Official WPML registration action.
        do_action('wpml_register_single_string', 'ZarinShopBot', $name, $value);
    }
    update_option('zarincode_wpml_strings_hash', $signature, false);
}
add_action('init', 'zarincode_register_wpml_strings', 20);
function zarincode_invalidate_wpml_strings_hash() {
    delete_option('zarincode_wpml_strings_hash');
}
add_action('update_option_zarincode_settings', 'zarincode_invalidate_wpml_strings_hash', 10, 0);
add_action('add_option_zarincode_settings', 'zarincode_invalidate_wpml_strings_hash', 10, 0);

/** Plugin lifecycle hooks used by WordPress and safe deployment tooling. */
function zarincode_activate() {
    $minimum_php = '7.4.0';
    if (version_compare(phpversion(), $minimum_php, '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            esc_html(sprintf(
                __('ZarinShopBot requires PHP version %1$s or higher. You are running %2$s.', 'zarinshopbot'),
                $minimum_php,
                phpversion()
            ))
        );
    }
    zarincode_defaults();
    flush_rewrite_rules(false);
}

function zarincode_deactivate() {
    $hooks = [
        'zarincode_prune_logs',
        'zarincode_check_abandoned_cart',
        'zarincode_retry_send_message',
        'zarincode_process_broadcast',
    ];
    foreach ($hooks as $hook) {
        wp_clear_scheduled_hook($hook);
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions($hook, [], 'zarincode');
        }
    }
    flush_rewrite_rules(false);
}

register_activation_hook(__FILE__, 'zarincode_activate');
register_deactivation_hook(__FILE__, 'zarincode_deactivate');

add_action('admin_init', function() {
    // Remove activation data left by the former paid edition once on upgrade.
    if (!get_option('zarincode_free_edition_migrated')) {
        $saved = get_option('zarincode_settings', []);
        if (is_array($saved) && array_key_exists('plugin_license', $saved)) {
            unset($saved['plugin_license']);
            update_option('zarincode_settings', $saved);
        }
        delete_option('sa_te_bo_li');
        delete_option('sa_te_bo_li_');
        update_option('zarincode_free_edition_migrated', 1, false);
    }
    // One-time upgrade: retire the former third-party Telegram relay and use direct HTTPS only.
    if (!get_option('zarinshopbot_direct_webhook_migrated')) {
        $saved_settings = get_option('zarincode_settings', []);
        if (is_array($saved_settings) && isset($saved_settings['mode']) && (string) $saved_settings['mode'] !== '0') {
            $saved_settings['mode'] = '0';
            update_option('zarincode_settings', $saved_settings);
        }
        update_option('zarinshopbot_direct_webhook_migrated', 1, false);
    }
    // Older installations can retain a Telegram webhook registered without
    // callback_query in allowed_updates. Refresh once after this upgrade so
    // inline buttons work without requiring an unrelated settings change.
    if (!get_option('zarinshopbot_callback_updates_migrated') && !get_transient('zarinshopbot_callback_webhook_sync_attempt')) {
        $saved_settings = (array) get_option('zarincode_settings', []);
        $saved_token = function_exists('zarincode_get_telegram_token') ? zarincode_get_telegram_token($saved_settings) : (string) ($saved_settings['token'] ?? '');
        $telegram_enabled = !function_exists('zarincode_telegram_enabled') || zarincode_telegram_enabled();
        if ($saved_token !== '' && $telegram_enabled) {
            set_transient('zarinshopbot_callback_webhook_sync_attempt', 1, 10 * MINUTE_IN_SECONDS);
            $webhook_result = \ZarinShopBot\Core\WooBot::setHook(1);
            $webhook_ok = $webhook_result !== false;
            update_option('zarincode_webhook_sync_status', ['ok' => $webhook_ok, 'checked_at' => gmdate('c'), 'reason' => 'callback_updates_upgrade'], false);
            if ($webhook_ok) {
                update_option('zarinshopbot_callback_updates_migrated', 1, false);
                delete_transient('zarinshopbot_callback_webhook_sync_attempt');
            }
        }
    }
    if (!function_exists('wp_add_privacy_policy_content')) {
        return;
    }
    wp_add_privacy_policy_content(
        __('ربات زرین شاپ | ZarinShopBot', 'zarinshopbot'),
        '<p>' . esc_html__('ZarinShopBot processes the messaging platform chat identifier, message/update data and shopping actions needed to operate configured Telegram, Bale or Rubika bots. For Bale and Rubika, temporary cart contents are held in WordPress transients and are transferred into the WooCommerce checkout only after the customer opens a short-lived checkout link. Necessary data is sent to the configured messaging platform API. ZarinShopBot registers direct webhooks on the store domain; no third-party relay is used. Store owners should disclose these data flows, retention periods, and applicable processors in their privacy policy.', 'zarinshopbot') . '</p>'
    );
});

function zarincode_render_main_panel() {
    static $rendered = false;
    if ($rendered) return;
    $rendered = true;
    require_once __DIR__ . '/panel/main.php';
}

function zarincode_render_settings_panel() {
    static $rendered = false;
    if ($rendered) return;
    $rendered = true;
    require_once __DIR__ . '/panel/settings.php';
}

function zarincode_render_guide_panel() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to access this page.', 'zarinshopbot'));
    }
    $guide_url = add_query_arg('zarinshopbot_admin_url', admin_url('admin.php'), plugins_url('docs/guide-fa.html', __FILE__));
    echo '<div class="wrap zarinshopbot-guide-admin" dir="rtl">';
    echo '<h1>' . esc_html__('راهنمای کامل کار با ZarinShopBot', 'zarinshopbot') . '</h1>';
    echo '<p>' . esc_html__('راهنمای آفلاین نسخهٔ جاری افزونه؛ برای چاپ یا ذخیره به PDF از دکمهٔ داخل راهنما استفاده کنید.', 'zarinshopbot') . ' <a href="' . esc_url($guide_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('بازکردن در برگهٔ جداگانه', 'zarinshopbot') . '</a></p>';
    echo '<iframe title="' . esc_attr__('راهنمای کامل افزونه ZarinShopBot', 'zarinshopbot') . '" src="' . esc_url($guide_url) . '" loading="lazy" style="display:block;width:100%;height:calc(100vh - 190px);min-height:360px;max-height:calc(100vh - 120px);border:1px solid #e5e1d6;border-radius:12px;background:#fff"></iframe>';
    echo '</div>';
}

function zarincode_get_admin_menu_icon() {
    $svg_path = __DIR__ . '/img/zarinshopbot-icon.svg';
    if (is_file($svg_path)) {
        return 'data:image/svg+xml;base64,' . base64_encode((string) file_get_contents($svg_path));
    }
    return plugins_url('img/zarinshopbot-icon.svg', __FILE__);
}

function zarincode_render_broadcast_panel() {
    wp_safe_redirect(admin_url('admin.php?page=zarincode_zarinshopbot&tab=broadcast'));
    exit;
}

// Primary ZarinShopBot navigation: all plugin controls are grouped under one top-level menu.
add_action('admin_menu', function() {
    $menu_title = __('ربات زرین شاپ', 'zarinshopbot');
    add_menu_page(
        $menu_title,
        $menu_title,
        'manage_options',
        'zarincode_zarinshopbot',
        'zarincode_render_main_panel',
        zarincode_get_admin_menu_icon(),
        58.5
    );
    add_submenu_page('zarincode_zarinshopbot', __('داشبورد', 'zarinshopbot'), __('داشبورد', 'zarinshopbot'), 'manage_options', 'zarincode_zarinshopbot', 'zarincode_render_main_panel');
    add_submenu_page('zarincode_zarinshopbot', __('تنظیمات ربات‌ها', 'zarinshopbot'), __('تنظیمات ربات‌ها', 'zarinshopbot'), 'manage_options', 'zarincode_zarinshopbot_setting', 'zarincode_render_settings_panel');
    add_submenu_page('zarincode_zarinshopbot', __('ارسال همگانی', 'zarinshopbot'), __('ارسال همگانی', 'zarinshopbot'), 'manage_options', 'zarincode_send', 'zarincode_render_broadcast_panel');
    add_submenu_page('zarincode_zarinshopbot', __('راهنمای افزونه', 'zarinshopbot'), __('راهنمای افزونه', 'zarinshopbot'), 'manage_options', 'zarincode_guide', 'zarincode_render_guide_panel');
}, 50);

function zarincode_log_panel() {
    wp_safe_redirect(admin_url('admin.php?page=zarincode_zarinshopbot&tab=logs'));
    exit;
}

add_action('admin_init', function() {
    register_setting('zarincode_settings_options', 'zarincode_settings', [
        'sanitize_callback' => 'zarincode_sanitize_options',
    ]);
    require_once __DIR__ . '/columns.php';
    require_once __DIR__ . '/admin-messages.php';

    // Settings Export Handler
    if (isset($_GET['action']) && sanitize_key(wp_unslash($_GET['action'])) === 'zarincode_export_settings') {
        if (!current_user_can('manage_options') && !current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Permission denied', 'zarinshopbot'));
        }
        check_admin_referer('zarincode_export_settings_nonce');

        $options = get_option('zarincode_settings', []);
        $export_options = zarincode_export_options(is_array($options) ? $options : []);
        foreach (['proxy_password', 'proxy_password_enc', 'proxy_password_fallback', 'proxy_password_enc_fallback'] as $secret_key) {
            unset($export_options[$secret_key]);
        }
        $export_data = [
            'generator'   => 'ZarinShopBot for WooCommerce',
            'version'     => defined('ZARINSHOPBOT_VERSION') ? ZARINSHOPBOT_VERSION : '1.8.43',
            'site_url'    => get_site_url(),
            'exported_at' => gmdate('Y-m-d H:i:s'),
            'settings'    => $export_options,
        ];

        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename=zarincode-settings-' . gmdate('Y-m-d') . '.json');
        echo wp_json_encode($export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Settings Import Handler
    if (isset($_POST['zarincode_import_settings_action']) && sanitize_key(wp_unslash($_POST['zarincode_import_settings_action'])) !== '') {
        if (!current_user_can('manage_options') && !current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Permission denied', 'zarinshopbot'));
        }
        check_admin_referer('zarincode_import_settings_nonce', 'zarincode_import_nonce');

        if (!empty($_FILES['zarincode_import_file']['tmp_name'])) {
            $tmp_file = sanitize_text_field(wp_unslash($_FILES['zarincode_import_file']['tmp_name']));
            if (is_uploaded_file($tmp_file)) {
                $json = file_get_contents($tmp_file);
                $data = json_decode($json, true);
                if (is_array($data) && !empty($data['settings']) && is_array($data['settings'])) {
                    $sanitized = zarincode_sanitize_options(array_merge((array) get_option('zarincode_settings', []), zarincode_export_options($data['settings'])));
                    update_option('zarincode_settings', $sanitized);
                    wp_safe_redirect(add_query_arg(['page' => 'zarincode_zarinshopbot_setting', 'tab' => 'marketing', 'imported' => '1'], admin_url('admin.php')));
                    exit;
                }
            }
        }
        wp_safe_redirect(add_query_arg(['page' => 'zarincode_zarinshopbot_setting', 'tab' => 'marketing', 'import_error' => '1'], admin_url('admin.php')));
        exit;
    }
});

/**
 * Comprehensive sanitization callback for ZarinShopBot settings.
 */
function zarincode_sanitize_options($options) {
    if (!is_array($options)) {
        return (array) get_option('zarincode_settings', []);
    }

    $sanitized = [];
    // Ignore activation keys in imports from the former paid edition.
    unset($options['plugin_license']);
    $previous = get_option('zarincode_settings', []);
    $previous = is_array($previous) ? $previous : [];
    $options = zarincode_validate_settings($options, $previous);
    $secret_fields = ['proxy_password' => 'proxy_password_enc', 'proxy_password_fallback' => 'proxy_password_enc_fallback', 'telegram_provider_token' => 'telegram_provider_token_enc', 'sms_kavenegar_api_key_new' => 'sms_kavenegar_api_key_enc', 'sms_melipayamak_username_new' => 'sms_melipayamak_username_enc', 'sms_melipayamak_password_new' => 'sms_melipayamak_password_enc'];
    if (!empty($options['clear_telegram_provider_token'])) {
        $sanitized['telegram_provider_token_enc'] = '';
    } elseif (!empty($options['telegram_provider_token']) && is_scalar($options['telegram_provider_token'])) {
        $sanitized['telegram_provider_token_enc'] = class_exists(\ZarinShopBot\Core\Http\ProxyManager::class)
            ? \ZarinShopBot\Core\Http\ProxyManager::encrypt(sanitize_text_field(trim((string) $options['telegram_provider_token'])))
            : sanitize_text_field(trim((string) $options['telegram_provider_token']));
    } elseif (!empty($previous['telegram_provider_token_enc'])) {
        $sanitized['telegram_provider_token_enc'] = $previous['telegram_provider_token_enc'];
    } elseif (!empty($previous['telegram_provider_token']) && class_exists(\ZarinShopBot\Core\Http\ProxyManager::class)) {
        $sanitized['telegram_provider_token_enc'] = \ZarinShopBot\Core\Http\ProxyManager::encrypt((string) $previous['telegram_provider_token']);
    }
    $allowed_html = class_exists(\ZarinShopBot\Message_Editor::class)
        ? \ZarinShopBot\Message_Editor::allowedHtml()
        : ['b' => [], 'strong' => [], 'i' => [], 'em' => [], 'u' => [], 's' => [], 'strike' => [], 'code' => [], 'pre' => [], 'a' => ['href' => []]];

    foreach ($options as $key => $value) {
        $clean_key = sanitize_key($key);
        if (in_array($clean_key, ['clear_telegram_provider_token', 'clear_telegram_token'], true)) continue;

        if (isset($secret_fields[$clean_key])) {
            $encrypted_key = $secret_fields[$clean_key];
            if ($clean_key === 'telegram_provider_token' && !empty($options['clear_telegram_provider_token'])) {
                $sanitized[$encrypted_key] = '';
                continue;
            }
            $secret = is_scalar($value) ? trim((string) $value) : ''; 
            if ($secret !== '' && class_exists(\ZarinShopBot\Core\Http\ProxyManager::class)) {
                $sanitized[$encrypted_key] = \ZarinShopBot\Core\Http\ProxyManager::encrypt($secret);
            } elseif (!empty($previous[$encrypted_key])) {
                $sanitized[$encrypted_key] = $previous[$encrypted_key];
            } elseif (!empty($previous[$clean_key]) && class_exists(\ZarinShopBot\Core\Http\ProxyManager::class)) {
                // One-time migration for installations that stored the old
                // plaintext proxy password before encrypted storage existed.
                $sanitized[$encrypted_key] = \ZarinShopBot\Core\Http\ProxyManager::encrypt((string) $previous[$clean_key]);
            }
            continue;
        }
        if (in_array($clean_key, ['proxy_password_enc', 'proxy_password_enc_fallback', 'telegram_provider_token_enc', 'token_enc'], true)) {
            if (!empty($previous[$clean_key])) $sanitized[$clean_key] = $previous[$clean_key];
            continue;
        }

        if ($clean_key === 'wc_checkout_fields') {
            $clean_profiles = [];
            $field_allowlist = ['billing_first_name', 'billing_last_name', 'billing_company', 'billing_country', 'billing_state', 'billing_city', 'billing_address_1', 'billing_address_2', 'billing_postcode', 'billing_phone', 'billing_email', 'shipping_first_name', 'shipping_last_name', 'shipping_company', 'shipping_country', 'shipping_state', 'shipping_city', 'shipping_address_1', 'shipping_address_2', 'shipping_postcode', 'order_comments'];
            if (is_array($value)) {
                foreach (['downloadable', 'physical'] as $profile_name) {
                    if (empty($value[$profile_name]) || !is_array($value[$profile_name])) continue;
                    foreach ($field_allowlist as $field_name) {
                        $field_config = $value[$profile_name][$field_name] ?? [];
                        if (!is_array($field_config)) continue;
                        $enabled = !empty($field_config['enabled']) && (string) $field_config['enabled'] === '1';
                        $required = !empty($field_config['required']) && (string) $field_config['required'] === '1';
                        if ($required) $enabled = true;
                        $clean_profiles[$profile_name][$field_name] = ['enabled' => $enabled ? '1' : '0', 'required' => $required ? '1' : '0'];
                    }
                }
            }
            $sanitized[$clean_key] = $clean_profiles;
        } elseif ($clean_key === 'custom_checkout_fields_json') {
            $raw_json = is_scalar($value) ? trim((string) $value) : '';
            $decoded_fields = $raw_json === '' ? [] : json_decode($raw_json, true);
            $clean_custom_fields = [];
            if (is_array($decoded_fields)) {
                foreach (array_slice($decoded_fields, 0, 30) as $custom_field) {
                    if (!is_array($custom_field)) continue;
                    $field_id = sanitize_key((string) ($custom_field['key'] ?? ''));
                    $field_type = sanitize_key((string) ($custom_field['type'] ?? 'text'));
                    $field_profiles = isset($custom_field['profiles']) && is_array($custom_field['profiles']) ? array_values(array_intersect(['downloadable', 'physical'], array_map('sanitize_key', $custom_field['profiles']))) : [];
                    if (!preg_match('/\A[a-z][a-z0-9_]{1,39}\z/', $field_id) || in_array($field_id, ['billing_email', 'billing_phone', 'billing_first_name', 'billing_last_name'], true) || !$field_profiles || !in_array($field_type, ['text', 'email', 'tel', 'textarea', 'select'], true)) continue;
                    $clean_custom_fields[] = ['key' => $field_id, 'label' => sanitize_text_field((string) ($custom_field['label'] ?? '')), 'type' => $field_type, 'profiles' => $field_profiles, 'required' => !empty($custom_field['required']) ? true : false, 'options' => isset($custom_field['options']) && is_array($custom_field['options']) ? array_slice(array_map('sanitize_text_field', $custom_field['options']), 0, 50) : []];
                }
            }
            $sanitized[$clean_key] = wp_json_encode($clean_custom_fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } elseif ($clean_key === 'message_overrides') {
            $clean_overrides = [];
            $allowed_platforms = ['telegram', 'bale', 'rubika'];
            $allowed_message_keys = ['start', 'home', 'bye', 'contact', 'help', 'about'];
            if (is_array($value)) {
                foreach ($allowed_platforms as $message_platform) {
                    if (empty($value[$message_platform]) || !is_array($value[$message_platform])) continue;
                    foreach ($allowed_message_keys as $message_key) {
                        if (!isset($value[$message_platform][$message_key]) || !is_scalar($value[$message_platform][$message_key])) continue;
                        $clean_overrides[$message_platform][$message_key] = class_exists(\ZarinShopBot\Message_Editor::class)
                            ? \ZarinShopBot\Message_Editor::sanitize($value[$message_platform][$message_key])
                            : wp_kses((string) $value[$message_platform][$message_key], $allowed_html);
                    }
                }
            }
            $sanitized[$clean_key] = $clean_overrides;
        } elseif (is_array($value)) {
            $clean_sub = [];
            foreach ($value as $sk => $sv) {
                if (is_array($sv)) {
                    $clean_sub[sanitize_key($sk)] = array_map('sanitize_text_field', $sv);
                } else {
                    $clean_sub[sanitize_key($sk)] = sanitize_text_field($sv);
                }
            }
            $sanitized[$clean_key] = $clean_sub;
        } elseif (is_numeric($value)) {
            $sanitized[$clean_key] = (string)$value;
        } elseif (is_bool($value)) {
            $sanitized[$clean_key] = $value ? '1' : '0';
        } else {
            if (in_array($clean_key, ['wmuser', 'bmuser', 'messagehome', 'contactuspage', 'help_message', 'aboutuspage', 'botsign', 'posttemplate'], true) || strpos($clean_key, 'msg_') !== false || strpos($clean_key, 'text') !== false || strpos($clean_key, 'banner') !== false) {
                $sanitized[$clean_key] = class_exists(\ZarinShopBot\Message_Editor::class)
                    ? \ZarinShopBot\Message_Editor::sanitize($value)
                    : wp_kses($value, $allowed_html);
            } else {
                $sanitized[$clean_key] = sanitize_text_field(trim((string) $value));
            }
        }
    }

    $brand_color_defaults = [
        'miniapp_brand_primary' => '#0284c7',
        'miniapp_brand_accent' => '#0ea5e9',
        'miniapp_brand_background' => '#ffffff',
        'miniapp_brand_text' => '#111827',
    ];
    foreach ($brand_color_defaults as $brand_key => $brand_default) {
        $candidate = isset($sanitized[$brand_key]) ? sanitize_hex_color((string) $sanitized[$brand_key]) : null;
        $previous_color = isset($previous[$brand_key]) ? sanitize_hex_color((string) $previous[$brand_key]) : null;
        $sanitized[$brand_key] = $candidate ?: ($previous_color ?: $brand_default);
    }
    if (($sanitized['customer_account_policy'] ?? ($previous['customer_account_policy'] ?? 'optional')) === 'account') {
        $sanitized['phone_sms_verification'] = '1';
    }
    if (array_key_exists('miniapp_brand_logo_id', $options)) {
        $sanitized['miniapp_brand_logo_id'] = absint($options['miniapp_brand_logo_id']);
    } elseif (isset($previous['miniapp_brand_logo_id'])) {
        $sanitized['miniapp_brand_logo_id'] = absint($previous['miniapp_brand_logo_id']);
    }

    $phone_mode_locked = ((string) ($options['phone_sms_verification'] ?? $previous['phone_sms_verification'] ?? '0') === '1')
        || (($options['customer_account_policy'] ?? $previous['customer_account_policy'] ?? 'optional') === 'account');

    $checkout_profile_fields = array('name', 'email', 'state', 'city', 'address', 'zip', 'ordernote', 'shipping', 'phone');
    foreach (array('checkout_fields_digital', 'checkout_fields_physical') as $profile_key) {
        $raw_profile = array_key_exists($profile_key, $options) ? $options[$profile_key] : ($previous[$profile_key] ?? null);
        if (!is_array($raw_profile)) continue;
        $profile = array();
        foreach ($checkout_profile_fields as $field) {
            if ($profile_key === 'checkout_fields_digital' && $field === 'shipping') {
                $profile[$field] = '0';
                continue;
            }
            $raw_value = $raw_profile[$field] ?? ($field === 'phone' ? ($phone_mode_locked ? '3' : 'global') : (($profile_key === 'checkout_fields_digital' && $field === 'name') ? '1' : '0'));
            $raw_value = is_scalar($raw_value) ? (string) $raw_value : '0';
            if ($field === 'phone') {
                $previous_profile = isset($previous[$profile_key]) && is_array($previous[$profile_key]) ? $previous[$profile_key] : array();
                $previous_phone_mode = isset($previous_profile['phone']) && is_scalar($previous_profile['phone']) ? (string) $previous_profile['phone'] : 'global';
                $profile[$field] = $phone_mode_locked
                    ? (in_array($previous_phone_mode, array('global', '0', '1', '2', '3'), true) ? $previous_phone_mode : 'global')
                    : (in_array($raw_value, array('global', '0', '1', '2', '3'), true) ? $raw_value : 'global');
            } else {
                $profile[$field] = in_array($raw_value, array('1', 'true', 'on'), true) ? '1' : '0';
            }
        }
        $sanitized[$profile_key] = $profile;
    }

    if (!empty($options['clear_telegram_token'])) {
        $telegram_token = '';
    } elseif (isset($sanitized['token']) && (string) $sanitized['token'] !== '') {
        $telegram_token = (string) $sanitized['token'];
    } else {
        $telegram_token = zarincode_get_telegram_token($previous);
    }
    unset($sanitized['token']);
    // Preserve old, previously exposed but runtime-unimplemented controls as inert legacy data.
    // They are intentionally not rendered in the UI until a real behavior is implemented.
    foreach (['telegram_exclusive_coupon', 'referral_reward_text'] as $legacy_key) {
        if (!array_key_exists($legacy_key, $sanitized) && isset($previous[$legacy_key]) && is_scalar($previous[$legacy_key])) {
            $sanitized[$legacy_key] = $legacy_key === 'referral_reward_text'
                ? wp_kses((string) $previous[$legacy_key], $allowed_html)
                : sanitize_text_field((string) $previous[$legacy_key]);
        }
    }
    if ($telegram_token !== '' && class_exists(\ZarinShopBot\Core\Http\ProxyManager::class)) {
        $sanitized['token_enc'] = \ZarinShopBot\Core\Http\ProxyManager::encrypt($telegram_token);
    } elseif ($telegram_token !== '') {
        $sanitized['token'] = $telegram_token;
    } else {
        $sanitized['token_enc'] = '';
        $sanitized['token'] = '';
    }

    foreach (['proxy_port', 'proxy_port_fallback'] as $port_key) {
        if (isset($sanitized[$port_key])) $sanitized[$port_key] = (string) max(1, min(65535, absint($sanitized[$port_key])));
    }
    foreach (['proxy_type', 'proxy_type_fallback'] as $type_key) {
        if (isset($sanitized[$type_key]) && !in_array($sanitized[$type_key], ['http', 'https', 'socks4', 'socks5'], true)) {
            $sanitized[$type_key] = 'http';
        }
    }
    if (isset($sanitized['telegram_http_timeout'])) $sanitized['telegram_http_timeout'] = (string) max(5, min(20, absint($sanitized['telegram_http_timeout'])));
    if (isset($sanitized['telegram_api_retries'])) $sanitized['telegram_api_retries'] = (string) min(2, absint($sanitized['telegram_api_retries']));
    $sanitized['telegram_enabled'] = array_key_exists('telegram_enabled', $options)
        ? (!empty($options['telegram_enabled']) ? '1' : '0')
        : (isset($previous['telegram_enabled']) ? (!empty($previous['telegram_enabled']) ? '1' : '0') : (zarincode_get_telegram_token($previous) !== '' ? '1' : '0'));
    $sanitized['membership_enabled'] = !empty($options['membership_enabled']) ? '1' : '0';
    $sanitized['membership_apply_to_admins'] = !isset($options['membership_apply_to_admins']) || !empty($options['membership_apply_to_admins']) ? '1' : '0';
    $sanitized['membership_requirements'] = zarincode_sanitize_membership_requirements($options['membership_requirements'] ?? []);

    return $sanitized;
}

require_once __DIR__ . '/custom-post-types.php';

// Broadcast Dispatcher (Action Scheduler or Direct)
function zarincode_broadcast_platform_is_enabled($platform) {
    $platform = sanitize_key((string) $platform);
    if ($platform === 'telegram') {
        return function_exists('zarincode_telegram_enabled') && zarincode_telegram_enabled();
    }
    if (in_array($platform, array('bale', 'rubika'), true) && class_exists('\\ZarinShopBot\\Channels')) {
        $options = \ZarinShopBot\Channels::options();
        return isset($options[$platform . '_enabled'], $options[$platform . '_token'])
            && $options[$platform . '_enabled'] === '1' && (string) $options[$platform . '_token'] !== '';
    }
    return false;
}

function zarincode_normalize_broadcast_platforms($platforms = 'all') {
    $allowed = array('telegram', 'bale', 'rubika');
    $requested = ($platforms === 'all' || $platforms === null) ? $allowed : (array) $platforms;
    $requested = array_values(array_unique(array_filter(array_map('sanitize_key', $requested), static function($platform) use ($allowed) {
        return in_array($platform, $allowed, true);
    })));
    return array_values(array_filter($requested, 'zarincode_broadcast_platform_is_enabled'));
}

function zarincode_broadcast_chat_platform($chat_id) {
    $chat_id = (string) $chat_id;
    if (strpos($chat_id, 'bale_') === 0) { return 'bale'; }
    if (strpos($chat_id, 'rubika_') === 0) { return 'rubika'; }
    return 'telegram';
}

function zarincode_sendmessage_touser_switch($target, $message, $ID = 0, $platforms = 'all') {
    $platforms = zarincode_normalize_broadcast_platforms($platforms);
    if (function_exists('as_enqueue_async_action') && !defined('ZARINCODE_PROCESSING_BROADCAST')) {
        $action_id = as_enqueue_async_action('zarincode_process_broadcast', array($target, $message, (int) $ID, $platforms), 'zarincode');
        return $action_id ? 0 : false;
    }
    return zarincode_process_broadcast($target, $message, $ID, $platforms);
}

function zarincode_process_broadcast($target, $message, $ID = 0, $platforms = 'all') {
    $count = 0;
    $platforms = zarincode_normalize_broadcast_platforms($platforms);
    switch ((int) $target) {
        case 0:
            $count += zarincode_sendmessagetoall($message, $ID, $platforms);
            break;
        case 1:
            $count += zarincode_sendmessage_users($message, $ID, $platforms);
            break;
        case 2:
            $count += zarincode_sendmessage_groups($message, $ID, $platforms);
            break;
        case 3:
            $count += zarincode_sendmessage_groups($message, $ID, $platforms);
            $count += zarincode_sendmessage_users($message, $ID, $platforms);
            break;
        case 4:
            if (in_array('telegram', $platforms, true)) { $count += zarincode_sendmessage_channel($message, $ID); }
            break;
    }
    return $count;
}

add_action('zarincode_process_broadcast', function($target, $message, $ID, $platforms = 'all') {
    if (!defined('ZARINCODE_PROCESSING_BROADCAST')) {
        define('ZARINCODE_PROCESSING_BROADCAST', true);
    }
    zarincode_process_broadcast($target, $message, $ID, $platforms);
}, 10, 4);

function zarincode_send_post_notification($ID, $post) {
    if (
        !empty($_POST['zarincode_product_misc_nonce']) &&
        wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['zarincode_product_misc_nonce'])), 'zarincode_product_misc_save') &&
        get_post_type($ID) === 'product' && get_post_status($ID) === 'publish'
    ) {
        if (!empty($_POST['zarincode_m_send']) && isset($_POST['zarincode_m_send_target'])) {
            $target = sanitize_text_field(wp_unslash($_POST['zarincode_m_send_target']));
            zarincode_sendmessage_touser_switch($target, '', $ID);
        }
        if (!empty($_POST['zarincode_m_send_social'])) {
            $platforms = isset($_POST['zarincode_m_send_social_platforms'])
                ? array_map('sanitize_key', array_filter((array) wp_unslash($_POST['zarincode_m_send_social_platforms']), 'is_scalar'))
                : array();
            $platforms = array_values(array_intersect(array_unique($platforms), array('telegram', 'bale', 'rubika')));
            foreach ($platforms as $platform) {
                zarincode_send_social_product_post($ID, $platform);
            }
        }
    }
}

/** Send an explicitly selected product post to one configured channel, using that channel's own API credentials and title. */
function zarincode_send_social_product_post($product_id, $platform) {
    $product_id = absint($product_id);
    $platform = sanitize_key((string) $platform);
    if (!$product_id || !in_array($platform, array('telegram', 'bale', 'rubika'), true)) return false;
    $product = function_exists('wc_get_product') ? wc_get_product($product_id) : false;
    if (!$product || !$product->exists() || $product->get_status() !== 'publish') return false;

    $destination = '';
    $title_template = '';
    if ($platform === 'telegram') {
        if (!function_exists('zarincode_telegram_enabled') || !zarincode_telegram_enabled()) return false;
        $destination = trim((string) zarincode_option('channelusername'));
        $title_template = (string) zarincode_option('telegram_post_title');
        $api = null;
    } else {
        if (!class_exists(\ZarinShopBot\Channels::class) || !class_exists(\ZarinShopBot\Channel_API::class)) return false;
        $channel_options = \ZarinShopBot\Channels::options();
        if (empty($channel_options[$platform . '_enabled']) || empty($channel_options[$platform . '_token'])) return false;
        $destination = trim((string) ($channel_options[$platform . '_post_chat_id'] ?? ''));
        $title_template = (string) ($channel_options[$platform . '_post_title'] ?? '');
        $api = new \ZarinShopBot\Channel_API($platform, (string) $channel_options[$platform . '_token']);
    }
    if ($destination === '') return false;

    $name = class_exists(\ZarinShopBot\Core\WooBot::class)
        ? \ZarinShopBot\Core\WooBot::normalizeProductTitle($product->get_name())
        : sanitize_text_field($product->get_name());
    $title_template = trim($title_template) !== '' ? $title_template : __('محصول جدید: %product%', 'zarinshopbot');
    if (class_exists(\ZarinShopBot\Core\WooBot::class)) {
        $title_template = \ZarinShopBot\Core\WooBot::normalizeProductTitle($title_template);
    }
    if (class_exists(\ZarinShopBot\Core\WooBot::class)) {
        // Keep one canonical safe HTML fragment here; each provider adapter
        // converts it to Telegram HTML, Bale Markdown, or Rubika metadata.
        $safe_name = \ZarinShopBot\Core\WooBot::telegramPlainText($name);
        $post_title = str_replace('%product%', '<b>' . $safe_name . '</b>', $title_template);
    } else {
        $post_title = sanitize_text_field(str_replace('%product%', $name, $title_template));
    }
    $description = wp_trim_words(wp_strip_all_tags($product->get_short_description()), 45, '…');
    $price = wp_strip_all_tags($product->get_price_html());
    $message = $post_title;
    if ($description !== '') $message .= "\n\n" . $description;
    if ($price !== '') $message .= "\n\n" . sprintf(__('قیمت: %s', 'zarinshopbot'), html_entity_decode($price, ENT_QUOTES, 'UTF-8'));
    $message .= "\n\n" . get_permalink($product_id);

    if ($platform === 'telegram') {
        if (!class_exists(\ZarinShopBot\Core\WooBot::class)) return false;
        \ZarinShopBot\Core\WooBot::setChatId($destination);
        \ZarinShopBot\Core\WooBot::commands();
        $result = \ZarinShopBot\Core\WooBot::sendMessage(array('chat_id' => $destination, 'text' => $message));
    } else {
        $result = $api->send($destination, $message);
    }
    $success = false;
    if (!is_wp_error($result)) {
        if (is_array($result)) {
            $success = !empty($result['ok']);
        } elseif (is_object($result) && method_exists($result, 'isOk')) {
            $success = (bool) $result->isOk();
        } else {
            $success = $result === true;
        }
    }
    if ($success) {
        update_post_meta($product_id, '_zsb_social_post_sent_' . $platform, current_time('timestamp'));
    } elseif (function_exists('zarincode_log_event')) {
        zarincode_log_event('social_product_post_failed', array('platform' => $platform, 'product_id' => $product_id, 'error_code' => is_wp_error($result) ? sanitize_key($result->get_error_code()) : 'delivery_failed'));
    }
    return $success;
}

function zarincode_defaults() {
    require_once __DIR__ . '/defaults.php';
}

// Front-end Routing (Webhook, Mini App, Signed Payment Redirect)
add_action('template_redirect', function() {
    global $wp_query;

    // Telegram Mini App
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- This is a public Telegram Mini App route; every AJAX mutation verifies its nonce and initData.
    if (isset($_GET['telenexa_webapp']) || isset($_GET['zarincode_webapp']) || isset($_GET['sale_bot_webapp'])) {
        status_header(200);
        \ZarinShopBot\Core\WooBot::renderWebApp();
        exit;
    }

    // Telegram Bot Webhook
    $apikey = get_option('zarincode_webhook_key');
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Telegram webhook requests are authenticated by the secret URL/header.
    $telegram_webhook_request = !empty($apikey) && isset($_GET[$apikey]) && !empty($wp_query->query[$apikey]);
    if ($telegram_webhook_request) {
        status_header(200);
        if (!function_exists('zarincode_telegram_enabled') || !zarincode_telegram_enabled()) { exit; }
        require_once __DIR__ . '/parse.php';
        exit;
    }

    // Signed Payment Gateway Redirection
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Signed payment redirects use the order key/HMAC instead of a WordPress nonce.
    if ((isset($_GET['telenexa_payment']) || isset($_GET['zarincode_payment']) || isset($_GET['sale_bot_payment'])) && isset($_GET['order_id']) && isset($_GET['key'])) {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Signed payment redirects are authenticated by the WooCommerce order key/HMAC.
        $payment_key = isset($_GET['zarincode_payment']) ? 'zarincode_payment' : (isset($_GET['telenexa_payment']) ? 'telenexa_payment' : 'sale_bot_payment');
        $payment_method = sanitize_text_field(wp_unslash($_GET[$payment_key]));
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Signed payment redirects are authenticated by the WooCommerce order key/HMAC.
        $order_id = absint(wp_unslash($_GET['order_id']));
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Signed payment redirects are authenticated by the WooCommerce order key/HMAC.
        $order_key = sanitize_text_field(wp_unslash($_GET['key']));
        \ZarinShopBot\Core\WooBot::redirectPayment($order_id, $order_key, $payment_method);
        exit;
    }
});

// Mini App AJAX Endpoints
add_action('wp_ajax_zarincode_webapp_products', [\ZarinShopBot\Core\WooBot::class, 'ajaxGetProducts']);
add_action('wp_ajax_nopriv_zarincode_webapp_products', [\ZarinShopBot\Core\WooBot::class, 'ajaxGetProducts']);
add_action('wp_ajax_zarincode_webapp_phone_otp_send', [\ZarinShopBot\Core\WooBot::class, 'ajaxSendPhoneOtp']);
add_action('wp_ajax_nopriv_zarincode_webapp_phone_otp_send', [\ZarinShopBot\Core\WooBot::class, 'ajaxSendPhoneOtp']);
add_action('wp_ajax_zarincode_webapp_phone_otp_verify', [\ZarinShopBot\Core\WooBot::class, 'ajaxVerifyPhoneOtp']);
add_action('wp_ajax_nopriv_zarincode_webapp_phone_otp_verify', [\ZarinShopBot\Core\WooBot::class, 'ajaxVerifyPhoneOtp']);
add_action('wp_ajax_zarincode_webapp_checkout', [\ZarinShopBot\Core\WooBot::class, 'ajaxCheckout']);
add_action('wp_ajax_nopriv_zarincode_webapp_checkout', [\ZarinShopBot\Core\WooBot::class, 'ajaxCheckout']);
add_action('wp_ajax_zarincode_webapp_sync_cart', [\ZarinShopBot\Core\WooBot::class, 'ajaxSyncCart']);
add_action('wp_ajax_nopriv_zarincode_webapp_sync_cart', [\ZarinShopBot\Core\WooBot::class, 'ajaxSyncCart']);
add_action('wp_ajax_zarincode_webapp_orders', [\ZarinShopBot\Core\WooBot::class, 'ajaxGetOrders']);
add_action('wp_ajax_nopriv_zarincode_webapp_orders', [\ZarinShopBot\Core\WooBot::class, 'ajaxGetOrders']);
add_action('wp_ajax_zarincode_webapp_shipping_tax', [\ZarinShopBot\Core\WooBot::class, 'ajaxGetShippingAndTax']);
add_action('wp_ajax_nopriv_zarincode_webapp_shipping_tax', [\ZarinShopBot\Core\WooBot::class, 'ajaxGetShippingAndTax']);
add_action('wp_ajax_zarincode_webapp_validate_coupon', [\ZarinShopBot\Core\WooBot::class, 'ajaxValidateCoupon']);
add_action('wp_ajax_nopriv_zarincode_webapp_validate_coupon', [\ZarinShopBot\Core\WooBot::class, 'ajaxValidateCoupon']);

// Admin Diagnostic & Health-Check Endpoints
add_action('wp_ajax_zarincode_test_connection', function() {
    check_ajax_referer('zarincode_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => esc_html__('Access denied.', 'zarinshopbot')]);
    }
    \ZarinShopBot\Core\WooBot::init('out');
    try {
        $result = \ZarinShopBot\Core\Http\TelegramApiAdapter::request('getMe');
        if ($result && $result->isOk()) {
            $user = $result->getResult();
            // translators: 1: Telegram Bot ID, 2: Bot first name, 3: Bot username
            $api_username = sanitize_user((string) $user->getUsername(), true);
            $configured_username = ltrim(sanitize_user((string) zarincode_option('username'), true), '@');
            $msg = sprintf(esc_html__('Connected successfully! Bot ID: %1$s | Name: %2$s | Username: @%3$s', 'zarinshopbot'), esc_html($user->getId()), esc_html($user->getFirstName()), esc_html($api_username));
            if ($configured_username !== '' && strcasecmp($configured_username, $api_username) !== 0) {
                $msg .= '<br><strong>' . esc_html__('Warning:', 'zarinshopbot') . '</strong> ' . sprintf(
                    esc_html__('The saved Bot Username (@%1$s) does not match this token (@%2$s). Select the token owner in BotFather and update the saved username.', 'zarinshopbot'),
                    esc_html($configured_username),
                    esc_html($api_username)
                );
            }
            wp_send_json_success([
                'message' => $msg
            ]);
        } else {
            $desc = ($result && method_exists($result, 'getDescription')) ? $result->getDescription() : esc_html__('Unknown API response', 'zarinshopbot');
            wp_send_json_error([
                'message' => esc_html__('Telegram API Error: ', 'zarinshopbot') . esc_html($desc)
            ]);
        }
    } catch (\Exception $e) {
        wp_send_json_error([
            'message' => esc_html__('Connection Exception: ', 'zarinshopbot') . esc_html($e->getMessage())
        ]);
    }
});

add_action('wp_ajax_zarincode_test_webhook', function() {
    check_ajax_referer('zarincode_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => esc_html__('Access denied.', 'zarinshopbot')]);
    }
    \ZarinShopBot\Core\WooBot::init('out');
    try {
        $result = \ZarinShopBot\Core\Http\TelegramApiAdapter::request('getWebhookInfo');
        if ($result && $result->isOk()) {
            $info = $result->getResult();
            $url = $info->getUrl();
            $pending = $info->getPendingUpdateCount();
            $last_error = $info->getLastErrorMessage();
            $last_error_date = $info->getLastErrorDate();
            $allowed_updates = $info->getAllowedUpdates();

            $safe_url = $url ? (string) wp_parse_url($url, PHP_URL_HOST) : esc_html__('Not set', 'zarinshopbot');
            // translators: 1: Webhook host URL, 2: Pending update count
            $msg = sprintf(esc_html__('Webhook URL: %1$s | Pending Updates: %2$d', 'zarinshopbot'), esc_html($safe_url), (int) $pending);
            if (is_array($allowed_updates) && !empty($allowed_updates)) {
                $callbacks_enabled = in_array('callback_query', $allowed_updates, true);
                $msg .= ' | ' . esc_html__('Inline callbacks', 'zarinshopbot') . ': ' . ($callbacks_enabled ? esc_html__('enabled', 'zarinshopbot') : esc_html__('NOT subscribed', 'zarinshopbot'));
            } else {
                $msg .= ' | ' . esc_html__('Inline callbacks', 'zarinshopbot') . ': ' . esc_html__('Telegram default (not explicitly filtered)', 'zarinshopbot');
            }
            if (!empty($last_error)) {
                // translators: 1: Last error timestamp, 2: Error description
                $msg .= ' | ' . sprintf(esc_html__('Last Error (%1$s): %2$s', 'zarinshopbot'), $last_error_date ? gmdate('Y-m-d H:i:s', $last_error_date) : '', esc_html($last_error));
            }
            $header = (array) get_option('zarincode_webhook_header_status', []);
            $msg .= ' | ' . esc_html__('Security header', 'zarinshopbot') . ': ' . (zarincode_option('webhook_secret_token') === '' ? 'disabled' : ($header['status'] ?? 'not observed'));
            if (!empty($header['checked_at'])) {
                $msg .= ' (' . esc_html($header['checked_at']) . ')';
            }
            wp_send_json_success(['message' => esc_html(zarincode_redact($msg)), 'pending_updates' => (int) $pending]);
        } else {
            $desc = ($result && method_exists($result, 'getDescription')) ? $result->getDescription() : esc_html__('Unknown API response', 'zarinshopbot');
            wp_send_json_error([
                'message' => esc_html__('Telegram API Error: ', 'zarinshopbot') . esc_html($desc)
            ]);
        }
    } catch (\Exception $e) {
        wp_send_json_error([
            'message' => esc_html__('Webhook Check Exception: ', 'zarinshopbot') . esc_html($e->getMessage())
        ]);
    }
});

add_action('wp_ajax_zarincode_test_proxy', function() {
    check_ajax_referer('zarincode_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => esc_html__('Access denied.', 'zarinshopbot')]);
    }
    \ZarinShopBot\Core\WooBot::init('out');
    try {
        $result = \ZarinShopBot\Core\Http\ProxyManager::test();
        if (!empty($result['ok'])) {
            // translators: 1: Proxy address, 2: Response time in milliseconds
            wp_send_json_success(['message' => sprintf(esc_html__('Proxy connection successful via %1$s (%2$d ms).', 'zarinshopbot'), esc_html($result['proxy']), (int) $result['ms'])]);
        }
        // translators: 1: Proxy address, 2: Failure message
        wp_send_json_error(['message' => sprintf(esc_html__('Proxy test failed via %1$s: %2$s', 'zarinshopbot'), esc_html($result['proxy']), esc_html($result['message']))]);
    } catch (\Throwable $e) {
        wp_send_json_error(['message' => esc_html__('Proxy test exception: ', 'zarinshopbot') . esc_html($e->getMessage())]);
    }
});

add_action('wp_ajax_zarincode_run_tests', function() {
    check_ajax_referer('zarincode_admin_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => esc_html__('Access denied.', 'zarinshopbot')]);
    }
    $suite_file = __DIR__ . '/tests/zarincode_test_suite.php';
    if (!file_exists($suite_file)) {
        wp_send_json_error(['message' => esc_html__('Test suite file not found in package.', 'zarinshopbot')]);
    }
    require_once $suite_file;
    $suite = new \SaleBotTestSuite();
    $report = $suite->runAll();
    wp_send_json_success($report);
});

// Automated Notifications & Event Hooks. Telegram calls are dispatched through
// Action Scheduler (or WP-Cron fallback) so checkout/admin requests stay fast.
add_action('woocommerce_new_order', [\ZarinShopBot\Core\WooBot::class, 'queueOrderCreated'], 20, 1);
add_action('woocommerce_order_status_changed', [\ZarinShopBot\Core\WooBot::class, 'queueOrderStatusChanged'], 20, 3);
add_action('woocommerce_payment_complete', [\ZarinShopBot\Core\WooBot::class, 'queuePaymentCompleted'], 20, 1);
add_action('woocommerce_payment_complete', [\ZarinShopBot\Channels::class, 'clearPaidOrderCart'], 30, 1);
// The admin dashboard uses shared transients for costly order aggregates; invalidate them on changes.
add_action('woocommerce_new_order', [\ZarinShopBot\Core\WooBot::class, 'invalidateDashboardCache'], 5, 1);
add_action('woocommerce_order_status_changed', [\ZarinShopBot\Core\WooBot::class, 'invalidateDashboardCache'], 5, 1);
add_action('woocommerce_payment_complete', [\ZarinShopBot\Core\WooBot::class, 'invalidateDashboardCache'], 5, 1);
add_action('woocommerce_update_order', [\ZarinShopBot\Core\WooBot::class, 'invalidateDashboardCache'], 5, 1);

add_action('woocommerce_product_set_stock_status', function($product_id, $status) {
    if ($status === 'instock') {
        \ZarinShopBot\Core\WooBot::queueBackInStock($product_id);
    }
}, 20, 2);

add_action('woocommerce_update_product_price', function($product_id, $price) {
    \ZarinShopBot\Core\WooBot::checkPriceDropAlerts($product_id, $price);
}, 20, 2);

add_action('zarincode_notify_order_created', [\ZarinShopBot\Core\WooBot::class, 'onOrderCreated'], 10, 1);
add_action('zarincode_notify_order_status_changed', [\ZarinShopBot\Core\WooBot::class, 'onOrderStatusChanged'], 10, 3);
add_action('zarincode_notify_payment_completed', [\ZarinShopBot\Core\WooBot::class, 'onPaymentCompleted'], 10, 1);
add_action('zarincode_notify_back_in_stock', [\ZarinShopBot\Core\WooBot::class, 'notifyBackInStock'], 10, 1);

add_action('zarincode_check_abandoned_cart', [\ZarinShopBot\Core\WooBot::class, 'sendAbandonedCartReminder'], 10, 1);
add_action('zarincode_retry_send_message', [\ZarinShopBot\Core\WooBot::class, 'executeRetrySendMessage'], 10, 1);

add_filter('query_vars', function($vars) {
    $vars[] = get_option('zarincode_webhook_key');
    return $vars;
});

function zarincode_option($name) {
    $channel_context = isset($GLOBALS['zarinshopbot_channel_context']) && is_array($GLOBALS['zarinshopbot_channel_context'])
        ? $GLOBALS['zarinshopbot_channel_context'] : array();
    if (!empty($channel_context['platform'])) {
        if ($name === 'token') { return (string) ($channel_context['token'] ?? ''); }
        if ($name === 'username') { return (string) ($channel_context['username'] ?? 'zarinshopbot'); }
    }
    $options = get_option('zarincode_settings');
    if (is_array($options)) {
        $message_option_map = ['wmuser' => 'start', 'bmuser' => 'bye', 'messagehome' => 'home', 'contactuspage' => 'contact', 'help_message' => 'help', 'aboutuspage' => 'about'];
        $platform = sanitize_key((string) ($channel_context['platform'] ?? 'telegram'));
        if (isset($message_option_map[$name], $options['message_overrides'][$platform][$message_option_map[$name]]) && trim((string) $options['message_overrides'][$platform][$message_option_map[$name]]) !== '') {
            return $options['message_overrides'][$platform][$message_option_map[$name]];
        }
    }
    if ($name === 'token' && is_array($options)) {
        return zarincode_get_telegram_token($options);
    }
    if ($name === 'telegram_provider_token' && is_array($options)) {
        $stored_token = (string) ($options['telegram_provider_token_enc'] ?? $options['telegram_provider_token'] ?? '');
        if (strpos($stored_token, 'gcm:') === 0 || strpos($stored_token, 'plain:') === 0) {
            return \ZarinShopBot\Core\Http\ProxyManager::decrypt($stored_token);
        }
        return $stored_token;
    }
    if (is_array($options) && isset($options[$name])) {
        return $options[$name];
    }
    return false;
}

add_filter('user_can_richedit', function($default) {
    global $post;
    if ($post && 'telegram_commands' == get_post_type($post)) return false;
    return $default;
});

function zarincode_log($action, $chat_id, $text) {
    if (preg_match('/error|fail|security_alert/i', (string) $text)) {
        zarincode_log_event('legacy_error', ['action' => $action, 'description' => $text]);
    }
}

/** Flush request-local structured events with one option write instead of one DB write per API/update log. */
function zarincode_flush_event_log_buffer() {
    if (empty($GLOBALS['zarincode_event_log_buffer']) || !is_array($GLOBALS['zarincode_event_log_buffer'])) return;
    $buffer = $GLOBALS['zarincode_event_log_buffer'];
    $GLOBALS['zarincode_event_log_buffer'] = [];
    $logs = get_option('wp_zarincode_activity_log', []);
    $logs = is_array($logs) ? $logs : [];
    $logs = array_slice(array_merge($logs, $buffer), -500);
    update_option('wp_zarincode_activity_log', $logs, false);
}

/** Unified structured activity log for webhook, button, API and proxy events. */
function zarincode_log_event($event, array $context = []) {
    if (function_exists('zarincode_option') && zarincode_option('zarincode_logging_enabled') === '0') return;
    if (zarincode_option('zarincode_log_level') === 'errors' && !preg_match('/error|fail|exception|exceeded|unresolved|security/i', $event)) return;
    $context = zarincode_redact($context);
    if (!isset($GLOBALS['zarincode_event_log_buffer']) || !is_array($GLOBALS['zarincode_event_log_buffer'])) $GLOBALS['zarincode_event_log_buffer'] = [];
    $GLOBALS['zarincode_event_log_buffer'][] = ['timestamp' => time(), 'time' => current_time('mysql'), 'event' => sanitize_key($event), 'chat_id' => '', 'context' => $context];
    // A safety cap keeps unusually chatty requests bounded without writing each event separately.
    if (count($GLOBALS['zarincode_event_log_buffer']) >= 250 || !function_exists('add_action')) {
        zarincode_flush_event_log_buffer();
        return;
    }
    static $shutdown_flush_registered = false;
    if (!$shutdown_flush_registered) {
        add_action('shutdown', 'zarincode_flush_event_log_buffer', 999);
        $shutdown_flush_registered = true;
    }
}

function zarincode_sendmessagetoall($message, $ID = 0, $platforms = 'all') {
    $count = 0;
    $platforms = zarincode_normalize_broadcast_platforms($platforms);
    if (in_array('telegram', $platforms, true)) { $count += zarincode_sendmessage_channel($message, $ID); }
    $count += zarincode_sendmessage_groups($message, $ID, $platforms);
    $count += zarincode_sendmessage_users($message, $ID, $platforms);
    return $count;
}

// Efficient chunked broadcast without limit=-1
function zarincode_sendmessage_users($message, $ID = 0, $platforms = 'all') {
    $platforms = zarincode_normalize_broadcast_platforms($platforms);
    global $wpdb;
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $chat_ids = $wpdb->get_col("SELECT DISTINCT post_title FROM {$wpdb->posts} WHERE post_type = 'zarincode_user' AND post_status = 'private'");
    $count = 0;

    if (!empty($chat_ids)) {
        foreach ($chat_ids as $chat_id) {
            $chat_id = \ZarinShopBot\Core\WooBot::fixPersianChar($chat_id);
            if (empty($chat_id) || !in_array(zarincode_broadcast_chat_platform($chat_id), $platforms, true)) continue;

            if (!empty($ID)) {
                \ZarinShopBot\Core\WooBot::setChatId($chat_id);
                \ZarinShopBot\Core\WooBot::commands();
                \ZarinShopBot\Core\WooBot::getProduct('P', $ID);
            } else {
                \ZarinShopBot\Core\WooBot::sendMessage([
                    'chat_id'  => $chat_id,
                    'text'     => $message,
                    'keyboard' => [[\ZarinShopBot\Core\WooBot::btnHome()]]
                ]);
            }
            $count++;
            usleep(25000); // 25ms throttle
        }
    }
    return $count;
}

// Efficient chunked group broadcast without limit=-1
function zarincode_sendmessage_groups($message, $ID = 0, $platforms = 'all') {
    $platforms = zarincode_normalize_broadcast_platforms($platforms);
    global $wpdb;
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $group_ids = $wpdb->get_col("SELECT DISTINCT post_title FROM {$wpdb->posts} WHERE post_type = 'zarincode_group' AND post_status = 'private'");
    $count = 0;

    if (!empty($group_ids)) {
        foreach ($group_ids as $group_id) {
            $group_id = \ZarinShopBot\Core\WooBot::fixPersianChar($group_id);
            if (empty($group_id) || !in_array(zarincode_broadcast_chat_platform($group_id), $platforms, true)) continue;

            if (!empty($ID)) {
                \ZarinShopBot\Core\WooBot::setChatId($group_id);
                \ZarinShopBot\Core\WooBot::getProduct('P', $ID);
            } else {
                \ZarinShopBot\Core\WooBot::sendMessage([
                    'chat_id'  => $group_id,
                    'text'     => $message,
                    'keyboard' => [[\ZarinShopBot\Core\WooBot::btnHome()]]
                ]);
            }
            $count++;
            usleep(25000);
        }
    }
    return $count;
}

function zarincode_delete_custom_posts($post_type = 'zarincode_user') {
    global $wpdb;
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $result = $wpdb->query($wpdb->prepare("
        DELETE posts, pt, pm 
        FROM {$wpdb->posts} posts 
        LEFT JOIN {$wpdb->term_relationships} pt ON pt.object_id = posts.ID 
        LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = posts.ID 
        WHERE posts.post_type = %s
    ", $post_type));
    return $result !== false;
}

function zarincode_sendmessage_channel($message = '', $ID = 0) {
    if (zarincode_option('channelusername')) {
        if (!empty($ID)) {
            \ZarinShopBot\Core\WooBot::setChatId(zarincode_option('channelusername'));
            \ZarinShopBot\Core\WooBot::commands();
            \ZarinShopBot\Core\WooBot::getProduct('P', $ID);
        } else {
            \ZarinShopBot\Core\WooBot::sendMessage([
                'chat_id' => zarincode_option('channelusername'),
                'text'    => $message,
            ]);
        }
        return 1;
    }
    return 0;
}

add_filter('enter_title_here', function($input) {
    global $post_type;
    if (is_admin() && 'telegram_commands' == $post_type) {
        return esc_html__('Type here your command', 'zarinshopbot') . ' <small><small>(eg. <b>/contacts</b> or <b>help</b>)</small></small>';
    }
    return $input;
});

add_action('admin_print_footer_scripts', function() {
    global $post;
    if (wp_script_is('quicktags') && isset($post) && is_object($post) && $post->post_type === 'telegram_commands') {
        $quicktags_script = "if (typeof QTags !== 'undefined') {
            QTags.addButton('wpt_bold', '*Bold*', '*', '*', 'b', 'Bold', 1);
            QTags.addButton('wpt_italic', '_Italic_', '_', '_', 'i', 'Italic', 2);
            QTags.addButton('wpt_link', '[text](url)', '[text](', ')', 'l', 'Link', 3);
        }";
        wp_add_inline_script('quicktags', $quicktags_script);
    }
});

add_filter('quicktags_settings', function($qtInit) {
    global $post;
    if ($post && $post->post_type == 'telegram_commands') {
        $qtInit['buttons'] = ',';
    }
    return $qtInit;
}, 10, 1);

add_action('widgets_init', function() {
    require_once __DIR__ . '/widget.php';
    register_widget('ZarinShopBot_Widget');
});

add_action('wp_enqueue_scripts', function() {
    if (function_exists('is_active_widget') && is_active_widget(false, false, 'zarincode_widget', true)) {
        wp_enqueue_style('zarinshopbot-typography', plugins_url('assets/css/typography.css', __FILE__), [], (string) ZARINSHOPBOT_VERSION);
    }
});

add_action('admin_init', function() {
    if (!is_admin()) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
    if ($page !== 'zarincode_zarinshopbot_setting') {
        return;
    }

    // Prevent WordPress's emoji detector from replacing menu emoji glyphs with remote Twemoji images on this screen.
    // Run before admin_enqueue_scripts so both the legacy print callback and newer emoji-style enqueue path are covered.
    remove_action('admin_enqueue_scripts', 'wp_enqueue_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    add_filter('tiny_mce_plugins', function($plugins) {
        return array_values(array_filter((array) $plugins, function($plugin) {
            return strtolower((string) $plugin) !== 'wpemoji';
        }));
    });
}, 1);

add_action('admin_enqueue_scripts', function($hook) {
    if (!is_admin()) {
        return;
    }
    global $pagenow, $post_type;

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
    // Keep the persistent plugin menu bilingual; the asset is version-cached and the font files are local.
    wp_enqueue_style('zarinshopbot-typography', plugins_url('assets/css/typography.css', __FILE__), [], (string) ZARINSHOPBOT_VERSION);
    $plugin_pages = ['zarincode_zarinshopbot', 'zarincode_zarinshopbot_setting', 'zarincode_send', 'zarincode_guide', 'zarinshopbot-channels', 'zarinshopbot_bale', 'zarinshopbot_rubika', 'telenexa_main', 'telenexa_settings'];
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $post_id = isset($_GET['post']) ? absint(wp_unslash($_GET['post'])) : 0;
    $is_product_editor = in_array($pagenow, ['post.php', 'post-new.php'], true)
        && (($post_type === 'product') || ($post_id && get_post_type($post_id) === 'product'));

    // The stylesheet scopes font and width changes to ZarinShopBot UI only.
    // The plugin menu is now top-level regardless of WooCommerce's menu state.
    if (in_array($page, $plugin_pages, true)) {
        // Load the core Dashicons font for icon classes without a local SVG mapping.
        wp_enqueue_style('dashicons');
        wp_enqueue_style('zarinshopbot-admin-menu', plugins_url('assets/css/admin-menu.css', __FILE__), [], (string) ZARINSHOPBOT_VERSION);
        wp_enqueue_style('zarinshopbot-local-icons', plugins_url('assets/css/local-icons.css', __FILE__), [], (string) ZARINSHOPBOT_VERSION);
    }

    // Product editor controls: existing metabox behavior plus explicit per-platform social publishing.
    if ($is_product_editor) {
        wp_enqueue_script('zarinshopbot-admin-product', plugins_url('assets/js/admin-product.js', __FILE__), ['jquery'], (string) ZARINSHOPBOT_VERSION, true);
        wp_enqueue_style('zarinshopbot-social-publish', plugins_url('assets/css/admin-social-publish.css', __FILE__), [], (string) ZARINSHOPBOT_VERSION);
        wp_enqueue_script('zarinshopbot-admin-social-publish', plugins_url('assets/js/admin-social-publish.js', __FILE__), ['jquery'], (string) ZARINSHOPBOT_VERSION, true);
        wp_localize_script('zarinshopbot-admin-social-publish', 'zarinshopbotSocialPublish', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'sending' => __('در حال ارسال محصول...', 'zarinshopbot'),
            'sent' => __('ارسال با موفقیت انجام شد.', 'zarinshopbot'),
            'failed' => __('ارسال انجام نشد. وضعیت ربات و مقصد این کانال را بررسی کنید.', 'zarinshopbot'),
        ]);
    }

    // ZarinShopBot\Core Dashboard / Main Hub
    if ($page === 'zarincode_zarinshopbot' || $page === 'telenexa_main') {
        wp_enqueue_style('zarinshopbot-admin-main', plugins_url('assets/css/admin-main.css', __FILE__), [], (string) ZARINSHOPBOT_VERSION);
        wp_enqueue_script('zarinshopbot-admin-main', plugins_url('assets/js/admin-main.js', __FILE__), ['jquery', 'editor'], (string) ZARINSHOPBOT_VERSION, true);
        wp_localize_script('zarinshopbot-admin-main', 'zarinshopbotMainI18n', [
            'previewPlaceholder' => __('Your live message preview will appear here in real time as you type...', 'zarinshopbot'),
            'copied'             => __('Copied!', 'zarinshopbot'),
            'boldText'           => __('Bold text', 'zarinshopbot'),
            'italicText'         => __('Italic text', 'zarinshopbot'),
            'codeText'           => __('Code', 'zarinshopbot'),
            'linkTitle'          => __('Link title', 'zarinshopbot'),
        ]);
        wp_localize_script('zarinshopbot-admin-main', 'telenexaMainI18n', [
            'previewPlaceholder' => __('Your live message preview will appear here in real time as you type...', 'zarinshopbot'),
            'copied'             => __('Copied!', 'zarinshopbot'),
            'boldText'           => __('Bold text', 'zarinshopbot'),
            'italicText'         => __('Italic text', 'zarinshopbot'),
            'codeText'           => __('Code', 'zarinshopbot'),
            'linkTitle'          => __('Link title', 'zarinshopbot'),
        ]);
    }

    // ZarinShopBot\Core Settings
    if (in_array($page, ['zarincode_zarinshopbot_setting', 'telenexa_settings', 'zarincode_send', 'zarinshopbot_bale', 'zarinshopbot_rubika', 'zarinshopbot-channels'], true)) {
        wp_enqueue_script('jquery');
        wp_enqueue_style('zarinshopbot-admin-settings', plugins_url('assets/css/admin-settings.css', __FILE__), [], (string) ZARINSHOPBOT_VERSION);
        wp_enqueue_script('zarinshopbot-admin-settings', plugins_url('assets/js/admin-settings.js', __FILE__), ['jquery'], (string) ZARINSHOPBOT_VERSION, true);
        if ($page === 'zarincode_zarinshopbot_setting') {
            wp_enqueue_media();
            // Enqueue the card editor from the main plugin bootstrap, independent of WooCommerce's gateway admin lifecycle.
            wp_enqueue_style('zarinshopbot-card-transfer-admin', plugins_url('assets/css/card-transfer-admin.css', __FILE__), [], (string) ZARINSHOPBOT_VERSION);
            wp_enqueue_script('zarinshopbot-card-transfer-admin', plugins_url('assets/js/card-transfer-admin.js', __FILE__), [], (string) ZARINSHOPBOT_VERSION, true);
        }
        wp_localize_script('zarinshopbot-admin-settings', 'zarinshopbotSettings', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('zarincode_admin_nonce'),
            'i18n'     => [
                'tokenGenerated'   => __('Secret token generated! Remember to save settings.', 'zarinshopbot'),
                'connecting'       => __('Connecting to Telegram API...', 'zarinshopbot'),
                'connectionFailed' => __('Connection failed', 'zarinshopbot'),
                'networkError'     => __('Server network error occurred.', 'zarinshopbot'),
                'checkingWebhook'  => __('Checking webhook status from Telegram...', 'zarinshopbot'),
                'webhookFailed'    => __('Webhook check failed', 'zarinshopbot'),
                'testingProxy'     => __('Testing proxy and fallback...', 'zarinshopbot'),
                'proxyFailed'      => __('Proxy test failed.', 'zarinshopbot'),
                'executingTests'   => __('Executing diagnostic unit tests...', 'zarinshopbot'),
                'testSummary'      => __('Automated Diagnostic Tests Summary:', 'zarinshopbot'),
                'suiteFailed'      => __('Failed to execute diagnostic test suite.', 'zarinshopbot'),
                'ajaxFailed'       => __('Test suite AJAX request failed.', 'zarinshopbot'),
                'channelLoading'   => __('Loading channel settings…', 'zarinshopbot'),
                'channelLoadError' => __('Could not load settings. Check your connection and try again.', 'zarinshopbot'),
                'retryChannel'     => __('Try again', 'zarinshopbot'),
                'variableAdded'    => __('Variable %s added successfully.', 'zarinshopbot'),
                'commandsCopied'   => __('Commands copied successfully.', 'zarinshopbot'),
                'commandsCopiedShort' => __('Commands copied.', 'zarinshopbot'),
                'manualCopy'       => __('Select the text and copy it manually.', 'zarinshopbot'),
                'passed'           => __('Passed', 'zarinshopbot'),
                'failed'           => __('Failed', 'zarinshopbot'),
            ],
        ]);
        wp_localize_script('zarinshopbot-admin-settings', 'telenexaSettings', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('zarincode_admin_nonce'),
            'i18n' => [
                'tokenGenerated' => __('Secret token generated! Remember to save settings.', 'zarinshopbot'),
                'connecting' => __('Connecting to Telegram API...', 'zarinshopbot'),
                'connectionFailed' => __('Connection failed', 'zarinshopbot'),
                'networkError' => __('Server network error occurred.', 'zarinshopbot'),
                'checkingWebhook' => __('Checking webhook status from Telegram...', 'zarinshopbot'),
                'webhookFailed' => __('Webhook check failed', 'zarinshopbot'),
                'testingProxy' => __('Testing proxy and fallback...', 'zarinshopbot'),
                'proxyFailed' => __('Proxy test failed.', 'zarinshopbot'),
                'executingTests' => __('Executing diagnostic unit tests...', 'zarinshopbot'),
                'testSummary' => __('Automated Diagnostic Tests Summary:', 'zarinshopbot'),
                'suiteFailed' => __('Failed to execute diagnostic test suite.', 'zarinshopbot'),
                'ajaxFailed' => __('Test suite AJAX request failed.', 'zarinshopbot'),
                'channelLoading' => __('Loading channel settings…', 'zarinshopbot'),
                'channelLoadError' => __('Could not load settings. Check your connection and try again.', 'zarinshopbot'),
                'retryChannel' => __('Try again', 'zarinshopbot'),
                'variableAdded' => __('Variable %s added successfully.', 'zarinshopbot'),
                'commandsCopied' => __('Commands copied successfully.', 'zarinshopbot'),
                'commandsCopiedShort' => __('Commands copied.', 'zarinshopbot'),
                'manualCopy' => __('Select the text and copy it manually.', 'zarinshopbot'),
                'passed' => __('Passed', 'zarinshopbot'),
                'failed' => __('Failed', 'zarinshopbot'),
            ],
        ]);
    }

    if (in_array($page, ['zarincode_zarinshopbot_setting', 'zarincode_zarinshopbot'], true)) {
        wp_enqueue_editor();
        wp_enqueue_script('zarinshopbot-message-editor', plugins_url('assets/js/message-editor.js', __FILE__), ['jquery', 'editor'], (string) ZARINSHOPBOT_VERSION, true);
    }

    // Enqueue the unified admin refinement layer last on every plugin-owned admin screen.
    if (in_array($page, $plugin_pages, true)) {
        wp_enqueue_style('zarinshopbot-admin-polish', plugins_url('assets/css/admin-polish.css', __FILE__), [], (string) ZARINSHOPBOT_VERSION);
    }
});

function zarincode_fix_emoji_input($text, $nofix = 0) {
    if ($nofix) return $text;
    $text = str_ireplace("<br>", "\n", $text);
    return wp_strip_all_tags($text);
}

function zarincode_footer_text_call() {
    add_filter('admin_footer_text', 'zarincode_footer_text');
}

function zarincode_footer_text($default) {
    // translators: 1: Developer link, 2: Plugin title
    $text = sprintf(__('Developed by %1$s | %2$s', 'zarinshopbot'), '<a href="https://zarincode.com" target="_blank" rel="noopener noreferrer" style="font-weight:600;color:#7B5B00;">Ehsan NaderiPanah</a>', esc_html__('ربات زرین شاپ | ZarinShopBot', 'zarinshopbot'));
    return wp_kses($text, ['a' => ['href' => [], 'target' => [], 'rel' => [], 'style' => []]]);
}

function zarincode_get_plugin_uri() {
    return plugin_dir_url(__FILE__);
}

add_action('woocommerce_admin_order_data_after_billing_address', function($order) {
    $source = sanitize_key((string) $order->get_meta('_order_from', true));
    $order_from = in_array($source, ['telegram', 'bale', 'rubika'], true) ? esc_html(strtoupper($source) . ' bot') : esc_html__('Web site', 'zarinshopbot');
    echo '<p><strong>' . esc_html__('From', 'zarinshopbot') . ':</strong><br>' . esc_html($order_from) . '</p>';
    if ($order->get_meta('_zarinshopbot_payment_provider', true) === 'bale_wallet' && $order->is_paid()) {
        $paid_irr = (int) $order->get_meta('_zarinshopbot_paid_amount_irr', true);
        echo '<p><strong>' . esc_html__('Bale wallet payment', 'zarinshopbot') . ':</strong><br>' . esc_html(number_format_i18n($paid_irr)) . ' ' . esc_html__('IRR', 'zarinshopbot') . '</p>';
        $bale_charge = (string) $order->get_meta('_zarinshopbot_bale_charge_id', true);
        if ($bale_charge !== '') {
            echo '<p><strong>' . esc_html__('Bale charge ID', 'zarinshopbot') . ':</strong><br><code dir="ltr">' . esc_html($bale_charge) . '</code></p>';
        }
    }
    if (class_exists(\ZarinShopBot\Core\Stars::class)) {
        \ZarinShopBot\Core\Stars::renderAdminOrderStars($order);
    }
}, 10, 1);

function zarincode_add_hide_cat_field($term = '') {
    $t_id = (!empty($term) && isset($term->term_id)) ? (int) $term->term_id : 0;
    $term_meta = ['zarincode_hide_cat' => 0];
    if ($t_id) {
        $saved = get_option("taxonomy_$t_id");
        if (is_array($saved)) {
            $term_meta = $saved;
        }
    }
    wp_nonce_field('zarincode_cat_meta_save', 'zarincode_cat_meta_nonce');
    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="term_meta[zarincode_hide_cat]"><?php esc_html_e('Show in ZarinShopBot bots', 'zarinshopbot'); ?></label></th>
        <td>
            <select name="term_meta[zarincode_hide_cat]" id="term_meta[zarincode_hide_cat]" class="postform">
                <option value="0" <?php selected(!empty($term_meta['zarincode_hide_cat']) ? $term_meta['zarincode_hide_cat'] : 0, 0); ?>><?php esc_html_e('Yes', 'zarinshopbot'); ?></option>
                <option value="1" <?php selected(!empty($term_meta['zarincode_hide_cat']) ? $term_meta['zarincode_hide_cat'] : 0, 1); ?>><?php esc_html_e('No', 'zarinshopbot'); ?></option>
            </select>
        </td>
    </tr>
<?php }
add_action('product_cat_add_form_fields', 'zarincode_add_hide_cat_field', 10, 2);
add_action('product_cat_edit_form_fields', 'zarincode_add_hide_cat_field', 10, 2);

function zarincode_save_hide_cat_field($term_id = 0) {
    if (
        !empty($term_id) &&
        isset($_POST['term_meta']) &&
        isset($_POST['zarincode_cat_meta_nonce']) &&
        wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['zarincode_cat_meta_nonce'])), 'zarincode_cat_meta_save')
    ) {
        if (!current_user_can('edit_term', (int) $term_id)) {
            return;
        }
        $t_id = (int) $term_id;
        $term_meta = get_option("taxonomy_$t_id");
        if (!is_array($term_meta)) {
            $term_meta = [];
        }
        $raw_term_meta = isset($_POST['term_meta']) && is_array($_POST['term_meta'])
            ? map_deep(wp_unslash($_POST['term_meta']), 'sanitize_text_field')
            : [];
        $raw_meta = is_array($raw_term_meta) ? $raw_term_meta : [];
        foreach ($raw_meta as $key => $val) {
            if (is_scalar($val)) {
                $term_meta[sanitize_key($key)] = sanitize_text_field($val);
            }
        }
        update_option("taxonomy_{$t_id}", $term_meta);
    }
}
add_action('edited_product_cat', 'zarincode_save_hide_cat_field', 10, 2);
add_action('create_product_cat', 'zarincode_save_hide_cat_field', 10, 2);

function zarincode_check_for_fatal() {
    $error = error_get_last();
    if ($error && $error["type"] == E_ERROR) {
        zarincode_log_error($error["type"], $error["message"], $error["file"], $error["line"]);
    }
}
function zarincode_log_error($num, $str, $file, $line, $context = null) {
    zarincode_log_exception(new ErrorException($str, 0, $num, $file, $line));
}
function zarincode_log_exception(Exception $e) {
    $message = gmdate('Y/m/d H:i:s >') . " Type: " . get_class($e) . "; Message: {$e->getMessage()}; File: {$e->getFile()}; Line: {$e->getLine()};";
    \ZarinShopBot\Core\WooBot::log($message);
}

add_action('init', function() {
    if (zarincode_option('testmod') === 'yes') {
        register_shutdown_function('zarincode_check_for_fatal');
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_set_error_handler -- Opt-in diagnostics mode only.
        set_error_handler('zarincode_log_error');
        set_exception_handler('zarincode_log_exception');
    }
    if (!class_exists('WooCommerce')) return;
    zarincode_defaults();
    require_once __DIR__ . '/WP_REST_Server_Rewrite.php';
    \ZarinShopBot\Core\WooBot::init('out');
    add_action('woocommerce_process_product_meta', 'zarincode_send_post_notification', 30, 2);

    // Register Telegram Stars product and checkout hooks
    if (class_exists(\ZarinShopBot\Core\Stars::class)) {
        add_action('woocommerce_product_options_pricing', [\ZarinShopBot\Core\Stars::class, 'renderProductField']);
        add_action('woocommerce_process_product_meta', [\ZarinShopBot\Core\Stars::class, 'saveProductField'], 20, 1);
        add_action('woocommerce_variation_options_pricing', [\ZarinShopBot\Core\Stars::class, 'renderVariationField'], 10, 3);
        add_action('woocommerce_save_product_variation', [\ZarinShopBot\Core\Stars::class, 'saveVariationField'], 10, 2);
        add_action('woocommerce_review_order_after_order_total', [\ZarinShopBot\Core\Stars::class, 'renderCheckoutStarsNotice']);
        add_action('woocommerce_order_details_after_order_table', [\ZarinShopBot\Core\Stars::class, 'renderOrderStarsNotice']);
        add_action('woocommerce_order_status_refunded', [\ZarinShopBot\Core\Stars::class, 'handleOrderRefunded'], 10, 1);
        add_action('woocommerce_checkout_order_created', [\ZarinShopBot\Core\Stars::class, 'saveOrderStarsAmount'], 20, 1);
    }
});

require_once __DIR__ . '/includes/legacy-compat.php';
