# Third-party notices

## TeleNexa Commerce for Telegram

The Telegram/WooCommerce foundation of ZarinShopBot is derived from **TeleNexa Commerce for Telegram**, originally published by **MilMit** at <https://github.com/MilMit/telenexa-commerce-for-telegram> under **GNU General Public License v2.0 or later (GPL-2.0-or-later)**.

ZarinShopBot is a modified derivative, not the original upstream release and not an endorsement by the upstream project. The code has been modified and expanded by Ehsan NaderiPanah / Zarincode.com, including the rebrand, direct-webhook changes, and Bale/Rubika adapters. Existing internal identifiers remain where changing them would risk losing installed-store settings or data. All distribution rights and downstream rights remain subject to the GPL; see `LICENSE`.

## Vazirmatn and Exo 2 variable fonts

The bundled webfont `assets/fonts/Vazirmatn[wght].woff2` is from the Vazirmatn project by Saber Rastikerdar and the Vazirmatn Project Authors (<https://github.com/rastikerdar/vazirmatn>). It is distributed under the SIL Open Font License, Version 1.1. The unmodified license and author list are included in `assets/fonts/OFL.txt` and `assets/fonts/AUTHORS.txt`.

The bundled Exo 2 variable webfont subsets `assets/fonts/Exo2-latin.woff2` and `assets/fonts/Exo2-latin-ext.woff2` are served from Google Fonts' Exo 2 family (<https://fonts.google.com/specimen/Exo+2>), designed by Natanael Gama and credited to the Exo 2 Project Authors. They are distributed under the SIL Open Font License, Version 1.1; the corresponding unmodified license is included as `assets/fonts/Exo2-OFL.txt`. The project applies Unicode-range font fallback so Latin/English glyphs use Exo 2 and Persian/Arabic glyphs use Vazirmatn.

The server-generated order invoice embeds `assets/fonts/DejaVuSans.ttf` for local PDF rendering, including Persian/Arabic and Latin glyphs. DejaVu Fonts are distributed under the Bitstream Vera Font License; the complete license notice is bundled as `assets/fonts/DejaVu-COPYRIGHT.txt`. The PDF renderer and its glyph metrics are local plugin code/data; invoice generation does not call a PDF or barcode service.

## Platform services and trademarks

The plugin calls the official APIs only when a store owner configures and uses them:

- Telegram Bot API: <https://core.telegram.org/bots/api>
- Bale Bot API: <https://docs.bale.ai/>
- Rubika Bot API: <https://rubika.ir/botapi>

Telegram, Bale, Rubika, WordPress and WooCommerce names and marks belong to their respective owners. ZarinShopBot is an independent product and is not officially affiliated with or endorsed by those services.

## Bale and Rubika logos

The original full-color SVGs `assets/icons/bale.svg` and `assets/icons/rubika.svg` are sourced from Persian Labs Icons, category `social-media/color` (<https://github.com/persianlabs/icons/tree/main/packages/icons/assets/social-media/color>). The upstream project is licensed under the MIT License; the copied license and copyright notice are included at `assets/icons/PERSIANLABS-MIT-LICENSE.txt`.

## Local interface icons

The local interface icon subset in `assets/icons/ui/` is based on Lucide (`lucide-static` 1.61.0), copyright Lucide contributors, distributed under the ISC License. Some icons derive from Feather and remain under its MIT terms; the complete ISC and MIT license notices are included as `assets/icons/ui/LICENSE.txt`. The SVGs are bundled locally; no external icon font or icon CDN is required.
