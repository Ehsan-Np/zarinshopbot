<?php
if (!defined('ABSPATH')) exit;

\ZarinShopBot\Core\WooBot::init('in');

$zarincode_key = (string) get_option('zarincode_webhook_key');
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public Telegram webhook endpoint verified via webhook key and secret token.
if (empty($zarincode_key) || !isset($_GET[$zarincode_key])) {
    zarincode_log('WebHook parse', 'Key empty', '');
    status_header(403);
    die(esc_html__('Forbidden: Key empty', 'zarinshopbot'));
}

// Security: Verify Telegram Webhook Secret Token if configured
if (!\ZarinShopBot\Core\WooBot::validateWebhookSecretToken()) {
    status_header(403);
    die(esc_html__('Forbidden: Invalid Webhook Secret Token', 'zarinshopbot'));
}

\ZarinShopBot\Core\WooBot::handle();
die('END PARSE');