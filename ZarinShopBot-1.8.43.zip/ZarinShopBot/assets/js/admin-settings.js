// Modified 2026-10-23 by Ehsan NaderiPanah / Zarincode.com; derived GPL script.
jQuery(document).ready(function($) {
    var zarinshopbotSettings = window.zarinshopbotSettings || window.telenexaSettings || {};
    // Keep channel content in this page and fetch only the selected form fragment.
    var channelRequests = {};

    $(document).on('click', '#miniapp_brand_logo_select', function(event) {
        event.preventDefault();
        if (!window.wp || !wp.media) return;
        var frame = wp.media({ title: 'انتخاب لوگوی Mini App', button: { text: 'استفاده از این تصویر' }, library: { type: 'image' }, multiple: false });
        frame.on('select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
            if (!attachment || !attachment.id || !attachment.url) return;
            $('#miniapp_brand_logo_id').val(parseInt(attachment.id, 10) || 0);
            $('#miniapp_brand_logo_preview').attr('src', attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url).show();
            $('#miniapp_brand_logo_remove').prop('disabled', false);
        });
        frame.open();
    });
    $(document).on('click', '#miniapp_brand_logo_remove', function(event) {
        event.preventDefault();
        $('#miniapp_brand_logo_id').val('0');
        $('#miniapp_brand_logo_preview').hide().attr('src', '');
        $(this).prop('disabled', true);
    });

    function escapeHtml(value) {
        return String(value == null ? '' : value).replace(/[&<>\"']/g, function(character) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#039;' }[character];
        });
    }

    function updateTabHash(tabId, updateHistory) {
        if (!updateHistory) return;
        var nextUrl = window.location.pathname + window.location.search + '#tab=' + encodeURIComponent(tabId);
        if (window.history && window.history.pushState) {
            window.history.pushState(null, '', nextUrl);
        } else {
            window.location.hash = 'tab=' + tabId;
        }
    }

    function updateChannelSaveBars(tabId) {
        var isChannelTab = tabId === 'bale' || tabId === 'rubika';
        $('.zarin-footer-bar').not('.zarin-channel-save-bar').toggleClass('is-hidden', isChannelTab);
        $('.zarin-channel-save-bar').each(function() {
            $(this).toggleClass('is-hidden', $(this).attr('data-channel-save') !== tabId);
        });
    }

    function placeChannelSaveBar(tabId) {
        var $pane = $('#tab-' + tabId);
        var $bar = $pane.find('.zarin-channel-save-bar').first();
        if (!$bar.length) $bar = $('.zarin-channel-save-bar[data-channel-save="' + tabId + '"]').first();
        var $wrapper = $('.zarin-settings-wrap').first();
        if (!$bar.length || !$wrapper.length) return;

        $bar.attr('data-channel-save', tabId);
        var $mainFooter = $wrapper.children('.zarin-footer-bar:not(.zarin-channel-save-bar)').first();
        if ($bar.parent()[0] !== $wrapper[0]) {
            if ($mainFooter.length) $bar.insertBefore($mainFooter);
            else $bar.appendTo($wrapper);
        }
        var activePaneId = $('.zarin-tab-pane.is-active').attr('id') || '';
        var activeTabId = activePaneId.indexOf('tab-') === 0 ? activePaneId.substring(4) : tabId;
        updateChannelSaveBars(activeTabId);
    }

    function setActiveTab(tabId, updateHistory) {
        var $pane = $('#tab-' + tabId);
        if (!$pane.length) return false;

        $('.zarin-tab-btn').removeClass('is-active');
        $('.zarin-tab-btn[role="tab"]').attr('aria-selected', 'false');
        $('.zarin-tab-btn[data-channel-tab]').attr('aria-current', 'false');
        $('.zarin-tab-btn[data-tab="' + tabId + '"]').addClass('is-active').attr('aria-selected', 'true');
        $('.zarin-tab-btn[data-channel-tab="' + tabId + '"]').addClass('is-active').attr('aria-current', 'page');
        $('.zarin-tab-pane').removeClass('is-active').attr('hidden', true);
        $pane.addClass('is-active').removeAttr('hidden');
        updateChannelSaveBars(tabId);
        var refererField = document.getElementById('zarincode_settings_referer');
        if (refererField && window.URL) {
            var refererUrl = new URL(refererField.value, window.location.href);
            refererUrl.searchParams.set('page', 'zarincode_zarinshopbot_setting');
            refererUrl.searchParams.set('tab', tabId);
            refererUrl.hash = '';
            refererField.value = refererUrl.toString();
        }
        updateTabHash(tabId, updateHistory);
        return true;
    }

    function channelLoadingMarkup() {
        var i18n = (window.zarinshopbotSettings || window.telenexaSettings || {}).i18n || {};
        return '<div class="zarin-card zarin-channel-loading" role="status"><span class="dashicons dashicons-update spin" aria-hidden="true"></span> ' + (i18n.channelLoading || 'در حال بارگذاری تنظیمات کانال…') + '</div>';
    }

    function showChannelError($pane, tabId) {
        var $error = $('<div class="zarin-card zarin-channel-load-error" role="alert"></div>');
        var i18n = (window.zarinshopbotSettings || window.telenexaSettings || {}).i18n || {};
        $('<p></p>').text(i18n.channelLoadError || 'بارگذاری تنظیمات ممکن نشد؛ اتصال را بررسی و دوباره تلاش کنید.').appendTo($error);
        $('<button type="button" class="button zarin-retry-channel"></button>').text(i18n.retryChannel || 'دوباره تلاش کنید').attr('data-channel-tab', tabId).appendTo($error);
        $pane.empty().append($error);
    }

    function loadChannelTab(tabId, updateHistory) {
        var $pane = $('#tab-' + tabId);
        if (!$pane.length || !/^(bale|rubika)$/.test(tabId)) return;
        setActiveTab(tabId, updateHistory);

        if ($pane.attr('data-channel-loaded') === 'true' || $pane.find('.zarin-channel-content').length) {
            $pane.attr('data-channel-loaded', 'true').attr('aria-busy', 'false');
            placeChannelSaveBar(tabId);
            return;
        }
        if (channelRequests[tabId]) return;

        $pane.attr('aria-busy', 'true').html(channelLoadingMarkup());
        var endpoint = (zarinshopbotSettings && zarinshopbotSettings.ajax_url) || window.ajaxurl || 'admin-ajax.php';
        channelRequests[tabId] = $.ajax({
            url: endpoint,
            type: 'POST',
            timeout: 12000,
            data: {
                action: 'zarincode_load_channel_tab',
                nonce: (zarinshopbotSettings && zarinshopbotSettings.nonce) || '',
                platform: tabId
            }
        }).done(function(response) {
            if (!response || !response.success || !response.data || typeof response.data.html !== 'string') {
                showChannelError($pane, tabId);
                return;
            }
            $pane.html(response.data.html).attr('data-channel-loaded', 'true');
            placeChannelSaveBar(tabId);
            var adminChatAnchor = document.getElementById(tabId + '-admin-chat-id');
            if (adminChatAnchor && window.location.hash === '#' + tabId + '-admin-chat-id' && adminChatAnchor.scrollIntoView) {
                window.setTimeout(function() { adminChatAnchor.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 60);
            }
        }).fail(function(xhr, status) {
            if (status === 'abort') return;
            showChannelError($pane, tabId);
        }).always(function() {
            delete channelRequests[tabId];
            $pane.attr('aria-busy', 'false');
        });
    }

    function activateTab(tabId, updateHistory) {
        if (tabId === 'bale' || tabId === 'rubika') {
            loadChannelTab(tabId, updateHistory !== false);
            return;
        }
        setActiveTab(tabId, updateHistory !== false);
    }

    $('.zarin-tab-btn').not('[data-page-link]').on('click', function(e) {
        e.preventDefault();
        activateTab(String($(this).data('tab') || ''), true);
    });

    $(document).on('click', '.zarin-tab-btn[data-channel-tab], .zarin-retry-channel', function(e) {
        e.preventDefault();
        loadChannelTab(String($(this).data('channel-tab') || ''), true);
    });

    // Direct links and browser history use the same lazy-loading path.
    var initialTab = '';
    var hashMatch = window.location.hash.match(/tab=([a-z0-9_-]+)/i);
    if (hashMatch && $('#tab-' + hashMatch[1]).length) {
        initialTab = hashMatch[1];
    } else {
        var queryTab = new URLSearchParams(window.location.search).get('tab') || '';
        queryTab = /^[a-z0-9_-]+$/i.test(queryTab) ? queryTab : '';
        if ($('#tab-' + queryTab).length) initialTab = queryTab;
    }
    if (initialTab) {
        if (initialTab === 'bale' || initialTab === 'rubika') loadChannelTab(initialTab, false);
        else setActiveTab(initialTab, false);
    }
    window.addEventListener('popstate', function() {
        var match = window.location.hash.match(/tab=([a-z0-9_-]+)/i);
        var queryTab = new URLSearchParams(window.location.search).get('tab') || '';
        queryTab = /^[a-z0-9_-]+$/i.test(queryTab) ? queryTab : '';
        var target = match && $('#tab-' + match[1]).length ? match[1] : ($('#tab-' + queryTab).length ? queryTab : 'basic');
        activateTab(target, false);
    });

    // Required membership destinations repeater
    function refreshMembershipRows() {
        var $rows = $('[data-membership-row]');
        $rows.each(function(index) {
            $(this).find('.zarin-membership-number').text(index + 1);
            $(this).find('.zarin-remove-membership').toggle($rows.length > 1);
        });
    }
    $('#zarincode_add_membership').on('click', function(e) {
        e.preventDefault();
        var $rows = $('[data-membership-row]');
        if ($rows.length >= 10) return;
        var index = $rows.length;
        var $row = $rows.first().clone();
        $row.find('input, select').each(function() {
            var $field = $(this);
            $field.attr('name', $field.attr('name').replace(/\[membership_requirements\]\[\d+\]/, '[membership_requirements][' + index + ']'));
            if ($field.is(':checkbox')) $field.prop('checked', false);
            else if ($field.is('select')) $field.val('channel');
            else $field.val('');
        });
        $('#zarincode_membership_list').append($row);
        refreshMembershipRows();
    });
    $(document).on('click', '.zarin-remove-membership', function() {
        $(this).closest('[data-membership-row]').remove();
        refreshMembershipRows();
    });
    refreshMembershipRows();

    // Toggle Bot Token visibility
    $('.zarin-toggle-token').on('click', function() {
        var $input = $('#token');
        var isPass = $input.attr('type') === 'password';
        $input.attr('type', isPass ? 'text' : 'password');
        $(this).find('.dashicons').toggleClass('dashicons-visibility dashicons-hidden');
    });

    // Radio card visual selection
    $('.zarin-radio-card input[type="radio"]').on('change', function() {
        var name = $(this).attr('name');
        $('input[name="' + name + '"]').closest('.zarin-radio-card').removeClass('is-selected');
        if ($(this).is(':checked')) {
            $(this).closest('.zarin-radio-card').addClass('is-selected');
        }
    });

    // Proxy collapse toggle
    $('input[name="zarincode_settings[proxy_status]"]').on('change', function() {
        var isEnabled = $(this).val() == '1';
        $('#zarin_proxy_fields').toggleClass('is-collapsed', !isEnabled);
    });

    // Copy commands to clipboard
    $('#zarin_copy_commands').on('click', function() {
        var copyText = document.getElementById('zarin_commands_text');
        if (!copyText) return;
        copyText.focus();
        copyText.select();
        copyText.setSelectionRange(0, copyText.value.length);
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(copyText.value).then(function() {
                showToast(((window.zarinshopbotSettings || window.telenexaSettings || {}).i18n || {}).commandsCopied || 'فرمان‌ها با موفقیت کپی شدند.');
            }).catch(function() {
                var copied = document.execCommand('copy');
                var i18n = (window.zarinshopbotSettings || window.telenexaSettings || {}).i18n || {};
                showToast(copied ? (i18n.commandsCopiedShort || 'فرمان‌ها کپی شدند.') : (i18n.manualCopy || 'متن را انتخاب کنید و به‌صورت دستی کپی کنید.'));
            });
        } else {
            var copied = document.execCommand('copy');
            var i18n = (window.zarinshopbotSettings || window.telenexaSettings || {}).i18n || {};
                showToast(copied ? (i18n.commandsCopiedShort || 'فرمان‌ها کپی شدند.') : (i18n.manualCopy || 'متن را انتخاب کنید و به‌صورت دستی کپی کنید.'));
        }
    });

    // Toast helper
    function showToast(msg) {
        var $toast = $('#zarin_toast');
        if (!$toast.length) {
            $toast = $('<div id="zarin_toast" class="zarin-toast"></div>').appendTo('body');
        }
        $toast.text(msg).addClass('is-show');
        setTimeout(function() {
            $toast.removeClass('is-show');
        }, 2800);
    }

    // Channel settings are loaded asynchronously, so copy handlers must be delegated.
    // This selector is used by the Bale Mini App URLs; no other channel is changed.
    $(document).on('click', '.zarin-copy-webapp-url', function(event) {
        event.preventDefault();
        var button = this;
        var value = String($(button).attr('data-copy') || '').trim();
        if (!value) {
            showToast('نشانی برای کپی پیدا نشد.');
            return;
        }
        var i18n = (window.zarinshopbotSettings || window.telenexaSettings || {}).i18n || {};
        var copyFallback = function() {
            var field = document.createElement('textarea');
            field.value = value;
            field.setAttribute('readonly', '');
            field.style.position = 'fixed';
            field.style.opacity = '0';
            document.body.appendChild(field);
            field.select();
            field.setSelectionRange(0, field.value.length);
            var copied = false;
            try { copied = document.execCommand('copy'); } catch (error) {}
            field.remove();
            return copied;
        };
        var finish = function(copied) {
            showToast(copied
                ? (i18n.channelUrlCopied || 'نشانی مینی‌اپ کپی شد.')
                : (i18n.manualCopy || 'کپی خودکار انجام نشد؛ نشانی را انتخاب و دستی کپی کنید.'));
        };
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(value).then(function() { finish(true); }).catch(function() { finish(copyFallback()); });
        } else {
            finish(copyFallback());
        }
    });

    // Diagnostic & Health-Check Endpoints
    var zarincode_admin_vars = {
        ajax_url: (zarinshopbotSettings && zarinshopbotSettings.ajax_url) || 'admin-ajax.php',
        nonce: (zarinshopbotSettings && zarinshopbotSettings.nonce) || ''
    };

    // Generate Webhook Secret Token
    $('#btn_generate_secret').on('click', function(e) {
        e.preventDefault();
        var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
        var secret = '';
        var randomValues = new Uint8Array(32);
        window.crypto.getRandomValues(randomValues);
        for (var i = 0; i < 32; i++) {
            secret += chars[randomValues[i] % chars.length];
        }
        $('#webhook_secret_token').val(secret);
        showToast((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.tokenGenerated) || 'توکن امنیتی ساخته شد؛ فراموش نکنید تنظیمات را ذخیره کنید.');
    });

    // Test Bot Connection (getMe)
    $('#btn_test_telegram_connection').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $res = $('#zarin_diag_result');
        $btn.prop('disabled', true);
        $res.show().css({ background: '#FFF5D1', color: '#7B5B00', border: '1px solid #F2D880' }).html('<span class="dashicons dashicons-update spin"></span> ' + ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.connecting) || 'در حال اتصال به API تلگرام...') + '');

        $.post(zarincode_admin_vars.ajax_url, {
            action: 'zarincode_test_connection',
            nonce: zarincode_admin_vars.nonce
        }, function(response) {
            $btn.prop('disabled', false);
            if (response && response.success) {
                $res.css({ background: '#dcfce7', color: '#15803d', border: '1px solid #bbf7d0' })
                    .html('<span class="dashicons dashicons-yes-alt"></span> ' + response.data.message);
            } else {
                var err = (response && response.data && response.data.message) ? response.data.message : ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.connectionFailed) || 'اتصال ناموفق بود.');
                $res.css({ background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca' })
                    .html('<span class="dashicons dashicons-warning"></span> ' + err);
            }
        }).fail(function() {
            $btn.prop('disabled', false);
            $res.css({ background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca' })
                .html('<span class="dashicons dashicons-dismiss"></span> ' + ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.networkError) || 'خطای شبکهٔ سرور رخ داد.') + '');
        });
    });

    // Test Webhook Info (getWebhookInfo)
    $('#btn_test_telegram_webhook').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $res = $('#zarin_diag_result');
        $btn.prop('disabled', true);
        $res.show().css({ background: '#FFF5D1', color: '#7B5B00', border: '1px solid #F2D880' }).html('<span class="dashicons dashicons-update spin"></span> ' + ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.checkingWebhook) || 'در حال بررسی وضعیت وب‌هوک تلگرام...') + '');

        $.post(zarincode_admin_vars.ajax_url, {
            action: 'zarincode_test_webhook',
            nonce: zarincode_admin_vars.nonce
        }, function(response) {
            $btn.prop('disabled', false);
            if (response && response.success) {
                $res.css({ background: '#dcfce7', color: '#15803d', border: '1px solid #bbf7d0' })
                    .html('<span class="dashicons dashicons-cloud-saved"></span> ' + response.data.message);
            } else {
                var err = (response && response.data && response.data.message) ? response.data.message : ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.webhookFailed) || 'بررسی وب‌هوک ناموفق بود.');
                $res.css({ background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca' })
                    .html('<span class="dashicons dashicons-warning"></span> ' + err);
            }
        }).fail(function() {
            $btn.prop('disabled', false);
            $res.css({ background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca' })
                .html('<span class="dashicons dashicons-dismiss"></span> ' + ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.networkError) || 'خطای شبکهٔ سرور رخ داد.') + '');
        });
    });

    // Test Proxy and automatic fallback
    $('#btn_test_telegram_proxy').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $res = $('#zarin_diag_result');
        $btn.prop('disabled', true);
        $res.show().css({ background: '#FFF5D1', color: '#7B5B00', border: '1px solid #F2D880' }).text('' + ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.testingProxy) || 'در حال آزمایش پراکسی و روش جایگزین...') + '');
        $.post(zarincode_admin_vars.ajax_url, {
            action: 'zarincode_test_proxy',
            nonce: zarincode_admin_vars.nonce
        }, function(response) {
            $btn.prop('disabled', false);
            var message = response && response.data && response.data.message ? response.data.message : ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.proxyFailed) || 'آزمایش پراکسی ناموفق بود.');
            $res.css(response && response.success
                ? { background: '#dcfce7', color: '#15803d', border: '1px solid #bbf7d0' }
                : { background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca' }).text(message);
        }).fail(function() {
            $btn.prop('disabled', false);
            $res.show().css({ background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca' }).text('' + ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.networkError) || 'خطای شبکهٔ سرور رخ داد.') + '');
        });
    });

    // Run System Unit Tests
    $('#btn_run_system_tests').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $res = $('#zarin_diag_result');
        $btn.prop('disabled', true);
        $res.show().css({ background: '#FFF5D1', color: '#7B5B00', border: '1px solid #F2D880' }).html('<span class="dashicons dashicons-update spin"></span> ' + ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.executingTests) || 'در حال اجرای آزمون‌های تشخیصی خودکار...') + '');

        $.post(zarincode_admin_vars.ajax_url, {
            action: 'zarincode_run_tests',
            nonce: zarincode_admin_vars.nonce
        }, function(response) {
            $btn.prop('disabled', false);
            if (response && response.success && response.data) {
                var data = response.data;
                var passedCount = Math.max(0, parseInt(data.passed, 10) || 0);
                var failedCount = Math.max(0, parseInt(data.failed, 10) || 0);
                var results = Array.isArray(data.results) ? data.results : [];
                var i18n = ((window.zarinshopbotSettings || window.telenexaSettings || {}).i18n || {});
                var html = '<div style="margin-bottom:8px;font-weight:bold;font-size:14px;">' +
                    escapeHtml((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.testSummary) || 'خلاصهٔ آزمون‌های تشخیصی خودکار:') + ' ' +
                    '<span style="color:#15803d;">' + passedCount + ' ' + escapeHtml(i18n.passed || 'موفق') + '</span> / ' +
                    '<span style="color:' + (failedCount > 0 ? '#b91c1c' : '#64748b') + ';">' + failedCount + ' ' + escapeHtml(i18n.failed || 'ناموفق') + '</span>' +
                    '</div><div style="display:flex;flex-direction:column;gap:6px;max-height:260px;overflow-y:auto;padding-right:4px;">';

                $.each(results, function(i, r) {
                    r = r || {};
                    var success = r.success === true;
                    var icon = success ? '<span style="color:#15803d;font-weight:bold;">✔ [PASS]</span>' : '<span style="color:#b91c1c;font-weight:bold;">✖ [FAIL]</span>';
                    var bg = success ? '#f0fdf4' : '#fef2f2';
                    var border = success ? '#bbf7d0' : '#fecaca';
                    html += '<div style="padding:6px 10px;background:' + bg + ';border:1px solid ' + border + ';border-radius:4px;font-size:12px;">' +
                        icon + ' <strong>' + escapeHtml(r.name) + '</strong><br><span style="color:#475569;margin-left:18px;">' + escapeHtml(r.details) + '</span></div>';
                });
                html += '</div>';

                var overallBg = data.failed === 0 ? '#dcfce7' : '#fef2f2';
                var overallBorder = data.failed === 0 ? '#bbf7d0' : '#fecaca';
                $res.css({ background: overallBg, color: '#1e293b', border: '1px solid ' + overallBorder }).html(html);
            } else {
                $res.css({ background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca' })
                    .html('<span class="dashicons dashicons-dismiss"></span> ' + ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.suiteFailed) || 'اجرای مجموعهٔ آزمون‌های تشخیصی ناموفق بود.') + '');
            }
        }).fail(function() {
            $btn.prop('disabled', false);
            $res.css({ background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca' })
                .html('<span class="dashicons dashicons-dismiss"></span> ' + ((zarinshopbotSettings && zarinshopbotSettings.i18n && zarinshopbotSettings.i18n.ajaxFailed) || 'درخواست AJAX مجموعهٔ آزمون‌ها ناموفق بود.') + '');
        });
    });

    // Native Unicode emoji are supported directly by the message fields.
});
