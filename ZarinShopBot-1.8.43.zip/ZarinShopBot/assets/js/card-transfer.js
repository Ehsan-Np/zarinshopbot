/* Local clipboard support for visible bank details and WooCommerce account choices. */
(() => {
    'use strict';

    async function copyText(value) {
        if (navigator.clipboard && window.isSecureContext) {
            await navigator.clipboard.writeText(value);
            return;
        }
        const field = document.createElement('textarea');
        field.value = value;
        field.setAttribute('readonly', '');
        field.style.position = 'fixed';
        field.style.opacity = '0';
        field.style.pointerEvents = 'none';
        document.body.appendChild(field);
        field.select();
        field.setSelectionRange(0, field.value.length);
        const copied = document.execCommand('copy');
        field.remove();
        if (!copied) throw new Error('clipboard_copy_failed');
    }

    document.addEventListener('click', async (event) => {
        const button = event.target.closest('.zsb-copy-value');
        if (!button) return;
        event.preventDefault();
        event.stopPropagation();
        const value = button.dataset.copyValue || '';
        if (!value) return;

        const accountCard = button.closest('.zsb-transfer-account-card');
        const status = accountCard?.querySelector('.zsb-copy-status');
        const text = button.querySelector('span');
        const defaultText = button.dataset.copyDefault || (text ? text.textContent : '');
        button.disabled = true;
        try {
            await copyText(value);
            if (text) text.textContent = button.dataset.copySuccess || defaultText;
            if (status) status.textContent = `${button.dataset.copyLabel || ''}: ${button.dataset.copySuccess || ''}`;
            button.classList.add('is-copied');
        } catch (error) {
            if (status) status.textContent = button.dataset.copyFailure || '';
        } finally {
            window.setTimeout(() => {
                button.disabled = false;
                if (text) text.textContent = defaultText;
                button.classList.remove('is-copied');
            }, 1800);
        }
    });

    document.addEventListener('change', (event) => {
        const radio = event.target.closest('.zsb-transfer-account-choice input[type="radio"]');
        if (!radio) return;
        const fieldset = radio.closest('.zsb-transfer-account-selection');
        fieldset?.querySelectorAll('.zsb-transfer-account-choice').forEach((card) => {
            card.classList.toggle('is-selected', Boolean(card.querySelector('input[type="radio"]:checked')));
        });
    });
})();
