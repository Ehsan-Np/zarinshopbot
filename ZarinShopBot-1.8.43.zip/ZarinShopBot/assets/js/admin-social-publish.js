'use strict';

(function ($, window, document) {
    const cfg = window.zarinshopbotSocialPublish || {};

    function showMessage($box, message, success) {
        $box.text(message || (success ? cfg.sent : cfg.failed));
        $box.prop('hidden', false)
            .removeClass('is-success is-error')
            .addClass(success ? 'is-success' : 'is-error');
    }

    $(document).on('click', '.zsb-social-publish-now', function (event) {
        event.preventDefault();
        const button = this;
        if (button.disabled) return;

        const $button = $(button);
        const $row = $button.closest('.zsb-social-platform');
        const $feedback = $button.closest('.zsb-social-publish-metabox').find('[data-zsb-social-feedback]');
        const originalText = $button.text().trim();
        const payload = {
            action: 'zarincode_publish_product_social',
            post_id: $button.data('post-id'),
            platform: $button.data('zsb-social-publish'),
            nonce: $button.data('nonce')
        };

        button.disabled = true;
        $button.addClass('is-busy').text(cfg.sending || 'Sending…');
        showMessage($feedback, cfg.sending || 'Sending…', true);

        $.ajax({
            url: cfg.ajaxUrl || window.ajaxurl,
            method: 'POST',
            dataType: 'json',
            data: payload
        }).done(function (response) {
            const message = response && response.data && response.data.message;
            if (response && response.success) {
                showMessage($feedback, message || cfg.sent, true);
                const statusText = response && response.data && response.data.status;
                if (statusText) $row.find('[data-zsb-social-status]').text(statusText);
            } else {
                showMessage($feedback, message || cfg.failed, false);
            }
        }).fail(function (xhr) {
            const response = xhr && xhr.responseJSON;
            const message = response && response.data && response.data.message;
            showMessage($feedback, message || cfg.failed, false);
        }).always(function () {
            $button.removeClass('is-busy').text(originalText);
            button.disabled = false;
        });
    });
})(jQuery, window, document);
