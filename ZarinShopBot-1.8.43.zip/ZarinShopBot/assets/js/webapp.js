// Modified 2026-10-24 by Zarincode.com; shared Telegram/Bale storefront Mini App controller.
const cfg = window.zarinshopbotWebAppConfig || window.teleNexaWebAppConfig || {};
const i18n = cfg.i18n || {};
        // Provider bridge: each app is authenticated with its own signed initData.
        const platform = cfg.platform === 'bale' ? 'bale' : 'telegram';
        const tg = platform === 'telegram' ? window.Telegram?.WebApp : null;
        const bale = platform === 'bale' ? window.Bale?.WebApp : null;
        const app = bale || tg;
        const appUser = app?.initDataUnsafe?.user || null;
        const platformNotice = document.getElementById('app_platform_notice');
        // Embedded WebViews may deny localStorage (privacy mode, iframe policy or
        // platform restrictions). Keep the Mini App interactive with an in-memory
        // fallback instead of aborting all event handlers during startup.
        const volatileStorage = Object.create(null);
        function storageGet(key) {
            if (Object.prototype.hasOwnProperty.call(volatileStorage, key)) return volatileStorage[key];
            try { return window.localStorage.getItem(key); } catch (error) { return null; }
        }
        function storageSet(key, value) {
            value = String(value);
            try { window.localStorage.setItem(key, value); delete volatileStorage[key]; }
            catch (error) { volatileStorage[key] = value; }
        }
        function storageRemove(key) {
            delete volatileStorage[key];
            try { window.localStorage.removeItem(key); } catch (error) {}
        }
        function storageJson(key, fallback) {
            const value = storageGet(key);
            if (value === null || value === '') return fallback;
            try { return JSON.parse(value); } catch (error) { storageRemove(key); return fallback; }
        }

        function baleSupportsVersion(required) {
            const current = String(bale?.version || '').split('.').map((part) => parseInt(part, 10) || 0);
            const minimum = String(required).split('.').map((part) => parseInt(part, 10) || 0);
            if (!current.length || !bale?.version) return false;
            for (let index = 0; index < Math.max(current.length, minimum.length); index++) {
                const have = current[index] || 0;
                const need = minimum[index] || 0;
                if (have > need) return true;
                if (have < need) return false;
            }
            return true;
        }

        function showPlatformNotice(message, isError = false) {
            if (!platformNotice) return;
            platformNotice.hidden = false;
            platformNotice.classList.toggle('is-error', Boolean(isError));
            platformNotice.textContent = message;
        }

        if (app) {
            try { app.ready?.(); } catch (error) {}
            try { app.expand?.(); } catch (error) {}
            if (appUser) {
                const name = [appUser.first_name, appUser.last_name].filter(Boolean).join(' ');
                if (name) document.getElementById('tg_user_display').innerText = name;
            }
        }

        if (platform === 'bale') {
            if (!bale || !bale.initData) {
                showPlatformNotice(cfg.i18n.bale_auth_required, true);
            } else if (bale.isMiniAppSupported === false) {
                showPlatformNotice(cfg.i18n.bale_miniapp_unsupported, true);
            }

            const theme = bale?.themeParams || {};
            const themeMap = {
                bg_color: '--bg-color', text_color: '--text-color', hint_color: '--hint-color',
                link_color: '--link-color', button_color: '--button-color',
                button_text_color: '--button-text', secondary_bg_color: '--secondary-bg'
            };
            Object.entries(themeMap).forEach(([key, cssVar]) => {
                const value = theme[key];
                if (typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value)) {
                    document.documentElement.style.setProperty(cssVar, value);
                }
            });
            if (bale?.colorScheme) {
                document.documentElement.dataset.colorScheme = bale.colorScheme === 'dark' ? 'dark' : 'light';
                document.documentElement.style.colorScheme = bale.colorScheme === 'dark' ? 'dark' : 'light';
            }
            try { if (baleSupportsVersion('1.1')) bale.setHeaderColor?.('bg_color'); } catch (error) {}
        }

        // Global State & Credentials
        const webappNonce = cfg.nonce || '';
        const initDataRaw = app?.initData || '';
        let currentTab = 'view-shop';
        let cart = storageJson('zarincode_cart', {});
        let wishlist = storageJson('zarincode_wishlist', []);
        if (!cart || typeof cart !== 'object' || Array.isArray(cart)) cart = {};
        if (!Array.isArray(wishlist)) wishlist = [];
        let productsCache = [];
        let appliedDiscount = 0;
        let appliedCouponCode = '';
        let selectedShippingCost = 0;
        let selectedTax = 0;
        let selectedShippingMethod = '';
        let selectedPaymentMethod = '';
        let selectedTransferAccount = '';
        let currentPaymentOptions = [];
        let currentCheckoutProfile = { downloadable_only: false, free_downloadable_only: false, needs_shipping: false };
        let activeVariableProduct = null;
        let selectedVariation = null;

        let cartSyncTimer = null;
        function syncCartWithBot() {
            clearTimeout(cartSyncTimer);
            cartSyncTimer = setTimeout(async () => {
                if (!initDataRaw || !appUser?.id) return;
                try {
                    await fetch(`${cfg.ajaxUrl || 'admin-ajax.php'}?action=zarincode_webapp_sync_cart`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            nonce: webappNonce,
                            platform: platform,
                            lang: cfg.lang || 'fa',
                            init_data: initDataRaw,
                            chat_id: String(appUser.id),
                            cart: JSON.stringify(cart)
                        })
                    });
                } catch (error) {}
            }, 250);
        }
        syncCartWithBot();

        const currency = cfg.currency || '$';
        const numberLocale = cfg.numberLocale || 'fa-IR';

        function formatMoney(value) {
            const amount = Number(value || 0);
            return `${new Intl.NumberFormat(numberLocale, { maximumFractionDigits: 2 }).format(amount)} ${currency}`;
        }

        function escapeHtml(value) {
            return String(value ?? '').replace(/[&<>\"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#039;' }[char]));
        }

        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', () => {
                document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('is-active'));
                document.querySelectorAll('.tab-view').forEach(v => v.classList.remove('is-active'));
                item.classList.add('is-active');
                const targetView = item.dataset.view;
                document.getElementById(targetView).classList.add('is-active');
                currentTab = targetView;
                syncNativeBackButton();

                if (targetView === 'view-cart') renderCartView();
                if (targetView === 'view-wishlist') renderWishlistView();
                if (targetView === 'view-orders') fetchOrdersView();
            });
        });

        function syncNativeBackButton() {
            if (platform !== 'bale' || !app?.BackButton) return;
            try {
                if (currentTab !== 'view-shop') app.BackButton.show?.();
                else app.BackButton.hide?.();
            } catch (error) {}
        }

        function openAppView(viewId) {
            const target = document.querySelector(`.nav-item[data-view="${viewId}"]`);
            target?.click();
        }

        if (platform === 'bale' && bale) {
            const backButton = bale.BackButton;
            if (backButton?.onClick) {
                backButton.onClick(() => {
                    if (currentTab !== 'view-shop') openAppView('view-shop');
                    else bale.close?.();
                });
                syncNativeBackButton();
            }

            const homeButton = document.getElementById('btn_add_home');
            if (homeButton && baleSupportsVersion('1.0') && typeof bale.checkHomeScreenStatus === 'function' && typeof bale.addToHomeScreen === 'function') {
                try {
                    bale.checkHomeScreenStatus((status) => {
                        if (status === 'missed' || status === 'unknown') homeButton.hidden = false;
                    });
                } catch (error) { /* Keep optional host controls hidden on unsupported clients. */ }
                homeButton.addEventListener('click', () => {
                    try { bale.addToHomeScreen(); } catch (error) {
                        showPlatformNotice(cfg.i18n.home_shortcut_unavailable);
                    }
                });
            }

            const contactButton = document.getElementById('btn_request_contact');
            if (contactButton && baleSupportsVersion('1.0') && typeof bale.requestContact === 'function') {
                contactButton.hidden = false;
                contactButton.addEventListener('click', () => {
                    try {
                        // This value is only a convenience for the checkout form; Bale requires server-side contact ownership verification for trusted phone numbers.
                        bale.requestContact((shared, phone) => {
                            if (shared && typeof phone === 'string' && phone.trim()) {
                                document.getElementById('chk_phone').value = phone.trim();
                                showPlatformNotice(cfg.i18n.bale_phone_unverified);
                            }
                        });
                    } catch (error) { showPlatformNotice(cfg.i18n.contact_share_unavailable); }
                });
            }

            const scanButtons = [document.getElementById('btn_scan_coupon'), document.getElementById('btn_scan_coupon_inline')].filter(Boolean);
            const handleQrText = (event) => {
                const value = typeof event === 'string' ? event : (event?.text || '');
                if (!value) return;
                const couponInput = document.getElementById('chk_coupon');
                couponInput.value = value.trim();
                openAppView('view-cart');
                window.setTimeout(() => document.getElementById('btn_apply_coupon')?.click(), 80);
            };
            if (typeof bale.onEvent === 'function') {
                bale.onEvent('qrTextReceived', handleQrText);
                bale.onEvent('homeScreenAdded', () => { if (homeButton) homeButton.hidden = true; });
                bale.onEvent('contactRequested', (event) => {
                    if (event?.status === 'cancelled') showPlatformNotice(cfg.i18n.contact_share_cancelled);
                });
                bale.onEvent('homeScreenFailed', () => showPlatformNotice(cfg.i18n.home_shortcut_failed));
                bale.onEvent('invoiceClosed', (event) => {
                    if (event?.status === 'paid') fetchOrdersView();
                });
            }
            scanButtons.forEach((button) => {
                if (baleSupportsVersion('1.2') && typeof bale.showScanQrPopup === 'function') {
                    button.hidden = false;
                    button.addEventListener('click', () => {
                        try { bale.showScanQrPopup({}); } catch (error) {
                            showPlatformNotice(cfg.i18n.bale_qr_unsupported);
                        }
                    });
                }
            });
        }

        // Fetch products
        async function fetchProducts(catId = 0, query = '') {
            const grid = document.getElementById('products_grid');
            grid.innerHTML = `<div style="grid-column: span 2; text-align: center; padding: 20px;"><span class="zsb-icon zsb-icon-hourglass" aria-hidden="true"></span> ${cfg.i18n.loading_products}</div>`;

            try {
                const endpoint = new URL(cfg.ajaxUrl || 'admin-ajax.php', window.location.href);
                if (window.location.protocol === 'https:' && endpoint.protocol === 'http:') endpoint.protocol = 'https:';
                endpoint.searchParams.set('action', 'zarincode_webapp_products');
                endpoint.searchParams.set('cat_id', String(catId));
                endpoint.searchParams.set('s', query);
                endpoint.searchParams.set('lang', cfg.lang || 'fa');
                endpoint.searchParams.set('platform', platform);
                const res = await fetch(endpoint.toString(), { credentials: 'same-origin', cache: 'no-store' });
                if (!res.ok) throw new Error(`http_${res.status}`);
                const data = await res.json();
                if (data?.success === true && Array.isArray(data.data)) {
                    productsCache = data.data;
                    renderProducts(data.data);
                } else if (data?.data?.message) {
                    grid.innerHTML = `<div style="grid-column: span 2; text-align: center; color: red;">${escapeHtml(data.data.message)}</div>`;
                } else {
                    grid.innerHTML = `<div style="grid-column: span 2; text-align: center; padding: 20px;">${cfg.i18n.no_products_available}</div>`;
                }
            } catch (err) {
                console.error('[ZarinShopBot] Mini App catalog request failed', {
                    platform,
                    error: String(err?.message || err || 'unknown_error'),
                    ajaxHost: (() => { try { return new URL(cfg.ajaxUrl || 'admin-ajax.php', window.location.href).host; } catch (e) { return 'invalid'; } })()
                });
                grid.innerHTML = `<div style="grid-column: span 2; text-align: center; color: red;">${cfg.i18n.products_load_error}</div>`;
            }
        }

        // Render products
        function renderProducts(products) {
            const grid = document.getElementById('products_grid');
            grid.innerHTML = '';
            if (!products.length) {
                grid.innerHTML = `<div style="grid-column: span 2; text-align: center; padding: 20px;">${cfg.i18n.no_products_found}</div>`;
                return;
            }

            products.forEach(p => {
                const isFav = wishlist.includes(p.id);
                const discount = p.discount_pct ? `<div class="product-discount-badge">${p.discount_pct}%</div>` : '';
                const typeBadge = p.is_variable ? `<div class="product-type-badge">${cfg.i18n.product_variable}</div>` : (p.is_virtual ? `<div class="product-type-badge">${cfg.i18n.product_digital}</div>` : '');
                const regPrice = p.regular_price ? `<span class="product-regular-price">${formatMoney(p.regular_price)}</span>` : '';
                const displayName = escapeHtml(p.display_name || p.name || '');
                const imageUrl = escapeHtml(p.image || '');

                const card = document.createElement('div');
                card.className = 'product-card';
                card.innerHTML = `
                    <div class="product-img-wrap">
                        <img src="${imageUrl}" class="product-img" alt="${displayName}" loading="lazy">
                        ${discount}
                        ${typeBadge}
                        <button class="product-wishlist-btn" onclick="toggleFav(${p.id})"><span class="zsb-icon zsb-icon-heart ${isFav ? 'is-active' : ''}" aria-hidden="true"></span></button>
                    </div>
                    <div class="product-info">
                        <div class="product-title">${displayName}</div>
                        <div class="product-price-row">
                            ${regPrice}
                            <span class="product-price">${p.is_variable ? (cfg.i18n.price_from) : ''}${formatMoney(p.price)}</span>
                        </div>
                        <div id="btn_wrap_${p.id}">
                            ${renderProductAction(p)}
                        </div>
                    </div>
                `;
                grid.appendChild(card);
            });
        }

        function renderProductAction(p) {
            if (p.is_variable) {
                return `<button class="btn-add-cart" onclick="openVariationModal(${p.id})"><span class="zsb-icon zsb-icon-settings-2" aria-hidden="true"></span> ${cfg.i18n.select_options}</button>`;
            }
            const qty = cart[p.id] || 0;
            if (qty > 0) {
                return `
                    <div class="cart-qty-counter">
                        <button class="qty-btn" onclick="updateQty(${p.id}, -1)">-</button>
                        <span class="qty-val">${qty}</span>
                        <button class="qty-btn" onclick="updateQty(${p.id}, 1)">+</button>
                    </div>
                `;
            }
            return `<button class="btn-add-cart" onclick="updateQty(${p.id}, 1)"><span class="zsb-icon zsb-icon-shopping-cart" aria-hidden="true"></span> ${cfg.i18n.add_to_cart}</button>`;
        }

        // Variation Modal Handlers
        function openVariationModal(pId) {
            const prod = productsCache.find(p => p.id == pId);
            if (!prod || !prod.variations) return;
            activeVariableProduct = prod;

            document.getElementById('var_modal_title').innerText = prod.display_name || prod.name;
            document.getElementById('var_modal_img').src = prod.image;
            document.getElementById('var_modal_price').innerText = formatMoney(prod.price);

            const container = document.getElementById('var_options_container');
            container.innerHTML = '';

            prod.variations.forEach((v, idx) => {
                const opt = document.createElement('div');
                opt.className = `option-card ${idx === 0 ? 'is-selected' : ''}`;
                const attrText = Object.entries(v.attributes).map(([k, val]) => val).join(' - ') || `Option #${idx+1}`;
                opt.innerHTML = `
                    <div>
                        <strong>${attrText}</strong>
                        <div style="font-size: 11px; color: var(--hint-color);">${v.is_in_stock ? (cfg.i18n.in_stock) : (cfg.i18n.out_of_stock)}</div>
                    </div>
                    <strong>${formatMoney(v.price)}</strong>
                `;
                opt.onclick = () => {
                    document.querySelectorAll('#var_options_container .option-card').forEach(el => el.classList.remove('is-selected'));
                    opt.classList.add('is-selected');
                    selectedVariation = v;
                    document.getElementById('var_modal_img').src = v.image;
                    document.getElementById('var_modal_price').innerText = formatMoney(v.price);
                };
                container.appendChild(opt);
            });

            selectedVariation = prod.variations[0];
            document.getElementById('var_modal').classList.add('is-active');
        }

        function closeVariationModal() {
            document.getElementById('var_modal').classList.remove('is-active');
            activeVariableProduct = null;
            selectedVariation = null;
        }

        document.getElementById('btn_add_variation')?.addEventListener('click', () => {
            if (!activeVariableProduct || !selectedVariation) return;
            const key = `${activeVariableProduct.id}V${selectedVariation.variation_id}`;
            cart[key] = (cart[key] || 0) + 1;
            storageSet('zarincode_cart', JSON.stringify(cart));
            syncCartWithBot();
            updateCartBadge();
            closeVariationModal();
            if (tg?.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
            alert(cfg.i18n.cart_added);
        });

        function updateQty(key, delta) {
            const current = cart[key] || 0;
            const updated = current + delta;
            if (updated <= 0) {
                delete cart[key];
            } else {
                cart[key] = updated;
            }
            storageSet('zarincode_cart', JSON.stringify(cart));
            syncCartWithBot();
            updateCartBadge();

            const wrap = document.getElementById(`btn_wrap_${key}`);
            if (wrap) {
                const prod = productsCache.find(p => p.id == key);
                if (prod) wrap.innerHTML = renderProductAction(prod);
            }
            if (currentTab === 'view-cart') renderCartView();
        }

        function updateCartBadge() {
            const totalItems = Object.values(cart).reduce((a, b) => a + b, 0);
            if (platform === 'bale') {
                try { if (baleSupportsVersion('1.0')) totalItems > 0 ? bale.enableClosingConfirmation?.() : bale.disableClosingConfirmation?.(); } catch (error) {}
            }
            const badge = document.getElementById('nav_cart_badge');
            if (totalItems > 0) {
                badge.innerText = totalItems;
                badge.style.display = 'flex';
            } else {
                badge.style.display = 'none';
            }
        }

        function toggleFav(pId) {
            if (wishlist.includes(pId)) {
                wishlist = wishlist.filter(id => id !== pId);
            } else {
                wishlist.push(pId);
            }
            storageSet('zarincode_wishlist', JSON.stringify(wishlist));
            renderProducts(productsCache);
            if (currentTab === 'view-wishlist') renderWishlistView();
        }

        // Render Cart View
        async function renderCartView() {
            const list = document.getElementById('cart_items_list');
            const summaryBox = document.getElementById('cart_summary_box');
            const entries = Object.entries(cart);

            if (!entries.length) {
                list.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-icon"><span class="zsb-icon zsb-icon-shopping-cart" aria-hidden="true"></span></div>
                        <div class="empty-title">${cfg.i18n.cart_empty}</div>
                        <div class="empty-desc">${cfg.i18n.cart_empty_hint}</div>
                    </div>
                `;
                summaryBox.style.display = 'none';
                return;
            }

            let subtotal = 0;
            list.innerHTML = '';
            entries.forEach(([key, qty]) => {
                let title = `${cfg.i18n.product_number}${key}`;
                let price = 0;
                let img = '';

                if (key.includes('V')) {
                    const [pId, vId] = key.split('V');
                    const parent = productsCache.find(p => p.id == pId);
                    const v = parent?.variations?.find(vr => vr.variation_id == vId);
                    title = parent ? `${v?.display_name || parent.display_name || parent.name} (${Object.values(v?.attributes || {}).join(', ')})` : `Variation #${vId}`;
                    price = v ? v.price : (parent ? parent.price : 0);
                    img = v?.image || parent?.image || '';
                } else {
                    const prod = productsCache.find(p => p.id == key);
                    title = prod ? (prod.display_name || prod.name) : `${cfg.i18n.product_number}${key}`;
                    price = prod ? prod.price : 0;
                    img = prod ? prod.image : '';
                }

                subtotal += (price * qty);

                const item = document.createElement('div');
                item.className = 'cart-item';
                item.innerHTML = `
                    <img src="${img}" class="cart-item-img">
                    <div class="cart-item-info">
                        <div class="cart-item-title">${escapeHtml(title)}</div>
                        <div class="cart-item-price">${formatMoney(price)}</div>
                    </div>
                    <div style="width: 90px;">
                        <div class="cart-qty-counter">
                            <button class="qty-btn" onclick="updateQty('${key}', -1)">-</button>
                            <span class="qty-val">${qty}</span>
                            <button class="qty-btn" onclick="updateQty('${key}', 1)">+</button>
                        </div>
                    </div>
                `;
                list.appendChild(item);
            });

            document.getElementById('cart_subtotal').innerText = formatMoney(subtotal);
            calculateFinalTotal(subtotal);
            summaryBox.style.display = 'block';

            // Fetch dynamic shipping and payment gateways
            fetchShippingAndTax(subtotal);
        }

        function calculateFinalTotal(subtotal) {
            const finalVal = Math.max(0, subtotal - appliedDiscount + selectedShippingCost + selectedTax);
            document.getElementById('cart_total').innerText = formatMoney(finalVal);
        }

        function applyCheckoutProfile(profile) {
            currentCheckoutProfile = {
                downloadable_only: Boolean(profile?.downloadable_only),
                free_downloadable_only: Boolean(profile?.free_downloadable_only),
                needs_shipping: Boolean(profile?.needs_shipping)
            };
            const profileKey = currentCheckoutProfile.downloadable_only ? 'downloadable' : 'physical';
            const fieldSettings = cfg.checkoutFieldProfiles?.[profileKey] || {};
            const isEnabled = (key) => Boolean(fieldSettings?.[key]?.enabled);
            const isRequired = (key) => Boolean(fieldSettings?.[key]?.required);
            document.querySelectorAll('[data-zsb-profile-fields]').forEach((group) => {
                const keys = (group.dataset.zsbProfileFields || '').split(',').map((key) => key.trim()).filter(Boolean);
                const visible = keys.some(isEnabled);
                group.hidden = !visible;
                const input = group.querySelector('input,textarea,select');
                if (input) input.required = keys.some(isRequired);
            });
            const nameInput = document.getElementById('chk_name');
            const nameRequired = isRequired('billing_first_name') || isRequired('billing_last_name');
            const phoneInput = document.getElementById('chk_phone');
            const phoneRequired = isRequired('billing_phone') || Boolean(cfg.phoneOtpRequired);
            const emailInput = document.getElementById('chk_email');
            if (nameInput) nameInput.required = nameRequired;
            if (phoneInput) phoneInput.required = phoneRequired;
            if (emailInput) emailInput.required = isRequired('billing_email');
            const extraContainer = document.getElementById('zsb_extra_checkout_fields');
            if (extraContainer) {
                const represented = new Set(['billing_first_name', 'billing_last_name', 'billing_phone', 'billing_email', 'billing_state', 'shipping_state', 'billing_city', 'shipping_city', 'billing_address_1', 'shipping_address_1', 'billing_postcode', 'shipping_postcode', 'order_comments']);
                const labels = { billing_company: cfg.isPersian ? 'شرکت' : 'Company', billing_country: cfg.isPersian ? 'کشور' : 'Country', billing_address_2: cfg.isPersian ? 'نشانی، خط دوم' : 'Address line 2', shipping_first_name: cfg.isPersian ? 'نام گیرنده' : 'Recipient first name', shipping_last_name: cfg.isPersian ? 'نام خانوادگی گیرنده' : 'Recipient last name', shipping_company: cfg.isPersian ? 'شرکت گیرنده' : 'Recipient company', shipping_country: cfg.isPersian ? 'کشور ارسال' : 'Shipping country', shipping_address_2: cfg.isPersian ? 'نشانی ارسال، خط دوم' : 'Shipping address line 2' };
                const keys = Object.keys(fieldSettings).filter((key) => !represented.has(key) && fieldSettings[key]?.enabled);
                extraContainer.innerHTML = keys.map((key) => {
                    const required = isRequired(key);
                    let control;
                    if (key === 'billing_country' || key === 'shipping_country') {
                        const countries = cfg.checkoutCountries && typeof cfg.checkoutCountries === 'object' ? cfg.checkoutCountries : {};
                        control = `<select id="zsb_default_${key}" class="form-input" data-zsb-default-field="${key}"${required ? ' required' : ''}><option value=""></option>${Object.entries(countries).map(([code, country]) => `<option value="${escapeHtml(code)}">${escapeHtml(country)}</option>`).join('')}</select>`;
                    } else {
                        control = `<input type="text" id="zsb_default_${key}" class="form-input" data-zsb-default-field="${key}"${required ? ' required' : ''}>`;
                    }
                    return `<div class="form-group"><label class="form-label" for="zsb_default_${key}">${escapeHtml(labels[key] || key)}${required ? ' *' : ''}</label>${control}</div>`;
                }).join('');
            }
            const optionalFields = document.getElementById('zsb_shipping_checkout_fields');
            if (optionalFields) optionalFields.hidden = currentCheckoutProfile.downloadable_only;
            const customContainer = document.getElementById('zsb_custom_checkout_fields');
            if (customContainer) {
                const profileKey = currentCheckoutProfile.downloadable_only ? 'downloadable' : 'physical';
                const customFields = Array.isArray(cfg.checkoutCustomFields?.[profileKey]) ? cfg.checkoutCustomFields[profileKey] : [];
                customContainer.innerHTML = customFields.map((field) => {
                    const key = String(field?.key || '').replace(/[^a-zA-Z0-9_]/g, '');
                    const label = escapeHtml(field?.label || key);
                    const type = ['email', 'tel', 'textarea', 'select'].includes(field?.type) ? field.type : 'text';
                    const required = field?.required ? ' required' : '';
                    const id = 'zsb_custom_' + key;
                    let control = '';
                    if (type === 'textarea') control = `<textarea id="${id}" class="form-input" data-zsb-custom-field="${key}"${required}></textarea>`;
                    else if (type === 'select') {
                        const options = Array.isArray(field?.options) ? field.options : [];
                        control = `<select id="${id}" class="form-input" data-zsb-custom-field="${key}"${required}><option value=""></option>${options.map((option) => `<option value="${escapeHtml(option)}">${escapeHtml(option)}</option>`).join('')}</select>`;
                    } else control = `<input type="${type}" id="${id}" class="form-input" data-zsb-custom-field="${key}"${required}>`;
                    return `<div class="form-group"><label class="form-label" for="${id}">${label}${required ? ' *' : ''}</label>${control}</div>`;
                }).join('');
            }
            const button = document.getElementById('btn_proceed_checkout');
            if (button) button.innerText = currentCheckoutProfile.free_downloadable_only
                ? (cfg.i18n.get_download || cfg.i18n.proceed_to_payment)
                : cfg.i18n.proceed_to_payment;
            if (currentCheckoutProfile.free_downloadable_only) {
                const paymentSection = document.getElementById('payment_section');
                const notice = document.getElementById('payment_notice');
                if (paymentSection) paymentSection.style.display = 'none';
                if (notice) notice.style.display = 'none';
                renderManualTransferDetails(null);
            }
        }

        // Fetch Shipping & Payment Methods
        async function fetchShippingAndTax(subtotal) {
            const city = document.getElementById('chk_city')?.value || '';
            const state = document.getElementById('chk_state')?.value || '';
            const zip = document.getElementById('chk_zip')?.value || '';

            try {
                const res = await fetch(`${cfg.ajaxUrl || 'admin-ajax.php'}?action=zarincode_webapp_shipping_tax`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        platform: platform,
                        lang: cfg.lang || 'fa',
                        chat_id: String(appUser?.id || ''),
                        nonce: webappNonce,
                        init_data: initDataRaw,
                        cart: JSON.stringify(cart),
                        city: city,
                        state: state,
                        address: document.getElementById('chk_address')?.value || '',
                        zip: zip,
                        coupon_code: appliedCouponCode
                    })
                });
                const data = await res.json();
                if (data.success && data.data) {
                    applyCheckoutProfile(data.data);
                    selectedTax = Number(data.data.tax || 0);
                    document.getElementById('cart_tax').innerText = formatMoney(selectedTax);
                    renderShippingMethods(data.data.shipping_methods, data.data.needs_shipping);
                    renderPaymentGateways(data.data.payment_gateways);
                }
            } catch (err) {}
        }

        let shippingRefreshTimer = null;
        ['chk_city', 'chk_state', 'chk_zip', 'chk_address'].forEach((id) => {
            const field = document.getElementById(id);
            field?.addEventListener('input', () => {
                clearTimeout(shippingRefreshTimer);
                shippingRefreshTimer = setTimeout(() => {
                    const subtotal = Number(document.getElementById('cart_subtotal')?.innerText.replace(/[^0-9.]/g, '')) || 0;
                    fetchShippingAndTax(subtotal);
                }, 650);
            });
        });

        function renderShippingMethods(methods, needsShipping) {
            const sec = document.getElementById('shipping_section');
            const list = document.getElementById('shipping_methods_list');
            if (!needsShipping) {
                sec.style.display = 'none';
                selectedShippingCost = 0;
                selectedShippingMethod = '';
                document.getElementById('cart_shipping').innerText = cfg.i18n.digital_delivery_free;
                const subtotal = Number(document.getElementById('cart_subtotal')?.innerText.replace(/[^0-9.]/g, '')) || 0;
                calculateFinalTotal(subtotal);
                return;
            }
            if (!methods || !methods.length) {
                sec.style.display = 'block';
                selectedShippingCost = 0;
                selectedShippingMethod = '';
                list.innerHTML = `<div class="form-help">${cfg.i18n.shipping_unavailable_for_address}</div>`;
                document.getElementById('cart_shipping').innerText = cfg.i18n.shipping_method_none;
                const subtotal = Number(document.getElementById('cart_subtotal')?.innerText.replace(/[^0-9.]/g, '')) || 0;
                calculateFinalTotal(subtotal);
                return;
            }

            sec.style.display = 'block';
            list.innerHTML = '';
            methods.forEach((m, idx) => {
                const card = document.createElement('div');
                card.className = `option-card ${idx === 0 ? 'is-selected' : ''}`;
                card.innerHTML = `
                    <span><span class="zsb-icon zsb-icon-truck" aria-hidden="true"></span> ${m.title}</span>
                    <strong>${m.formatted_cost}</strong>
                `;
                card.onclick = () => {
                    document.querySelectorAll('#shipping_methods_list .option-card').forEach(el => el.classList.remove('is-selected'));
                    card.classList.add('is-selected');
                    selectedShippingCost = Number(m.cost || 0) + Number(m.tax || 0);
                    selectedShippingMethod = m.id;
                    document.getElementById('cart_shipping').innerText = m.formatted_cost;
                    const subtotal = Number(document.getElementById('cart_subtotal').innerText.replace(/[^0-9.]/g, '')) || 0;
                    calculateFinalTotal(subtotal);
                };
                list.appendChild(card);
            });

            // Default first
            selectedShippingCost = Number(methods[0].cost || 0) + Number(methods[0].tax || 0);
            selectedShippingMethod = methods[0].id;
            document.getElementById('cart_shipping').innerText = methods[0].formatted_cost;
            const subtotal = Number(document.getElementById('cart_subtotal').innerText.replace(/[^0-9.]/g, '')) || 0;
            calculateFinalTotal(subtotal);
        }

        function renderManualTransferDetails(gateway) {
            const details = document.getElementById('manual_transfer_details');
            const accountsList = document.getElementById('transfer_accounts_list');
            const receiptInput = document.getElementById('payment_receipt');
            const help = document.getElementById('receipt_upload_help');
            if (!details || !accountsList || !receiptInput || !help) return;
            const isTransfer = gateway?.type === 'card_transfer';
            details.hidden = !isTransfer;
            receiptInput.required = isTransfer;
            accountsList.replaceChildren();
            if (!isTransfer) return;

            const heading = document.createElement('strong');
            heading.textContent = gateway.account_prompt || cfg.i18n.transfer_account_prompt;
            accountsList.appendChild(heading);
            const accounts = Array.isArray(gateway.accounts) ? gateway.accounts : [];
            if (!accounts.some((account) => account.id === selectedTransferAccount)) {
                selectedTransferAccount = accounts[0]?.id || '';
            }

            const appendCopyField = (target, labelText, value, modifier = '') => {
                value = String(value || '').trim();
                if (!value) return;
                const field = document.createElement('div');
                field.className = `zsb-bank-field ${modifier}`.trim();
                const copy = document.createElement('div');
                copy.className = 'zsb-bank-field-copy';
                const caption = document.createElement('span');
                caption.className = 'zsb-bank-field-label';
                caption.textContent = labelText;
                const printed = document.createElement('bdi');
                printed.className = 'zsb-bank-field-value';
                printed.dir = 'ltr';
                printed.textContent = value;
                copy.append(caption, printed);
                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'zsb-copy-value';
                button.dataset.copyValue = value;
                button.dataset.copyLabel = cfg.i18n.transfer_copy_field.replace('%s', labelText);
                button.dataset.copyDefault = cfg.i18n.transfer_copy;
                button.dataset.copySuccess = cfg.i18n.transfer_copied;
                button.dataset.copyFailure = cfg.i18n.transfer_copy_failed;
                button.setAttribute('aria-label', button.dataset.copyLabel);
                const copyIcon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                copyIcon.setAttribute('viewBox', '0 0 24 24');
                copyIcon.setAttribute('aria-hidden', 'true');
                copyIcon.setAttribute('focusable', 'false');
                const copyRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
                copyRect.setAttribute('x', '8'); copyRect.setAttribute('y', '8'); copyRect.setAttribute('width', '12'); copyRect.setAttribute('height', '12'); copyRect.setAttribute('rx', '2');
                const copyPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                copyPath.setAttribute('d', 'M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3');
                copyIcon.append(copyRect, copyPath);
                const copyLabel = document.createElement('span');
                copyLabel.textContent = cfg.i18n.transfer_copy;
                button.append(copyIcon, copyLabel);
                field.append(copy, button);
                target.appendChild(field);
            };

            accounts.forEach((account, index) => {
                const option = document.createElement('article');
                option.className = `zsb-transfer-account-choice transfer-account-option ${account.id === selectedTransferAccount ? 'is-selected' : ''}`;
                const selector = document.createElement('label');
                const radio = document.createElement('input');
                radio.type = 'radio';
                radio.name = 'transfer-account-choice';
                radio.value = account.id || '';
                radio.checked = account.id === selectedTransferAccount || (!selectedTransferAccount && index === 0);
                const selectedName = document.createElement('span');
                selectedName.textContent = account.label || account.bank || cfg.i18n.transfer_bank_account;
                radio.addEventListener('change', () => {
                    selectedTransferAccount = radio.value;
                    accountsList.querySelectorAll('.zsb-transfer-account-choice').forEach((item) => item.classList.toggle('is-selected', item === option));
                });
                selector.append(radio, selectedName);
                option.appendChild(selector);

                const card = document.createElement('section');
                card.className = 'zsb-transfer-account-card';
                const header = document.createElement('header');
                header.className = 'zsb-bank-card-header';
                const chip = document.createElement('span');
                chip.className = 'zsb-bank-card-chip';
                chip.setAttribute('aria-hidden', 'true');
                const title = document.createElement('span');
                title.className = 'zsb-bank-card-title';
                title.textContent = cfg.i18n.transfer_bank_transfer;
                const bank = document.createElement('span');
                bank.className = 'zsb-bank-card-brand';
                bank.textContent = account.bank || account.label || '';
                header.append(chip, title, bank);
                card.appendChild(header);

                const content = document.createElement('div');
                content.className = 'zsb-bank-card-content';
                const accountName = document.createElement('div');
                accountName.className = 'zsb-bank-card-name';
                const nameLabel = document.createElement('span');
                nameLabel.textContent = cfg.i18n.transfer_account_name;
                const name = document.createElement('strong');
                name.textContent = account.label || cfg.i18n.transfer_bank_account;
                accountName.append(nameLabel, name);
                content.appendChild(accountName);
                appendCopyField(content, cfg.i18n.transfer_account_holder, account.holder, 'zsb-bank-field-holder');

                const numberGrid = document.createElement('div');
                numberGrid.className = 'zsb-bank-number-grid';
                appendCopyField(numberGrid, cfg.i18n.transfer_card_number, account.card_number, 'zsb-bank-field-card');
                appendCopyField(numberGrid, cfg.i18n.transfer_account_number, account.account_number, 'zsb-bank-field-account');
                appendCopyField(numberGrid, cfg.i18n.transfer_iban, account.iban, 'zsb-bank-field-iban');
                content.appendChild(numberGrid);
                if (account.instructions) {
                    const note = document.createElement('p');
                    note.className = 'zsb-bank-instructions';
                    note.textContent = account.instructions;
                    content.appendChild(note);
                }
                const status = document.createElement('span');
                status.className = 'zsb-copy-status';
                status.setAttribute('role', 'status');
                status.setAttribute('aria-live', 'polite');
                content.appendChild(status);
                card.appendChild(content);
                option.appendChild(card);
                accountsList.appendChild(option);
                if (radio.checked) selectedTransferAccount = radio.value;
            });
            if (gateway.instructions) {
                const instructions = document.createElement('div');
                instructions.className = 'zsb-transfer-instructions';
                instructions.textContent = gateway.instructions;
                accountsList.appendChild(instructions);
            }
            receiptInput.accept = gateway.accept || '';
            const formats = Array.isArray(gateway.allowed_extensions) ? gateway.allowed_extensions.join(', ') : '';
            help.textContent = gateway.receipt_help || cfg.i18n.receipt_upload_help.replace('%1$s', formats || cfg.i18n.receipt_formats_default).replace('%2$s', gateway.max_upload_label || cfg.i18n.receipt_max_default);
        }

        function renderPaymentGateways(gateways) {
            const sec = document.getElementById('payment_section');
            const list = document.getElementById('payment_gateways_list');
            const notice = document.getElementById('payment_notice');
            currentPaymentOptions = Array.isArray(gateways) ? gateways : [];
            if (currentCheckoutProfile.free_downloadable_only) {
                sec.style.display = 'none';
                selectedPaymentMethod = '';
                if (notice) notice.style.display = 'none';
                renderManualTransferDetails(null);
                return;
            }
            if (!currentPaymentOptions.length) {
                sec.style.display = 'none';
                selectedPaymentMethod = '';
                if (notice) notice.style.display = 'block';
                renderManualTransferDetails(null);
                return;
            }
            if (notice) notice.style.display = 'none';
            sec.style.display = 'block';
            list.replaceChildren();
            currentPaymentOptions.forEach((gateway, index) => {
                const card = document.createElement('button');
                card.type = 'button';
                card.className = `option-card ${index === 0 ? 'is-selected' : ''}`;
                const title = document.createElement('span');
                title.className = 'payment-option-title';
                title.textContent = gateway.title || gateway.id || '';
                const icon = document.createElement('span');
                icon.className = 'zsb-icon zsb-icon-credit-card';
                icon.setAttribute('aria-hidden', 'true');
                title.prepend(icon);
                card.appendChild(title);
                if (gateway.description) {
                    const description = document.createElement('small');
                    description.className = 'payment-option-description';
                    description.textContent = gateway.description;
                    card.appendChild(description);
                }
                card.addEventListener('click', () => {
                    list.querySelectorAll('.option-card').forEach((el) => el.classList.remove('is-selected'));
                    card.classList.add('is-selected');
                    selectedPaymentMethod = gateway.id;
                    renderManualTransferDetails(gateway);
                });
                list.appendChild(card);
            });
            selectedPaymentMethod = currentPaymentOptions[0].id;
            renderManualTransferDetails(currentPaymentOptions[0]);
        }

        // Coupon Application
        document.getElementById('btn_apply_coupon')?.addEventListener('click', async () => {
            const code = document.getElementById('chk_coupon').value.trim();
            const feedback = document.getElementById('coupon_feedback');
            if (!code) return;

            const subtotal = Number(document.getElementById('cart_subtotal').innerText.replace(/[^0-9.]/g, '')) || 0;
            try {
                const res = await fetch(`${cfg.ajaxUrl || 'admin-ajax.php'}?action=zarincode_webapp_validate_coupon`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ platform: platform, lang: cfg.lang || 'fa', chat_id: String(appUser?.id || ''), nonce: webappNonce, init_data: initDataRaw, coupon_code: code, subtotal: subtotal })
                });
                const data = await res.json();
                if (data.success && data.data) {
                    appliedDiscount = data.data.discount;
                    appliedCouponCode = data.data.coupon_code;
                    feedback.style.color = '#15803d';
                    feedback.innerText = data.data.message;
                    document.getElementById('row_discount').style.display = 'flex';
                    document.getElementById('cart_discount').innerText = `-${data.data.formatted_discount}`;
                    calculateFinalTotal(subtotal);
                } else {
                    feedback.style.color = '#b91c1c';
                    feedback.innerText = data.data?.message || cfg.i18n.invalidCoupon;
                }
            } catch (err) {
                feedback.style.color = '#b91c1c';
                        feedback.innerText = cfg.i18n.coupon_validation_error;
            }
        });

        // Render Wishlist
        function renderWishlistView() {
            const list = document.getElementById('wishlist_items_list');
            if (!wishlist.length) {
                list.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-icon"><span class="zsb-icon zsb-icon-heart" aria-hidden="true"></span></div>
                        <div class="empty-title">${cfg.i18n.wishlist_empty}</div>
                        <div class="empty-desc">${cfg.i18n.wishlist_empty_hint}</div>
                    </div>
                `;
                return;
            }

            list.innerHTML = '';
            wishlist.forEach(id => {
                const prod = productsCache.find(p => p.id == id);
                if (!prod) return;
                const item = document.createElement('div');
                item.className = 'cart-item';
                item.innerHTML = `
                    <img src="${prod.image}" class="cart-item-img">
                    <div class="cart-item-info">
                        <div class="cart-item-title">${escapeHtml(prod.display_name || prod.name)}</div>
                        <div class="cart-item-price">${formatMoney(prod.price)}</div>
                    </div>
                    <button class="btn-add-cart" style="width: auto; padding: 0 12px;" onclick="updateQty(${prod.id}, 1)"><span class="zsb-icon zsb-icon-shopping-cart" aria-hidden="true"></span></button>
                    <button style="border: none; background: transparent; font-size: 16px; cursor: pointer;" onclick="toggleFav(${prod.id})"><span class="zsb-icon zsb-icon-x" aria-hidden="true"></span></button>
                `;
                list.appendChild(item);
            });
        }

        // Fetch Orders View
        async function fetchOrdersView() {
            const list = document.getElementById('orders_list');
            list.innerHTML = `<div style="text-align: center; padding: 20px;"><span class="zsb-icon zsb-icon-hourglass" aria-hidden="true"></span> ${cfg.i18n.loading_orders}</div>`;

            const chatId = appUser?.id || '';
            try {
                const res = await fetch(`${cfg.ajaxUrl || 'admin-ajax.php'}?action=zarincode_webapp_orders`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ chat_id: String(chatId), nonce: webappNonce, init_data: initDataRaw, platform: platform, lang: cfg.lang || 'fa' })
                });
                const data = await res.json();
                if (data.success && data.data && data.data.length) {
                    list.innerHTML = '';
                    data.data.forEach(o => {
                        const card = document.createElement('div');
                        card.className = 'cart-summary';
                        card.style.marginTop = '10px';

                        let itemsHtml = '<div style="margin: 8px 0; font-size: 12px; color: var(--hint-color);">';
                        (o.items || []).forEach(it => {
                            itemsHtml += `<div>▫ ${it.name} × ${it.quantity} (${it.total})</div>`;
                        });
                        itemsHtml += '</div>';

                        let downloadsHtml = '';
                        if (o.downloads && o.downloads.length) {
                            downloadsHtml = '<div style="margin-top: 8px; border-top: 1px dashed var(--card-border); padding-top: 6px;">';
                            o.downloads.forEach(d => {
                                downloadsHtml += `<a href="${d.url}" target="_blank" style="display: block; font-size: 12px; color: var(--button-color); text-decoration: none; margin-bottom: 4px;"><span class="zsb-icon zsb-icon-download" aria-hidden="true"></span> ${d.name}</a>`;
                            });
                            downloadsHtml += '</div>';
                        }

                        const invoiceHandle = platform === 'bale' ? o.invoice_params : o.invoice_url;
                        const invoiceLabel = platform === 'bale'
                            ? (cfg.i18n.pay_bale)
                            : (cfg.i18n.pay_telegram);
                        const reviewLabels = {
                            awaiting_receipt: cfg.i18n.receipt_awaiting_upload,
                            pending: cfg.i18n.receipt_review_pending,
                            rejected: cfg.i18n.receipt_rejected,
                            approved: cfg.i18n.receipt_approved
                        };
                        const paymentInfoHtml = o.payment_method_title
                            ? `<div class="payment-method-summary"><span>${escapeHtml(cfg.i18n.payment_method_label)}:</span> <strong>${escapeHtml(o.payment_method_title)}</strong></div>`
                            : '';
                        const reviewInfoHtml = o.payment_review_status
                            ? `<div class="payment-review-summary">${escapeHtml(reviewLabels[o.payment_review_status] || o.payment_review_status)}</div>`
                            : '';
                        const onlinePaymentButton = o.payment_url
                            ? `<button type="button" class="btn-checkout zarin-website-payment" data-payment-url="${escapeHtml(o.payment_url)}" style="display:block;width:100%;margin-top:8px;">${escapeHtml(cfg.i18n.complete_payment)}</button>`
                            : '';
                        card.innerHTML = `
                            <div class="summary-row">
                                <strong>#${o.number}</strong>
                                <span>${o.status_label || o.status}</span>
                            </div>
                            <div class="summary-row">
                                <span>${cfg.i18n.order_date} ${o.date}</span>
                                <strong>${o.formatted_total}</strong>
                            </div>
                            ${paymentInfoHtml}
                            ${reviewInfoHtml}
                            ${itemsHtml}
                            ${downloadsHtml}
                            ${onlinePaymentButton}
                            ${invoiceHandle ? `<button type="button" class="btn-checkout zarin-native-invoice" data-invoice-handle="${encodeURIComponent(invoiceHandle)}" style="display:block;width:100%;margin-top:8px;"><span class="zsb-icon zsb-icon-credit-card" aria-hidden="true"></span> ${invoiceLabel}</button>` : ''}
                        `;
                        const nativeInvoiceButton = card.querySelector('.zarin-native-invoice');
                        nativeInvoiceButton?.addEventListener('click', () => openNativeInvoice(decodeURIComponent(nativeInvoiceButton.dataset.invoiceHandle || ''), o.number, nativeInvoiceButton, false));
                        card.querySelector('.zarin-website-payment')?.addEventListener('click', (event) => {
                            const paymentUrl = event.currentTarget.dataset.paymentUrl || '';
                            if (paymentUrl) window.location.assign(paymentUrl);
                        });
                        list.appendChild(card);
                    });
                } else {
                    list.innerHTML = `
                        <div class="empty-state">
                            <div class="empty-icon"><span class="zsb-icon zsb-icon-package" aria-hidden="true"></span></div>
                            <div class="empty-title">${cfg.i18n.no_orders}</div>
                        </div>
                    `;
                }
            } catch (e) {
                list.innerHTML = `<div>${cfg.i18n.orders_error}</div>`;
            }
        }

        async function verifyOrderPaid(orderNumber) {
            if (!appUser?.id || !initDataRaw) return false;
            const attempts = 7;
            for (let attempt = 0; attempt < attempts; attempt++) {
                try {
                    const response = await fetch(`${cfg.ajaxUrl || 'admin-ajax.php'}?action=zarincode_webapp_orders`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({ chat_id: String(appUser.id), nonce: webappNonce, init_data: initDataRaw, platform: platform, lang: cfg.lang || 'fa' })
                    });
                    const result = await response.json();
                    const order = result.success && Array.isArray(result.data)
                        ? result.data.find((item) => String(item.number) === String(orderNumber))
                        : null;
                    if (order && ['processing', 'completed'].includes(String(order.status).toLowerCase())) return true;
                } catch (error) {}
                if (attempt < attempts - 1) await new Promise((resolve) => window.setTimeout(resolve, 1200));
            }
            return false;
        }

        function openWebsitePayment(paymentUrl) {
            const url = String(paymentUrl || '');
            if (!url) return false;
            // Use each Mini App's documented link-opening bridge for WooCommerce
            // gateway pages. Navigating the embedded WebView directly can leave
            // some clients on the checkout screen with the button still loading.
            try {
                if (platform === 'telegram' && typeof tg?.openLink === 'function') {
                    tg.openLink(url);
                    return true;
                }
                if (platform === 'bale' && typeof bale?.openLink === 'function') {
                    bale.openLink(url);
                    return true;
                }
            } catch (error) {}
            try {
                window.location.assign(url);
                return true;
            } catch (error) {
                return false;
            }
        }

        function openNativeInvoice(invoiceHandle, orderNumber, btn, clearCartOnPaid = true) {
            const invoiceMethod = platform === 'bale' ? bale?.openInvoice : tg?.openInvoice;
            if (!app || typeof invoiceMethod !== 'function' || (platform === 'bale' && !baleSupportsVersion('1.3'))) {
                const message = platform === 'bale'
                    ? (cfg.i18n.bale_invoice_unsupported)
                    : (cfg.i18n.telegram_invoice_unsupported);
                alert(message);
                btn.disabled = false;
                return;
            }
            btn.dataset.invoiceHandle = invoiceHandle;
            btn.dataset.orderNumber = orderNumber;
            btn.disabled = true;
            const callback = async (result) => {
                const status = typeof result === 'string' ? result : (result?.status || '');
                if (status === 'paid') {
                    const confirmed = await verifyOrderPaid(orderNumber);
                    if (confirmed) {
                        if (clearCartOnPaid) {
                            storageRemove('zarincode_cart');
                            cart = {};
                        }
                        delete btn.dataset.invoiceHandle;
                        delete btn.dataset.orderNumber;
                        updateCartBadge();
                        if (tg?.HapticFeedback?.notificationOccurred) tg.HapticFeedback.notificationOccurred('success');
                        if (platform === 'bale' && baleSupportsVersion('1.4') && typeof bale.askReview === 'function') {
                            try { bale.askReview({ delay_seconds: 5 }); } catch (error) {}
                        }
                        alert(cfg.i18n.payment_confirmed.replace('%s', orderNumber));
                        document.querySelector('.nav-item[data-view="view-orders"]')?.click();
                    } else {
                        alert(cfg.i18n.payment_pending_confirmation);
                    }
                } else if (status === 'cancelled') {
                    alert(cfg.i18n.payment_cancelled);
                } else if (status === 'pending') {
                    alert(cfg.i18n.payment_pending);
                } else {
                    alert(cfg.i18n.payment_not_completed);
                }
                btn.disabled = false;
                btn.innerText = cfg.i18n.proceed_to_payment;
            };
            try {
                // Bale requires the exact createInvoiceLink result; do not URL-encode or alter it here.
                if (platform === 'bale') bale.openInvoice(invoiceHandle, callback);
                else tg.openInvoice(invoiceHandle, callback);
            } catch (error) {
                btn.disabled = false;
                alert(cfg.i18n.invoice_open_unavailable);
            }
        }

        // Phone OTP is bound to the signed Mini App identity and normalized phone number.
        let phoneOtpVerified = false;
        const otpControls = document.getElementById('zsb_phone_otp_controls');
        const otpStatus = document.getElementById('zsb_phone_otp_status');
        const phoneInputForOtp = document.getElementById('chk_phone');
        if (otpControls && cfg.phoneOtpRequired) otpControls.hidden = false;
        phoneInputForOtp?.addEventListener('input', () => {
            phoneOtpVerified = false;
            if (otpStatus) otpStatus.textContent = '';
        });
        async function requestPhoneOtp(action, extra = {}) {
            const form = new FormData();
            form.append('action', action);
            form.append('nonce', webappNonce);
            form.append('init_data', initDataRaw || '');
            form.append('platform', platform || 'telegram');
            form.append('chat_id', String(appUser?.id || ''));
            form.append('phone', phoneInputForOtp?.value?.trim() || '');
            Object.entries(extra).forEach(([key, value]) => form.append(key, String(value ?? '')));
            const response = await fetch(cfg.ajaxUrl, { method: 'POST', body: form, credentials: 'same-origin' });
            const result = await response.json();
            if (!result?.success) throw new Error(result?.data?.message || cfg.i18n.otp_failed);
            return result.data || {};
        }
        document.getElementById('zsb_phone_otp_send')?.addEventListener('click', async (event) => {
            const button = event.currentTarget;
            if (!phoneInputForOtp?.value?.trim()) { phoneInputForOtp?.focus(); return; }
            button.disabled = true;
            try {
                await requestPhoneOtp('zarincode_webapp_phone_otp_send');
                if (otpStatus) otpStatus.textContent = cfg.i18n.otp_sent;
            } catch (error) {
                if (otpStatus) otpStatus.textContent = error.message || cfg.i18n.otp_failed;
            } finally { button.disabled = false; }
        });
        document.getElementById('zsb_phone_otp_verify')?.addEventListener('click', async (event) => {
            const button = event.currentTarget;
            const code = document.getElementById('zsb_phone_otp_code')?.value?.trim() || '';
            if (!/^\d{6}$/.test(code)) { if (otpStatus) otpStatus.textContent = cfg.i18n.otp_failed; return; }
            button.disabled = true;
            try {
                await requestPhoneOtp('zarincode_webapp_phone_otp_verify', { code });
                phoneOtpVerified = true;
                if (otpStatus) otpStatus.textContent = cfg.i18n.otp_verified;
            } catch (error) {
                phoneOtpVerified = false;
                if (otpStatus) otpStatus.textContent = error.message || cfg.i18n.otp_failed;
            } finally { button.disabled = false; }
        });

        // Checkout submit
        document.getElementById('btn_proceed_checkout')?.addEventListener('click', async () => {
            const name = document.getElementById('chk_name').value.trim();
            const phone = document.getElementById('chk_phone').value.trim();
            const email = document.getElementById('chk_email').value.trim();
            const state = document.getElementById('chk_state').value.trim();
            const city = document.getElementById('chk_city').value.trim();
            const address = document.getElementById('chk_address').value.trim();
            const zip = document.getElementById('chk_zip').value.trim();
            const note = document.getElementById('chk_note').value.trim();

            const emailInput = document.getElementById('chk_email');
            const activeProfileKey = currentCheckoutProfile.downloadable_only ? 'downloadable' : 'physical';
            const activeFieldSettings = cfg.checkoutFieldProfiles?.[activeProfileKey] || {};
            const fieldRequired = (key) => Boolean(activeFieldSettings?.[key]?.required);
            const nameRequired = fieldRequired('billing_first_name') || fieldRequired('billing_last_name');
            const phoneRequired = fieldRequired('billing_phone') || Boolean(cfg.phoneOtpRequired);
            const emailRequired = fieldRequired('billing_email');
            const addressRequired = fieldRequired('billing_address_1') || fieldRequired('shipping_address_1');
            const stateRequired = fieldRequired('billing_state') || fieldRequired('shipping_state');
            const cityRequired = fieldRequired('billing_city') || fieldRequired('shipping_city');
            const zipRequired = fieldRequired('billing_postcode') || fieldRequired('shipping_postcode');
            if ((nameRequired && !name) || (phoneRequired && !phone) || (emailRequired && !email) || (email && !emailInput?.checkValidity()) || (addressRequired && !address) || (stateRequired && !state) || (cityRequired && !city) || (zipRequired && !zip)) {
                alert(cfg.i18n.recipient_fields_required);
                if (emailRequired && !email) emailInput?.focus();
                return;
            }
            if (cfg.phoneOtpRequired && !phoneOtpVerified) {
                alert(cfg.i18n.otp_failed);
                document.getElementById('zsb_phone_otp_controls')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                return;
            }
            const invalidDefaultField = Array.from(document.querySelectorAll('#zsb_extra_checkout_fields [data-zsb-default-field][required]')).find((field) => !field.value.trim() || !field.checkValidity());
            if (invalidDefaultField) { invalidDefaultField.focus(); alert(cfg.i18n.recipient_fields_required); return; }
            const defaultFieldValues = {};
            document.querySelectorAll('#zsb_extra_checkout_fields [data-zsb-default-field]').forEach((field) => { defaultFieldValues[field.dataset.zsbDefaultField] = field.value; });
            const invalidCustomField = Array.from(document.querySelectorAll('#zsb_custom_checkout_fields [data-zsb-custom-field][required]')).find((field) => !field.value.trim() || !field.checkValidity());
            if (invalidCustomField) { invalidCustomField.focus(); alert(cfg.i18n.recipient_fields_required); return; }
            const customFieldValues = {};
            document.querySelectorAll('#zsb_custom_checkout_fields [data-zsb-custom-field]').forEach((field) => { customFieldValues[field.dataset.zsbCustomField] = field.value; });

            const btn = document.getElementById('btn_proceed_checkout');
            const chosenGateway = currentPaymentOptions.find((item) => item.id === selectedPaymentMethod) || null;
            if (!currentCheckoutProfile.free_downloadable_only && !chosenGateway) {
                alert(cfg.i18n.payment_method_required);
                return;
            }
            if (chosenGateway?.type === 'card_transfer' && !selectedTransferAccount) {
                alert(cfg.i18n.transfer_account_required);
                return;
            }
            const selectedReceipt = document.getElementById('payment_receipt')?.files?.[0];
            if (chosenGateway?.type === 'card_transfer' && !selectedReceipt) {
                alert(cfg.i18n.receipt_required);
                return;
            }
            if (chosenGateway?.type === 'card_transfer' && selectedReceipt && chosenGateway.max_upload_bytes && selectedReceipt.size > Number(chosenGateway.max_upload_bytes)) {
                alert(cfg.i18n.receipt_too_large.replace('%s', chosenGateway.max_upload_label || cfg.i18n.receipt_max_default));
                return;
            }
            if (btn.dataset.invoiceHandle && btn.dataset.orderNumber) {
                openNativeInvoice(btn.dataset.invoiceHandle, btn.dataset.orderNumber, btn);
                return;
            }
            btn.disabled = true;
            btn.innerText = cfg.i18n.processing_order;

            try {
                const checkoutForm = new FormData();
                const checkoutFields = {
                    action: 'zarincode_webapp_checkout', platform: platform, lang: cfg.lang || 'fa', nonce: webappNonce,
                    init_data: initDataRaw, cart: JSON.stringify(cart), name, phone, email, state,
                    city, address, zip, note, default_fields: JSON.stringify(defaultFieldValues), custom_fields: JSON.stringify(customFieldValues), coupon_code: appliedCouponCode,
                    shipping_method: selectedShippingMethod, shipping_cost: selectedShippingCost,
                    payment_method: selectedPaymentMethod, transfer_account_id: selectedTransferAccount,
                    chat_id: appUser?.id || '', username: appUser?.username || ''
                };
                Object.entries(checkoutFields).forEach(([key, value]) => checkoutForm.append(key, String(value ?? '')));
                const receiptFile = document.getElementById('payment_receipt')?.files?.[0];
                if (chosenGateway?.type === 'card_transfer' && receiptFile) checkoutForm.append('payment_receipt', receiptFile, receiptFile.name);
                const checkoutAbortController = new AbortController();
                const checkoutTimeout = window.setTimeout(() => checkoutAbortController.abort(), 60000);
                let res;
                let data;
                try {
                    res = await fetch(cfg.ajaxUrl || 'admin-ajax.php', {
                        method: 'POST',
                        body: checkoutForm,
                        signal: checkoutAbortController.signal
                    });
                    data = await res.json();
                } finally {
                    window.clearTimeout(checkoutTimeout);
                }
                const checkoutInvoice = platform === 'bale' ? data.data?.invoice_params : data.data?.invoice_url;
                if (data.success && checkoutInvoice) {
                    openNativeInvoice(checkoutInvoice, data.data.order_number, btn);
                } else if (data.success && data.data?.payment_url) {
                    // The WooCommerce order now owns the basket; keep retries available in My Orders.
                    storageRemove('zarincode_cart');
                    cart = {};
                    updateCartBadge();
                    // Open payment gateways through the active Mini App SDK when available.
                    // The order is already created, so retain the order in My Orders if
                    // this client cannot open the provider page.
                    btn.disabled = true;
                    btn.innerText = cfg.i18n.payment_page_opened;
                    if (!openWebsitePayment(data.data.payment_url)) {
                        btn.disabled = false;
                        btn.innerText = cfg.i18n.proceed_to_payment;
                        alert(cfg.i18n.payment_page_open_failed.replace('%s', data.data.order_number || ''));
                        document.querySelector('.nav-item[data-view="view-orders"]')?.click();
                    }
                } else if (data.success && data.data?.manual_review) {
                    storageRemove('zarincode_cart');
                    cart = {};
                    updateCartBadge();
                    alert(cfg.i18n.receipt_review_order_pending.replace('%s', data.data.order_number));
                    document.querySelector('.nav-item[data-view="view-orders"]')?.click();
                    btn.disabled = false;
                    btn.innerText = cfg.i18n.proceed_to_payment;
                } else if (data.success && data.data?.paid) {
                    storageRemove('zarincode_cart');
                    cart = {};
                    updateCartBadge();
                    const successMessage = data.data?.free_downloadable
                        ? cfg.i18n.free_download_order_placed.replace('%s', data.data.order_number)
                        : cfg.i18n.free_order_placed.replace('%s', data.data.order_number);
                    alert(successMessage);
                    document.querySelector('.nav-item[data-view="view-orders"]')?.click();
                    btn.disabled = false;
                    btn.innerText = cfg.i18n.proceed_to_payment;
                } else {
                    alert(data.data?.message || (cfg.i18n.order_create_error));
                    btn.disabled = false;
                    btn.innerText = cfg.i18n.proceed_to_payment;
                }
            } catch (err) {
                console.error('[ZarinShopBot] Mini App checkout request failed', {
                    platform,
                    error: String(err?.message || err || 'unknown_error'),
                    ajaxHost: (() => { try { return new URL(cfg.ajaxUrl || 'admin-ajax.php', window.location.href).host; } catch (e) { return 'invalid'; } })()
                });
                if (err?.name === 'AbortError') {
                    alert(cfg.i18n.checkout_timeout);
                    document.querySelector('.nav-item[data-view="view-orders"]')?.click();
                } else {
                    alert(cfg.i18n.connection_error);
                }
                btn.disabled = false;
                btn.innerText = cfg.i18n.proceed_to_payment;
            }
        });

        // Search listener
        let searchTimer = null;
        document.getElementById('search_input')?.addEventListener('input', (e) => {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                fetchProducts(0, e.target.value.trim());
            }, 300);
        });

        // Initial Load
        updateCartBadge();
        fetchProducts();
