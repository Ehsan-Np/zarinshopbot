// Modified 2026-10-23 by Ehsan NaderiPanah / Zarincode.com; derived GPL script.
document.addEventListener('DOMContentLoaded', function() {
    var zarinshopbotMainI18n = window.zarinshopbotMainI18n || window.telenexaMainI18n || {};
    // 1. Rich editor live preview and character count.
    var messageBox = document.getElementById('telegram_new_message');
    var livePreview = document.getElementById('zarin-tg-live-preview');
    var charCount = document.getElementById('zarin-char-count');

    function escapePreviewText(value) {
        return String(value).replace(/[&<>"']/g, function(character) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[character];
        });
    }

    function safePreviewMarkup(source) {
        var container = document.createElement('div');
        container.innerHTML = String(source || '');
        var allowed = { B: 'b', STRONG: 'strong', I: 'i', EM: 'em', U: 'u', S: 's', DEL: 'del', CODE: 'code', PRE: 'pre', BLOCKQUOTE: 'blockquote', BR: 'br', P: 'p', DIV: 'div', UL: 'ul', OL: 'ol', LI: 'li' };
        function render(node) {
            if (node.nodeType === 3) return escapePreviewText(node.nodeValue || '');
            if (node.nodeType !== 1) return '';
            var tag = node.tagName.toUpperCase();
            if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'IFRAME' || tag === 'OBJECT') return '';
            var inner = Array.prototype.map.call(node.childNodes, render).join('');
            if (tag === 'A') {
                var href = node.getAttribute('href') || '';
                try {
                    var url = new URL(href, window.location.href);
                    if (url.protocol === 'http:' || url.protocol === 'https:') return '<a href="' + escapePreviewText(url.href) + '" target="_blank" rel="noopener noreferrer">' + inner + '</a>';
                } catch (e) {}
                return inner;
            }
            if (!allowed[tag]) return inner;
            if (tag === 'BR') return '<br>';
            return '<' + allowed[tag] + '>' + inner + '</' + allowed[tag] + '>';
        }
        return Array.prototype.map.call(container.childNodes, render).join('');
    }

    function updatePreview(editor) {
        if (!livePreview) return;
        var html = editor ? editor.getContent() : (messageBox ? messageBox.value : '');
        var text = editor ? (editor.getContent({ format: 'text' }) || '') : (messageBox ? messageBox.value : '');
        if (charCount) charCount.textContent = String(text.length);
        if (!String(text).trim()) {
            livePreview.textContent = (zarinshopbotMainI18n.previewPlaceholder || 'پیش‌نمایش زندهٔ پیام اینجا نمایش داده می‌شود.');
            return;
        }
        livePreview.innerHTML = safePreviewMarkup(html).replace(/\n/g, '<br>');
    }

    function bindBroadcastEditor(editor) {
        if (!editor || editor.id !== 'telegram_new_message' || editor.__zsbPreviewBound) return;
        editor.__zsbPreviewBound = true;
        editor.on('input keyup change SetContent Undo Redo', function() { updatePreview(editor); });
        updatePreview(editor);
    }

    if (window.tinymce) {
        window.tinymce.on('AddEditor', function(event) { bindBroadcastEditor(event.editor); });
        Object.keys(window.tinymce.editors || {}).forEach(function(key) { bindBroadcastEditor(window.tinymce.editors[key]); });
    }
    if (messageBox) {
        messageBox.addEventListener('input', function() { updatePreview(null); });
        updatePreview(null);
    }

    // 5. Client-side Audience Instant Search
    var searchInput = document.getElementById('zarin-audience-search');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            var q = this.value.toLowerCase().trim();
            var rows = document.querySelectorAll('.zarin-audience-row');
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                if (text.indexOf(q) !== -1) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }

    // 6. Click ChatID to copy
    var chatTags = document.querySelectorAll('.zarin-chatid-tag');
    chatTags.forEach(function(tag) {
        tag.addEventListener('click', function() {
            var val = tag.textContent.trim();
            if (navigator.clipboard) {
                navigator.clipboard.writeText(val).then(function() {
                    var orig = tag.textContent;
                    tag.textContent = "✓ " + ((zarinshopbotMainI18n && zarinshopbotMainI18n.copied) || "کپی شد!");
                    setTimeout(function() { tag.textContent = orig; }, 1500);
                });
            }
        });
    });
});
