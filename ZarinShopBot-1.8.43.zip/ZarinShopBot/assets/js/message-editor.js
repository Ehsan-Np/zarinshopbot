// ZarinShopBot rich-message editor helpers (WordPress TinyMCE).
jQuery(function($) {
    function editorText(editor) {
        return String(editor.getContent({ format: 'text' }) || '').replace(/\u00a0/g, ' ').trim();
    }

    function updateOverrideButton(editorId, hasContent) {
        $('.zarin-message-use-shared[data-target="' + editorId + '"]').prop('disabled', !hasContent);
    }

    function bindOverrideEditor(editor) {
        if (!editor || editor.__zsbOverrideBound) return;
        editor.__zsbOverrideBound = true;
        var refresh = function() { updateOverrideButton(editor.id, editorText(editor) !== ''); };
        editor.on('input change keyup SetContent Undo Redo', refresh);
        refresh();
    }

    if (window.tinymce) {
        window.tinymce.on('AddEditor', function(event) { bindOverrideEditor(event.editor); });
        Object.keys(window.tinymce.editors || {}).forEach(function(key) { bindOverrideEditor(window.tinymce.editors[key]); });
    }
    $(document).on('input', '.zarin-message-platform .zarin-message-override', function() {
        updateOverrideButton(this.id, String(this.value || '').trim() !== '');
    });

    $(document).on('click', '.zarin-message-use-shared', function(event) {
        event.preventDefault();
        var editorId = String($(this).attr('data-target') || '');
        var editor = window.tinymce && window.tinymce.get(editorId);
        if (editor) {
            editor.setContent('');
            editor.save();
            editor.fire('input');
            editor.focus();
        } else {
            var target = document.getElementById(editorId);
            if (!target) return;
            target.value = '';
            $(target).trigger('input').trigger('change').trigger('focus');
        }
        $(this).prop('disabled', true);
    });

    function insertIntoEditor(editorId, text) {
        var editor = window.tinymce && window.tinymce.get(editorId);
        if (editor) {
            editor.focus();
            editor.selection.setContent(text);
            editor.fire('input');
            return true;
        }
        var textarea = document.getElementById(editorId);
        if (!textarea) return false;
        var start = typeof textarea.selectionStart === 'number' ? textarea.selectionStart : textarea.value.length;
        var end = typeof textarea.selectionEnd === 'number' ? textarea.selectionEnd : textarea.value.length;
        textarea.setRangeText(text, start, end, 'end');
        textarea.focus();
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
    }

    $(document).on('click', '.zsb-message-variable', function(event) {
        event.preventDefault();
        var text = String($(this).data('variable') || '');
        var editorId = String($(this).data('editor-id') || '');
        if (!text || !editorId || !insertIntoEditor(editorId, text)) return;
        var i18n = (window.zarinshopbotSettings || window.telenexaSettings || window.zarinshopbotMainI18n || {}).i18n || {};
        if (typeof window.showToast === 'function') window.showToast((i18n.variableAdded || 'متغیر %s افزوده شد.').replace('%s', text));
    });

    $(document).on('click', '.zarin-variable-input', function(event) {
        event.preventDefault();
        var targetId = String($(this).data('target') || '');
        var text = String($(this).data('variable') || '');
        if (targetId && text) insertIntoEditor(targetId, text);
    });
});
