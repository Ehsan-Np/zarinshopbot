/* Local repeatable bank-account editor for the ZarinShopBot settings panel. */
(function () {
    'use strict';

    var fields = ['label', 'bank', 'holder', 'card_number', 'account_number', 'iban', 'instructions'];

    function defaults() {
        return { id: '', label: '', bank: '', holder: '', card_number: '', account_number: '', iban: '', instructions: '' };
    }

    function hasClass(element, name) {
        return !!element && (' ' + element.className + ' ').indexOf(' ' + name + ' ') !== -1;
    }

    function addClass(element, name) {
        if (!hasClass(element, name)) element.className = (element.className ? element.className + ' ' : '') + name;
    }

    function removeClass(element, name) {
        if (element) element.className = (' ' + element.className + ' ').replace(' ' + name + ' ', ' ').replace(/^\s+|\s+$/g, '');
    }

    function findAncestor(element, className) {
        while (element && element !== document) {
            if (hasClass(element, className)) return element;
            element = element.parentNode;
        }
        return null;
    }

    function parseLegacy(raw) {
        return String(raw || '').split(/\r\n|\r|\n/).filter(function (line) {
            return line.replace(/^\s+|\s+$/g, '') !== '';
        }).map(function (line) {
            var columns = line.split('|').map(function (part) { return part.replace(/^\s+|\s+$/g, ''); });
            while (columns.length < 7) columns.push('');
            return {
                label: columns[0], bank: columns[1], holder: columns[2], card_number: columns[3],
                iban: columns[4], instructions: columns[5], account_number: columns[6]
            };
        });
    }

    function parseValue(raw) {
        var value = String(raw || '').replace(/^\s+|\s+$/g, '');
        if (value.charAt(0) === '[') {
            try {
                var parsed = JSON.parse(value);
                if (Object.prototype.toString.call(parsed) === '[object Array]') return parsed;
            } catch (ignore) { /* Fall back to the legacy line format below. */ }
        }
        return parseLegacy(value);
    }

    function initEditor(editor) {
        if (editor.__zsbAccountEditorReady) return;
        var list = editor.querySelector('[data-account-list]');
        var rawInput = editor.querySelector('[data-account-raw]');
        var addButton = editor.querySelector('[data-add-account]');
        var errorBox = editor.querySelector('[data-account-error]');
        if (!list || !rawInput || !addButton) return;

        try {
            var parsed = parseValue(rawInput.value);
            var accounts = [];
            for (var i = 0; i < parsed.length; i++) {
                var normalized = defaults();
                if (parsed[i] && typeof parsed[i] === 'object') {
                    for (var key in parsed[i]) {
                        if (Object.prototype.hasOwnProperty.call(parsed[i], key)) normalized[key] = parsed[i][key];
                    }
                }
                accounts.push(normalized);
            }

            function labelFor(name) {
                var attributeName = 'data-label-' + name;
                var value = editor.getAttribute(attributeName);
                if (value) return value;
                return name;
            }

            function store() {
                var lines = [];
                for (var accountIndex = 0; accountIndex < accounts.length; accountIndex++) {
                    var account = accounts[accountIndex];
                    var hasBankIdentifier = String(account.card_number || '').replace(/\s/g, '') !== ''
                        || String(account.account_number || '').replace(/\s/g, '') !== ''
                        || String(account.iban || '').replace(/\s/g, '') !== '';
                    if (!String(account.label || '').replace(/\s/g, '') || !hasBankIdentifier) continue;
                    var columns = ['label', 'bank', 'holder', 'card_number', 'iban', 'instructions', 'account_number'];
                    var values = [];
                    for (var columnIndex = 0; columnIndex < columns.length; columnIndex++) {
                        var text = String(account[columns[columnIndex]] || '').replace(/[|\r\n]/g, ' ').replace(/^\s+|\s+$/g, '');
                        values.push(text);
                    }
                    lines.push(values.join(' | '));
                }
                rawInput.value = lines.join('\n');
                if (errorBox) {
                    var allValid = true;
                    for (var validateIndex = 0; validateIndex < accounts.length; validateIndex++) {
                        var candidate = accounts[validateIndex];
                        if (!String(candidate.label || '').replace(/\s/g, '') || !String(candidate.holder || '').replace(/\s/g, '') || !String(candidate.card_number || '').replace(/\s/g, '')) {
                            allValid = false;
                            break;
                        }
                    }
                    if (allValid) {
                        errorBox.innerHTML = '';
                        errorBox.setAttribute('hidden', 'hidden');
                    }
                }
            }

            function clearList() {
                while (list.firstChild) list.removeChild(list.firstChild);
            }

            function render() {
                clearList();
                if (!accounts.length) {
                    var empty = document.createElement('p');
                    empty.className = 'zsb-account-editor-empty';
                    empty.textContent = editor.getAttribute('data-empty-label') || '';
                    list.appendChild(empty);
                }

                for (var accountIndex = 0; accountIndex < accounts.length; accountIndex++) {
                    (function (index) {
                        var account = accounts[index];
                        var card = document.createElement('section');
                        card.className = 'zsb-account-editor-card';

                        var heading = document.createElement('div');
                        heading.className = 'zsb-account-editor-heading';
                        var title = document.createElement('strong');
                        title.textContent = labelFor('label') + ' ' + (index + 1);
                        var remove = document.createElement('button');
                        remove.type = 'button';
                        remove.className = 'button-link-delete zsb-account-remove';
                        remove.textContent = editor.getAttribute('data-remove-label') || '';
                        remove.addEventListener('click', function (event) {
                            event.preventDefault();
                            accounts.splice(index, 1);
                            store();
                            render();
                        });
                        heading.appendChild(title);
                        heading.appendChild(remove);
                        card.appendChild(heading);

                        var grid = document.createElement('div');
                        grid.className = 'zsb-account-editor-grid';
                        for (var fieldIndex = 0; fieldIndex < fields.length; fieldIndex++) {
                            (function (name) {
                                var wrapper = document.createElement('label');
                                wrapper.className = 'zsb-account-editor-field zsb-account-field-' + name;
                                var caption = document.createElement('span');
                                caption.textContent = labelFor(name);
                                var control = name === 'instructions' ? document.createElement('textarea') : document.createElement('input');
                                if (name !== 'instructions') control.type = 'text';
                                control.autocomplete = 'off';
                                control.value = String(account[name] || '');
                                control.setAttribute('data-field', name);
                                control.placeholder = name === 'card_number' ? (editor.getAttribute('data-card-placeholder') || '') : '';
                                if (name === 'card_number' || name === 'account_number' || name === 'iban') control.dir = 'ltr';
                                else control.dir = 'auto';
                                control.addEventListener('input', function () {
                                    account[name] = control.value;
                                    store();
                                });
                                wrapper.appendChild(caption);
                                wrapper.appendChild(control);
                                grid.appendChild(wrapper);
                            })(fields[fieldIndex]);
                        }
                        card.appendChild(grid);
                        list.appendChild(card);
                    })(accountIndex);
                }
            }

            addButton.addEventListener('click', function (event) {
                event.preventDefault();
                accounts.push(defaults());
                store();
                render();
                var cards = list.querySelectorAll('.zsb-account-editor-card');
                if (cards.length) {
                    var inputs = cards[cards.length - 1].querySelectorAll('input');
                    if (inputs.length && inputs[0].focus) inputs[0].focus();
                }
            });

            var form = findAncestor(editor, 'zarin-form');
            if (form) {
                form.addEventListener('submit', function (event) {
                    store();
                    var activePane = findAncestor(editor, 'zarin-tab-pane');
                    if (!activePane || !hasClass(activePane, 'is-active')) return;
                    var invalidIndex = -1;
                    for (var checkIndex = 0; checkIndex < accounts.length; checkIndex++) {
                        var item = accounts[checkIndex];
                        if (!String(item.label || '').replace(/\s/g, '') || !String(item.holder || '').replace(/\s/g, '') || !String(item.card_number || '').replace(/\s/g, '')) {
                            invalidIndex = checkIndex;
                            break;
                        }
                    }
                    if (invalidIndex < 0) return;
                    event.preventDefault();
                    if (errorBox) {
                        errorBox.textContent = editor.getAttribute('data-required-message') || '';
                        errorBox.removeAttribute('hidden');
                    }
                    var cards = list.querySelectorAll('.zsb-account-editor-card');
                    var account = accounts[invalidIndex];
                    var fieldName = !String(account.label || '').replace(/\s/g, '') ? 'label' : (!String(account.holder || '').replace(/\s/g, '') ? 'holder' : 'card_number');
                    if (cards[invalidIndex]) {
                        var invalidControl = cards[invalidIndex].querySelector('[data-field="' + fieldName + '"]');
                        if (invalidControl && invalidControl.focus) invalidControl.focus();
                    }
                });
            }

            render();
            store();
            editor.__zsbAccountEditorReady = true;
            addClass(editor, 'has-js');
        } catch (error) {
            // Keep the visible legacy textarea available if the browser cannot initialize the enhanced editor.
            if (window.console && window.console.error) window.console.error('ZarinShopBot account editor initialization failed.', error);
            removeClass(editor, 'has-js');
        }
    }

    function boot() {
        var editors = document.querySelectorAll('[data-account-editor]');
        for (var i = 0; i < editors.length; i++) initEditor(editors[i]);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
