(function () {
    'use strict';
    const cfg = window.zsbCheckoutOtp;
    if (!cfg) return;
    const phone = () => document.querySelector('#billing_phone');
    const status = () => document.querySelector('#zsb-checkout-otp-status');
    let verifiedValue = '';
    const post = async (action, extra = {}) => {
        const form = new FormData();
        form.append('action', action);
        form.append('nonce', cfg.nonce || '');
        form.append('phone', phone()?.value?.trim() || '');
        Object.entries(extra).forEach(([key, value]) => form.append(key, String(value ?? '')));
        const response = await fetch(cfg.ajaxUrl, { method: 'POST', body: form, credentials: 'same-origin' });
        const result = await response.json();
        if (!result?.success) throw new Error(result?.data?.message || cfg.i18n.failed);
        return result.data || {};
    };
    document.addEventListener('input', (event) => {
        if (event.target?.id === 'billing_phone') {
            verifiedValue = '';
            const note = status();
            if (note) note.textContent = '';
        }
    });
    document.addEventListener('click', async (event) => {
        const button = event.target.closest('#zsb-checkout-otp-send, #zsb-checkout-otp-verify');
        if (!button) return;
        event.preventDefault();
        const note = status();
        const isVerify = button.id === 'zsb-checkout-otp-verify';
        button.disabled = true;
        try {
            if (isVerify) {
                const code = document.querySelector('#zsb-checkout-otp-code')?.value?.trim() || '';
                if (!/^\d{6}$/.test(code)) throw new Error(cfg.i18n.failed);
                await post('zsb_checkout_otp_verify', { code });
                verifiedValue = phone()?.value?.trim() || '';
                if (note) note.textContent = cfg.i18n.verified;
            } else {
                await post('zsb_checkout_otp_send');
                if (note) note.textContent = cfg.i18n.sent;
            }
        } catch (error) {
            if (note) note.textContent = error.message || cfg.i18n.failed;
        } finally { button.disabled = false; }
    });
    document.addEventListener('submit', (event) => {
        if (event.target?.classList?.contains('checkout') && verifiedValue !== (phone()?.value?.trim() || '')) {
            event.preventDefault();
            window.alert(cfg.i18n.failed);
        }
    }, true);
})();
