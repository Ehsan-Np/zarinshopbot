Local icon subset from lucide-static 1.61.0 (ISC License). All UI masks are bundled in assets/icons/ui/. No icon font, CDN, or remote icon request is used by the plugin UI.
