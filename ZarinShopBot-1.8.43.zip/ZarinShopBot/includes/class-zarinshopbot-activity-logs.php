<?php
/** Privacy-aware log normalization for the ZarinShopBot admin dashboard. */
if (!defined('ABSPATH')) { exit; }

final class ZarinShopBot_Activity_Logs {
    private const SOURCES = array('telegram', 'bale', 'rubika', 'system');

    /** Return normalized, newest-first records and counts for a source filter. */
    public static function query($source = 'all') {
        $source = in_array($source, array_merge(array('all'), self::SOURCES), true) ? $source : 'all';
        $entries = array();

        // The legacy log store is Telegram-only. Keep its history visible while
        // structured activity from all current channels is collected below.
        $legacy = get_option('wp_zarincode_log', array());
        if (is_string($legacy)) {
            $decoded = json_decode($legacy, true);
            $legacy = is_array($decoded) ? $decoded : array();
        }
        if (is_array($legacy)) {
            foreach ($legacy as $row) {
                if (!is_array($row)) { continue; }
                $event = $row['event'] ?? $row[0] ?? 'legacy_event';
                $time = $row['time'] ?? $row[1] ?? '';
                $chat = $row['chat_id'] ?? $row[2] ?? '';
                $description = $row['description'] ?? $row[3] ?? '';
                // Older free-form records may contain message text. Preserve
                // structured error details where safe, but never echo raw chat
                // content into the admin activity table.
                if (is_string($description)) {
                    $legacy_context = json_decode($description, true);
                    if (is_array($legacy_context)) {
                        $description = wp_json_encode(function_exists('zarincode_redact') ? zarincode_redact($legacy_context) : $legacy_context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    } elseif (preg_match('/request|message|update/i', (string) $event) && trim($description) !== '') {
                        $description = __('Legacy message details hidden for privacy.', 'zarinshopbot');
                    }
                }
                $timestamp = isset($row['timestamp']) ? absint($row['timestamp']) : (is_numeric($time) ? (int) $time : (strtotime((string) $time) ?: 0));
                $entries[] = self::normalize(array(
                    'platform' => 'telegram', 'event' => $event, 'time' => $time,
                    'timestamp' => $timestamp, 'chat_id' => $chat, 'description' => $description,
                ));
            }
        }

        $structured = get_option('wp_zarincode_activity_log', array());
        if (!is_array($structured) || !$structured) {
            $structured = get_option('wp_zarincode_structured_logs', array());
        }
        if (is_array($structured)) {
            foreach ($structured as $row) {
                if (!is_array($row)) { continue; }
                $context = isset($row['context']) && is_array($row['context']) ? $row['context'] : array();
                $event = sanitize_key((string) ($row['event'] ?? 'event'));
                $platform = self::source_from_context($context, $event);
                $description = $context ? wp_json_encode(function_exists('zarincode_redact') ? zarincode_redact($context) : $context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
                $timestamp = isset($row['timestamp']) ? absint($row['timestamp']) : (isset($row['time']) ? (strtotime((string) $row['time']) ?: 0) : 0);
                $entries[] = self::normalize(array(
                    'platform' => $platform, 'event' => $event,
                    'time' => $row['time'] ?? '', 'timestamp' => $timestamp,
                    'chat_id' => $row['chat_id'] ?? '', 'description' => $description,
                ));
            }
        }

        usort($entries, static function($a, $b) { return (int) $b['timestamp'] <=> (int) $a['timestamp']; });
        $counts = array('all' => count($entries), 'telegram' => 0, 'bale' => 0, 'rubika' => 0, 'system' => 0);
        foreach ($entries as $entry) {
            if (isset($counts[$entry['platform']])) { ++$counts[$entry['platform']]; }
        }
        $visible = $source === 'all' ? $entries : array_values(array_filter($entries, static function($entry) use ($source) { return $entry['platform'] === $source; }));
        return array('entries' => $visible, 'counts' => $counts, 'source' => $source);
    }

    private static function source_from_context(array $context, $event) {
        $candidate = sanitize_key((string) ($context['platform'] ?? ''));
        if (in_array($candidate, self::SOURCES, true)) { return $candidate; }
        foreach (array('telegram', 'bale', 'rubika') as $platform) {
            if (strpos($event, $platform . '_') === 0) { return $platform; }
        }
        return 'system';
    }

    private static function normalize(array $row) {
        $platform = sanitize_key((string) ($row['platform'] ?? 'system'));
        if (!in_array($platform, self::SOURCES, true)) { $platform = 'system'; }
        $description = $row['description'] ?? '';
        if (is_array($description)) { $description = wp_json_encode($description, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }
        if (function_exists('zarincode_redact')) { $description = zarincode_redact((string) $description, 'description'); }
        $time = (string) ($row['time'] ?? '');
        if ($time === '' && !empty($row['timestamp'])) { $time = function_exists('wp_date') ? wp_date('Y-m-d H:i:s', (int) $row['timestamp']) : date('Y-m-d H:i:s', (int) $row['timestamp']); }
        return array(
            'platform' => $platform,
            'event' => sanitize_key((string) ($row['event'] ?? 'event')),
            'time' => $time,
            'timestamp' => (int) ($row['timestamp'] ?? 0),
            'chat_id' => sanitize_text_field((string) ($row['chat_id'] ?? '')),
            'description' => is_string($description) ? $description : '',
        );
    }
}
