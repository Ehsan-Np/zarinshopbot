<?php
namespace ZarinShopBot\Platforms;

if (!defined('ABSPATH') && php_sapi_name() !== 'cli') {
    exit;
}

/** Minimal WordPress HTTP transport shared by channel-specific API clients. */
final class JsonHttpTransport {
    /**
     * Send one POST request and return the decoded envelope without assigning
     * provider-specific meaning to its fields.
     *
     * @return array|\WP_Error
     */
    public static function post($url, array $params, $timeout = 15) {
        $request_args = array(
            'timeout'     => max(3, min(25, absint($timeout))),
            'redirection' => 0,
            'sslverify'   => true,
            'headers'     => array('Accept' => 'application/json'),
            'data_format' => 'body',
        );

        // An empty argument list means a POST with no body. Do not serialize it
        // as JSON []: some providers distinguish it from a bodyless request.
        if ($params !== array()) {
            $encoded = wp_json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (!is_string($encoded)) {
                return new \WP_Error('zsb_api_encode', __('ساخت درخواست پیام‌رسان ناموفق بود.', 'zarinshopbot'));
            }
            $request_args['headers']['Content-Type'] = 'application/json; charset=utf-8';
            $request_args['body'] = $encoded;
        }

        $response = wp_remote_post($url, $request_args);
        if (is_wp_error($response)) {
            return $response;
        }

        $raw = (string) wp_remote_retrieve_body($response);
        $data = json_decode($raw, true);
        $json_error = json_last_error();

        return array(
            'http_status' => (int) wp_remote_retrieve_response_code($response),
            'raw_body'    => $raw,
            'data'        => $data,
            'json_error'  => $json_error,
            'json_valid'  => is_array($data) && $json_error === JSON_ERROR_NONE,
        );
    }
}
