<?php
namespace ZarinShopBot\Platforms\Bale;

use ZarinShopBot\Platforms\JsonHttpTransport;

if (!defined('ABSPATH') && php_sapi_name() !== 'cli') {
    exit;
}

/** Bale Bot API client. Bale's endpoint and response envelope stay local here. */
final class ApiClient {
    private $token;

    public function __construct($token) {
        $this->token = trim((string) $token);
    }

    /** @return array|\WP_Error */
    public function request($method, array $params = array(), $timeout = 15) {
        $method = (string) $method;
        if ($this->token === '' || !preg_match('/\A[A-Za-z][A-Za-z0-9]*\z/', $method)) {
            $this->log('channel_api_config_error', $method, array());
            return new \WP_Error('zsb_api_config', __('پیکربندی API کامل نیست.', 'zarinshopbot'));
        }

        $started = microtime(true);
        $url = 'https://tapi.bale.ai/bot' . rawurlencode($this->token) . '/' . $method;
        $response = JsonHttpTransport::post($url, $params, $timeout);
        if (is_wp_error($response)) {
            $code = sanitize_key($response->get_error_code());
            $this->log('channel_api_transport_error', $method, array(
                'duration_ms' => $this->duration($started),
                'error_code'  => $code,
            ));
            if ($response->get_error_code() === 'zsb_api_encode') {
                return $response;
            }
            return new \WP_Error(
                'zsb_api_transport',
                __('ارتباط HTTPS با سرویس پیام‌رسان برقرار نشد؛ DNS، TLS، فایروال خروجی و دسترسی میزبان را بررسی کنید.', 'zarinshopbot'),
                array('cause_code' => $code)
            );
        }

        $status = $response['http_status'];
        $data = $response['data'];
        if ($status < 200 || $status >= 300 || !$response['json_valid']) {
            $this->log('channel_api_response_error', $method, array(
                'http_status' => $status,
                'json_error'  => $response['json_error'],
                'duration_ms' => $this->duration($started),
            ));
            return new \WP_Error(
                'zsb_api_response',
                __('پاسخ HTTP یا JSON پیام‌رسان معتبر نبود.', 'zarinshopbot'),
                array('http_status' => $status, 'json_error' => $response['json_error'])
            );
        }

        if (!isset($data['ok']) || $data['ok'] !== true) {
            $provider_code = sanitize_key((string) ($data['error_code'] ?? ''));
            $this->log('channel_api_rejected', $method, array(
                'http_status'  => $status,
                'provider_code'=> $provider_code,
                'duration_ms'  => $this->duration($started),
            ));
            $error = isset($data['description'])
                ? sanitize_text_field($data['description'])
                : __('درخواست API ناموفق بود.', 'zarinshopbot');
            return new \WP_Error('zsb_api_rejected', $error, array(
                'http_status'  => $status,
                'provider_code'=> $provider_code,
            ));
        }

        $this->log('channel_api_success', $method, array(
            'http_status' => $status,
            'duration_ms' => $this->duration($started),
        ));
        return $data;
    }

    private function duration($started) {
        return (int) round((microtime(true) - $started) * 1000);
    }

    private function log($event, $method, array $context) {
        if (!function_exists('zarincode_log_event')) {
            return;
        }
        zarincode_log_event($event, array_merge(array(
            'platform' => 'bale',
            'method'   => sanitize_key((string) $method),
        ), $context));
    }
}
