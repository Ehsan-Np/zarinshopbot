<?php
/**
 * ZarinShopBot multi-channel storefront bridge.
 *
 * Copyright (C) 2026 Ehsan NaderiPanah / Zarincode.com.
 * Derived-work notice and required upstream attribution are maintained in
 * LICENSE and THIRD_PARTY_NOTICES.md; legacy identifiers remain for compatibility.
 */
namespace ZarinShopBot;

if (!defined('ABSPATH')) { exit; }

require_once __DIR__ . '/platforms/class-json-http-transport.php';
require_once __DIR__ . '/platforms/class-bale-api-client.php';
require_once __DIR__ . '/platforms/class-rubika-api-client.php';

/** Backwards-compatible façade; platform transport and envelopes live in their adapters. */
final class Channel_API {
    private $platform;
    private $client;
    private $token;

    public function __construct($platform, $token) {
        $this->platform = in_array($platform, array('bale', 'rubika'), true) ? $platform : '';
        $token = trim((string) $token);
        $this->token = $token;
        if ($this->platform === 'bale') {
            $this->client = new \ZarinShopBot\Platforms\Bale\ApiClient($token);
        } elseif ($this->platform === 'rubika') {
            $this->client = new \ZarinShopBot\Platforms\Rubika\ApiClient($token);
        } else {
            $this->client = null;
        }
    }

    /**
     * Send one request without automatic retry: a lost response may mean a
     * mutating provider call succeeded, so retrying can duplicate a message.
     *
     * @return array|\WP_Error
     */
    public function request($method, array $params = array(), $timeout = 15) {
        if (!$this->client || !is_string($method) || !preg_match('/\A[A-Za-z][A-Za-z0-9]*\z/', $method)) {
            if (function_exists('zarincode_log_event')) zarincode_log_event('channel_api_config_error', array(
                'platform' => $this->platform ?: 'unknown',
                'method' => is_string($method) ? sanitize_key($method) : 'invalid',
            ));
            return new \WP_Error('zsb_api_config', __('پیکربندی API کامل نیست.', 'zarinshopbot'));
        }
        return $this->client->request($method, $params, $timeout);
    }

    /** Execute the Telegram-compatible subset used by the inherited commerce engine. */
    public function telegram_call($method, array $params = array()) {
        $chat_id = isset($params['chat_id']) ? self::unprefix_id($params['chat_id']) : '';
        switch ($method) {
            case 'sendMessage':
                $body = array('chat_id' => $chat_id, 'text' => (string) ($params['text'] ?? ''));
                $rubika_markup = array();
                if ($this->platform === 'rubika' && !empty($params['reply_markup']) && is_array($params['reply_markup'])) {
                    list($rubika_markup, $rubika_link_text) = $this->rubika_link_buttons_to_metadata($params['reply_markup']);
                    if ($rubika_link_text) {
                        $link_markup = array_map(function($link) {
                            return '<a href="' . esc_attr($link['url']) . '">' . esc_html($link['label']) . '</a>';
                        }, $rubika_link_text);
                        $body['text'] .= ($body['text'] !== '' ? "\n\n" : '') . implode("\n", $link_markup);
                    }
                }
                if ($this->platform === 'bale') {
                    $body['text'] = self::bale_format_text($body['text']);
                }
                if ($this->platform === 'rubika') {
                    $formatted = self::rubika_format_text($body['text']);
                    $body['text'] = $formatted['text'];
                    if (!empty($formatted['metadata'])) { $body['metadata'] = array('meta_data_parts' => $formatted['metadata']); }
                }
                if ($this->platform === 'rubika') {
                    if (!empty($rubika_markup)) { $body = array_merge($body, $this->translate_markup($rubika_markup)); }
                } elseif (!empty($params['reply_markup'])) {
                    $body = array_merge($body, $this->translate_markup($params['reply_markup']));
                }
                if (!empty($params['reply_to_message_id'])) { $body['reply_to_message_id'] = (string) $params['reply_to_message_id']; }
                if ($this->platform === 'rubika') {
                    return $this->rubika_send_message($body, $chat_id);
                }
                return $this->canonical($this->request('sendMessage', $body), $chat_id);
            case 'sendPhoto':
                if ($this->platform === 'bale') {
                    $body = array('chat_id' => $chat_id, 'photo' => $params['photo'] ?? '', 'caption' => self::bale_format_text($params['caption'] ?? ''));
                    if (!empty($params['reply_markup'])) { $body = array_merge($body, $this->translate_markup($params['reply_markup'])); }
                    return $this->canonical($this->request('sendPhoto', $body), $chat_id);
                }
                return $this->send_rubika_photo($chat_id, $params['photo'] ?? '', $params['caption'] ?? '', $params['reply_markup'] ?? array());
            case 'sendMediaGroup':
                $media_items = isset($params['media']) && is_array($params['media']) ? array_values($params['media']) : array();
                if (count($media_items) < 2 || count($media_items) > 10) {
                    return new \WP_Error('zsb_media_group_invalid', __('آلبوم باید بین ۲ تا ۱۰ فایل داشته باشد.', 'zarinshopbot'));
                }
                if ($this->platform === 'bale') {
                    foreach ($media_items as $media_item) {
                        if (!is_array($media_item) || !in_array($media_item['type'] ?? '', array('photo', 'video', 'document', 'audio'), true) || empty($media_item['media'])) {
                            return new \WP_Error('zsb_media_group_invalid', __('ساختار یکی از فایل‌های آلبوم معتبر نیست.', 'zarinshopbot'));
                        }
                    }
                    foreach ($media_items as &$media_item) {
                        if (isset($media_item['caption'])) $media_item['caption'] = self::bale_format_text($media_item['caption']);
                        unset($media_item['parse_mode']);
                    }
                    unset($media_item);
                    $body = array('chat_id' => $chat_id, 'media' => $media_items);
                    foreach (array('disable_notification', 'protect_content', 'reply_to_message_id') as $key) {
                        if (array_key_exists($key, $params)) $body[$key] = $params[$key];
                    }
                    return $this->canonical($this->request('sendMediaGroup', $body), $chat_id);
                }
                // Rubika's published API does not document sendMediaGroup. Preserve
                // photo-only galleries as individual documented sendPhoto calls;
                // validate the entire batch before sending to avoid partial albums.
                foreach ($media_items as $media_item) {
                    if (!is_array($media_item) || ($media_item['type'] ?? '') !== 'photo' || empty($media_item['media'])) {
                        return new \WP_Error('zsb_method_unsupported', __('آلبوم چندرسانه‌ای روبیکا در API عمومی مستند نشده؛ فقط ارسال جداگانهٔ تصاویر پشتیبانی می‌شود.', 'zarinshopbot'));
                    }
                }
                $last = null;
                foreach ($media_items as $media_item) {
                    $last = $this->telegram_call('sendPhoto', array(
                        'chat_id' => $chat_id, 'photo' => $media_item['media'], 'caption' => $media_item['caption'] ?? '',
                    ));
                    if (is_wp_error($last)) { return $last; }
                }
                return $last ?: array('ok' => true, 'result' => array());
            case 'sendVideo':
            case 'sendAudio':
            case 'sendDocument':
            case 'sendAnimation':
            case 'sendVoice':
                if ($this->platform !== 'bale') {
                    return new \WP_Error('zsb_method_unsupported', sprintf(__('ارسال %s در API عمومی این پیام‌رسان مستند نشده است.', 'zarinshopbot'), sanitize_key($method)));
                }
                $field = array('sendVideo' => 'video', 'sendAudio' => 'audio', 'sendDocument' => 'document', 'sendAnimation' => 'animation', 'sendVoice' => 'voice')[$method];
                if (empty($params[$field]) || !is_scalar($params[$field])) {
                    return new \WP_Error('zsb_media_missing', __('شناسه یا نشانی فایل برای ارسال رسانه وارد نشده است.', 'zarinshopbot'));
                }
                $body = array('chat_id' => $chat_id, $field => $params[$field]);
                if (isset($params['caption'])) $body['caption'] = $this->platform === 'bale' ? self::bale_format_text($params['caption']) : self::plain_text($params['caption']);
                foreach (array('duration', 'width', 'height', 'supports_streaming', 'performer', 'title', 'reply_to_message_id') as $key) {
                    if (array_key_exists($key, $params)) $body[$key] = $params[$key];
                }
                if (!empty($params['reply_markup'])) $body = array_merge($body, $this->translate_markup($params['reply_markup']));
                return $this->canonical($this->request($method, $body), $chat_id);
            case 'editMessageText':
                $body = array('chat_id' => $chat_id, 'message_id' => $params['message_id'] ?? '', 'text' => (string) ($params['text'] ?? ''));
                if ($this->platform === 'bale') {
                    $body['text'] = self::bale_format_text($body['text']);
                }
                if ($this->platform === 'rubika') {
                    $edit_markup = isset($params['reply_markup']) && is_array($params['reply_markup']) ? $params['reply_markup'] : array();
                    list($edit_markup, $edit_links) = $this->rubika_link_buttons_to_metadata($edit_markup);
                    if ($edit_links) {
                        $link_markup = array_map(function($link) {
                            return '<a href="' . esc_attr($link['url']) . '">' . esc_html($link['label']) . '</a>';
                        }, $edit_links);
                        $body['text'] .= ($body['text'] !== '' ? "\n\n" : '') . implode("\n", $link_markup);
                    }
                    $formatted = self::rubika_format_text($body['text']);
                    $body['text'] = $formatted['text'];
                    if (!empty($formatted['metadata'])) { $body['metadata'] = array('meta_data_parts' => $formatted['metadata']); }
                    $rubika_markup = !empty($edit_markup) ? $this->translate_markup($edit_markup) : array();
                    // Rubika edits text and inline keypad through separate documented methods.
                    $result = $this->request('editMessageText', $body);
                    if (is_wp_error($result)) {
                        // Replacing the page is safe only after an explicit provider rejection.
                        // A timeout or malformed/5xx response may mean the edit succeeded;
                        // sending a new message then would duplicate the customer's page.
                        if (!$this->is_explicit_provider_rejection($result)) { return $result; }
                        return $this->telegram_call('sendMessage', array('chat_id' => $chat_id, 'text' => $params['text'] ?? '', 'reply_markup' => $params['reply_markup'] ?? array()));
                    }
                    if (!empty($rubika_markup['inline_keypad'])) {
                        $keypad_result = $this->request('editMessageKeypad', array(
                            'chat_id' => $chat_id,
                            'message_id' => $params['message_id'] ?? '',
                            'inline_keypad' => $rubika_markup['inline_keypad'],
                        ));
                        // The text edit has already committed. Do not send a second
                        // page when only the keypad edit fails.
                        if (is_wp_error($keypad_result)) { return $keypad_result; }
                    }
                    return $this->canonical($result, $chat_id);
                }
                if (!empty($params['reply_markup'])) { $body = array_merge($body, $this->translate_markup($params['reply_markup'])); }
                return $this->canonical($this->request('editMessageText', $body), $chat_id);
            case 'deleteMessage':
                return $this->canonical($this->request('deleteMessage', array('chat_id' => $chat_id, 'message_id' => $params['message_id'] ?? '')), $chat_id);
            case 'answerCallbackQuery':
                if ($this->platform === 'bale') {
                    $callback_id = isset($params['callback_query_id']) && is_scalar($params['callback_query_id'])
                        ? trim((string) $params['callback_query_id']) : '';
                    if ($callback_id === '') {
                        return new \WP_Error('zsb_callback_id_missing', __('شناسهٔ callback بله خالی است.', 'zarinshopbot'));
                    }
                    // Bale documents callback IDs beginning with "1" as coming
                    // from clients that do not support answerCallbackQuery.
                    // The shared handler still sends the resulting bot message.
                    if (strpos($callback_id, '1') === 0) {
                        return array('ok' => true, 'result' => true);
                    }
                    $body = array(
                        'callback_query_id' => $callback_id,
                        'text' => isset($params['text']) && is_scalar($params['text']) ? (string) $params['text'] : '',
                    );
                    if (array_key_exists('show_alert', $params)) {
                        $body['show_alert'] = (bool) $params['show_alert'];
                    }
                    $result = $this->request('answerCallbackQuery', $body);
                    return $this->canonical($result, $chat_id);
                }
                return array('ok' => true, 'result' => true); // Rubika button replies arrive as regular updates.
            case 'getMe':
                return $this->canonical($this->request('getMe'), $chat_id);
            case 'getChatMember':
                if ($this->platform === 'rubika') {
                    return new \WP_Error('zsb_method_unsupported', __('بررسی عضویت اعضا در Bot API عمومی روبیکا مستند نشده است.', 'zarinshopbot'));
                }
                $body = array('chat_id' => $chat_id, 'user_id' => self::unprefix_id($params['user_id'] ?? ''));
                return $this->canonical($this->request('getChatMember', $body), $chat_id);
            case 'setMyCommands':
                if ($this->platform === 'rubika') {
                    $commands = array();
                    foreach ((array) ($params['commands'] ?? array()) as $command) {
                        if (!is_array($command)) { continue; }
                        $name = strtolower((string) ($command['command'] ?? ''));
                        $description = sanitize_text_field($command['description'] ?? '');
                        if (preg_match('/\A[a-z][a-z0-9_]{0,31}\z/', $name) && $description !== '') {
                            $commands[] = array('command' => $name, 'description' => self::utf8_substr($description, 0, 256));
                        }
                    }
                    return $this->canonical($this->request('setCommands', array('bot_commands' => $commands)), '');
                }
                // Bale command-menu setup is managed in its BotFather UI; incoming commands still use the shared dispatcher.
                return array('ok' => true, 'result' => true);
            case 'setChatMenuButton':
                // Telegram's global chat-menu-button API has no equivalent contract on these adapters.
                return array('ok' => true, 'result' => true);
            case 'sendInvoice':
            case 'answerPreCheckoutQuery':
            case 'refundStarPayment':
                return new \WP_Error('zsb_native_payment_unsupported', __('پرداخت بومی تلگرام در این پیام‌رسان در دسترس نیست؛ از checkout ووکامرس استفاده کنید.', 'zarinshopbot'));
            default:
                return new \WP_Error('zsb_method_unsupported', sprintf(__('متد %s در آداپتور این پیام‌رسان پشتیبانی نشده است.', 'zarinshopbot'), sanitize_key($method)));
        }
    }

    /**
     * Rubika rejects an entire message when any MetadataPart is invalid. If the
     * provider explicitly rejects a send as invalid_input, retry once without
     * metadata, then once with the documented minimal chat_id/text payload.
     * These retries happen only after an explicit rejection, never after a
     * timeout/5xx where delivery could have succeeded.
     */
    private function rubika_send_message(array $body, $chat_id) {
        $result = $this->request('sendMessage', $body);
        if (!$this->is_rubika_invalid_input($result)) {
            return $this->canonical($result, $chat_id);
        }
        $this->log_rubika_send_rejection('initial', $body, $result);

        if (isset($body['metadata'])) {
            $without_metadata = $body;
            unset($without_metadata['metadata']);
            // Preserve checkout destinations in the explicit invalid_input
            // fallback: Link metadata may be the rejected part of the payload.
            $fallback_urls = array();
            foreach ((array) ($body['metadata']['meta_data_parts'] ?? array()) as $part) {
                if (!is_array($part) || ($part['type'] ?? '') !== 'Link' || empty($part['link_url'])) { continue; }
                $url = esc_url_raw((string) $part['link_url'], array('https'));
                $parts = $url !== '' ? wp_parse_url($url) : false;
                if ($url !== '' && is_array($parts) && strtolower((string) ($parts['scheme'] ?? '')) === 'https'
                    && !empty($parts['host']) && !isset($parts['user']) && !isset($parts['pass'])) { $fallback_urls[] = $url; }
            }
            $fallback_urls = array_values(array_unique($fallback_urls));
            if ($fallback_urls) {
                $fallback_text = (string) ($without_metadata['text'] ?? '');
                foreach ($fallback_urls as $url) {
                    if (strpos($fallback_text, $url) === false) { $fallback_text .= ($fallback_text !== '' ? "\n\n" : '') . $url; }
                }
                $without_metadata['text'] = $fallback_text;
            }
            $result = $this->request('sendMessage', $without_metadata);
            if (!$this->is_rubika_invalid_input($result)) {
                if (!is_wp_error($result) && function_exists('zarincode_log_event')) {
                    zarincode_log_event('rubika_sendmessage_fallback', array('stage' => 'metadata_removed'));
                }
                return $this->canonical($result, $chat_id);
            }
            $this->log_rubika_send_rejection('metadata_removed', $without_metadata, $result);
            $body = $without_metadata;
        }

        $plain_body = array(
            'chat_id' => $body['chat_id'] ?? self::unprefix_id($chat_id),
            'text' => (string) ($body['text'] ?? ''),
        );
        if ($plain_body !== $body) {
            $result = $this->request('sendMessage', $plain_body);
            if ($this->is_rubika_invalid_input($result)) {
                $this->log_rubika_send_rejection('minimal_text', $plain_body, $result);
            } elseif (!is_wp_error($result) && function_exists('zarincode_log_event')) {
                zarincode_log_event('rubika_sendmessage_fallback', array('stage' => 'minimal_text'));
            }
        }
        return $this->canonical($result, $chat_id);
    }

    /** Log only structural facts needed to diagnose Rubika invalid_input; never log chat IDs or message text. */
    private function log_rubika_send_rejection($stage, array $body, $result) {
        if (!function_exists('zarincode_log_event')) { return; }
        $chat_id = $body['chat_id'] ?? null;
        $text = isset($body['text']) && is_scalar($body['text']) ? (string) $body['text'] : '';
        $metadata = isset($body['metadata']['meta_data_parts']) && is_array($body['metadata']['meta_data_parts'])
            ? $body['metadata']['meta_data_parts'] : array();
        $error_data = is_wp_error($result) ? $result->get_error_data('zsb_api_rejected') : null;
        zarincode_log_event('rubika_sendmessage_invalid_input', array(
            'stage' => sanitize_key((string) $stage),
            'payload_keys' => array_values(array_map('sanitize_key', array_keys($body))),
            'chat_id_type' => gettype($chat_id),
            'chat_id_length' => is_scalar($chat_id) ? strlen((string) $chat_id) : 0,
            'chat_id_ascii_alnum' => is_scalar($chat_id) && preg_match('/\A[A-Za-z0-9]+\z/', (string) $chat_id) === 1,
            'text_present' => array_key_exists('text', $body),
            'text_nonempty' => trim($text) !== '',
            'text_bytes' => strlen($text),
            'text_utf8_valid' => preg_match('//u', $text) === 1,
            'metadata_part_count' => count($metadata),
            'has_inline_keypad' => isset($body['inline_keypad']) && is_array($body['inline_keypad']),
            'provider_code' => sanitize_key((string) (is_array($error_data) ? ($error_data['provider_code'] ?? '') : '')),
            'content_type' => 'application/json; charset=utf-8',
        ));
    }

    private function is_rubika_invalid_input($result) {
        if (!is_wp_error($result) || $result->get_error_code() !== 'zsb_api_rejected') return false;
        $error_data = $result->get_error_data('zsb_api_rejected');
        return is_array($error_data) && sanitize_key((string) ($error_data['provider_code'] ?? '')) === 'invalid_input';
    }

    /** True only when a well-formed provider response explicitly rejected the operation. */
    private function is_explicit_provider_rejection($result) {
        return is_wp_error($result) && $result->get_error_code() === 'zsb_api_rejected';
    }

    /** Rubika's documented Button schema has no URL field; represent URL buttons as documented Link metadata instead. */
    private function rubika_link_buttons_to_metadata(array $markup) {
        $links = array();
        if (empty($markup['inline_keyboard']) || !is_array($markup['inline_keyboard'])) return array($markup, $links);
        $rows = array();
        foreach ($markup['inline_keyboard'] as $row) {
            $buttons = array();
            foreach ((array) $row as $button) {
                if (!is_array($button)) continue;
                $raw_url = $button['url'] ?? '';
                if (($raw_url === '' || $raw_url === null) && isset($button['web_app']) && is_array($button['web_app'])) {
                    $raw_url = $button['web_app']['url'] ?? '';
                }
                if (is_scalar($raw_url) && (string) $raw_url !== '') {
                    $url = esc_url_raw((string) $raw_url, array('https'));
                    $url_parts = $url !== '' ? wp_parse_url($url) : false;
                    if ($url !== '' && is_array($url_parts) && strtolower((string) ($url_parts['scheme'] ?? '')) === 'https'
                        && !empty($url_parts['host']) && !isset($url_parts['user']) && !isset($url_parts['pass'])) {
                        $label = sanitize_text_field((string) ($button['text'] ?? __('ادامه پرداخت', 'zarinshopbot')));
                        $links[] = array('label' => $label !== '' ? $label : __('ادامه پرداخت', 'zarinshopbot'), 'url' => $url);
                    } elseif (function_exists('zarincode_log_event')) {
                        zarincode_log_event('rubika_payment_link_rejected', array('reason' => 'https_url_required'));
                    }
                    // Never send the undocumented `url` Button property to Rubika.
                    continue;
                }
                $buttons[] = $button;
            }
            if ($buttons) $rows[] = $buttons;
        }
        if ($rows) $markup['inline_keyboard'] = $rows;
        else unset($markup['inline_keyboard']);
        return array($markup, $links);
    }

    private function translate_markup($markup) {
        if (!is_array($markup)) { return array(); }
        if (isset($markup['inline_keyboard']) && is_array($markup['inline_keyboard'])) {
            if ($this->platform === 'bale') {
                foreach ($markup['inline_keyboard'] as &$row) {
                    foreach ($row as &$button) {
                        if (isset($button['web_app']['url'])) {
                            $button['web_app']['url'] = esc_url_raw($button['web_app']['url']);
                            $label = (string) ($button['text'] ?? __('فروشگاه', 'zarinshopbot'));
                            $button['text'] = self::utf8_substr($label, 0, 20);
                        }
                    }
                    unset($button);
                }
                unset($row);
                return array('reply_markup' => $markup);
            }
            $rows = array();
            foreach ($markup['inline_keyboard'] as $row) {
                $buttons = array();
                foreach ((array) $row as $button) {
                    $label = sanitize_text_field($button['text'] ?? __('انتخاب', 'zarinshopbot'));
                    if (isset($button['url']) || isset($button['web_app']['url'])) {
                        // URL buttons must be extracted into documented Link metadata
                        // before this point; Rubika's Button model does not document a URL field.
                        continue;
                    }
                    $buttons[] = array('id' => sanitize_text_field($button['callback_data'] ?? ''), 'type' => 'Simple', 'button_text' => $label);
                }
                if ($buttons) { $rows[] = array('buttons' => $buttons); }
            }
            return array('inline_keypad' => array('rows' => $rows));
        }
        if ($this->platform === 'bale') { return array('reply_markup' => $markup); }
        if (isset($markup['keyboard']) && is_array($markup['keyboard'])) {
            $rows = array();
            foreach ($markup['keyboard'] as $row) {
                $buttons = array();
                foreach ((array) $row as $button) {
                    $text = is_array($button) ? (string) ($button['text'] ?? '') : (string) $button;
                    if ($text !== '') { $buttons[] = array('id' => $text, 'type' => 'Simple', 'button_text' => $text); }
                }
                if ($buttons) { $rows[] = array('buttons' => $buttons); }
            }
            return array('chat_keypad' => array('rows' => $rows), 'chat_keypad_type' => 'New');
        }
        if (!empty($markup['remove_keyboard'])) { return array('chat_keypad_type' => 'Remove'); }
        return array();
    }

    /** Rubika uses provider-side file IDs, so upload public WooCommerce images through its documented file flow. */
    private function send_rubika_photo($chat_id, $photo, $caption, $markup) {
        $photo_started_at = microtime(true);
        $photo_url = esc_url_raw((string) $photo);
        $fallback = trim((string) $caption . "\n" . (string) $photo);
        if (!$photo_url || !in_array(strtolower((string) wp_parse_url($photo_url, PHP_URL_SCHEME)), array('https', 'http'), true)
            || (function_exists('wp_http_validate_url') && !wp_http_validate_url($photo_url))) {
            return $this->telegram_call('sendMessage', array('chat_id' => $chat_id, 'text' => $fallback, 'reply_markup' => $markup));
        }

        // Rubika accepts a previously uploaded file_id. Scope the cache to both
        // the image URL and this bot token so file IDs can never cross bots.
        $cache_key = 'zsb_rubika_photo_' . hash('sha256', $this->token . "\0" . $photo_url);
        $cached_file_id = get_transient($cache_key);
        if (is_string($cached_file_id) && $cached_file_id !== '' && strlen($cached_file_id) <= 512
            && !preg_match('/[\x00-\x1F\x7F]/', $cached_file_id)) {
            $cached_body = $this->rubika_photo_message_body($chat_id, $cached_file_id, $caption, $markup);
            $cached_result = $this->request('sendFile', $cached_body);
            if (!$this->is_rubika_invalid_input($cached_result)) {
                $canonical = $this->canonical($cached_result, self::unprefix_id($chat_id));
                if (!is_wp_error($canonical) && function_exists('zarincode_log_event')) {
                    zarincode_log_event('rubika_photo_pipeline_complete', array(
                        'duration_ms' => (int) round((microtime(true) - $photo_started_at) * 1000),
                        'file_cache_hit' => true,
                    ));
                }
                return $canonical;
            }
            // A provider rejection explicitly confirms this cached ID is no
            // longer accepted; a timeout is ambiguous and must not trigger a retry.
            delete_transient($cache_key);
            if (function_exists('zarincode_log_event')) zarincode_log_event('rubika_photo_cache_invalidated', array('reason' => 'provider_rejected_cached_file_id'));
        } elseif ($cached_file_id !== false) {
            delete_transient($cache_key);
        }

        // Cache miss: fetch and upload the public image once. Later product views
        // skip both network legs and use a single sendFile call.
        $image_response = wp_safe_remote_get($photo_url, array('timeout' => 20, 'redirection' => 3, 'limit_response_size' => 10 * MB_IN_BYTES));
        if (is_wp_error($image_response) || wp_remote_retrieve_response_code($image_response) < 200 || wp_remote_retrieve_response_code($image_response) >= 300) {
            return $this->telegram_call('sendMessage', array('chat_id' => $chat_id, 'text' => $fallback, 'reply_markup' => $markup));
        }
        $image_data = wp_remote_retrieve_body($image_response);
        $content_type_header = wp_remote_retrieve_header($image_response, 'content-type');
        if (is_array($content_type_header)) { $content_type_header = reset($content_type_header); }
        $content_type = is_scalar($content_type_header)
            ? strtolower(trim(explode(';', (string) $content_type_header)[0]))
            : '';
        $allowed_image_types = array('image/jpeg', 'image/png', 'image/gif', 'image/webp');
        if (!$image_data || strlen($image_data) > 10 * 1024 * 1024 || !in_array($content_type, $allowed_image_types, true)) {
            return $this->telegram_call('sendMessage', array('chat_id' => $chat_id, 'text' => $fallback, 'reply_markup' => $markup));
        }

        $upload_request = $this->request('requestSendFile', array('type' => 'Image'));
        if (is_wp_error($upload_request)) {
            return $this->telegram_call('sendMessage', array('chat_id' => $chat_id, 'text' => $fallback, 'reply_markup' => $markup));
        }
        $raw_upload_url = $upload_request['data']['upload_url'] ?? '';
        $upload_url = is_scalar($raw_upload_url) ? esc_url_raw((string) $raw_upload_url) : '';
        $upload_parts = $upload_url !== '' ? wp_parse_url($upload_url) : false;
        if (!$upload_url || strtolower((string) wp_parse_url($upload_url, PHP_URL_SCHEME)) !== 'https'
            || !is_array($upload_parts) || empty($upload_parts['host']) || (isset($upload_parts['user']) || isset($upload_parts['pass']))) {
            return $this->telegram_call('sendMessage', array('chat_id' => $chat_id, 'text' => $fallback, 'reply_markup' => $markup));
        }
        // Rubika's upload_url expects a multipart/form-data field named "file".
        $mime = $content_type ?: 'application/octet-stream';
        $extension = 'jpg';
        if (strpos($mime, 'image/png') === 0) { $extension = 'png'; }
        elseif (strpos($mime, 'image/gif') === 0) { $extension = 'gif'; }
        elseif (strpos($mime, 'image/webp') === 0) { $extension = 'webp'; }
        $filename = 'zarinshopbot-image.' . $extension;
        $boundary = 'zsb-' . wp_generate_password(24, false, false);
        $multipart = '--' . $boundary . "\r\n"
            . 'Content-Disposition: form-data; name="file"; filename="' . $filename . "\"\r\n"
            . 'Content-Type: ' . $mime . "\r\n\r\n"
            . $image_data . "\r\n--" . $boundary . "--\r\n";
        if (function_exists('wp_http_validate_url') && !wp_http_validate_url($upload_url)) {
            return $this->telegram_call('sendMessage', array('chat_id' => $chat_id, 'text' => $fallback, 'reply_markup' => $markup));
        }
        $uploaded = wp_safe_remote_post($upload_url, array(
            'timeout' => 30,
            'redirection' => 0,
            'sslverify' => true,
            'headers' => array('Content-Type' => 'multipart/form-data; boundary=' . $boundary),
            'body' => $multipart,
            'data_format' => 'body',
        ));
        if (is_wp_error($uploaded) || wp_remote_retrieve_response_code($uploaded) < 200 || wp_remote_retrieve_response_code($uploaded) >= 300) {
            return $this->telegram_call('sendMessage', array('chat_id' => $chat_id, 'text' => $fallback, 'reply_markup' => $markup));
        }
        $upload_data = json_decode(wp_remote_retrieve_body($uploaded), true);
        $raw_file_id = is_array($upload_data) ? ($upload_data['data']['file_id'] ?? $upload_data['file_id'] ?? '') : '';
        $file_id = is_scalar($raw_file_id) ? trim((string) $raw_file_id) : '';
        if ($file_id === '' || strlen($file_id) > 512 || preg_match('/[\x00-\x1F\x7F]/', $file_id)) {
            return $this->telegram_call('sendMessage', array('chat_id' => $chat_id, 'text' => $fallback, 'reply_markup' => $markup));
        }

        $body = $this->rubika_photo_message_body($chat_id, $file_id, $caption, $markup);
        $result = $this->request('sendFile', $body);
        $canonical = $this->canonical($result, self::unprefix_id($chat_id));
        if (!is_wp_error($canonical)) {
            set_transient($cache_key, $file_id, 30 * DAY_IN_SECONDS);
            if (function_exists('zarincode_log_event')) {
                zarincode_log_event('rubika_photo_pipeline_complete', array(
                    'duration_ms' => (int) round((microtime(true) - $photo_started_at) * 1000),
                    'file_cache_hit' => false,
                ));
            }
        }
        return $canonical;
    }

    /** Build Rubika's documented sendFile payload from a cached or freshly uploaded file_id. */
    private function rubika_photo_message_body($chat_id, $file_id, $caption, $markup) {
        $rubika_markup = is_array($markup) ? $markup : array();
        list($rubika_markup, $caption_links) = $this->rubika_link_buttons_to_metadata($rubika_markup);
        if ($caption_links) {
            $visible_links = array_map(function($link) { return $link['label'] . ': ' . $link['url']; }, $caption_links);
            $caption = trim((string) $caption . "\n\n" . implode("\n", $visible_links));
        }
        $formatted_caption = self::rubika_format_text($caption);
        $body = array('chat_id' => self::unprefix_id($chat_id), 'file_id' => $file_id, 'text' => $formatted_caption['text']);
        if ($rubika_markup) { $body = array_merge($body, $this->translate_markup($rubika_markup)); }
        return $body;
    }

    private function canonical($response, $chat_id) {
        if (is_wp_error($response)) { return $response; }
        $ok = $this->platform === 'bale' ? !empty($response['ok']) : (!isset($response['status']) || strtoupper((string) $response['status']) === 'OK');
        if (!$ok) { return new \WP_Error('zsb_api_error', sanitize_text_field($response['description'] ?? $response['dev_message'] ?? 'API error')); }
        $result = $this->platform === 'bale' ? ($response['result'] ?? array()) : ($response['data'] ?? array());
        if (isset($result['bot'])) { $result = $result['bot']; }
        if (!is_array($result)) { $result = array(); }
        if (!isset($result['message_id']) && isset($result['message']['message_id'])) { $result['message_id'] = $result['message']['message_id']; }
        if (!isset($result['chat']) && $chat_id !== '') { $result['chat'] = array('id' => $chat_id, 'type' => 'private'); }
        return array('ok' => true, 'result' => $result);
    }

    private static function unprefix_id($value) {
        $value = (string) $value;
        foreach (array('bale_', 'rubika_') as $prefix) {
            if (strpos($value, $prefix) === 0) { return substr($value, strlen($prefix)); }
        }
        return $value;
    }

    public function send($chat_id, $text, array $actions = array()) {
        // Direct channel callbacks bypass the inherited WooBot formatter; append
        // the same administrator-configurable sign here, once, at send time.
        $signature = function_exists('zarincode_option') ? trim((string) zarincode_option('botsign')) : '';
        $text = (string) $text;
        if ($signature !== '' && substr(rtrim($text), -strlen($signature)) !== $signature) {
            $clean_text = rtrim($text);
            $text = $clean_text === '' ? $signature : $clean_text . "\n\n" . $signature;
        }
        $params = array('chat_id' => (string) $chat_id, 'text' => $text);
        if ($actions) {
            $rows = array();
            foreach (array_chunk($actions, 2) as $chunk) {
                $row = array();
                foreach ($chunk as $action) {
                    $row[] = array('text' => (string) $action[0], 'callback_data' => (string) $action[1]);
                }
                $rows[] = $row;
            }
            // Use the shared markup format; telegram_call translates it to each provider.
            $params['reply_markup'] = array('inline_keyboard' => $rows);
        }
        return $this->telegram_call('sendMessage', $params);
    }

    /** Translate the shared HTML subset to Bale's documented Markdown syntax. */
    private static function bale_format_text($html) {
        $html = str_replace(array("\r\n", "\r"), "\n", (string) $html);
        $tokens = preg_split('/(<\\/?[a-z][^>]*>|<br\\s*\\/?>)/i', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        $text = '';
        $stack = array();
        foreach ((array) $tokens as $token) {
            if (preg_match('/^<br\\s*\\/?>$/i', $token)) { $text .= "\n"; continue; }
            if (preg_match('/^<\\/?([a-z][a-z0-9]*)\\b([^>]*)>$/i', $token, $match)) {
                $tag = strtolower($match[1]);
                $closing = isset($token[1]) && $token[1] === '/';
                if (in_array($tag, array('p', 'div', 'li', 'blockquote'), true)) {
                    if ($closing && $text !== '' && substr($text, -1) !== "\n") $text .= "\n";
                    continue;
                }
                if (!in_array($tag, array('b', 'strong', 'i', 'em', 'u', 'ins', 's', 'strike', 'del', 'a'), true)) continue;
                if ($tag === 'a') {
                    if (!$closing && preg_match('/\\bhref\\s*=\\s*(["\\\'])(.*?)\\1/i', $match[2], $href)) {
                        $url = esc_url_raw(html_entity_decode($href[2], ENT_QUOTES | ENT_HTML5, 'UTF-8'));
                        $stack[] = array('tag' => $tag, 'close' => $url !== '' ? '](' . $url . ')' : '');
                        $text .= '[';
                    } elseif ($closing) {
                        for ($i = count($stack) - 1; $i >= 0; --$i) {
                            if ($stack[$i]['tag'] === $tag) { $item = $stack[$i]; array_splice($stack, $i, 1); $text .= $item['close']; break; }
                        }
                    }
                    continue;
                }
                $marker = in_array($tag, array('b', 'strong'), true) ? '*' : (in_array($tag, array('i', 'em'), true) ? '_' : '');
                if ($marker === '') continue; // Bale's public text docs do not define underline/strike syntax.
                if (!$closing) { $stack[] = array('tag' => $tag, 'close' => $marker); $text .= $marker; }
                else {
                    for ($i = count($stack) - 1; $i >= 0; --$i) {
                        if ($stack[$i]['tag'] === $tag) { $item = $stack[$i]; array_splice($stack, $i, 1); $text .= $item['close']; break; }
                    }
                }
                continue;
            }
            // Decode character entities only after tokenizing. Escaped tags are
            // content, not markup; escape their angle brackets for Bale's Markdown.
            $plain = html_entity_decode($token, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $text .= str_replace(array('<', '>'), array('\\<', '\\>'), $plain);
        }
        return $text;
    }

    /** Convert the Telegram-compatible HTML subset to Rubika UTF-16 indexed metadata. */
    private static function rubika_format_text($html) {
        $html = str_replace(array("\r\n", "\r"), "\n", (string) $html);
        $tokens = preg_split('/(<\\/?[a-z][^>]*>|<br\\s*\\/?>)/i', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        $plain = '';
        $stack = array();
        $parts = array();
        $types = array('b' => 'Bold', 'strong' => 'Bold', 'i' => 'Italic', 'em' => 'Italic', 'u' => 'Underline', 'ins' => 'Underline', 's' => 'Strike', 'strike' => 'Strike', 'del' => 'Strike', 'code' => 'Mono', 'pre' => 'Pre', 'a' => 'Link');
        foreach ((array) $tokens as $token) {
            if (preg_match('/^<br\\s*\\/?>$/i', $token)) {
                if ($plain !== '' && substr($plain, -1) !== "\n") { $plain .= "\n"; }
                continue;
            }
            if (preg_match('/^<\\/?([a-z][a-z0-9]*)\\b([^>]*)>$/i', $token, $match)) {
                $tag = strtolower($match[1]);
                $closing = isset($token[1]) && $token[1] === '/';
                if (in_array($tag, array('p', 'div', 'li', 'blockquote'), true)) {
                    if ($closing && $plain !== '' && substr($plain, -1) !== "\n") { $plain .= "\n"; }
                    continue;
                }
                if (!isset($types[$tag])) { continue; }
                if ($closing) {
                    for ($i = count($stack) - 1; $i >= 0; --$i) {
                        if ($stack[$i]['tag'] !== $tag) { continue; }
                        $item = $stack[$i];
                        array_splice($stack, $i, 1);
                        $length = self::utf16_length($plain) - $item['start'];
                        if ($length > 0) {
                            $part = array('type' => $item['type'], 'from_index' => $item['start'], 'length' => $length);
                            if ($item['type'] === 'Link' && $item['url'] !== '') { $part['link_url'] = $item['url']; }
                            if ($item['type'] !== 'Link' || $item['url'] !== '') { $parts[] = $part; }
                        }
                        break;
                    }
                } else {
                    $url = '';
                    if ($tag === 'a' && preg_match('/\\bhref\\s*=\\s*(["\\\'])(.*?)\\1/i', $match[2], $href)) {
                        $url = esc_url_raw(html_entity_decode($href[2], ENT_QUOTES | ENT_HTML5, 'UTF-8'));
                    }
                    $stack[] = array('tag' => $tag, 'type' => $types[$tag], 'url' => $url, 'start' => self::utf16_length($plain));
                }
                continue;
            }
            $plain .= html_entity_decode($token, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        $plain = self::utf8_substr($plain, 0, 3900);
        $limit = self::utf16_length($plain);
        foreach ($parts as &$part) {
            if ($part['from_index'] >= $limit) { $part['length'] = 0; }
            elseif ($part['from_index'] + $part['length'] > $limit) { $part['length'] = $limit - $part['from_index']; }
        }
        unset($part);
        $parts = array_values(array_filter($parts, function($part) { return !empty($part['length']); }));
        // A checkout/merchant link is operationally important; retain Link parts
        // before optional formatting if a long message exceeds Rubika's 30-part cap.
        usort($parts, function($a, $b) {
            $a_link = ($a['type'] ?? '') === 'Link' ? 0 : 1;
            $b_link = ($b['type'] ?? '') === 'Link' ? 0 : 1;
            return ($a_link <=> $b_link) ?: ($a['from_index'] <=> $b['from_index']);
        });
        $parts = array_slice($parts, 0, 30);
        usort($parts, function($a, $b) { return $a['from_index'] <=> $b['from_index']; });
        return array('text' => $plain, 'metadata' => $parts);
    }

    public static function utf8_substr($text, $start, $length) {
        $text = (string) $text;
        $start = max(0, (int) $start);
        $length = max(0, (int) $length);
        if (function_exists('mb_substr')) return mb_substr($text, $start, $length, 'UTF-8');
        if (function_exists('iconv_substr')) {
            $slice = @iconv_substr($text, $start, $length, 'UTF-8');
            if ($slice !== false) return $slice;
        }
        if (preg_match_all('/./us', $text, $characters) !== false) {
            return implode('', array_slice($characters[0], $start, $length));
        }
        return substr($text, $start, $length);
    }

    private static function utf16_length($text) {
        $text = (string) $text;
        if (function_exists('mb_convert_encoding')) { return (int) (strlen(mb_convert_encoding($text, 'UTF-16LE', 'UTF-8')) / 2); }
        if (function_exists('iconv')) {
            $encoded = @iconv('UTF-8', 'UTF-16LE', $text);
            if ($encoded !== false) { return (int) (strlen($encoded) / 2); }
        }
        // Extension-free UTF-8 fallback that still counts supplementary emoji as
        // two UTF-16 code units, matching Rubika's metadata-index contract.
        if (preg_match_all('/./us', $text, $characters) !== false) {
            $units = 0;
            foreach ($characters[0] as $character) {
                $bytes = strlen($character);
                $first = ord($character[0]);
                if ($bytes === 4) {
                    $codepoint = (($first & 0x07) << 18) | ((ord($character[1]) & 0x3F) << 12) | ((ord($character[2]) & 0x3F) << 6) | (ord($character[3]) & 0x3F);
                } elseif ($bytes === 3) {
                    $codepoint = (($first & 0x0F) << 12) | ((ord($character[1]) & 0x3F) << 6) | (ord($character[2]) & 0x3F);
                } elseif ($bytes === 2) {
                    $codepoint = (($first & 0x1F) << 6) | (ord($character[1]) & 0x3F);
                } else {
                    $codepoint = $first;
                }
                $units += $codepoint > 0xFFFF ? 2 : 1;
            }
            return $units;
        }
        return strlen($text);
    }

    private static function plain_text($text) {
        $text = wp_strip_all_tags((string) $text, true);
        return self::utf8_substr($text, 0, 3900);
    }
}

/** Shared WooCommerce product/cart actions for Bale and Rubika webhooks. */
final class Channels {
    private static $active_event_claims = array();

    const OPTION = 'zarinshopbot_channels';
    const REGISTERED_ROUTES_OPTION = 'zarinshopbot_channel_registered_routes';

    public static function boot() {
        add_action('admin_menu', array(__CLASS__, 'admin_menu'), 70);
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('admin_post_zarinshopbot_register_channel_webhooks', array(__CLASS__, 'register_webhooks'));
        add_action('admin_post_zarinshopbot_test_channel_connection', array(__CLASS__, 'test_connection'));
        add_action('rest_api_init', array(__CLASS__, 'register_routes'));
        add_action('template_redirect', array(__CLASS__, 'consume_checkout_link'), 1);
        add_action('init', array(__CLASS__, 'migrate_plaintext_secrets'), 1);
    }

    public static function defaults() {
        return array(
            'bale_enabled' => '0', 'bale_token' => '', 'bale_username' => '', 'bale_admin_chat_id' => '', 'bale_secret' => '', 'bale_registered_fingerprint' => '', 'bale_status' => '',
            'bale_miniapp_enabled' => '0', 'bale_wallet_enabled' => '0', 'bale_provider_token' => '', 'bale_irr_per_store_unit' => '0', 'bale_post_chat_id' => '', 'bale_post_title' => 'محصول جدید: %product%', 'bale_notify_customer_new_order' => '1', 'bale_notify_admin_new_order' => '1',
            'rubika_enabled' => '0', 'rubika_token' => '', 'rubika_username' => '', 'rubika_admin_chat_id' => '', 'rubika_secret' => '', 'rubika_registered_fingerprint' => '', 'rubika_status' => '', 'rubika_post_chat_id' => '', 'rubika_post_title' => 'محصول جدید: %product%', 'rubika_notify_customer_new_order' => '1', 'rubika_notify_admin_new_order' => '1',
        );
    }

    public static function options() {
        $options = wp_parse_args((array) get_option(self::OPTION, array()), self::defaults());
        foreach (array('bale_token', 'rubika_token', 'bale_provider_token') as $secret_key) {
            $stored = (string) ($options[$secret_key] ?? '');
            if ((strpos($stored, 'gcm:') === 0 || strpos($stored, 'sod:') === 0 || strpos($stored, 'plain:') === 0) && class_exists('\\ZarinShopBot\\Core\\Http\\ProxyManager')) {
                $options[$secret_key] = \ZarinShopBot\Core\Http\ProxyManager::decrypt($stored);
            }
        }
        return $options;
    }

    /** Convert legacy raw channel credentials to the same authenticated-at-rest format used by proxy secrets. */
    public static function migrate_plaintext_secrets() {
        $stored_options = get_option(self::OPTION, array());
        if (!is_array($stored_options) || !class_exists('\\ZarinShopBot\\Core\\Http\\ProxyManager')) { return; }
        $changed = false;
        foreach (array('bale_token', 'rubika_token', 'bale_provider_token') as $secret_key) {
            $secret = isset($stored_options[$secret_key]) ? (string) $stored_options[$secret_key] : '';
            if ($secret !== '' && strpos($secret, 'gcm:') !== 0 && strpos($secret, 'sod:') !== 0 && strpos($secret, 'plain:') !== 0) {
                $stored_options[$secret_key] = \ZarinShopBot\Core\Http\ProxyManager::encrypt($secret);
                $changed = true;
            }
        }
        if ($changed) { update_option(self::OPTION, $stored_options, false); }
    }

    private static function encode_secrets(array $options) {
        if (!class_exists('\\ZarinShopBot\\Core\\Http\\ProxyManager')) { return $options; }
        foreach (array('bale_token', 'rubika_token', 'bale_provider_token') as $secret_key) {
            $secret = isset($options[$secret_key]) ? (string) $options[$secret_key] : '';
            if ($secret !== '' && strpos($secret, 'gcm:') !== 0 && strpos($secret, 'sod:') !== 0 && strpos($secret, 'plain:') !== 0) {
                $options[$secret_key] = \ZarinShopBot\Core\Http\ProxyManager::encrypt($secret);
            }
        }
        return $options;
    }

    /** Persist runtime credentials without writing their plaintext representation to the options table. */
    private static function persist_options(array $options) {
        return update_option(self::OPTION, self::encode_secrets($options), false);
    }

    public static function sanitize_options($input) {
        $old = self::options();
        $input = is_array($input) ? $input : array();
        $clean = $old;
        foreach (array('bale', 'rubika') as $platform) {
            $enabled_key = $platform . '_enabled';
            if (array_key_exists($enabled_key, $input)) {
                $clean[$enabled_key] = empty($input[$enabled_key]) ? '0' : '1';
            }
            $username_key = $platform . '_username';
            if (isset($input[$username_key])) {
                $clean[$username_key] = sanitize_text_field(ltrim((string) $input[$username_key], '@'));
            }
            $admin_chat_key = $platform . '_admin_chat_id';
            if (array_key_exists($admin_chat_key, $input)) {
                $admin_chat_id = trim(sanitize_text_field((string) $input[$admin_chat_key]));
                $clean[$admin_chat_key] = preg_match('/\A[A-Za-z0-9_\-]{1,160}\z/', $admin_chat_id) ? $admin_chat_id : '';
            }
            $post_chat_key = $platform . '_post_chat_id';
            if (array_key_exists($post_chat_key, $input)) {
                $post_chat_id = trim(sanitize_text_field((string) $input[$post_chat_key]));
                $clean[$post_chat_key] = preg_match('/\A[A-Za-z0-9_@.\-]{1,160}\z/', $post_chat_id) ? $post_chat_id : '';
            }
            $post_title_key = $platform . '_post_title';
            if (array_key_exists($post_title_key, $input)) {
                $clean[$post_title_key] = sanitize_text_field((string) $input[$post_title_key]);
            }
            foreach (array('notify_customer_new_order', 'notify_admin_new_order') as $notification_key) {
                $channel_notification_key = $platform . '_' . $notification_key;
                if (array_key_exists($channel_notification_key, $input)) {
                    $clean[$channel_notification_key] = empty($input[$channel_notification_key]) ? '0' : '1';
                }
            }
            $token_key = $platform . '_token';
            $token = isset($input[$token_key]) ? trim((string) $input[$token_key]) : '';
            // Blank secret inputs mean "keep existing"; never expose a saved secret in HTML.
            if ($token !== '') {
                $sanitized_token = sanitize_text_field($token);
                $previous_token = (string) ($old[$token_key] ?? '');
                $clean[$token_key] = $sanitized_token;
                // A webhook path secret is tied to the remote registration. Do
                // not rotate it on every settings save when the same bot token
                // is resubmitted; that silently invalidates the provider URL.
                if (!hash_equals($previous_token, $sanitized_token)) {
                    $clean[$platform . '_secret'] = wp_generate_password(40, false, false);
                    $clean[$platform . '_status'] = '';
                }
            }
            if (!empty($input['clear_' . $token_key])) {
                $clean[$token_key] = '';
                $clean[$platform . '_secret'] = '';
                $clean[$platform . '_registered_fingerprint'] = '';
                $clean[$platform . '_status'] = '';
            }
        }
        if (array_key_exists('bale_miniapp_enabled', $input)) {
            $clean['bale_miniapp_enabled'] = empty($input['bale_miniapp_enabled']) ? '0' : '1';
        }
        if (array_key_exists('bale_wallet_enabled', $input)) {
            $clean['bale_wallet_enabled'] = empty($input['bale_wallet_enabled']) ? '0' : '1';
        }
        $provider_token = isset($input['bale_provider_token']) ? trim((string) $input['bale_provider_token']) : '';
        if ($provider_token !== '') {
            $clean['bale_provider_token'] = sanitize_text_field($provider_token);
        }
        if (!empty($input['clear_bale_provider_token'])) {
            $clean['bale_provider_token'] = '';
        }
        if (isset($input['bale_irr_per_store_unit'])) {
            $rate = trim((string) $input['bale_irr_per_store_unit']);
            if ($rate === '' || !is_numeric($rate) || (float) $rate < 0 || (float) $rate > 1000000000) {
                add_settings_error(self::OPTION, 'bale_irr_rate', __('ضریب تبدیل باید عددی بزرگ‌تر یا مساوی صفر باشد؛ صفر یعنی تشخیص خودکار IRR/IRT.', 'zarinshopbot'), 'error');
            } else {
                $clean['bale_irr_per_store_unit'] = (string) (float) $rate;
            }
        }
        return self::encode_secrets($clean);
    }

    public static function admin_menu() {
        // Keep old bookmarks valid without exposing separate items in WordPress navigation.
        add_submenu_page(null, __('تنظیمات ربات بله', 'zarinshopbot'), __('تنظیمات ربات بله', 'zarinshopbot'), 'manage_options', 'zarinshopbot_bale', array(__CLASS__, 'render_admin'));
        add_submenu_page(null, __('تنظیمات ربات روبیکا', 'zarinshopbot'), __('تنظیمات ربات روبیکا', 'zarinshopbot'), 'manage_options', 'zarinshopbot_rubika', array(__CLASS__, 'render_admin'));
        add_submenu_page(null, __('تنظیمات قدیمی کانال‌ها', 'zarinshopbot'), __('تنظیمات قدیمی کانال‌ها', 'zarinshopbot'), 'manage_options', 'zarinshopbot-channels', array(__CLASS__, 'render_admin'));
    }

    public static function register_settings() {
        register_setting('zarinshopbot_channels_group', self::OPTION, array('type' => 'array', 'sanitize_callback' => array(__CLASS__, 'sanitize_options'), 'default' => self::defaults()));
    }

    public static function render_admin() {
        if (!current_user_can('manage_options')) { return; }
        // Legacy routes now land in the matching sidebar section inside Settings.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        $tab = $page === 'zarinshopbot_rubika' ? 'rubika' : 'bale';
        wp_safe_redirect(add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => $tab), admin_url('admin.php')));
        exit;
    }

    public static function render_settings_content($platform) {
        if (!current_user_can('manage_options') || !in_array($platform, array('bale', 'rubika'), true)) { return; }
        $label = $platform === 'bale' ? __('بله', 'zarinshopbot') : __('روبیکا', 'zarinshopbot');
        $options = self::options();
        $token_key = $platform . '_token';
        $username_key = $platform . '_username';
        $enabled_key = $platform . '_enabled';
        $webhook_url = self::webhook_url($platform, $options);
        $rubika_registered_digest = $platform === 'rubika' ? self::registered_route_digest('rubika', $options) : '';
        $rubika_current_digest = $platform === 'rubika' ? self::webhook_secret_digest($options['rubika_secret'] ?? '') : '';
        $rubika_route_state = $platform !== 'rubika' ? 'not_applicable' : ($rubika_registered_digest === '' ? 'missing' : (hash_equals($rubika_current_digest, $rubika_registered_digest) ? 'current' : 'previous'));
        $bale_webapp_url = class_exists('ZarinShopBot\\Core\\WooBot') ? \ZarinShopBot\Core\WooBot::getWebAppUrl('bale') : add_query_arg(array('zarincode_webapp' => '1', 'platform' => 'bale'), home_url('/'));
        $bale_main_app_link = !empty($options['bale_username']) ? 'https://ble.ir/' . rawurlencode(ltrim((string) $options['bale_username'], '@')) . '?startapp' : '';
        $current_currency = function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : 'IRR';
        ?>
        <div class="zarin-channel-content">
            <div class="zarin-card zarin-channel-card">
                <div class="zarin-card-header">
                    <img class="zarin-platform-logo zarin-channel-title-logo" src="<?php echo esc_url(zarincode_get_plugin_uri() . 'assets/icons/' . $platform . '.svg'); ?>" alt="" aria-hidden="true" />
                    <div>
                        <h2 class="zarin-card-title"><?php echo esc_html(sprintf(__('تنظیمات ربات %s', 'zarinshopbot'), $label)); ?></h2>
                        <p class="zarin-card-subtitle"><?php echo esc_html(sprintf(__('توکن، وب‌هوک و قابلیت‌های اختصاصی کانال %s؛ مستقل از تنظیمات تلگرام.', 'zarinshopbot'), $label)); ?></p>
                    </div>
                </div>
                <div class="zarin-card-body">
            <?php settings_errors(self::OPTION); ?>
            <p class="description"><?php echo esc_html__('توکن‌ها و کلیدهای پرداخت محرمانه‌اند؛ پس از ذخیره دوباره در HTML نمایش داده نمی‌شوند. هر پیام‌رسان از تنظیمات و وب‌هوک مستقل خود استفاده می‌کند.', 'zarinshopbot'); ?></p>
            <?php if (!class_exists('WooCommerce')) : ?><div class="notice notice-error"><p><?php echo esc_html__('برای ثبت سفارش‌ها و پرداخت‌ها، WooCommerce باید نصب و فعال باشد.', 'zarinshopbot'); ?></p></div><?php endif; ?>
            <?php if (isset($_GET['settings-updated']) || isset($_GET['connection-tested']) || isset($_GET['webhook-updated'])) : ?><div class="zarin-alert zarin-alert-success"><span class="dashicons dashicons-saved"></span><div><?php echo esc_html__('وضعیت تنظیمات یا اتصال به‌روزرسانی شد.', 'zarinshopbot'); ?></div></div><?php endif; ?>
            <?php if (!empty($options[$platform . '_status'])) : ?><div class="notice notice-info"><p><strong><?php echo esc_html($options[$platform . '_status']); ?></strong></p></div><?php endif; ?>
            <?php if ($platform === 'rubika' && $options['rubika_enabled'] === '1' && $rubika_route_state === 'missing') : ?><div class="notice notice-error"><p><strong><?php echo esc_html__('وب‌هوک روبیکا هنوز با مسیر تأییدشده ثبت نشده است؛ درخواست‌هایی که کلید مسیرشان با تنظیم فعلی یکی نباشد با پاسخ 403 رد می‌شوند. «ثبت وب‌هوک همین ربات» را اجرا کنید.', 'zarinshopbot'); ?></strong></p></div><?php elseif ($platform === 'rubika' && $options['rubika_enabled'] === '1' && $rubika_route_state === 'previous') : ?><div class="notice notice-warning"><p><?php echo esc_html__('کلید ذخیره‌شدهٔ وب‌هوک روبیکا با کلید فعلی متفاوت است. برای همگام‌سازی endpointهای روبیکا، «ثبت وب‌هوک همین ربات» را اجرا کنید.', 'zarinshopbot'); ?></p></div><?php endif; ?>

            <form id="zarinshopbot_<?php echo esc_attr($platform); ?>_settings_form" method="post" action="<?php echo esc_url(admin_url('options.php')); ?>">
                <?php settings_fields('zarinshopbot_channels_group'); ?>
                <input type="hidden" name="_wp_http_referer" value="<?php echo esc_url(add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => $platform), admin_url('admin.php'))); ?>">
                <input type="hidden" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($enabled_key); ?>]" value="0">
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><?php echo esc_html__('وضعیت ربات', 'zarinshopbot'); ?></th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($enabled_key); ?>]" value="1" <?php checked($options[$enabled_key], '1'); ?>> <?php echo esc_html(sprintf(__('فعال‌سازی ربات %s', 'zarinshopbot'), $label)); ?></label><p class="description"><?php echo esc_html__('تا وقتی توکن معتبر، وب‌هوک قابل دسترس و ووکامرس فعال نباشند، بات نمی‌تواند سفارش پردازش کند.', 'zarinshopbot'); ?></p></td></tr>
                    <tr><th scope="row"><label for="<?php echo esc_attr($token_key); ?>"><?php echo esc_html__('توکن اتصال ربات', 'zarinshopbot'); ?></label></th><td><input id="<?php echo esc_attr($token_key); ?>" type="password" autocomplete="new-password" class="regular-text" dir="ltr" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($token_key); ?>]" value="" placeholder="<?php echo esc_attr(!empty($options[$token_key]) ? '•••••••••••••••• (تنظیم شده؛ برای حفظ خالی بگذارید)' : ''); ?>"><p class="description"><?php echo esc_html(sprintf(__('توکن اختصاصی ربات %s را وارد کنید؛ برای حفظ توکن فعلی، فیلد را خالی بگذارید.', 'zarinshopbot'), $label)); ?></p><?php if (!empty($options[$token_key])) : ?><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[clear_<?php echo esc_attr($token_key); ?>]" value="1"> <?php echo esc_html__('حذف توکن ذخیره‌شده', 'zarinshopbot'); ?></label><?php endif; ?></td></tr>
                    <tr><th scope="row"><label for="<?php echo esc_attr($username_key); ?>"><?php echo esc_html__('نام کاربری ربات', 'zarinshopbot'); ?></label></th><td><input id="<?php echo esc_attr($username_key); ?>" type="text" class="regular-text" dir="ltr" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($username_key); ?>]" value="<?php echo esc_attr($options[$username_key]); ?>" placeholder="my_shop_bot"><p class="description"><?php echo esc_html__('بدون @؛ برای ساخت لینک شروع و نمایش هویت ربات استفاده می‌شود.', 'zarinshopbot'); ?></p></td></tr>
                    <tr id="<?php echo esc_attr($platform); ?>-admin-chat-id"><th scope="row"><label for="<?php echo esc_attr($platform); ?>_admin_chat_id"><?php echo esc_html(sprintf(__('شناسهٔ گفت‌وگوی مدیر در %s', 'zarinshopbot'), $label)); ?></label></th><td><input id="<?php echo esc_attr($platform); ?>_admin_chat_id" type="text" class="regular-text" dir="ltr" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($platform); ?>_admin_chat_id]" value="<?php echo esc_attr($options[$platform . '_admin_chat_id']); ?>" placeholder="123456789"><p class="description"><?php echo sprintf(esc_html__('این مقدار شناسهٔ chat.id گفت‌وگوی خصوصی مدیر در همین پیام‌رسان است، نه توکن ربات و نه شناسهٔ گروه. مدیر ابتدا در گفت‌وگوی خصوصی ربات گزینهٔ Start یا %1$s را بزند؛ سپس در پنل اصلی افزونه ← مخاطبان و گروه‌ها ← کاربران، ردیف همین پیام‌رسان را با نام کاربری پیدا کند و مقدار ستون Chat ID را وارد کند. این مقصد، رسید کارت‌به‌کارت و دکمه‌های تأیید/رد را دریافت می‌کند.', 'zarinshopbot'), '<code>/start</code>'); ?></p></td></tr>
                    <tr><th scope="row"><label for="<?php echo esc_attr($platform); ?>_post_chat_id"><?php echo esc_html(sprintf(__('مقصد انتشار محصول در %s', 'zarinshopbot'), $label)); ?></label></th><td><input id="<?php echo esc_attr($platform); ?>_post_chat_id" type="text" class="regular-text" dir="ltr" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($platform); ?>_post_chat_id]" value="<?php echo esc_attr($options[$platform . '_post_chat_id']); ?>" placeholder="@channel_or_chat_id"><p class="description"><?php echo esc_html(sprintf(__('مقصد این کانال مستقل از ربات Telegram است. بات %s باید در مقصد مجوز ارسال پیام داشته باشد؛ مقدار باید شناسهٔ گفت‌وگو یا نام کاربری قابل‌قبول در API رسمی همین پلتفرم باشد.', 'zarinshopbot'), $label)); ?></p></td></tr>
                    <tr><th scope="row"><label for="<?php echo esc_attr($platform); ?>_post_title"><?php echo esc_html(sprintf(__('عنوان پست محصول در %s', 'zarinshopbot'), $label)); ?></label></th><td><input id="<?php echo esc_attr($platform); ?>_post_title" type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($platform); ?>_post_title]" value="<?php echo esc_attr($options[$platform . '_post_title']); ?>"><p class="description"><?php echo esc_html__('برای درج نام محصول جاری، متغیر زیر را در عنوان بگذارید؛ هنگام ارسال با نام همان محصول جایگزین می‌شود.', 'zarinshopbot'); ?> <button type="button" class="zsb-message-variable" data-editor-id="<?php echo esc_attr($platform . '_post_title'); ?>" data-variable="%product%"><code>%product%</code><span><?php echo esc_html__('نام محصول جاری', 'zarinshopbot'); ?></span></button></p></td></tr>
                    <tr><th scope="row"><?php echo esc_html__('اعلان سفارش در همین کانال', 'zarinshopbot'); ?></th><td>
                        <input type="hidden" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($platform); ?>_notify_customer_new_order]" value="0"><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($platform); ?>_notify_customer_new_order]" value="1" <?php checked($options[$platform . '_notify_customer_new_order'], '1'); ?>> <?php echo esc_html__('ارسال تأیید سفارش به مشتری در همین پیام‌رسان', 'zarinshopbot'); ?></label><br>
                        <input type="hidden" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($platform); ?>_notify_admin_new_order]" value="0"><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($platform); ?>_notify_admin_new_order]" value="1" <?php checked($options[$platform . '_notify_admin_new_order'], '1'); ?>> <?php echo esc_html__('ارسال اعلان سفارش به مدیر همین کانال', 'zarinshopbot'); ?></label>
                        <p class="description"><?php echo esc_html__('این سوئیچ‌ها فقط برای سفارش‌های ثبت‌شده از همین کانال هستند و تنظیمات Telegram یا پیام‌رسان دیگر را تغییر نمی‌دهند.', 'zarinshopbot'); ?></p></td></tr>
                    <?php if ($platform === 'bale') : ?>
                    <tr><th scope="row"><?php echo esc_html__('مینی‌اپ فروشگاه بله', 'zarinshopbot'); ?></th><td><input type="hidden" name="<?php echo esc_attr(self::OPTION); ?>[bale_miniapp_enabled]" value="0"><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[bale_miniapp_enabled]" value="1" <?php checked($options['bale_miniapp_enabled'], '1'); ?>> <?php echo esc_html__('فعال‌سازی فروشگاه تعاملی در مینی‌اپ بله', 'zarinshopbot'); ?></label><p class="description"><?php echo esc_html__('همان کاتالوگ، جستجو، تنوع کالا، سبد، علاقه‌مندی‌ها، ارسال، کوپن، سفارش‌ها و پرداخت کیف‌پولیِ پشتیبانی‌شده در مینی‌اپ را در بله فعال می‌کند. بازشدن امن برنامه به initData امضاشدهٔ بله وابسته است.', 'zarinshopbot'); ?></p><p class="description"><strong><?php echo esc_html__('نشانی وب‌اپ برای دکمهٔ اینلاین/صفحه‌کلید:', 'zarinshopbot'); ?></strong></p><div class="zarin-channel-app-link"><input type="url" class="regular-text zarin-ltr" readonly dir="ltr" aria-label="<?php echo esc_attr__('نشانی HTTPS وب‌اپ برای دکمه‌های بله', 'zarinshopbot'); ?>" value="<?php echo esc_attr($bale_webapp_url); ?>"><button type="button" class="button zarin-copy-webapp-url" data-copy="<?php echo esc_attr($bale_webapp_url); ?>"><?php echo esc_html__('کپی نشانی وب‌اپ', 'zarinshopbot'); ?></button></div><p class="description"><?php echo esc_html__('این نشانی را برای دکمهٔ Web App اینلاین/صفحه‌کلید و تنظیم Main Mini App در BotFather بله وارد کنید. پس از تنظیم در BotFather، پیوند مستقیم زیر می‌تواند مینی‌اپ را داخل بله باز کند؛ باز کردن نشانی وب‌اپ در مرورگر عادی، initData امضاشده ندارد و برای ورود امن کافی نیست.', 'zarinshopbot'); ?></p><?php if ($bale_main_app_link) : ?><div class="zarin-channel-app-link zarin-bale-direct-link"><a href="<?php echo esc_url($bale_main_app_link); ?>" target="_blank" rel="noopener noreferrer" dir="ltr"><?php echo esc_html($bale_main_app_link); ?></a><button type="button" class="button zarin-copy-webapp-url" data-copy="<?php echo esc_attr($bale_main_app_link); ?>"><?php echo esc_html__('کپی پیوند مستقیم', 'zarinshopbot'); ?></button></div><?php else : ?><p class="description"><?php echo esc_html__('ابتدا نام کاربری ربات بله را در همین صفحه ذخیره کنید تا پیوند مستقیم ساخته شود.', 'zarinshopbot'); ?></p><?php endif; ?><p class="description"><?php echo esc_html__('برای نسخهٔ وب بله، اگر سرور CSP می‌فرستد باید frame-src برای https://*.bale.ai مجاز باشد و X-Frame-Options در همین مسیر مانع iframe نشود؛ سیاست امنیتی را به‌صورت سراسری حذف نکنید.', 'zarinshopbot'); ?></p></td></tr>
                    <?php endif; ?>
                    <?php if ($platform === 'bale') : ?>
                    <tr><th scope="row"><?php echo esc_html__('پرداخت کیف‌پولی بله', 'zarinshopbot'); ?></th><td><input type="hidden" name="<?php echo esc_attr(self::OPTION); ?>[bale_wallet_enabled]" value="0"><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[bale_wallet_enabled]" value="1" <?php checked($options['bale_wallet_enabled'], '1'); ?>> <?php echo esc_html__('ارسال صورتحساب پرداخت در خود گفت‌وگوی بله', 'zarinshopbot'); ?></label><p class="description"><?php echo esc_html__('در گفت‌وگوی عادی بله، بات پس از محاسبهٔ سفارش صورتحساب کیف‌پولی می‌فرستد. در مینی‌اپ بله، همین درگاه از مسیر createInvoiceLink/openInvoice استفاده می‌کند؛ checkout مینی‌اپ به درگاه وب یا صفحهٔ سایت redirect نمی‌شود. درگاه‌های وب فقط در checkout عادی وب‌سایت در دسترس‌اند.', 'zarinshopbot'); ?></p></td></tr>
                    <tr><th scope="row"><label for="bale_provider_token"><?php echo esc_html__('توکن پرداخت کیف‌پولی (Provider Token)', 'zarinshopbot'); ?></label></th><td><input id="bale_provider_token" type="password" autocomplete="new-password" class="regular-text" dir="ltr" name="<?php echo esc_attr(self::OPTION); ?>[bale_provider_token]" value="" placeholder="<?php echo esc_attr(!empty($options['bale_provider_token']) ? '•••••••••••••••• (تنظیم شده؛ برای حفظ خالی بگذارید)' : 'WALLET-…'); ?>"><p class="description"><?php echo esc_html__('این توکن پرداخت را جداگانه از BotFather بله برای همان بازو دریافت کنید؛ با توکن اتصال ربات یکی نیست. برای تست می‌توان از توکن آزمایشی مستندات بله استفاده کرد.', 'zarinshopbot'); ?></p><?php if (!empty($options['bale_provider_token'])) : ?><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[clear_bale_provider_token]" value="1"> <?php echo esc_html__('حذف توکن پرداخت ذخیره‌شده', 'zarinshopbot'); ?></label><?php endif; ?></td></tr>
                    <tr><th scope="row"><label for="bale_irr_per_store_unit"><?php echo esc_html__('ضریب تبدیل ارز فروشگاه به ریال', 'zarinshopbot'); ?></label></th><td><input id="bale_irr_per_store_unit" type="number" min="0" step="0.00000001" class="small-text" dir="ltr" name="<?php echo esc_attr(self::OPTION); ?>[bale_irr_per_store_unit]" value="<?php echo esc_attr($options['bale_irr_per_store_unit']); ?>"><p class="description"><?php echo esc_html(sprintf(__('واحد پول فعلی ووکامرس: %s. صفر = تشخیص خودکار (IRR برابر ۱ و IRT/TOMAN برابر ۱۰ ریال)؛ برای ارز دیگر مقدار ریال به ازای هر واحد ارز فروشگاه را وارد کنید. مبلغ نهایی باید به عدد صحیح ریال برسد.', 'zarinshopbot'), $current_currency)); ?></p></td></tr>
                    <?php else : ?>
                    <tr><th scope="row"><?php echo esc_html__('پرداخت سفارش‌های روبیکا', 'zarinshopbot'); ?></th><td><p><?php echo esc_html__('پرداخت بومی/کیف‌پولی روبیکا در مستندات عمومی Bot API که مبنای این نسخه است مستند نشده؛ بنابراین در این افزونه صورتحساب جعلی روبیکا ساخته نمی‌شود. بات مشتری را به checkout امن ووکامرس می‌فرستد و درگاه‌های فعال سایت، از جمله هر درگاه روبیکای نصب‌شده و معتبر، همان‌جا کار می‌کنند.', 'zarinshopbot'); ?></p><p class="description"><?php echo esc_html__('پس از بازگشت درگاه ووکامرس، شناسه و وضعیت تراکنش را خود درگاه به سفارش ووکامرس می‌نویسد. فعال‌سازی یکپارچگی مستقیم روبیکا به مستندات رسمی API پرداخت نیاز دارد.', 'zarinshopbot'); ?></p></td></tr>
                    <?php endif; ?>
                    <tr><th scope="row"><?php echo esc_html__('آدرس وب‌هوک', 'zarinshopbot'); ?></th><td><code dir="ltr" style="word-break:break-all"><?php echo esc_html($webhook_url); ?></code><p class="description"><?php echo esc_html__('این URL دارای secret اختصاصی است؛ آن را عمومی نکنید. پس از تغییر توکن، وب‌هوک را دوباره ثبت کنید.', 'zarinshopbot'); ?></p></td></tr>
                </table>
            </form>
            <?php
            $settings_save_bar = array(
                'class' => 'zarin-channel-save-bar',
                'platform' => $platform,
                'form' => 'zarinshopbot_' . $platform . '_settings_form',
                'hint' => sprintf(__('این دکمه فقط تنظیمات کانال %s را ذخیره می‌کند؛ تنظیمات مشترک فروشگاه با دکمهٔ ذخیرهٔ اصلی ذخیره می‌شوند.', 'zarinshopbot'), $label),
                'aria' => sprintf(__('ذخیره تنظیمات کانال %s', 'zarinshopbot'), $label),
            );
            require dirname(__DIR__) . '/panel/partials/settings-save-bar.php';
            unset($settings_save_bar);
            ?>

            <hr><h2><?php echo esc_html__('آزمایش اتصال و ثبت وب‌هوک', 'zarinshopbot'); ?></h2>
            <p><?php echo esc_html__('ثبت وب‌هوک فقط پس از فشردن دکمه به API پیام‌رسان درخواست می‌فرستد. سایت برای وب‌هوک باید از HTTPS معتبر و عمومی استفاده کند.', 'zarinshopbot'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;margin-inline-end:10px">
                <input type="hidden" name="action" value="zarinshopbot_test_channel_connection"><input type="hidden" name="platform" value="<?php echo esc_attr($platform); ?>">
                <?php wp_nonce_field('zarinshopbot_test_channel_' . $platform); ?><?php submit_button(__('آزمایش توکن و دریافت اطلاعات ربات', 'zarinshopbot'), 'secondary zarin-btn-ghost', 'submit', false); ?>
            </form>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block">
                <input type="hidden" name="action" value="zarinshopbot_register_channel_webhooks"><input type="hidden" name="platform" value="<?php echo esc_attr($platform); ?>">
                <?php wp_nonce_field('zarinshopbot_register_channel_webhooks'); ?><?php submit_button(__('ثبت وب‌هوک همین ربات', 'zarinshopbot'), 'secondary zarin-btn-ghost', 'submit', false); ?>
            </form>
            <h3><?php echo esc_html__('دستورهای مشترک فروشگاه', 'zarinshopbot'); ?></h3>
            <p><?php echo esc_html__('این دستورها را می‌توان مستقیماً برای ربات فرستاد؛ دکمه‌های منوی اصلی و دکمه‌های محصول نیز همان گردش‌کار مشترک را اجرا می‌کنند.', 'zarinshopbot'); ?></p>
            <code dir="ltr">/start &nbsp; /shop &nbsp; /search &nbsp; /category &nbsp; /newproducts &nbsp; /cart &nbsp; /orders &nbsp; /wishlist &nbsp; /settings &nbsp; /contactus &nbsp; /help</code>
            <?php if ($platform === 'rubika') : ?><p class="description"><?php echo sprintf(esc_html__('فهرست دستورهای قابل‌نمایش در روبیکا هنگام ثبت وب‌هوک با متد رسمی %1$s همگام می‌شود.', 'zarinshopbot'), '<code>setCommands</code>'); ?></p><?php else : ?><p class="description"><?php echo esc_html__('دستورهای متنی در موتور مشترک پشتیبانی می‌شوند؛ ثبت/نمایش فهرست منو را در صورت ارائهٔ این گزینه در BotFather بله انجام دهید.', 'zarinshopbot'); ?></p><?php endif; ?>
            <p><a href="<?php echo esc_url(admin_url('admin.php?page=zarincode_guide#channel-page')); ?>"><?php echo esc_html__('مشاهدهٔ بخش راه‌اندازی کانال در راهنما', 'zarinshopbot'); ?></a></p>
                </div>
            </div>
        </div>
        <?php
    }

    public static function webhook_url($platform, $options = null) {
        $options = $options === null ? self::options() : $options;
        $secret = isset($options[$platform . '_secret']) ? $options[$platform . '_secret'] : '';
        return rest_url('zarinshopbot/v1/hook/' . $platform . '/' . rawurlencode($secret));
    }

    /** Full keyed digest is persisted as the last registered-route verifier; raw URL credentials are never duplicated. */
    private static function webhook_secret_digest($secret) {
        $secret = (string) $secret;
        if ($secret === '' || !function_exists('wp_salt')) { return ''; }
        return hash_hmac('sha256', $secret, (string) wp_salt('auth'));
    }

    /** Short, non-reversible diagnostic representation. */
    private static function webhook_secret_fingerprint($secret) {
        $digest = self::webhook_secret_digest($secret);
        return $digest === '' ? '' : 'h' . substr($digest, 0, 12);
    }

    /** Read the last accepted provider route from a dedicated option, falling back to 1.6.8's nested setting. */
    private static function registered_route_digest($platform, array $options = array()) {
        $routes = get_option(self::REGISTERED_ROUTES_OPTION, array());
        $digest = is_array($routes) ? (string) ($routes[$platform] ?? '') : '';
        if ($digest === '') { $digest = (string) ($options[$platform . '_registered_fingerprint'] ?? ''); }
        return preg_match('/\\A[a-f0-9]{64}\\z/i', $digest) ? strtolower($digest) : '';
    }

    /** Persist route state separately from editable channel settings; verify the write before reporting success. */
    private static function persist_registered_route_digest($platform, $digest) {
        if (!in_array($platform, array('bale', 'rubika'), true) || !preg_match('/\\A[a-f0-9]{64}\\z/i', (string) $digest)) { return false; }
        $routes = get_option(self::REGISTERED_ROUTES_OPTION, array());
        $routes = is_array($routes) ? $routes : array();
        $routes[$platform] = strtolower((string) $digest);
        update_option(self::REGISTERED_ROUTES_OPTION, $routes, false);
        $saved = get_option(self::REGISTERED_ROUTES_OPTION, array());
        return is_array($saved) && isset($saved[$platform]) && hash_equals(strtolower((string) $digest), strtolower((string) $saved[$platform]));
    }

    /** Extract a credential only from a URL path matching this plugin's own route. */
    private static function webhook_secret_from_url($url, $platform) {
        if (!is_string($url)) { return ''; }
        $parts = wp_parse_url($url);
        $path = is_array($parts) && isset($parts['path']) ? (string) $parts['path'] : '';
        // WordPress without pretty permalinks puts the REST route in rest_route.
        if (is_array($parts) && !empty($parts['query'])) {
            parse_str((string) $parts['query'], $query);
            if (isset($query['rest_route']) && is_string($query['rest_route'])) { $path = $query['rest_route']; }
        }
        $pattern = '~/(?:wp-json/)?zarinshopbot/v1/hook/' . preg_quote($platform, '~') . '/([A-Za-z0-9]+)/?$~';
        return $path !== '' && preg_match($pattern, $path, $matches) ? $matches[1] : '';
    }

    public static function test_connection() {
        if (!current_user_can('manage_options')) { wp_die(esc_html__('دسترسی مجاز نیست.', 'zarinshopbot')); }
        $platform = isset($_POST['platform']) ? sanitize_key(wp_unslash($_POST['platform'])) : '';
        if (!in_array($platform, array('bale', 'rubika'), true)) { wp_die(esc_html__('کانال نامعتبر است.', 'zarinshopbot')); }
        check_admin_referer('zarinshopbot_test_channel_' . $platform);
        $options = self::options();
        $token = (string) ($options[$platform . '_token'] ?? '');
        if ($token === '') {
            $options[$platform . '_status'] = __('ابتدا توکن ربات را ذخیره کنید.', 'zarinshopbot');
        } else {
            $result = (new Channel_API($platform, $token))->request('getMe');
            if (is_wp_error($result)) {
                $options[$platform . '_status'] = sprintf(__('آزمایش اتصال ناموفق بود (%s). متن خام یا توکن در گزارش ثبت نشده است.', 'zarinshopbot'), $result->get_error_code());
            } else {
                $bot = $platform === 'bale' ? ($result['result'] ?? array()) : ($result['data']['bot'] ?? $result['data'] ?? array());
                if (is_array($bot) && !empty($bot['username'])) {
                    $options[$platform . '_username'] = sanitize_text_field(ltrim((string) $bot['username'], '@'));
                }
                $options[$platform . '_status'] = sprintf(__('اتصال API موفق بود؛ دریافت اطلاعات ربات انجام شد (%s).', 'zarinshopbot'), current_time('mysql'));
            }
        }
        self::persist_options($options);
        $tab = $platform;
        wp_safe_redirect(add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => $tab, 'connection-tested' => '1'), admin_url('admin.php')));
        exit;
    }

    public static function register_webhooks() {
        if (!current_user_can('manage_options')) { wp_die(esc_html__('دسترسی مجاز نیست.', 'zarinshopbot')); }
        check_admin_referer('zarinshopbot_register_channel_webhooks');
        $requested = isset($_POST['platform']) ? sanitize_key(wp_unslash($_POST['platform'])) : 'all';
        $platforms = $requested === 'all' ? array('bale', 'rubika') : array($requested);
        if (array_diff($platforms, array('bale', 'rubika'))) { wp_die(esc_html__('کانال نامعتبر است.', 'zarinshopbot')); }
        $options = self::options();
        foreach ($platforms as $platform) {
            if ($options[$platform . '_enabled'] !== '1' || !$options[$platform . '_token']) {
                $options[$platform . '_status'] = __('ربات فعال نیست یا توکن آن ذخیره نشده است.', 'zarinshopbot');
                continue;
            }
            if (!$options[$platform . '_secret']) {
                $options[$platform . '_secret'] = wp_generate_password(40, false, false);
                // Persist authentication before the provider can deliver the first update.
                self::persist_options($options);
            }
            $api = new Channel_API($platform, $options[$platform . '_token']);
            $url = self::webhook_url($platform, $options);
            if (strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) !== 'https') {
                $options[$platform . '_status'] = __('برای ثبت وب‌هوک، نشانی سایت باید HTTPS باشد.', 'zarinshopbot');
                continue;
            }
            $registered_fingerprint = self::webhook_secret_fingerprint($options[$platform . '_secret']);
            $bale_verification = null;
            if ($platform === 'bale') {
                $result = $api->request('setWebhook', array('url' => $url));
                if (function_exists('zarincode_log_event')) {
                    zarincode_log_event('channel_webhook_registration_result', array(
                        'platform' => 'bale', 'method' => 'setWebhook',
                        'accepted' => !is_wp_error($result), 'registered_fingerprint' => $registered_fingerprint,
                        'error_code' => is_wp_error($result) ? $result->get_error_code() : '',
                    ));
                }
                if (!is_wp_error($result)) {
                    // Bale officially exposes getWebhookInfo. Verify the actual
                    // remote URL instead of treating setWebhook's ack alone as proof.
                    $info_result = $api->request('getWebhookInfo');
                    if (is_wp_error($info_result)) {
                        $bale_verification = array('available' => false, 'error_code' => $info_result->get_error_code());
                        if (function_exists('zarincode_log_event')) {
                            zarincode_log_event('channel_webhook_registration_verified', array(
                                'platform' => 'bale', 'verification' => 'unavailable', 'error_code' => $info_result->get_error_code(),
                                'registered_fingerprint' => $registered_fingerprint,
                            ));
                        }
                    } else {
                        $provider_info = isset($info_result['result']) && is_array($info_result['result']) ? $info_result['result'] : array();
                        $provider_url = isset($provider_info['url']) && is_string($provider_info['url']) ? $provider_info['url'] : '';
                        $provider_secret = self::webhook_secret_from_url($provider_url, 'bale');
                        $url_matches = $provider_url !== '' && hash_equals(rtrim($url, '/'), rtrim($provider_url, '/'));
                        $secret_matches = $provider_secret !== '' && hash_equals((string) $options['bale_secret'], $provider_secret);
                        $bale_verification = array(
                            'available' => true, 'url_matches' => $url_matches, 'secret_matches' => $secret_matches,
                            'provider_fingerprint' => self::webhook_secret_fingerprint($provider_secret),
                        );
                        if (function_exists('zarincode_log_event')) {
                            zarincode_log_event('channel_webhook_registration_verified', array(
                                'platform' => 'bale', 'verification' => ($url_matches && $secret_matches) ? 'match' : 'mismatch',
                                'provider_url_present' => $provider_url !== '', 'provider_url_matches' => $url_matches,
                                'provider_route_matches' => $secret_matches,
                                'registered_fingerprint' => $registered_fingerprint,
                                'provider_fingerprint' => self::webhook_secret_fingerprint($provider_secret),
                                'pending_updates' => absint($provider_info['pending_update_count'] ?? 0),
                                'last_error_present' => !empty($provider_info['last_error_message']),
                            ));
                        }
                    }
                }
            } else {
                // Rubika documents separate ReceiveUpdate and ReceiveInlineMessage endpoints.
                $results = array();
                foreach (array('ReceiveUpdate', 'ReceiveInlineMessage') as $endpoint_type) {
                    $endpoint_result = $api->request('updateBotEndpoints', array('url' => $url, 'type' => $endpoint_type));
                    $results[] = $endpoint_result;
                    if (function_exists('zarincode_log_event')) {
                        zarincode_log_event('channel_webhook_registration_result', array(
                            'platform' => 'rubika', 'method' => 'updateBotEndpoints', 'endpoint_type' => $endpoint_type,
                            'accepted' => !is_wp_error($endpoint_result), 'registered_fingerprint' => $registered_fingerprint,
                            'error_code' => is_wp_error($endpoint_result) ? $endpoint_result->get_error_code() : '',
                        ));
                    }
                }
                $result = count(array_filter($results, 'is_wp_error')) ? new \WP_Error('zsb_rubika_endpoint_registration', __('One or more Rubika webhook endpoint types failed.', 'zarinshopbot')) : end($results);
            }
            if (is_wp_error($result)) {
                $options[$platform . '_status'] = sprintf(__('ثبت وب‌هوک ناموفق بود (%s). تنظیمات API و دسترسی شبکه را بررسی کنید.', 'zarinshopbot'), $result->get_error_code());
            } elseif ($platform === 'bale' && is_array($bale_verification) && !empty($bale_verification['available'])) {
                $verifier_saved = false;
                if (!empty($bale_verification['secret_matches'])) {
                    $options['bale_registered_fingerprint'] = self::webhook_secret_digest($options['bale_secret']);
                    $verifier_saved = self::persist_registered_route_digest('bale', $options['bale_registered_fingerprint']);
                    if (function_exists('zarincode_log_event')) {
                        zarincode_log_event('channel_webhook_route_verifier_saved', array(
                            'platform' => 'bale', 'saved' => $verifier_saved,
                            'registered_fingerprint' => self::webhook_secret_fingerprint($options['bale_secret']),
                        ));
                    }
                }
                if (empty($bale_verification['secret_matches'])) {
                    $options[$platform . '_status'] = sprintf(__('API بله نشانی فعالی با مسیر مورد انتظار نشان نداد؛ ثبت واقعی وب‌هوک تأیید نشد (%s).', 'zarinshopbot'), current_time('mysql'));
                } elseif (!$verifier_saved) {
                    $options[$platform . '_status'] = sprintf(__('API بله مسیر را تأیید کرد، اما ذخیرهٔ verifier آن ناموفق بود. دسترسی نوشتن پایگاه داده/کش را بررسی کنید (%s).', 'zarinshopbot'), current_time('mysql'));
                } elseif (!empty($bale_verification['url_matches'])) {
                    $options[$platform . '_status'] = sprintf(__('وب‌هوک بله ثبت و مسیر فعال تأیید و ذخیره شد (%s).', 'zarinshopbot'), current_time('mysql'));
                } else {
                    $options[$platform . '_status'] = sprintf(__('API بله secret مسیر را تأیید کرد، اما نشانی کامل متفاوت است؛ دامنه و بازنویسی REST را بررسی کنید (%s).', 'zarinshopbot'), current_time('mysql'));
                }
            } elseif ($platform === 'bale' && is_array($bale_verification)) {
                $options[$platform . '_status'] = sprintf(__('API بله ثبت وب‌هوک را پذیرفت، اما getWebhookInfo برای تأیید نشانی در دسترس نبود (%s).', 'zarinshopbot'), current_time('mysql'));
            } elseif ($platform === 'rubika') {
                // The official API acknowledges each endpoint update but does not
                // document a read-back method; both accepted calls establish the
                // active route verifier used by receive().
                $options['rubika_registered_fingerprint'] = self::webhook_secret_digest($options['rubika_secret']);
                $verifier_saved = self::persist_registered_route_digest('rubika', $options['rubika_registered_fingerprint']);
                if (function_exists('zarincode_log_event')) {
                    zarincode_log_event('channel_webhook_route_verifier_saved', array(
                        'platform' => 'rubika', 'saved' => $verifier_saved,
                        'registered_fingerprint' => self::webhook_secret_fingerprint($options['rubika_secret']),
                    ));
                }
                if (!$verifier_saved) {
                    $options[$platform . '_status'] = sprintf(__('روبیکا دو endpoint را پذیرفت، اما ذخیرهٔ verifier مسیر ثبت‌شده ناموفق بود؛ دسترسی نوشتن پایگاه داده/کش را بررسی کنید (%s).', 'zarinshopbot'), current_time('mysql'));
                // Respect the store's global command-menu switch before using Rubika's documented setCommands API.
                } elseif (zarincode_option('feature_menu_commands') === '0') {
                    $options[$platform . '_status'] = sprintf(__('وب‌هوک روبیکا ثبت شد؛ همگام‌سازی فهرست فرمان به‌دلیل غیرفعال‌بودن گزینهٔ منوی فرمان رد شد (%s).', 'zarinshopbot'), current_time('mysql'));
                } else {
                    $command_result = $api->request('setCommands', array('bot_commands' => self::rubika_commands()));
                    $options[$platform . '_status'] = is_wp_error($command_result)
                        ? sprintf(__('وب‌هوک روبیکا ثبت شد، اما همگام‌سازی دستورها ناموفق بود (%s).', 'zarinshopbot'), $command_result->get_error_code())
                        : sprintf(__('وب‌هوک و فهرست دستورهای روبیکا ثبت شدند (%s).', 'zarinshopbot'), current_time('mysql'));
                }
            } else {
                $options[$platform . '_status'] = sprintf(__('وب‌هوک بله ثبت شد (%s). دستورهای متنی از موتور مشترک پشتیبانی می‌شوند؛ در صورت نیاز فهرست منو را در BotFather بله تنظیم کنید.', 'zarinshopbot'), current_time('mysql'));
            }
        }
        self::persist_options($options);
        $tab = $requested === 'rubika' ? 'rubika' : 'bale';
        wp_safe_redirect(add_query_arg(array('page' => 'zarincode_zarinshopbot_setting', 'tab' => $tab, 'webhook-updated' => '1'), admin_url('admin.php')));
        exit;
    }

    /** Rubika's documented setCommands schema (no leading slash in command names). */
    private static function rubika_commands() {
        return array(
            array('command' => 'start', 'description' => __('شروع و نمایش منوی فروشگاه', 'zarinshopbot')),
            array('command' => 'shop', 'description' => __('نمایش فروشگاه و محصولات', 'zarinshopbot')),
            array('command' => 'search', 'description' => __('جستجوی محصول با نام یا کد', 'zarinshopbot')),
            array('command' => 'category', 'description' => __('نمایش دسته‌بندی محصولات', 'zarinshopbot')),
            array('command' => 'newproducts', 'description' => __('نمایش محصولات جدید', 'zarinshopbot')),
            array('command' => 'cart', 'description' => __('مشاهده و مدیریت سبد خرید', 'zarinshopbot')),
            array('command' => 'orders', 'description' => __('پیگیری سفارش‌های من', 'zarinshopbot')),
            array('command' => 'wishlist', 'description' => __('نمایش علاقه‌مندی‌ها', 'zarinshopbot')),
            array('command' => 'settings', 'description' => __('تنظیم زبان ربات', 'zarinshopbot')),
            array('command' => 'contactus', 'description' => __('تماس با فروشگاه', 'zarinshopbot')),
            array('command' => 'help', 'description' => __('راهنمای دستورها', 'zarinshopbot')),
        );
    }

    public static function register_routes() {
        register_rest_route('zarinshopbot/v1', '/hook/(?P<platform>bale|rubika)/(?P<secret>[A-Za-z0-9]+)', array(
            'methods' => 'POST', 'callback' => array(__CLASS__, 'receive'), 'permission_callback' => '__return_true',
            'args' => array('platform' => array('sanitize_callback' => 'sanitize_key'), 'secret' => array('sanitize_callback' => 'sanitize_text_field')),
        ));
    }

    public static function receive(\WP_REST_Request $request) {
        $webhook_started_at = microtime(true);
        $platform = sanitize_key((string) $request->get_param('platform'));
        if (!in_array($platform, array('bale', 'rubika'), true)) {
            return new \WP_REST_Response(array('ok' => false), 404);
        }
        // Record provider ingress without storing webhook secrets, message text,
        // chat IDs, usernames, or the raw request body.
        if (function_exists('zarincode_log_event')) {
            zarincode_log_event('channel_webhook_received', array('platform' => $platform, 'method' => sanitize_key($request->get_method())));
        }
        $options = self::options();
        $stored = isset($options[$platform . '_secret']) ? (string) $options[$platform . '_secret'] : '';
        $registered_digest = self::registered_route_digest($platform, $options);
        // The URL route is authoritative. A provider may still call the exact
        // route confirmed at registration even if a later settings/token save
        // changed the editable secret. Trust only the current secret or the
        // full keyed digest of the last successfully registered route.
        $url_params = $request->get_url_params();
        $received_raw = isset($url_params['secret']) ? $url_params['secret'] : '';
        $received = is_scalar($received_raw) ? (string) $received_raw : '';
        $combined_param = $request->get_param('secret');
        $param_shadowed = is_scalar($combined_param) && (string) $combined_param !== $received;
        $current_match = $stored !== '' && $received !== '' && hash_equals($stored, $received);
        $received_digest = self::webhook_secret_digest($received);
        $registered_match = $registered_digest !== '' && $received_digest !== '' && hash_equals($registered_digest, $received_digest);
        if (!$current_match && !$registered_match) {
            $reason = ($stored === '' && $registered_digest === '') ? 'stored_key_missing' : ($received === '' ? 'path_key_missing' : 'key_mismatch');
            $auth_context = array(
                'platform' => $platform,
                'reason' => $reason,
                'expected_present' => $stored !== '',
                'registered_present' => $registered_digest !== '',
                'received_present' => $received !== '',
                'registered_match' => false,
                'expected_length' => strlen($stored),
                'received_length' => strlen($received),
                'param_shadowed' => $param_shadowed,
            );
            $auth_context['expected_fingerprint'] = self::webhook_secret_fingerprint($stored);
            $auth_context['registered_fingerprint'] = $registered_digest !== '' ? 'h' . substr($registered_digest, 0, 12) : '';
            $auth_context['received_fingerprint'] = self::webhook_secret_fingerprint($received);
            if (function_exists('zarincode_log_event')) { zarincode_log_event('channel_webhook_auth_error', $auth_context); }
            return new \WP_REST_Response(array('ok' => false), 403);
        }
        if ($registered_match && !$current_match && function_exists('zarincode_log_event')) {
            zarincode_log_event('channel_webhook_auth_registered_route', array(
                'platform' => $platform, 'registered_match' => true,
                'registered_fingerprint' => 'h' . substr($registered_digest, 0, 12),
                'expected_fingerprint' => self::webhook_secret_fingerprint($stored),
            ));
        }
        if ($options[$platform . '_enabled'] !== '1') {
            if (function_exists('zarincode_log_event')) { zarincode_log_event('channel_webhook_ignored_disabled', array('platform' => $platform)); }
            return new \WP_REST_Response(array('ok' => true, 'disabled' => true), 200);
        }
        $body = $request->get_json_params();
        if (!is_array($body)) {
            if (function_exists('zarincode_log_event')) { zarincode_log_event('channel_webhook_payload_error', array('platform' => $platform, 'reason' => 'invalid_json')); }
            return new \WP_REST_Response(array('ok' => false), 400);
        }
        $provider_update_type = $platform === 'rubika'
            ? sanitize_key((string) ($body['update']['type'] ?? (isset($body['inline_message']) ? 'inline_message' : 'unknown')))
            : (isset($body['callback_query']) ? 'callback_query' : (isset($body['message']) ? 'message' : 'unknown'));
        if ($platform === 'rubika') {
            $inline_event = isset($body['inline_message']) && is_array($body['inline_message']);
            if ($inline_event) {
                $aux_data = isset($body['inline_message']['aux_data']) && is_array($body['inline_message']['aux_data']) ? $body['inline_message']['aux_data'] : array();
                if (empty($aux_data['button_id']) || !is_scalar($aux_data['button_id'])) {
                    if (function_exists('zarincode_log_event')) zarincode_log_event('channel_update_ignored', array('platform' => 'rubika', 'reason' => 'inline_button_id_missing'));
                    return new \WP_REST_Response(array('ok' => true, 'ignored' => true), 200);
                }
            } else {
                $rubika_type = isset($body['update']['type']) && is_string($body['update']['type']) ? $body['update']['type'] : '';
                if (!in_array($rubika_type, array('NewMessage', 'StartedBot'), true)) {
                    if (function_exists('zarincode_log_event')) zarincode_log_event('channel_update_ignored', array('platform' => 'rubika', 'reason' => 'unsupported_update_type', 'update_type' => sanitize_key($rubika_type)));
                    return new \WP_REST_Response(array('ok' => true, 'ignored' => true), 200);
                }
                $sender_type = $body['update']['new_message']['sender_type'] ?? '';
                if ($sender_type !== '' && $sender_type !== 'User') {
                    if (function_exists('zarincode_log_event')) zarincode_log_event('channel_update_ignored', array('platform' => 'rubika', 'reason' => 'non_user_sender'));
                    return new \WP_REST_Response(array('ok' => true, 'ignored' => true), 200);
                }
            }
        }
        if (function_exists('zarincode_log_event')) {
            zarincode_log_event('channel_update_received', array('platform' => $platform, 'update_type' => $provider_update_type));
        }
        if (!class_exists('WooCommerce') && $platform === 'bale' && (isset($body['pre_checkout_query']) || !empty($body['message']['successful_payment']))) {
            return new \WP_REST_Response(array('ok' => false, 'error' => 'woocommerce_required'), 503);
        }
        if ($platform === 'bale' && (isset($body['pre_checkout_query']) || !empty($body['message']['successful_payment']))) {
            $payment_event_id = isset($body['update_id']) ? (string) $body['update_id'] : hash('sha256', wp_json_encode($body));
            $payment_dedupe = 'zsb_bale_pay_' . hash('sha256', $payment_event_id);
            if (get_transient($payment_dedupe) || !self::acquire_event_claim($payment_dedupe)) {
                return new \WP_REST_Response(array('ok' => true, 'duplicate' => true), 200);
            }
            try {
                $payment_result = isset($body['pre_checkout_query'])
                    ? Bale_Payments::handle_pre_checkout($body)
                    : Bale_Payments::handle_successful_payment($body);
                if (is_wp_error($payment_result)) {
                    if (function_exists('zarincode_log_event')) { zarincode_log_event('bale_payment_update_failed', array('error' => $payment_result->get_error_code())); }
                    return new \WP_REST_Response(array('ok' => false, 'error' => $payment_result->get_error_code()), 500);
                }
                set_transient($payment_dedupe, 1, DAY_IN_SECONDS);
                if (function_exists('zarincode_log_event')) zarincode_log_event('channel_update_handled', array('platform' => $platform, 'update_type' => $provider_update_type, 'duration_ms' => (int) round((microtime(true) - $webhook_started_at) * 1000)));
                return new \WP_REST_Response(array('ok' => true), 200);
            } finally {
                self::release_event_claim($payment_dedupe);
            }
        }
        $message = self::extract_message($platform, $body);
        $raw_chat_id = $message['chat_id'] ?? '';
        if (!is_scalar($raw_chat_id)) { return new \WP_REST_Response(array('ok' => false, 'error' => 'invalid_chat_id'), 400); }
        $message['chat_id'] = trim((string) $raw_chat_id);
        $message_text = $message['text'] ?? '';
        if (!is_scalar($message_text)) { return new \WP_REST_Response(array('ok' => false, 'error' => 'invalid_message'), 400); }
        $message['text'] = (string) $message_text;
        if ($message['chat_id'] === '') { return new \WP_REST_Response(array('ok' => true, 'ignored' => true), 200); }
        if (strlen($message['chat_id']) > 160 || preg_match('/[\x00-\x1F\x7F]/', $message['chat_id'])) {
            return new \WP_REST_Response(array('ok' => false, 'error' => 'invalid_chat_id'), 400);
        }
        if (strlen($message['text']) > 65536) { return new \WP_REST_Response(array('ok' => false, 'error' => 'message_too_large'), 413); }
        if (!class_exists('WooCommerce')) { return new \WP_REST_Response(array('ok' => false, 'error' => 'woocommerce_required'), 503); }
        $event_id = self::event_id($platform, $body);
        $has_provider_event_id = $event_id !== '';
        if (!$has_provider_event_id) {
            // Some provider event types omit a stable update ID. Hash the exact
            // body and use a short window so identical retries are suppressed
            // without blocking a later, intentional repeat from the same user.
            $event_id = hash('sha256', (string) wp_json_encode($body));
        }
        $dedupe = 'zsb_event_' . hash('sha256', $platform . '|' . (string) $message['chat_id'] . '|' . $event_id);
        if (get_transient($dedupe) || !self::acquire_event_claim($dedupe)) {
            return new \WP_REST_Response(array('ok' => true, 'duplicate' => true), 200);
        }
        $short_window = !$has_provider_event_id || ($platform === 'rubika' && isset($body['inline_message']));
        try {
            if ($platform === 'rubika') {
                $chat_type = self::rubika_chat_type($message['chat_id'], $options['rubika_token']);
                if ($chat_type === '') {
                    if (function_exists('zarincode_log_event')) zarincode_log_event('rubika_chat_type_unverified', array('reason' => 'get_chat_unavailable_or_unrecognized'));
                    return new \WP_REST_Response(array('ok' => false, 'error' => 'chat_type_unverified'), 503);
                }
                if ($chat_type !== 'User') {
                    if (in_array($chat_type, array('Group', 'Channel'), true)) {
                        $private_chat_notice = sprintf(__('برای حفظ حریم خصوصی سفارش، لطفاً گفت‌وگوی خصوصی این ربات را باز کنید و %1$s بفرستید.', 'zarinshopbot'), '/start');
                        $delivery = (new Channel_API('rubika', $options['rubika_token']))->send($message['chat_id'], $private_chat_notice);
                        if (is_wp_error($delivery) && function_exists('zarincode_log_event')) {
                            zarincode_log_event('rubika_private_chat_notice_failed', array('error_code' => $delivery->get_error_code()));
                        }
                    }
                    if (function_exists('zarincode_log_event')) zarincode_log_event('rubika_group_commerce_blocked', array('chat_type' => sanitize_key($chat_type)));
                    set_transient($dedupe, 1, $short_window ? 10 : DAY_IN_SECONDS);
                    return new \WP_REST_Response(array('ok' => true, 'ignored' => true, 'private_chat_required' => true), 200);
                }
            }
            $direct_callback_action = strpos((string) $message['text'], 'ztr:') === 0 || strpos((string) $message['text'], 'zs:') === 0;
            if ($platform === 'bale' && $direct_callback_action && isset($body['callback_query']) && is_array($body['callback_query'])) {
                $ack_result = self::acknowledge_direct_bale_callback($body, $options);
                if (is_wp_error($ack_result) && function_exists('zarincode_log_event')) {
                    zarincode_log_event('bale_callback_ack_failed', array('error_code' => sanitize_key($ack_result->get_error_code())));
                }
            }
            if (strpos((string) $message['text'], 'ztr:') === 0) {
                $actor_id = self::callback_actor_id($platform, $body, $message['chat_id']);
                $review_result = class_exists(Card_Transfer::class)
                    ? Card_Transfer::handleBotReview($platform, $actor_id, $message['text'])
                    : new \WP_Error('zsb_transfer_review_unavailable', __('Card-transfer review is unavailable.', 'zarinshopbot'));
                if (is_wp_error($review_result) && function_exists('zarincode_log_event')) {
                    zarincode_log_event('card_transfer_bot_review_failed', array(
                        'platform' => $platform,
                        'error_code' => sanitize_key($review_result->get_error_code()),
                    ));
                }
            } elseif (strpos((string) $message['text'], 'zs:') === 0) {
                $dispatch_result = self::dispatch($platform, $message['chat_id'], $message['text'], $options, $body);
                if (is_wp_error($dispatch_result) && function_exists('zarincode_log_event')) {
                    // Cart/order state may already have changed. Acknowledge this update
                    // rather than letting provider retries execute the action twice.
                    zarincode_log_event('channel_outbound_delivery_failed', array(
                        'platform' => $platform,
                        'error_code' => $dispatch_result->get_error_code(),
                        'chat_hash' => hash('sha256', $platform . '|' . (string) $message['chat_id']),
                        'event_hash' => hash('sha256', (string) $event_id),
                    ));
                }
            } else {
                $result = self::run_compat_bot($platform, $message['chat_id'], $body, $options);
                if (is_wp_error($result)) {
                    if (function_exists('zarincode_log_event')) { zarincode_log_event('channel_dispatch_error', array('platform' => $platform, 'error_code' => $result->get_error_code())); }
                    return new \WP_REST_Response(array('ok' => false, 'error' => $result->get_error_code()), 500);
                }
            }
            if (function_exists('zarincode_log_event')) {
                zarincode_log_event('channel_update_handled', array('platform' => $platform, 'update_type' => $provider_update_type, 'duration_ms' => (int) round((microtime(true) - $webhook_started_at) * 1000)));
            }
            // Keep provider IDs for a day; use short-lived fallback keys for event
            // types without a documented stable ID and for Rubika inline taps.
            set_transient($dedupe, 1, $short_window ? 10 : DAY_IN_SECONDS);
            return new \WP_REST_Response(array('ok' => true), 200);
        } finally {
            self::release_event_claim($dedupe);
        }
    }

    /** Atomically claim a provider update using the unique option_name index. */
    private static function acquire_event_claim($dedupe, $ttl = 90) {
        if (!function_exists('add_option') || !function_exists('get_option')) return false;
        $key = 'zsb_claim_' . substr(hash('sha256', (string) $dedupe), 0, 48);
        $value = (string) (time() + max(15, min(600, absint($ttl)))) . ':' . wp_generate_password(32, false, false);
        if (add_option($key, $value, '', 'no')) {
            self::$active_event_claims[$key] = $value;
            return true;
        }
        $existing = get_option($key, '');
        $parts = is_string($existing) ? explode(':', $existing, 2) : array();
        $expires = isset($parts[0]) && preg_match('/\\A[0-9]+\\z/', $parts[0]) ? (int) $parts[0] : 0;
        if ($expires > time() || !self::delete_event_claim_value($key, $existing)) return false;
        if (!add_option($key, $value, '', 'no')) return false;
        self::$active_event_claims[$key] = $value;
        return true;
    }

    /** Conditional DB delete avoids a stale request releasing a newer claim owner. */
    private static function delete_event_claim_value($key, $value) {
        global $wpdb;
        if (!isset($wpdb->options) || !method_exists($wpdb, 'prepare') || !method_exists($wpdb, 'query')) return false;
        $stored_value = function_exists('maybe_serialize') ? maybe_serialize($value) : (string) $value;
        $sql = $wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $key, $stored_value);
        $deleted = $wpdb->query($sql);
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete($key, 'options');
            wp_cache_delete('alloptions', 'options');
            wp_cache_delete('notoptions', 'options');
        }
        return (int) $deleted === 1;
    }

    private static function release_event_claim($dedupe) {
        $key = 'zsb_claim_' . substr(hash('sha256', (string) $dedupe), 0, 48);
        if (!isset(self::$active_event_claims[$key])) return;
        self::delete_event_claim_value($key, self::$active_event_claims[$key]);
        unset(self::$active_event_claims[$key]);
    }


    /** Resolve Rubika chat type so private customer/order data is never processed in groups/channels. */
    private static function rubika_chat_type($chat_id, $token) {
        $chat_id = trim((string) $chat_id);
        if ($chat_id === '' || !is_string($token) || $token === '') return '';
        $cache_key = 'zsb_rubika_chat_type_' . hash('sha256', $chat_id);
        $cached = get_transient($cache_key);
        if (is_string($cached) && in_array($cached, array('User', 'Group', 'Channel', 'Bot'), true)) return $cached;

        $response = (new Channel_API('rubika', $token))->request('getChat', array('chat_id' => $chat_id));
        if (is_wp_error($response)) {
            if (function_exists('zarincode_log_event')) zarincode_log_event('rubika_chat_type_lookup_failed', array('error_code' => sanitize_key($response->get_error_code())));
            return '';
        }
        $data = isset($response['data']) && is_array($response['data']) ? $response['data'] : array();
        $chat = isset($data['chat']) && is_array($data['chat']) ? $data['chat'] : (isset($response['chat']) && is_array($response['chat']) ? $response['chat'] : $data);
        $type = isset($chat['chat_type']) && is_scalar($chat['chat_type']) ? (string) $chat['chat_type'] : '';
        foreach (array('User', 'Group', 'Channel', 'Bot') as $known_type) {
            if (strcasecmp($type, $known_type) === 0) {
                set_transient($cache_key, $known_type, DAY_IN_SECONDS);
                return $known_type;
            }
        }
        return '';
    }

    /** Resolve the human clicking a review button; never authorize by message text alone. */
    private static function callback_actor_id($platform, array $body, $fallback_chat_id) {
        if ($platform === 'bale') {
            if (isset($body['callback_query']['from']['id']) && is_scalar($body['callback_query']['from']['id'])) return (string) $body['callback_query']['from']['id'];
            if (isset($body['message']['from']['id']) && is_scalar($body['message']['from']['id'])) return (string) $body['message']['from']['id'];
        } else {
            $inline = $body['inline_message'] ?? array();
            if (isset($inline['sender_id']) && is_scalar($inline['sender_id'])) return (string) $inline['sender_id'];
            $update = isset($body['update']) && is_array($body['update']) ? $body['update'] : $body;
            $source = isset($update['new_message']) && is_array($update['new_message']) ? $update['new_message'] : array();
            if (isset($source['sender_id']) && is_scalar($source['sender_id'])) return (string) $source['sender_id'];
        }
        return (string) $fallback_chat_id;
    }

    /**
     * Preserve the provider conversation and human sender IDs for the active event.
     * The conversation ID is the destination for a reply; the sender ID is used
     * for identity/session data by the shared Telegram-compatible engine.
     */
    private static function channel_reply_context($platform, array $body, $chat_id) {
        $chat_id = trim((string) $chat_id);
        $sender_id = $chat_id;
        if ($platform === 'bale') {
            $message = isset($body['message']) && is_array($body['message']) ? $body['message'] : array();
            $callback = isset($body['callback_query']) && is_array($body['callback_query']) ? $body['callback_query'] : array();
            $sender = $callback['from'] ?? ($message['from'] ?? array());
            $sender_id = (string) ($sender['id'] ?? $chat_id);
        } elseif ($platform === 'rubika' && isset($body['inline_message']) && is_array($body['inline_message'])) {
            $sender_id = (string) ($body['inline_message']['sender_id'] ?? $chat_id);
        } elseif ($platform === 'rubika') {
            $update = isset($body['update']) && is_array($body['update']) ? $body['update'] : $body;
            $message = isset($update['new_message']) && is_array($update['new_message']) ? $update['new_message'] : array();
            $sender_id = (string) ($message['sender_id'] ?? $chat_id);
        }
        $sender_id = trim($sender_id);
        return array(
            'reply_chat_id' => $chat_id,
            'reply_sender_id' => $sender_id !== '' ? $sender_id : $chat_id,
        );
    }

    /** Answer a Bale callback that is routed through this class instead of the common WooBot handler. */
    private static function acknowledge_direct_bale_callback(array $body, array $options) {
        $callback = isset($body['callback_query']) && is_array($body['callback_query']) ? $body['callback_query'] : array();
        $callback_id = isset($callback['id']) && is_scalar($callback['id']) ? trim((string) $callback['id']) : '';
        if ($callback_id === '') {
            return new \WP_Error('zsb_callback_id_missing', __('شناسهٔ callback بله خالی است.', 'zarinshopbot'));
        }
        $api = new Channel_API('bale', (string) ($options['bale_token'] ?? ''));
        return $api->telegram_call('answerCallbackQuery', array('callback_query_id' => $callback_id, 'text' => ''));
    }

    /** Feed normalized Bale/Rubika updates into the shared WooCommerce bot workflows. */
    private static function run_compat_bot($platform, $chat_id, array $body, array $options) {
        if (!class_exists(\ZarinShopBot\Core\WooBot::class)) { return new \WP_Error('zsb_bot_missing', __('Bot engine unavailable', 'zarinshopbot')); }
        $normalized = self::normalize_update($platform, $body, $chat_id);
        $GLOBALS['zarinshopbot_channel_context'] = array(
            'platform' => $platform,
            'token' => (string) ($options[$platform . '_token'] ?? ''),
            'username' => !empty($options[$platform . '_username']) ? (string) $options[$platform . '_username'] : 'zarinshopbot_' . $platform,
        );
        // Keep sender and conversation identities available to the API bridge on
        // both channels: Rubika sends to chat_id; Bale group commerce replies privately.
        $reply_context = self::channel_reply_context($platform, $body, $chat_id);
        $GLOBALS['zarinshopbot_channel_context'] = array_merge(
            $GLOBALS['zarinshopbot_channel_context'],
            $reply_context,
            array('private_group_reply' => $platform === 'bale' && (string) $reply_context['reply_sender_id'] !== (string) $reply_context['reply_chat_id'])
        );
        $GLOBALS['zarinshopbot_channel_update'] = $normalized;
        try {
            $handled = \ZarinShopBot\Core\WooBot::handle();
            if ($handled === false) {
                if (function_exists('zarincode_log_event')) zarincode_log_event('channel_bot_handler_failed', array('platform' => $platform, 'stage' => 'update_parse_or_persistence'));
                return new \WP_Error('zsb_bot_handler_failed', __('پردازش پیام ربات کامل نشد.', 'zarinshopbot'));
            }
        } catch (\Throwable $error) {
            if (function_exists('zarincode_log_event')) { zarincode_log_event('channel_bot_exception', array('platform' => $platform, 'error_type' => get_class($error))); }
            return new \WP_Error('zsb_bot_exception', __('خطا در اجرای فرایند فروشگاه برای این پیام‌رسان.', 'zarinshopbot'));
        } finally {
            unset($GLOBALS['zarinshopbot_channel_context'], $GLOBALS['zarinshopbot_channel_update']);
        }
        return true;
    }

    /** Resolve an outbound channel destination so delayed WooCommerce notifications use the correct bot. */
    public static function context_for_chat($chat_id) {
        $chat_id = (string) $chat_id;
        foreach (array('bale', 'rubika') as $platform) {
            $prefix = $platform . '_';
            if (strpos($chat_id, $prefix) === 0) {
                $options = self::options();
                if ($options[$platform . '_enabled'] !== '1' || empty($options[$platform . '_token'])) { return array(); }
                return array('platform' => $platform, 'token' => $options[$platform . '_token'], 'username' => $options[$platform . '_username'] ?: 'zarinshopbot_' . $platform);
            }
        }
        return array();
    }

    /** Static bridge called by the legacy Telegram HTTP adapter during a channel webhook. */
    public static function telegram_api_call($method, array $params = array()) {
        $context = $GLOBALS['zarinshopbot_channel_context'] ?? array();
        if (empty($context['platform']) || empty($context['token'])) { return new \WP_Error('zsb_channel_context', __('Missing channel context', 'zarinshopbot')); }
        if (in_array($context['platform'], array('bale', 'rubika'), true)
            && isset($params['chat_id'], $context['reply_chat_id'], $context['reply_sender_id'])) {
            $platform = $context['platform'];
            $requested_chat_id = (string) $params['chat_id'];
            $sender_chat_id = $platform . '_' . (string) $context['reply_sender_id'];
            $conversation_chat_id = $platform . '_' . (string) $context['reply_chat_id'];
            if ($platform === 'rubika' && ($requested_chat_id === $sender_chat_id || $requested_chat_id === $conversation_chat_id)) {
                // Rubika API replies must use the event conversation, while the cart
                // remains owned by the human sender. Never redirect admin destinations.
                $params['chat_id'] = (string) $context['reply_chat_id'];
                if ($requested_chat_id !== $conversation_chat_id && function_exists('zarincode_log_event')) {
                    zarincode_log_event('rubika_reply_chat_id_remapped', array(
                        'sender_differs_from_chat' => (string) $context['reply_sender_id'] !== (string) $context['reply_chat_id'],
                        'method' => sanitize_key((string) $method),
                    ));
                }
            } elseif ($platform === 'bale' && $requested_chat_id === $conversation_chat_id) {
                $is_private_group = !empty($context['private_group_reply'])
                    && (string) $context['reply_sender_id'] !== (string) $context['reply_chat_id'];
                if ($is_private_group && $method === 'editMessageText') {
                    // Never edit a group source message with a user's cart/order
                    // page; make the shared core fall back to a private sendMessage.
                    return new \WP_Error('zsb_bale_group_edit_private', __('در گروه، صفحهٔ فروشگاهی به‌صورت خصوصی برای کاربر ارسال می‌شود.', 'zarinshopbot'));
                }
                if ($is_private_group && $method === 'deleteMessage') {
                    // The callback source belongs to the group, not the sender's
                    // private chat. Keep it intact rather than deleting by a
                    // potentially colliding per-chat message ID.
                    return array('ok' => true, 'result' => true);
                }
                $message_methods = array('sendMessage', 'sendPhoto', 'sendMediaGroup', 'sendVideo', 'sendAudio', 'sendDocument', 'sendAnimation', 'sendVoice');
                if (!$is_private_group || in_array($method, $message_methods, true)) {
                    // Bale's shared core chooses group_chat_id on group events;
                    // route only customer-facing sends to the human sender.
                    $params['chat_id'] = (string) $context['reply_sender_id'];
                    if ($is_private_group && function_exists('zarincode_log_event')) {
                        zarincode_log_event('bale_group_reply_private', array('method' => sanitize_key((string) $method)));
                    }
                }
            }
        }
        $api = new Channel_API($context['platform'], $context['token']);
        return $api->telegram_call($method, $params);
    }

    private static function normalize_update($platform, array $body, $chat_id) {
        $event = self::event_id($platform, $body);
        if ($event === '') { $event = hash('sha256', wp_json_encode($body)); }
        $update_id = (int) sprintf('%u', crc32($platform . ':' . (string) $chat_id . ':' . $event));
        if ($platform === 'rubika' && isset($body['inline_message']) && is_array($body['inline_message'])) {
            $inline = $body['inline_message'];
            $inline_chat = (string) ($inline['chat_id'] ?? $chat_id);
            $sender_id = (string) ($inline['sender_id'] ?? $inline_chat);
            $aux = isset($inline['aux_data']) && is_array($inline['aux_data']) ? $inline['aux_data'] : array();
            $chat = array('id' => 'rubika_' . $inline_chat, 'type' => 'private', 'first_name' => '');
            $user = array('id' => 'rubika_' . $sender_id, 'is_bot' => false, 'first_name' => __('مشتری', 'zarinshopbot'), 'username' => '');
            $inline_message_id = isset($inline['message_id']) && is_scalar($inline['message_id']) ? (string) $inline['message_id'] : '';
            $message = array('message_id' => $inline_message_id, 'date' => time(), 'chat' => $chat, 'from' => $user, 'text' => (string) ($inline['text'] ?? ''));
            return array('update_id' => $update_id, 'callback_query' => array(
                'id' => 'rubika_' . hash('sha256', $event . '|' . $inline_chat . '|' . $sender_id),
                'from' => $user,
                'message' => $message,
                'data' => (string) ($aux['button_id'] ?? ''),
            ));
        }
        $chat = array('id' => $platform . '_' . (string) $chat_id, 'type' => 'private', 'first_name' => '');
        $user = array('id' => $platform . '_' . (string) $chat_id, 'is_bot' => false, 'first_name' => __('مشتری', 'zarinshopbot'), 'username' => '');
        if ($platform === 'bale') {
            $source = isset($body['message']) && is_array($body['message']) ? $body['message'] : array();
            $callback = isset($body['callback_query']) && is_array($body['callback_query']) ? $body['callback_query'] : array();
            if ($callback) { $source = isset($callback['message']) && is_array($callback['message']) ? $callback['message'] : $source; }
            $raw_chat = $source['chat'] ?? array(); $raw_user = $callback['from'] ?? ($source['from'] ?? array());
            $raw_user_id = $raw_user['id'] ?? $chat_id;
            $chat['type'] = in_array(($raw_chat['type'] ?? 'private'), array('group', 'supergroup'), true) ? $raw_chat['type'] : 'private';
            $chat['title'] = (string) ($raw_chat['title'] ?? '');
            $user = array_merge($user, $raw_user, array('id' => $platform . '_' . (string) $raw_user_id));
            $message = array('message_id' => (int) ($source['message_id'] ?? 0), 'date' => (int) ($source['date'] ?? time()), 'chat' => $chat, 'from' => $user, 'text' => self::bale_message_text($source));
            if ($callback) {
                return array('update_id' => $update_id, 'callback_query' => array('id' => (string) ($callback['id'] ?? $event), 'from' => $user, 'message' => $message, 'data' => (string) ($callback['data'] ?? '')));
            }
            return array('update_id' => $update_id, 'message' => $message);
        }
        $update = isset($body['update']) && is_array($body['update']) ? $body['update'] : $body;
        $source = isset($update['new_message']) && is_array($update['new_message']) ? $update['new_message'] : array();
        $aux = isset($source['aux_data']) && is_array($source['aux_data']) ? $source['aux_data'] : array();
        $raw_user_id = (string) ($source['sender_id'] ?? $update['user_id'] ?? $chat_id);
        $chat['id'] = $platform . '_' . (string) $chat_id;
        $user['id'] = $platform . '_' . $raw_user_id;
        $rubika_text = (string) ($source['text'] ?? '');
        if ($rubika_text === '' && isset($source['contact_message']['phone_number']) && is_scalar($source['contact_message']['phone_number'])) {
            $rubika_text = (string) $source['contact_message']['phone_number'];
        }
        if (($update['type'] ?? '') === 'StartedBot') { $start_id = (string) ($update['start_id'] ?? $aux['start_id'] ?? ''); $rubika_text = '/start' . ($start_id !== '' ? ' ' . sanitize_text_field($start_id) : ''); }
        // Rubika documents message_id as string; keep it opaque rather than
        // coercing IDs such as "m_..." to integer zero in the Telegram model.
        $rubika_message_id = isset($source['message_id']) && is_scalar($source['message_id']) ? (string) $source['message_id'] : '';
        $message = array('message_id' => $rubika_message_id, 'date' => (int) ($source['time'] ?? time()), 'chat' => $chat, 'from' => $user, 'text' => $rubika_text);
        if (!empty($aux['button_id'])) {
            return array('update_id' => $update_id, 'callback_query' => array('id' => 'rubika_' . $event, 'from' => $user, 'message' => $message, 'data' => (string) $aux['button_id']));
        }
        return array('update_id' => $update_id, 'message' => $message);
    }

    private static function event_id($platform, array $body) {
        if ($platform === 'bale') { return isset($body['update_id']) ? (string) $body['update_id'] : ''; }
        if (isset($body['inline_message']) && is_array($body['inline_message'])) {
            $inline = $body['inline_message'];
            return hash('sha256', implode('|', array(
                (string) ($inline['chat_id'] ?? ''),
                (string) ($inline['sender_id'] ?? ''),
                (string) ($inline['message_id'] ?? ''),
                (string) ($inline['aux_data']['button_id'] ?? ''),
                (string) ($inline['text'] ?? ''),
            )));
        }
        $update = isset($body['update']) && is_array($body['update']) ? $body['update'] : $body;
        if (isset($update['update_id'])) { return (string) $update['update_id']; }
        return isset($update['new_message']['message_id']) ? (string) $update['new_message']['message_id'] : '';
    }

    /** Return Bale message text, accepting a shared contact only when its user_id matches from.id. */
    private static function bale_message_text(array $message) {
        if (isset($message['text']) && is_scalar($message['text']) && (string) $message['text'] !== '') {
            return (string) $message['text'];
        }
        $contact = isset($message['contact']) && is_array($message['contact']) ? $message['contact'] : array();
        $from = isset($message['from']) && is_array($message['from']) ? $message['from'] : array();
        $from_id = $from['id'] ?? null;
        $contact_user_id = $contact['user_id'] ?? null;
        $phone = $contact['phone_number'] ?? null;
        if (is_scalar($from_id) && is_scalar($contact_user_id) && is_scalar($phone)
            && (string) $from_id !== '' && hash_equals((string) $from_id, (string) $contact_user_id)) {
            return (string) $phone;
        }
        return '';
    }

    private static function extract_message($platform, array $body) {
        if ($platform === 'bale') {
            $message = isset($body['message']) && is_array($body['message']) ? $body['message'] : array();
            $callback = isset($body['callback_query']) && is_array($body['callback_query']) ? $body['callback_query'] : array();
            $source = isset($callback['message']) && is_array($callback['message']) ? $callback['message'] : $message;
            $chat = isset($source['chat']['id']) ? $source['chat']['id'] : '';
            $text = isset($callback['data']) && is_scalar($callback['data']) ? (string) $callback['data'] : self::bale_message_text($source);
            return array('chat_id' => $chat, 'text' => $text);
        }
        // Rubika inline-keypad taps arrive as a separate InlineMessage webhook,
        // not as Update.new_message. Normalize that shape before dispatching.
        if (isset($body['inline_message']) && is_array($body['inline_message'])) {
            $inline = $body['inline_message'];
            $aux = isset($inline['aux_data']) && is_array($inline['aux_data']) ? $inline['aux_data'] : array();
            return array(
                'chat_id' => isset($inline['chat_id']) ? $inline['chat_id'] : '',
                'text' => !empty($aux['button_id']) ? $aux['button_id'] : (isset($inline['text']) ? $inline['text'] : ''),
            );
        }
        $update = isset($body['update']) && is_array($body['update']) ? $body['update'] : $body;
        $message = isset($update['new_message']) && is_array($update['new_message']) ? $update['new_message'] : array();
        $aux = isset($message['aux_data']) && is_array($message['aux_data']) ? $message['aux_data'] : array();
        $text = !empty($aux['button_id']) ? $aux['button_id'] : (isset($message['text']) ? $message['text'] : '');
        if (($update['type'] ?? '') === 'StartedBot') {
            $start_id = (string) ($update['start_id'] ?? $aux['start_id'] ?? '');
            $text = '/start' . ($start_id !== '' ? ' ' . sanitize_text_field($start_id) : '');
        }
        return array('chat_id' => isset($update['chat_id']) ? $update['chat_id'] : '', 'text' => $text);
    }

    /** Keep per-user carts private: Bale replies to the sender in groups, Rubika replies to the conversation. */
    private static function channel_dispatch_context($platform, array $body, $chat_id) {
        $reply_context = self::channel_reply_context($platform, $body, $chat_id);
        $sender_id = trim((string) ($reply_context['reply_sender_id'] ?? $chat_id));
        if ($sender_id === '') $sender_id = trim((string) $chat_id);
        $conversation_id = trim((string) $chat_id);
        return array(
            'reply_chat_id' => $platform === 'bale' ? $sender_id : $conversation_id,
            'cart_owner_id' => $sender_id,
            'private_group_reply' => $platform === 'bale' && $sender_id !== $conversation_id,
        );
    }

    private static function dispatch($platform, $chat_id, $input, array $options, array $body = array()) {
        $api = new Channel_API($platform, $options[$platform . '_token']);
        $input = trim(sanitize_text_field((string) $input));
        $dispatch_context = self::channel_dispatch_context($platform, $body, $chat_id);
        $reply_chat_id = $dispatch_context['reply_chat_id'];
        $cart_owner_id = $dispatch_context['cart_owner_id'];
        if ($platform === 'bale') {
            $source = isset($body['callback_query']['message']) && is_array($body['callback_query']['message'])
                ? $body['callback_query']['message'] : (isset($body['message']) && is_array($body['message']) ? $body['message'] : array());
            $chat_type = (string) ($source['chat']['type'] ?? 'private');
            if (in_array($chat_type, array('group', 'supergroup'), true)
                && function_exists('zarincode_option') && !zarincode_option('enabledingroups')) {
                if (function_exists('zarincode_log_event')) zarincode_log_event('bale_group_commerce_blocked_by_setting', array('chat_type' => sanitize_key($chat_type)));
                return true;
            }
        }
        if (strpos($input, 'zs:') === 0) {
            $parts = explode(':', $input);
            if (isset($parts[1]) && $parts[1] === 'add' && isset($parts[2])) {
                return self::add_product($api, $platform, $reply_chat_id, absint($parts[2]), $cart_owner_id);
            }
            if (isset($parts[1]) && $parts[1] === 'cart') { return self::show_cart($api, $platform, $reply_chat_id, $cart_owner_id); }
            if (isset($parts[1]) && $parts[1] === 'checkout') {
                self::begin_shared_checkout($api, $platform, $reply_chat_id, $body, $options, $cart_owner_id, !empty($dispatch_context['private_group_reply']));
                return true;
            }
            if (isset($parts[1]) && $parts[1] === 'products') { return self::show_products($api, $platform, $reply_chat_id, ''); }
        }
        if (preg_match('/\A\/(start|home|help)\b/i', $input) || $input === '') {
            return $api->send($reply_chat_id, __('به فروشگاه زرین خوش آمدید. برای یافتن کالای دلخواه، نام محصول را بفرستید یا از گزینه‌های منو استفاده کنید.', 'zarinshopbot'), array(array(__('🛍 محصولات', 'zarinshopbot'), 'zs:products'), array(__('🛒 سبد خرید', 'zarinshopbot'), 'zs:cart')));
        }
        if (preg_match('/\A\/(products|shop)\b/i', $input)) { return self::show_products($api, $platform, $reply_chat_id, ''); }
        if (preg_match('/\A\/(cart)\b/i', $input)) { return self::show_cart($api, $platform, $reply_chat_id, $cart_owner_id); }
        if (preg_match('/\A\/(checkout)\b/i', $input)) {
            self::begin_shared_checkout($api, $platform, $reply_chat_id, $body, $options, $cart_owner_id, !empty($dispatch_context['private_group_reply']));
            return true;
        }
        $term = preg_replace('/\A\/search\s*/iu', '', $input);
        return self::show_products($api, $platform, $reply_chat_id, $term);
    }

    private static function plain_product_name($product) {
        if (!is_object($product) || !method_exists($product, 'get_name')) return '';
        $name = (string) $product->get_name();
        return class_exists('\\ZarinShopBot\\Core\\WooBot')
            ? \ZarinShopBot\Core\WooBot::productDisplayTitle($product)
            : sanitize_text_field($name);
    }

    private static function show_products(Channel_API $api, $platform, $chat_id, $term) {
        $args = array('status' => 'publish', 'limit' => 6, 'orderby' => 'date', 'order' => 'DESC', 'return' => 'objects');
        if ($term !== '') { $args['s'] = $term; }
        $products = wc_get_products($args);
        if (!$products) {
            return $api->send($chat_id, $term ? __('محصولی با این عبارت پیدا نشد. عبارت دیگری را امتحان کنید.', 'zarinshopbot') : __('هنوز محصولی برای نمایش وجود ندارد.', 'zarinshopbot'), array(array(__('🛍 همه محصولات', 'zarinshopbot'), 'zs:products'), array(__('🛒 سبد خرید', 'zarinshopbot'), 'zs:cart')));
        }
        $actions = array(); $lines = array($term ? __('نتایج جست‌وجو:', 'zarinshopbot') : __('محصولات تازه فروشگاه:', 'zarinshopbot'));
        foreach ($products as $product) {
            if (!$product->is_visible()) { continue; }
            $price = wp_strip_all_tags(wc_price(wc_get_price_to_display($product)));
            $product_name = self::plain_product_name($product);
            $lines[] = sprintf(__("\n%s — %s\n%s", 'zarinshopbot'), $product_name, $price, get_permalink($product->get_id()));
            if ($product->is_purchasable() && $product->is_in_stock() && !$product->is_type('variable') && !$product->is_type('grouped')) {
                $actions[] = array(sprintf(__('افزودن: %s', 'zarinshopbot'), self::short_label($product_name)), 'zs:add:' . $product->get_id());
            }
        }
        $actions[] = array(__('🛍 محصولات', 'zarinshopbot'), 'zs:products'); $actions[] = array(__('🛒 سبد خرید', 'zarinshopbot'), 'zs:cart');
        return $api->send($chat_id, implode("\n", $lines), array_slice($actions, 0, 12));
    }

    private static function add_product(Channel_API $api, $platform, $chat_id, $product_id, $cart_owner_id = null) {
        $product = wc_get_product($product_id);
        if (!$product || !$product->is_purchasable() || !$product->is_in_stock() || $product->is_type('variable') || $product->is_type('grouped')) {
            return $api->send($chat_id, __('این محصول در حال حاضر از طریق ربات قابل سفارش نیست.', 'zarinshopbot'), array(array(__('🛍 محصولات', 'zarinshopbot'), 'zs:products')));
        }
        $key = self::cart_key($platform, $cart_owner_id !== null ? $cart_owner_id : $chat_id); $cart = get_transient($key); $cart = is_array($cart) ? $cart : array();
        $next_quantity = min(99, (isset($cart[$product_id]) ? absint($cart[$product_id]) : 0) + 1);
        if (!$product->has_enough_stock($next_quantity)) {
            return $api->send($chat_id, __('موجودی کافی برای تعداد درخواستی در سبد وجود ندارد.', 'zarinshopbot'), array(array(__('🛒 مشاهده سبد', 'zarinshopbot'), 'zs:cart'), array(__('🛍 محصولات', 'zarinshopbot'), 'zs:products')));
        }
        $cart[$product_id] = $next_quantity;
        set_transient($key, $cart, 14 * DAY_IN_SECONDS);
        return $api->send($chat_id, sprintf(__('محصول به سبد خرید افزوده شد: %s', 'zarinshopbot'), self::plain_product_name($product)), array(array(__('🛒 مشاهده سبد', 'zarinshopbot'), 'zs:cart'), array(__('ادامه خرید', 'zarinshopbot'), 'zs:products')));
    }

    private static function show_cart(Channel_API $api, $platform, $chat_id, $cart_owner_id = null) {
        $cart_key = self::cart_key($platform, $cart_owner_id !== null ? $cart_owner_id : $chat_id);
        $cart = get_transient($cart_key); $cart = is_array($cart) ? $cart : array();
        if (!$cart) { return $api->send($chat_id, __('سبد خرید شما خالی است.', 'zarinshopbot'), array(array(__('🛍 مشاهده محصولات', 'zarinshopbot'), 'zs:products'))); }
        $lines = array(__('سبد خرید شما:', 'zarinshopbot')); $total = 0; $valid = array();
        foreach ($cart as $id => $qty) {
            $product = wc_get_product($id); $qty = max(1, absint($qty));
            if (!$product || !$product->is_purchasable()) { continue; }
            $line = (float) wc_get_price_to_display($product) * $qty; $total += $line; $valid[$id] = $qty;
            $lines[] = sprintf(__("\n%s × %d — %s", 'zarinshopbot'), self::plain_product_name($product), $qty, wp_strip_all_tags(wc_price($line)));
        }
        set_transient($cart_key, $valid, 14 * DAY_IN_SECONDS);
        if (!$valid) {
            delete_transient($cart_key);
            return $api->send($chat_id, __('محصولات سبد دیگر قابل سفارش نیستند.', 'zarinshopbot'), array(array(__('🛍 محصولات', 'zarinshopbot'), 'zs:products')));
        }
        $lines[] = sprintf(__("\nجمع تقریبی: %s\nهزینهٔ ارسال و تخفیف در تسویه‌حساب نهایی می‌شود.", 'zarinshopbot'), wp_strip_all_tags(wc_price($total)));
        return $api->send($chat_id, implode('', $lines), array(array(__('✅ ادامه به تسویه‌حساب', 'zarinshopbot'), 'zs:checkout'), array(__('🛍 ادامه خرید', 'zarinshopbot'), 'zs:products')));
    }

    private static function begin_shared_checkout(Channel_API $api, $platform, $chat_id, array $body, array $options, $cart_owner_id = null, $private_group_reply = false) {
        $cart_key = self::cart_key($platform, $cart_owner_id !== null ? $cart_owner_id : $chat_id);
        $cart = get_transient($cart_key);
        $cart = is_array($cart) ? $cart : array();
        if (!$cart) {
            $api->send($chat_id, __('سبد خرید شما خالی است.', 'zarinshopbot'), array(array(__('🛍 مشاهده محصولات', 'zarinshopbot'), 'zs:products')));
            return;
        }
        if (!class_exists(\ZarinShopBot\Core\WooBot::class)) {
            $api->send($chat_id, __('فرایند سفارش ووکامرس در دسترس نیست؛ لطفاً با فروشگاه تماس بگیرید.', 'zarinshopbot'));
            return;
        }

        $context_chat_id = $chat_id;
        if ($platform === 'bale' && $private_group_reply) {
            $source_message = isset($body['callback_query']['message']) && is_array($body['callback_query']['message'])
                ? $body['callback_query']['message'] : (isset($body['message']) && is_array($body['message']) ? $body['message'] : array());
            if (isset($source_message['chat']['id']) && is_scalar($source_message['chat']['id'])) $context_chat_id = (string) $source_message['chat']['id'];
        }
        $reply_context = self::channel_reply_context($platform, $body, $context_chat_id);
        $GLOBALS['zarinshopbot_channel_context'] = array_merge(array(
            'platform' => $platform,
            'token' => (string) ($options[$platform . '_token'] ?? ''),
            'username' => !empty($options[$platform . '_username']) ? (string) $options[$platform . '_username'] : 'zarinshopbot_' . $platform,
        ), $reply_context, array(
            'private_group_reply' => (bool) $private_group_reply,
            'cart_owner_id' => (string) ($cart_owner_id !== null ? $cart_owner_id : $reply_context['reply_sender_id']),
        ));
        try {
            $bot = \ZarinShopBot\Core\WooBot::class;
            // User/session data belongs to sender_id; Rubika API replies still
            // target the separate chat_id held in the active request context.
            $bot::setChatId($platform . '_' . self::unprefix_id((string) $reply_context['reply_sender_id']));
            $bot::init('in');
            $user = $bot::getUser();
            if (empty($user)) { $bot::updateUser(0); }
            $bot::initSession();
            $bot::saveCart($cart);
            $bot::updateSession();

            $normalized = self::normalize_update($platform, $body, $chat_id);
            if (isset($normalized['callback_query'])) {
                $normalized['callback_query']['data'] = '/CHECKOUT';
            } elseif (isset($normalized['message'])) {
                $normalized['message']['text'] = '/CHECKOUT';
            } else {
                $api->send($chat_id, __('درخواست تسویه‌حساب معتبر نیست؛ لطفاً از دکمهٔ سبد خرید دوباره اقدام کنید.', 'zarinshopbot'));
                return;
            }
            $GLOBALS['zarinshopbot_channel_update'] = $normalized;
            $bot::handle();
        } catch (\Throwable $error) {
            if (function_exists('zarincode_log_event')) { zarincode_log_event('channel_checkout_exception', array('platform' => $platform, 'error_type' => get_class($error))); }
            $api->send($chat_id, __('هنگام شروع تسویه‌حساب خطایی رخ داد؛ سبد خرید حفظ شده است. لطفاً دوباره تلاش کنید یا با فروشگاه تماس بگیرید.', 'zarinshopbot'));
        } finally {
            unset($GLOBALS['zarinshopbot_channel_context'], $GLOBALS['zarinshopbot_channel_update']);
        }
    }

    private static function checkout(Channel_API $api, $platform, $chat_id) {
        $cart = get_transient(self::cart_key($platform, $chat_id)); $cart = is_array($cart) ? $cart : array();
        if (!$cart) { $api->send($chat_id, __('سبد خرید شما خالی است.', 'zarinshopbot'), array(array(__('🛍 مشاهده محصولات', 'zarinshopbot'), 'zs:products'))); return; }
        $token = wp_generate_password(48, false, false);
        set_transient('zsb_checkout_' . hash('sha256', $token), array('platform' => $platform, 'chat' => (string) $chat_id, 'cart' => $cart), 15 * MINUTE_IN_SECONDS);
        $url = add_query_arg('zarinshopbot_cart', rawurlencode($token), wc_get_checkout_url());
        $api->send($chat_id, sprintf(__("برای تکمیل سفارش و پرداخت امن، این پیوند را باز کنید (اعتبار ۱۵ دقیقه):\n%s", 'zarinshopbot'), $url));
    }

    /** Clear bot/channel cart state only after payment and only if it still matches the order snapshot. */
    public static function clearPaidOrderCart($order_id) {
        if (!function_exists('wc_get_order')) return;
        $order = wc_get_order(absint($order_id));
        if (!$order instanceof \WC_Order) return;
        $platform = sanitize_key((string) $order->get_meta('_order_from', true));
        if (!in_array($platform, array('telegram', 'bale', 'rubika'), true)) return;
        $fingerprint = (string) $order->get_meta('_zarinshopbot_cart_fingerprint', true);
        $chat_id = (string) $order->get_meta('_chat_id', true);
        if ($fingerprint === '' || $chat_id === '') return;

        if (in_array($platform, array('bale', 'rubika'), true)) {
            $owner = (string) $order->get_meta('_zarinshopbot_channel_cart_owner', true);
            if ($owner === '') $owner = preg_replace('/\A' . preg_quote($platform . '_', '/') . '/', '', $chat_id);
            $transient_key = self::cart_key($platform, $owner);
            $channel_cart = get_transient($transient_key);
            if (is_array($channel_cart) && class_exists(\ZarinShopBot\Core\WooBot::class)
                && hash_equals($fingerprint, \ZarinShopBot\Core\WooBot::cartFingerprint($channel_cart))) {
                delete_transient($transient_key);
            }
        }

        if (class_exists(\ZarinShopBot\Core\WooBot::class)
            && method_exists(\ZarinShopBot\Core\WooBot::class, 'setChatId')
            && method_exists(\ZarinShopBot\Core\WooBot::class, 'initSession')) {
            $bot = \ZarinShopBot\Core\WooBot::class;
            $bot::setChatId($chat_id);
            $bot::initSession();
            $bot_cart = $bot::getCart();
            if (is_array($bot_cart) && hash_equals($fingerprint, $bot::cartFingerprint($bot_cart))) {
                $bot::emptyCart();
                $bot::updateSession();
            }
        }
    }

    private static function cart_key($platform, $chat_id) { return 'zsb_cart_' . hash('sha256', $platform . '|' . (string) $chat_id); }
    private static function short_label($text) { $text = sanitize_text_field($text); return Channel_API::utf8_substr($text, 0, 22); }

    public static function consume_checkout_link() {
        if (empty($_GET['zarinshopbot_cart']) || !function_exists('WC') || !WC()->cart) { return; }
        $token = sanitize_text_field(wp_unslash($_GET['zarinshopbot_cart']));
        if (!preg_match('/\A[A-Za-z0-9]+\z/', $token)) { return; }
        $key = 'zsb_checkout_' . hash('sha256', $token); $payload = get_transient($key);
        if (!is_array($payload) || empty($payload['cart'])) { return; }
        delete_transient($key);
        WC()->cart->empty_cart();
        foreach ($payload['cart'] as $product_id => $quantity) {
            $product = wc_get_product($product_id);
            if ($product && $product->is_purchasable() && $product->is_in_stock() && !$product->is_type('variable')) {
                WC()->cart->add_to_cart($product->get_id(), min(99, max(1, absint($quantity))));
            }
        }
        if (WC()->cart->is_empty()) { wc_add_notice(__('سبد خرید پیوندشده دیگر قابل سفارش نیست.', 'zarinshopbot'), 'error'); }
        wp_safe_redirect(wc_get_checkout_url());
        exit;
    }
}
