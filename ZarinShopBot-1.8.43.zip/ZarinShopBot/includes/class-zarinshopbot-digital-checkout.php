<?php
/* Modified 2026-10-28 by Zarincode.com. Derived code remains under GPL-2.0-or-later. */
namespace ZarinShopBot;

if (!defined('ABSPATH')) { exit; }

/**
 * Enforce recipient identity on WooCommerce website checkout and keep digital
 * goods out of shipping packages. Required fields are validated server-side.
 */
final class Digital_Checkout {
    public static function boot() {
        add_filter('woocommerce_product_needs_shipping', array(__CLASS__, 'filter_product_needs_shipping'), 20, 2);
        add_filter('woocommerce_cart_needs_shipping', array(__CLASS__, 'filter_cart_needs_shipping'), 20, 1);
        add_filter('woocommerce_checkout_fields', array(__CLASS__, 'filter_checkout_fields'), 20, 1);
        add_filter('woocommerce_checkout_posted_data', array(__CLASS__, 'filter_posted_data'), 20, 1);
        add_filter('the_content', array(__CLASS__, 'force_classic_checkout_for_digital_cart'), 8, 1);
        add_filter('render_block', array(__CLASS__, 'replace_checkout_block_for_digital_cart'), 10, 2);
        add_action('woocommerce_after_checkout_validation', array(__CLASS__, 'validate_checkout'), 20, 2);
        add_action('woocommerce_checkout_validate_order_before_payment', array(__CLASS__, 'validate_order_before_payment'), 20, 2);
        // Store API requests can be made directly even when the storefront replaces
        // Checkout Blocks with the classic form. Validate both supported API hooks.
        add_action('woocommerce_store_api_checkout_update_order_from_request', array(__CLASS__, 'validate_store_api_checkout'), 20, 2);
        add_action('woocommerce_store_api_checkout_order_processed', array(__CLASS__, 'validate_store_api_order_processed'), 20, 1);
        add_filter('woocommerce_checkout_registration_enabled', array(__CLASS__, 'checkout_registration_enabled'), 20, 1);
        add_filter('woocommerce_checkout_registration_required', array(__CLASS__, 'checkout_registration_required'), 20, 1);
        add_action('woocommerce_checkout_create_order', array(__CLASS__, 'save_custom_order_fields'), 20, 2);
        add_action('woocommerce_checkout_create_order', array(__CLASS__, 'link_verified_customer'), 30, 2);
    }

    /** Return true only when every valid cart line resolves to a downloadable product. */
    public static function cart_is_downloadable_only() {
        if (!self::cart_items()) return false;
        foreach (self::cart_items() as $item) {
            $product = is_array($item) ? ($item['data'] ?? null) : null;
            if (!$product || !is_object($product) || !method_exists($product, 'exists') || !$product->exists()) return false;
            if (!method_exists($product, 'is_downloadable') || !$product->is_downloadable()) return false;
            if (method_exists($product, 'needs_shipping') && $product->needs_shipping()) return false;
        }
        return true;
    }

    private static function cart_items() {
        if (!function_exists('WC') || !WC() || !isset(WC()->cart) || !is_object(WC()->cart)) return array();
        $items = WC()->cart->get_cart();
        return is_array($items) ? $items : array();
    }

    private static function cart_has_items() {
        return !empty(self::cart_items());
    }

    /** Avoid assumptions about the concrete order class while still rejecting non-order inputs. */
    private static function isWooOrder($order) {
        return is_object($order) && is_a($order, 'WC_Order');
    }

    public static function filter_product_needs_shipping($needs_shipping, $product) {
        // Downloadable is not synonymous with virtual: preserve WooCommerce's
        // true shipping requirement for products that ship a physical copy too.
        return (bool) $needs_shipping;
    }

    public static function filter_cart_needs_shipping($needs_shipping) {
        return self::cart_is_downloadable_only() ? false : $needs_shipping;
    }

    /** Return the configured default/custom checkout fields for the active cart profile. */
    public static function configured_checkout_fields($digital_only = null) {
        if ($digital_only === null) $digital_only = self::cart_is_downloadable_only();
        $profile = $digital_only ? 'downloadable' : 'physical';
        $defaults = [];
        $standard = ['billing_first_name', 'billing_last_name', 'billing_company', 'billing_country', 'billing_state', 'billing_city', 'billing_address_1', 'billing_address_2', 'billing_postcode', 'billing_phone', 'billing_email', 'shipping_first_name', 'shipping_last_name', 'shipping_company', 'shipping_country', 'shipping_state', 'shipping_city', 'shipping_address_1', 'shipping_address_2', 'shipping_postcode', 'order_comments'];
        foreach ($standard as $key) {
            $enabled = !$digital_only && (strpos($key, 'shipping_') === 0 || in_array($key, ['billing_first_name', 'billing_last_name', 'billing_company', 'billing_country', 'billing_state', 'billing_city', 'billing_address_1', 'billing_address_2', 'billing_postcode', 'billing_phone', 'billing_email', 'order_comments'], true));
            if ($digital_only && in_array($key, ['billing_first_name', 'billing_last_name', 'billing_phone', 'billing_email'], true)) $enabled = true;
            $required = in_array($key, ['billing_first_name', 'billing_phone', 'billing_email'], true);
            $defaults[$key] = ['enabled' => $enabled, 'required' => $required];
        }
        $settings = get_option('zarincode_settings', []);
        $saved = is_array($settings) ? ($settings['wc_checkout_fields'][$profile] ?? []) : [];
        if (is_array($saved)) {
            foreach ($saved as $key => $config) {
                if (!isset($defaults[$key]) || !is_array($config)) continue;
                $defaults[$key] = ['enabled' => !empty($config['enabled']), 'required' => !empty($config['required'])];
                if ($defaults[$key]['required']) $defaults[$key]['enabled'] = true;
            }
        }
        $account_policy = (string) ($settings['customer_account_policy'] ?? 'optional');
        if (($settings['phone_sms_verification'] ?? '0') === '1' || $account_policy === 'account') {
            $defaults['billing_phone'] = ['enabled' => true, 'required' => true];
        }
        if ($account_policy === 'account') {
            foreach (['billing_first_name', 'billing_last_name', 'billing_email'] as $required_key) $defaults[$required_key] = ['enabled' => true, 'required' => true];
        }
        $custom = [];
        $custom_json = is_array($settings) ? (string) ($settings['custom_checkout_fields_json'] ?? '') : '';
        $custom_decoded = $custom_json !== '' ? json_decode($custom_json, true) : [];
        if (is_array($custom_decoded)) {
            foreach ($custom_decoded as $field) {
                if (!is_array($field) || empty($field['key']) || empty($field['label']) || empty($field['profiles']) || !in_array($profile, (array) $field['profiles'], true)) continue;
                $custom[] = $field;
            }
        }
        return ['profile' => $profile, 'fields' => $defaults, 'custom' => $custom];
    }

    /** Apply the saved profile to WooCommerce's default classic checkout fields. */
    public static function filter_checkout_fields($fields) {
        if (!self::cart_has_items() || !is_array($fields)) return $fields;
        $profile = self::configured_checkout_fields();
        $settings = (array) get_option('zarincode_settings', []);
        if (($settings['customer_account_policy'] ?? 'optional') === 'account') {
            foreach (['billing_first_name', 'billing_last_name', 'billing_phone', 'billing_email'] as $required_identity_field) {
                $profile['fields'][$required_identity_field] = ['enabled' => true, 'required' => true];
            }
        }
        foreach (['billing' => 'billing_', 'shipping' => 'shipping_', 'order' => 'order_'] as $group => $prefix) {
            if (!isset($fields[$group]) || !is_array($fields[$group])) continue;
            foreach ($fields[$group] as $key => $field) {
                $config = $profile['fields'][$key] ?? null;
                if ($config === null) continue; // retain third-party fields not managed here
                if (empty($config['enabled'])) { unset($fields[$group][$key]); continue; }
                $field = is_array($field) ? $field : [];
                $field['required'] = !empty($config['required']);
                if ($key === 'billing_phone') $field['type'] = 'tel';
                if ($key === 'billing_email') $field['type'] = 'email';
                $fields[$group][$key] = $field;
            }
        }
        foreach ($profile['custom'] as $custom) {
            $key = 'billing_zsb_custom_' . sanitize_key($custom['key']);
            $type = in_array(($custom['type'] ?? 'text'), ['text', 'email', 'tel', 'textarea', 'select'], true) ? $custom['type'] : 'text';
            $field = ['type' => $type, 'label' => sanitize_text_field($custom['label']), 'required' => !empty($custom['required']), 'class' => ['form-row-wide'], 'priority' => 120];
            if ($type === 'select') {
                $field['options'] = [];
                foreach ((array) ($custom['options'] ?? []) as $option) { $option = sanitize_text_field($option); if ($option !== '') $field['options'][$option] = $option; }
            }
            $fields['billing'][$key] = $field;
        }
        return $fields;
    }

    /** Do not blank the billing email for downloadable orders. */
    public static function filter_posted_data($data) {
        if (!is_array($data)) return $data;
        $profile = self::configured_checkout_fields();
        foreach ($profile['fields'] as $key => $config) {
            if (empty($config['enabled']) && array_key_exists($key, $data)) unset($data[$key]);
        }
        foreach ($profile['custom'] as $custom) {
            $key = 'billing_zsb_custom_' . sanitize_key($custom['key']);
            if (!array_key_exists($key, $data)) continue;
            $type = $custom['type'] ?? 'text';
            $value = is_scalar($data[$key]) ? (string) $data[$key] : '';
            if ($type === 'email') $data[$key] = sanitize_email($value);
            elseif ($type === 'textarea') $data[$key] = sanitize_textarea_field($value);
            else $data[$key] = sanitize_text_field($value);
        }
        return $data;
    }

    public static function save_custom_order_fields($order, $data) {
        if (!self::isWooOrder($order)) return;
        $profile = self::configured_checkout_fields();
        foreach ($profile['custom'] as $custom) {
            $input_key = 'billing_zsb_custom_' . sanitize_key($custom['key']);
            if (!isset($_POST[$input_key])) continue;
            $raw = wp_unslash($_POST[$input_key]);
            if (is_array($raw)) continue;
            $value = ($custom['type'] ?? '') === 'email' ? sanitize_email($raw) : (($custom['type'] ?? '') === 'textarea' ? sanitize_textarea_field($raw) : sanitize_text_field($raw));
            if ($value !== '') $order->update_meta_data('_zsb_custom_' . sanitize_key($custom['key']), $value);
        }
    }

    public static function link_verified_customer($order, $data) {
        if (!self::isWooOrder($order)) return;
        $settings = (array) get_option('zarincode_settings', []);
        $policy = sanitize_key((string) ($settings['customer_account_policy'] ?? 'optional'));
        if ($policy === 'guest') return;
        $phone = (string) $order->get_billing_phone();
        $scope = Phone_Accounts::checkoutScope();
        $customer_id = Phone_Accounts::customerIdForOrder($phone, (string) $order->get_billing_email(), trim((string) $order->get_billing_first_name() . ' ' . (string) $order->get_billing_last_name()), $scope);
        if (is_wp_error($customer_id)) return;
        if ($customer_id > 0) $order->set_customer_id($customer_id);
    }

    /** Enforce required recipient data server-side; do not rely on browser validation. */
    public static function validate_checkout($data, $errors) {
        if (!self::cart_has_items() || !is_object($errors) || !method_exists($errors, 'add')) return;
        $profile = self::configured_checkout_fields();
        $settings = (array) get_option('zarincode_settings', []);
        $account_policy = $settings['customer_account_policy'] ?? 'optional';
        $phone = trim((string) (is_array($data) ? ($data['billing_phone'] ?? '') : ''));
        $phone_required = !empty($profile['fields']['billing_phone']['required']) || $account_policy === 'account';
        if ($phone_required && $phone === '') $errors->add('zsb_checkout_phone_required', self::checkout_text('شماره تلفن الزامی است.', 'A phone number is required.'));
        if ($phone !== '' && !self::is_valid_phone($phone)) $errors->add('zsb_checkout_phone_invalid', self::checkout_text('یک شمارهٔ تلفن معتبر وارد کنید.', 'Please enter a valid phone number.'));
        if (($settings['phone_sms_verification'] ?? '0') === '1' || $account_policy === 'account') {
            $scope = Phone_Accounts::checkoutScope();
            if ($scope === '' || !Phone_Accounts::isVerified($phone, $scope)) $errors->add('zsb_checkout_phone_unverified', self::checkout_text('شمارهٔ تلفن را با کد پیامکی تأیید کنید.', 'Please verify your phone number by SMS.'));
        }
    }

    /** Checkout Blocks do not consistently honor classic field filters. */
    public static function force_classic_checkout_for_digital_cart($content) {
        if (!function_exists('is_checkout') || !is_checkout() || !self::cart_has_items()) return $content;
        return do_shortcode('[woocommerce_checkout]');
    }

    /** Replace a Checkout block rendered from a site-editor template as well. */
    public static function replace_checkout_block_for_digital_cart($block_content, $block) {
        if (!function_exists('is_checkout') || !is_checkout() || !self::cart_has_items() || !is_array($block) || ($block['blockName'] ?? '') !== 'woocommerce/checkout') return $block_content;
        return do_shortcode('[woocommerce_checkout]');
    }

    /** Final order validation fallback for themes using an alternate classic form. */
    public static function validate_order_before_payment($order, $errors) {
        if (!self::cart_has_items() || !self::isWooOrder($order) || !is_object($errors) || !method_exists($errors, 'add')) return;
        $settings = (array) get_option('zarincode_settings', []);
        $profile = self::configured_checkout_fields();
        $required = !empty($profile['fields']['billing_phone']['required']) || ($settings['customer_account_policy'] ?? 'optional') === 'account';
        $phone = trim((string) $order->get_billing_phone());
        if ($required && $phone === '') $errors->add('zsb_checkout_phone_required', self::checkout_text('شماره تلفن الزامی است.', 'A phone number is required.'));
        if ($phone !== '' && !self::is_valid_phone($phone)) $errors->add('zsb_checkout_phone_invalid', self::checkout_text('یک شمارهٔ تلفن معتبر وارد کنید.', 'Please enter a valid phone number.'));
        if (($settings['phone_sms_verification'] ?? '0') === '1' || ($settings['customer_account_policy'] ?? 'optional') === 'account') {
            $scope = Phone_Accounts::checkoutScope();
            if ($scope === '' || !Phone_Accounts::isVerified($phone, $scope)) $errors->add('zsb_checkout_phone_unverified', self::checkout_text('شمارهٔ تلفن را با کد پیامکی تأیید کنید.', 'Please verify your phone number by SMS.'));
        }
    }

    /** Reject direct Store API checkout requests that omit recipient identity. */
    public static function validate_store_api_checkout($order, $request) {
        if (!is_object($request) || !method_exists($request, 'get_method') || strtoupper((string) $request->get_method()) !== 'POST') return;
        self::validate_store_api_order_processed($order);
    }

    /** Fallback hook for Store API versions that do not expose the earlier request hook. */
    public static function validate_store_api_order_processed($order) {
        if (!self::cart_has_items() || !self::isWooOrder($order)) return;
        $settings = (array) get_option('zarincode_settings', []);
        $profile = self::configured_checkout_fields();
        $phone = trim((string) $order->get_billing_phone());
        $required = !empty($profile['fields']['billing_phone']['required']) || ($settings['customer_account_policy'] ?? 'optional') === 'account';
        $error = null;
        if ($required && $phone === '') $error = ['zsb_checkout_phone_required', self::checkout_text('شماره تلفن الزامی است.', 'A phone number is required.')];
        elseif ($phone !== '' && !self::is_valid_phone($phone)) $error = ['zsb_checkout_phone_invalid', self::checkout_text('یک شمارهٔ تلفن معتبر وارد کنید.', 'Please enter a valid phone number.')];
        elseif (($settings['phone_sms_verification'] ?? '0') === '1' || ($settings['customer_account_policy'] ?? 'optional') === 'account') {
            $scope = Phone_Accounts::checkoutScope();
            if ($scope === '' || !Phone_Accounts::isVerified($phone, $scope)) $error = ['zsb_checkout_phone_unverified', self::checkout_text('شمارهٔ تلفن را با کد پیامکی تأیید کنید.', 'Please verify your phone number by SMS.')];
        }
        if (!$error) return;
        $exception_class = 'Automattic\WooCommerce\StoreApi\Exceptions\RouteException';
        if (class_exists($exception_class)) throw new $exception_class($error[0], $error[1], 400);
        throw new \RuntimeException($error[1]);
    }

    private static function is_valid_phone($phone) {
        $phone = trim((string) $phone);
        $digits = preg_replace('/\D/u', '', $phone);
        if (!is_string($digits) || strlen($digits) < 6 || strlen($digits) > 15) return false;
        if (class_exists('WC_Validation') && method_exists('WC_Validation', 'is_phone')) return (bool) \WC_Validation::is_phone($phone);
        return preg_match('/\A[0-9\s#_+\/().-]{6,32}\z/u', $phone) === 1;
    }

    private static function checkout_text($persian, $english) {
        $locale = function_exists('determine_locale') ? (string) determine_locale() : (function_exists('get_locale') ? (string) get_locale() : '');
        return strpos(strtolower($locale), 'fa') === 0 ? $persian : __($english, 'zarinshopbot');
    }

    public static function checkout_registration_enabled($enabled) {
        $settings = (array) get_option('zarincode_settings', []);
        $policy = $settings['customer_account_policy'] ?? 'optional';
        if ($policy === 'guest') return false;
        if ($policy === 'account') return true;
        return true;
    }

    public static function checkout_registration_required($required) {
        $settings = (array) get_option('zarincode_settings', []);
        return ($settings['customer_account_policy'] ?? 'optional') === 'account' ? true : false;
    }
}

Digital_Checkout::boot();
