<?php
/** Telegram credential access, migration, and independent enable switch. */
if (!defined('ABSPATH')) { exit; }

if (!function_exists('zarincode_get_telegram_token')) {
    function zarincode_get_telegram_token($options = null) {
        if (!is_array($options)) { $options = get_option('zarincode_settings', array()); }
        $options = is_array($options) ? $options : array();
        $stored = (string) ($options['token_enc'] ?? $options['token'] ?? '');
        if ((strpos($stored, 'gcm:') === 0 || strpos($stored, 'sod:') === 0 || strpos($stored, 'plain:') === 0) && class_exists('\\ZarinShopBot\\Core\\Http\\ProxyManager')) {
            return \ZarinShopBot\Core\Http\ProxyManager::decrypt($stored);
        }
        return $stored;
    }
}

if (!function_exists('zarincode_telegram_enabled')) {
    function zarincode_telegram_enabled() {
        $options = get_option('zarincode_settings', array());
        $options = is_array($options) ? $options : array();
        $enabled = array_key_exists('telegram_enabled', $options) ? (string) $options['telegram_enabled'] === '1' : zarincode_get_telegram_token($options) !== '';
        return $enabled && zarincode_get_telegram_token($options) !== '';
    }
}

/** Migrate the legacy Telegram token to authenticated-at-rest storage without changing its runtime value. */
function zarincode_migrate_telegram_token_secret() {
    $options = get_option('zarincode_settings', array());
    if (!is_array($options) || !class_exists('\\ZarinShopBot\\Core\\Http\\ProxyManager')) { return; }
    $token = isset($options['token']) ? (string) $options['token'] : '';
    if ($token !== '' && strpos($token, 'gcm:') !== 0 && strpos($token, 'sod:') !== 0 && strpos($token, 'plain:') !== 0) {
        $options['token_enc'] = \ZarinShopBot\Core\Http\ProxyManager::encrypt($token);
        unset($options['token']);
        update_option('zarincode_settings', $options, false);
    }
}
add_action('init', 'zarincode_migrate_telegram_token_secret', 1);


