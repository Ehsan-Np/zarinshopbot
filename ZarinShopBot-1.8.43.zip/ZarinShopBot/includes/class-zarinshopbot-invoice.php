<?php
/**
 * Self-contained WooCommerce order invoice PDF and Code 128 barcode.
 * No remote service, CDN, PDF executable or PHP package is used at runtime.
 */
namespace ZarinShopBot;

if (!defined('ABSPATH')) exit;

final class Invoice {
    const ACTION = 'zsb_download_order_invoice';
    const FONT_PATH = 'assets/fonts/DejaVuSans.ttf';
    const METRICS_PATH = 'assets/fonts/DejaVuSans-metrics.json';
    private static $metrics = null;

    /** Use a string class name so optional WooCommerce load order never requires a PHP class token. */
    private static function isWooOrder($order) {
        return is_object($order) && is_a($order, 'WC_Order');
    }

    public static function boot() {
        add_action('woocommerce_order_details_after_order_table', [__CLASS__, 'renderOrderDownloadLink'], 30, 1);
        add_action('woocommerce_email_after_order_table', [__CLASS__, 'renderEmailDownloadLink'], 30, 4);
        add_filter('woocommerce_my_account_my_orders_actions', [__CLASS__, 'addMyAccountAction'], 30, 2);
        add_action('admin_post_' . self::ACTION, [__CLASS__, 'download']);
        add_action('admin_post_nopriv_' . self::ACTION, [__CLASS__, 'download']);
    }

    public static function addMyAccountAction($actions, $order) {
        if (!self::isWooOrder($order)) return $actions;
        $actions['zsb_invoice'] = [
            'url' => self::downloadUrl($order),
            'name' => __('Download invoice PDF', 'zarinshopbot'),
        ];
        return $actions;
    }

    public static function renderOrderDownloadLink($order) {
        if (!self::isWooOrder($order)) return;
        echo '<p class="zsb-order-invoice-download"><a class="button" rel="nofollow" href="' . esc_url(self::downloadUrl($order)) . '">' . esc_html__('Download order invoice (PDF)', 'zarinshopbot') . '</a></p>';
    }

    public static function renderEmailDownloadLink($order, $sent_to_admin, $plain_text, $email) {
        if ($sent_to_admin || !self::isWooOrder($order)) return;
        $url = self::downloadUrl($order);
        if ($plain_text) echo esc_html__('Download order invoice (PDF)', 'zarinshopbot') . ': ' . esc_url_raw($url) . "\n";
        else echo '<p><a href="' . esc_url($url) . '">' . esc_html__('Download order invoice (PDF)', 'zarinshopbot') . '</a></p>';
    }

    /** Create a bot-facing invoice link only when the order belongs to this exact chat. */
    public static function getBotDownloadUrl($order, $chat_id) {
        if (!self::isWooOrder($order)) return '';
        $chat_id = self::normalizeChatIdentity($chat_id);
        $owner_chat_id = self::normalizeChatIdentity($order->get_meta('_chat_id', true));
        if ($chat_id === '' || $owner_chat_id === '' || !hash_equals($owner_chat_id, $chat_id)) return '';
        return set_url_scheme(self::downloadUrl($order), 'https');
    }

    private static function normalizeChatIdentity($chat_id) {
        $chat_id = trim((string) $chat_id);
        return strtr($chat_id, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ));
    }

    private static function downloadUrl($order) {
        return add_query_arg([
            'action' => self::ACTION,
            'order_id' => (int) $order->get_id(),
            'key' => (string) $order->get_order_key(),
        ], admin_url('admin-post.php'));
    }

    public static function download() {
        if (!function_exists('wc_get_order')) wp_die(esc_html__('WooCommerce is required.', 'zarinshopbot'), '', ['response' => 503]);
        $order_id = isset($_GET['order_id']) ? absint(wp_unslash($_GET['order_id'])) : 0;
        $order = $order_id ? wc_get_order($order_id) : false;
        if (!self::isWooOrder($order)) wp_die(esc_html__('Order not found.', 'zarinshopbot'), '', ['response' => 404]);

        $provided_key = isset($_GET['key']) ? wc_clean(wp_unslash($_GET['key'])) : '';
        $key_ok = $provided_key !== '' && hash_equals((string) $order->get_order_key(), (string) $provided_key);
        $owner_ok = is_user_logged_in() && (int) get_current_user_id() === (int) $order->get_user_id();
        if (!$key_ok && !$owner_ok) wp_die(esc_html__('You are not allowed to download this order invoice.', 'zarinshopbot'), '', ['response' => 403]);

        $pdf = self::buildOrderPdf($order);
        if (is_wp_error($pdf)) wp_die(esc_html($pdf->get_error_message()), '', ['response' => 500]);
        $filename = 'order-invoice-' . sanitize_file_name((string) $order->get_order_number()) . '.pdf';
        nocache_headers();
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"; filename*=UTF-8\'\'' . rawurlencode($filename));
        header('Content-Length: ' . strlen($pdf));
        header('X-Content-Type-Options: nosniff');
        echo $pdf;
        exit;
    }

    public static function buildOrderPdf($order) {
        if (!self::isWooOrder($order)) return new \WP_Error('zsb_invoice_order', __('Order not found.', 'zarinshopbot'));
        $metrics = self::getMetrics();
        $font_path = dirname(__DIR__) . '/' . self::FONT_PATH;
        if (!$metrics || !is_readable($font_path)) return new \WP_Error('zsb_invoice_assets', __('The bundled invoice font or metrics file is unavailable.', 'zarinshopbot'));

        $items = [];
        foreach ($order->get_items('line_item') as $item) {
            if (!is_object($item) || !method_exists($item, 'get_name')) continue;
            $items[] = [
                'name' => (string) $item->get_name(),
                'quantity' => (string) $item->get_quantity(),
                'unit' => self::plainPrice((float) $item->get_subtotal() / max(1, (float) $item->get_quantity()), $order->get_currency()),
                'total' => self::plainPrice((float) $item->get_total() + (float) $item->get_total_tax(), $order->get_currency()),
            ];
        }
        if (!$items) $items[] = ['name' => __('No line items', 'zarinshopbot'), 'quantity' => '0', 'unit' => '', 'total' => ''];

        $pages = [];
        $chunks = array_chunk($items, 12);
        foreach ($chunks as $page_index => $chunk) {
            $is_first = $page_index === 0;
            $is_last = $page_index === count($chunks) - 1;
            $pages[] = self::renderInvoicePage($order, $chunk, $page_index + 1, count($chunks), $is_first, $is_last);
        }
        $font_bytes = @file_get_contents($font_path);
        if (!is_string($font_bytes) || $font_bytes === '') return new \WP_Error('zsb_invoice_font_read', __('The bundled invoice font could not be read.', 'zarinshopbot'));
        return self::assemblePdf($pages, $font_bytes, $metrics);
    }

    private static function renderInvoicePage($order, $items, $page_number, $page_count, $first, $last) {
        $pdf = new Invoice_Pdf_Page(self::getMetrics());
        $ink = [25, 37, 58];
        $muted = [94, 107, 125];
        $brand = [12, 93, 99];
        $pdf->rect(0, 0, 595, 86, $ink);
        $pdf->text(555, 30, get_bloginfo('name'), 16, [255,255,255], 'right');
        $pdf->text(555, 57, __('Order invoice', 'zarinshopbot'), 12, [205,235,232], 'right');
        $pdf->text(40, 38, '#' . (string) $order->get_order_number(), 12, [255,255,255], 'left');
        $pdf->text(40, 59, sprintf(__('Page %1$d of %2$d', 'zarinshopbot'), $page_number, $page_count), 8, [205,219,232], 'left');

        $table_top = $first ? 278 : 157;
        if ($first) {
            $pdf->text(40, 117, __('Seller', 'zarinshopbot'), 10, $brand, 'left');
            $pdf->text(40, 136, get_bloginfo('name'), 9, $ink, 'left');
            $shop_address = self::storeAddress();
            if ($shop_address !== '') $pdf->text(40, 154, self::shortenText($shop_address, 64), 7, $muted, 'left');
            $shop_email = sanitize_email((string) get_option('woocommerce_email_from_address', ''));
            if ($shop_email !== '') $pdf->text(40, 170, $shop_email, 7, $muted, 'left');
            $pdf->text(555, 117, __('Order details', 'zarinshopbot'), 11, $brand, 'right');
            $pdf->line(40, 129, 555, 129, [214,224,230], 0.8);
            $date = $order->get_date_created();
            $date_text = $date ? $date->date_i18n(get_option('date_format') . ' ' . get_option('time_format')) : '';
            $pdf->text(555, 151, __('Invoice number', 'zarinshopbot') . ': ' . (string) $order->get_order_number(), 9, $ink, 'right');
            $pdf->text(555, 171, __('Order date', 'zarinshopbot') . ': ' . $date_text, 9, $ink, 'right');
            $pdf->text(555, 191, __('Payment method', 'zarinshopbot') . ': ' . (string) $order->get_payment_method_title(), 9, $ink, 'right');
            $pdf->text(555, 211, __('Order status', 'zarinshopbot') . ': ' . wc_get_order_status_name($order->get_status()), 9, $ink, 'right');
            $billing_name = trim((string) $order->get_formatted_billing_full_name());
            $pdf->text(40, 203, __('Bill to', 'zarinshopbot'), 9, $brand, 'left');
            $pdf->text(40, 220, $billing_name !== '' ? $billing_name : __('Customer', 'zarinshopbot'), 8, $ink, 'left');
            $formatted_address = preg_replace('~<br\s*/?>~i', ', ', (string) $order->get_formatted_billing_address());
            $address = self::shortenText(trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($formatted_address))), 68);
            if ($address !== '') $pdf->text(40, 238, $address, 7, $muted, 'left');
            $contact_parts = [];
            if ((string) $order->get_billing_email() !== '') $contact_parts[] = __('Email', 'zarinshopbot') . ': ' . (string) $order->get_billing_email();
            if ((string) $order->get_billing_phone() !== '') $contact_parts[] = __('Phone', 'zarinshopbot') . ': ' . (string) $order->get_billing_phone();
            $contact = implode('   ', $contact_parts);
            if ($contact !== '') $pdf->text(40, 255, self::shortenText($contact, 68), 7, $muted, 'left');
        } else {
            $pdf->text(555, 119, __('Order', 'zarinshopbot') . ' #' . (string) $order->get_order_number(), 10, $muted, 'right');
        }

        $pdf->rect(40, $table_top, 515, 26, [232,240,243]);
        $pdf->text(340, $table_top + 8, __('Product', 'zarinshopbot'), 8, $ink, 'right');
        $pdf->text(390, $table_top + 8, __('Qty', 'zarinshopbot'), 8, $ink, 'right');
        $pdf->text(465, $table_top + 8, __('Unit price', 'zarinshopbot'), 8, $ink, 'right');
        $pdf->text(550, $table_top + 8, __('Line total', 'zarinshopbot'), 8, $ink, 'right');
        $y = $table_top + 31;
        foreach ($items as $index => $item) {
            if (($index % 2) === 1) $pdf->rect(40, $y - 3, 515, 24, [249,251,252]);
            $name = self::shortenText($item['name'], 55);
            $pdf->text(340, $y, $name, 8, $ink, 'right');
            $pdf->text(390, $y, $item['quantity'], 8, $ink, 'right');
            $pdf->text(465, $y, $item['unit'], 8, $ink, 'right');
            $pdf->text(550, $y, $item['total'], 8, $ink, 'right');
            $y += 24;
        }
        $pdf->line(40, $y - 4, 555, $y - 4, [214,224,230], 0.7);

        if ($last) {
            $totals = $order->get_order_item_totals();
            $ty = max($y + 13, 593);
            $pdf->text(555, $ty, __('Totals', 'zarinshopbot'), 9, $brand, 'right');
            $ty += 18;
            foreach ((array) $totals as $total) {
                if (!is_array($total)) continue;
                $label = trim(wp_strip_all_tags(html_entity_decode((string) ($total['label'] ?? ''), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8')));
                $value = trim(wp_strip_all_tags(html_entity_decode((string) ($total['value'] ?? ''), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8')));
                if ($label === '' && $value === '') continue;
                $pdf->text(555, $ty, $label, 8, $muted, 'right');
                $pdf->text(410, $ty, $value, 8, $ink, 'right');
                $ty += 16;
            }
            $barcode = self::barcodeValue($order);
            $pdf->text(555, 733, __('Invoice barcode', 'zarinshopbot'), 8, $muted, 'right');
            $pdf->barcode(55, 746, 485, 37, $barcode);
            $pdf->text(297, 790, $barcode, 8, $ink, 'center');
        }
        $pdf->line(40, 817, 555, 817, [214,224,230], 0.7);
        $pdf->text(555, 823, __('Generated locally by the store website.', 'zarinshopbot'), 7, $muted, 'right');
        return $pdf->content();
    }

    private static function barcodeValue($order) {
        $order_id = absint($order->get_id());
        $reference = 'ZSB-' . $order_id;
        $signature = strtoupper(substr(hash_hmac('sha256', $reference . '|' . (string) $order->get_order_key(), wp_salt('auth')), 0, 12));
        return $reference . '-' . $signature;
    }

    private static function shortenText($text, $max_chars) {
        $chars = preg_split('//u', (string) $text, -1, PREG_SPLIT_NO_EMPTY);
        if (!is_array($chars) || count($chars) <= $max_chars) return (string) $text;
        return implode('', array_slice($chars, 0, max(1, $max_chars - 1))) . '…';
    }

    private static function plainPrice($amount, $currency) {
        if (function_exists('wc_price')) return trim(html_entity_decode(wp_strip_all_tags(wc_price($amount, ['currency' => $currency])), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8'));
        return number_format((float) $amount, 2, '.', ' ') . ' ' . $currency;
    }

    private static function storeAddress() {
        $parts = array_filter([
            trim((string) get_option('woocommerce_store_address', '')),
            trim((string) get_option('woocommerce_store_address_2', '')),
            trim((string) get_option('woocommerce_store_postcode', '') . ' ' . (string) get_option('woocommerce_store_city', '')),
        ], 'strlen');
        $location = explode(':', (string) get_option('woocommerce_default_country', ''));
        $country_code = strtoupper(sanitize_key($location[0] ?? ''));
        if ($country_code !== '' && function_exists('WC') && WC() && isset(WC()->countries->countries[$country_code])) $parts[] = WC()->countries->countries[$country_code];
        elseif ($country_code !== '') $parts[] = $country_code;
        return implode(', ', $parts);
    }

    private static function getMetrics() {
        if (self::$metrics !== null) return self::$metrics;
        $path = dirname(__DIR__) . '/' . self::METRICS_PATH;
        $json = is_readable($path) ? file_get_contents($path) : false;
        $data = is_string($json) ? json_decode($json, true) : null;
        self::$metrics = is_array($data) && isset($data['cmap'], $data['widths']) ? $data : false;
        return self::$metrics;
    }

    private static function assemblePdf($pages, $font_bytes, $metrics) {
        $used_glyphs = [];
        foreach ($pages as $content) {
            if (preg_match_all('/<([0-9A-F]+)> Tj/', $content, $matches)) {
                foreach ($matches[1] as $hex) {
                    for ($i = 0; $i + 3 < strlen($hex); $i += 4) {
                        $used_glyphs[hexdec(substr($hex, $i, 4))] = true;
                    }
                }
            }
        }
        $unicode_by_gid = [];
        foreach ((array) $metrics['cmap'] as $codepoint => $gid) {
            $gid = (int) $gid;
            // Prefer ordinary Unicode code points over presentation-form aliases when both map to a glyph.
            if (!isset($unicode_by_gid[$gid]) || ((int)$codepoint < 0xFB00 && $unicode_by_gid[$gid] >= 0xFB00)) $unicode_by_gid[$gid] = (int) $codepoint;
        }
        $glyph_map = [];
        foreach ($used_glyphs as $gid => $_) $glyph_map[(int)$gid] = (int)($unicode_by_gid[$gid] ?? 63);
        // Keep streams uncompressed so generation does not require the optional zlib extension.
        $embedded_font = $font_bytes;

        $objects = [];
        $reserve = function() use (&$objects) { $objects[] = null; return count($objects); };
        $add = function($value) use (&$objects) { $objects[] = $value; return count($objects); };
        $catalog_id = $reserve();
        $pages_id = $reserve();
        $fontfile_id = $add('<< /Length ' . strlen($embedded_font) . ' /Length1 ' . strlen($font_bytes) . ' >>' . "\nstream\n" . $embedded_font . "\nendstream");
        $bbox = implode(' ', array_map('intval', $metrics['bbox']));
        $descriptor_id = $add('<< /Type /FontDescriptor /FontName /DejaVuSans /Flags 32 /FontBBox [' . $bbox . '] /ItalicAngle 0 /Ascent ' . (int)$metrics['ascent'] . ' /Descent ' . (int)$metrics['descent'] . ' /CapHeight ' . (int)$metrics['capheight'] . ' /StemV 80 /FontFile2 ' . $fontfile_id . ' 0 R >>');
        $width_defs = [];
        foreach (array_keys($glyph_map) as $gid) {
            $width = isset($metrics['widths'][$gid]) ? (int) $metrics['widths'][$gid] : 600;
            $width_defs[] = (int)$gid . ' [' . $width . ']';
        }
        $cidfont_id = $add('<< /Type /Font /Subtype /CIDFontType2 /BaseFont /DejaVuSans /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /FontDescriptor ' . $descriptor_id . ' 0 R /DW 600 /W [' . implode(' ', $width_defs) . '] /CIDToGIDMap /Identity >>');
        $cmap = self::toUnicodeCmap($glyph_map);
        $cmap_id = $add('<< /Length ' . strlen($cmap) . ' >>' . "\nstream\n" . $cmap . "\nendstream");
        $type0_id = $add('<< /Type /Font /Subtype /Type0 /BaseFont /DejaVuSans /Encoding /Identity-H /DescendantFonts [' . $cidfont_id . ' 0 R] /ToUnicode ' . $cmap_id . ' 0 R >>');
        $page_ids = [];
        foreach ($pages as $content) {
            $content_id = $add('<< /Length ' . strlen($content) . ' >>' . "\nstream\n" . $content . "\nendstream");
            $page_id = $add('<< /Type /Page /Parent ' . $pages_id . ' 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ' . $type0_id . ' 0 R >> >> /Contents ' . $content_id . ' 0 R >>');
            $page_ids[] = $page_id;
        }
        $objects[$pages_id - 1] = '<< /Type /Pages /Kids [' . implode(' ', array_map(function($id) { return $id . ' 0 R'; }, $page_ids)) . '] /Count ' . count($page_ids) . ' >>';
        $objects[$catalog_id - 1] = '<< /Type /Catalog /Pages ' . $pages_id . ' 0 R >>';

        $pdf = "%PDF-1.7\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [0];
        foreach ($objects as $index => $body) {
            $offsets[] = strlen($pdf);
            $pdf .= ($index + 1) . " 0 obj\n" . $body . "\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= 'xref' . "\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= count($objects); $i++) $pdf .= sprintf('%010d 00000 n ', $offsets[$i]) . "\n";
        $pdf .= 'trailer << /Size ' . (count($objects) + 1) . ' /Root ' . $catalog_id . ' 0 R >>' . "\nstartxref\n" . $xref . "\n%%EOF";
        return $pdf;
    }

    private static function toUnicodeCmap($glyph_map) {
        $lines = [
            '/CIDInit /ProcSet findresource begin', '12 dict begin', 'begincmap',
            '/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def',
            '/CMapName /ZarinShopBot-UCS def', '/CMapType 2 def',
            '1 begincodespacerange', '<0000> <FFFF>', 'endcodespacerange',
        ];
        $pairs = [];
        foreach ($glyph_map as $gid => $unicode) $pairs[] = '<' . sprintf('%04X', (int)$gid) . '> <' . self::utf16Hex((int)$unicode) . '>';
        foreach (array_chunk($pairs, 100) as $chunk) {
            $lines[] = count($chunk) . ' beginbfchar';
            foreach ($chunk as $pair) $lines[] = $pair;
            $lines[] = 'endbfchar';
        }
        $lines[] = 'endcmap';
        $lines[] = 'CMapName currentdict /CMap defineresource pop';
        $lines[] = 'end'; $lines[] = 'end';
        return implode("\n", $lines);
    }

    private static function utf16Hex($cp) {
        if ($cp <= 0xFFFF) return sprintf('%04X', $cp);
        $cp -= 0x10000;
        return sprintf('%04X%04X', 0xD800 + ($cp >> 10), 0xDC00 + ($cp & 0x3FF));
    }
}

/** Small internal PDF page writer: vector primitives, embedded TrueType font and standard Code 128-B. */
final class Invoice_Pdf_Page {
    private $metrics;
    private $stream = '';
    private static $arabic_forms = null;
    private static $code128_patterns = [
        '212222','222122','222221','121223','121322','131222','122213','122312','132212','221213',
        '221312','231212','112232','122132','122231','113222','123122','123221','223211','221132',
        '221231','213212','223112','312131','311222','321122','321221','312212','322112','322211',
        '212123','212321','232121','111323','131123','131321','112313','132113','132311','211313',
        '231113','231311','112133','112331','132131','113123','113321','133121','313121','211331',
        '231131','213113','213311','213131','311123','311321','331121','312113','312311','332111',
        '314111','221411','431111','111224','111422','121124','121421','141122','141221','112214',
        '112412','122114','122411','142112','142211','241211','221114','413111','241112','134111',
        '111242','121142','121241','114212','124112','124211','411212','421112','421211','212141',
        '214121','412121','111143','111341','131141','114113','114311','411113','411311','113141',
        '114131','311141','411131','211412','211214','211232','2331112',
    ];

    public function __construct($metrics) { $this->metrics = $metrics; }
    public function content() { return $this->stream; }

    private static function pdfNum($number, $decimals = 3) { return number_format((float) $number, $decimals, '.', ''); }

    public function rect($x, $top, $width, $height, $rgb) {
        $y = 842 - $top - $height;
        $this->stream .= self::pdfNum($rgb[0]/255) . ' ' . self::pdfNum($rgb[1]/255) . ' ' . self::pdfNum($rgb[2]/255) . ' rg ' . self::pdfNum($x) . ' ' . self::pdfNum($y) . ' ' . self::pdfNum($width) . ' ' . self::pdfNum($height) . " re f\n";
    }
    public function line($x1, $top1, $x2, $top2, $rgb, $width=1) {
        $this->stream .= self::pdfNum($rgb[0]/255) . ' ' . self::pdfNum($rgb[1]/255) . ' ' . self::pdfNum($rgb[2]/255) . ' RG ' . self::pdfNum($width, 2) . ' w ' . self::pdfNum($x1) . ' ' . self::pdfNum(842-$top1) . ' m ' . self::pdfNum($x2) . ' ' . self::pdfNum(842-$top2) . " l S\n";
    }

    public function text($x, $top, $text, $size=10, $rgb=[0,0,0], $align='left') {
        $glyphs = $this->shapeAndBidi((string)$text);
        if (!$glyphs) return;
        $hex = ''; $width_units = 0;
        foreach ($glyphs as $glyph) {
            $gid = (int)$glyph[0]; $hex .= sprintf('%04X', $gid);
            $width_units += (int)($this->metrics['widths'][$gid] ?? 600);
        }
        $width = $width_units * $size / 1000;
        if ($align === 'right') $x -= $width;
        elseif ($align === 'center') $x -= $width / 2;
        $baseline = 842 - $top - $size;
        $this->stream .= self::pdfNum($rgb[0]/255) . ' ' . self::pdfNum($rgb[1]/255) . ' ' . self::pdfNum($rgb[2]/255) . ' rg BT /F1 ' . self::pdfNum($size, 2) . ' Tf 1 0 0 1 ' . self::pdfNum($x) . ' ' . self::pdfNum($baseline) . ' Tm <' . $hex . "> Tj ET\n";
    }

    public function barcode($x, $top, $width, $height, $data) {
        $patterns = self::$code128_patterns;
        if (count($patterns) !== 107) return;
        $bytes = array_values(unpack('C*', (string)$data));
        $values = [104];
        foreach ($bytes as $byte) {
            if ($byte < 32 || $byte > 126) continue;
            $values[] = $byte - 32;
        }
        if (count($values) < 2) return;
        $check = 104;
        for ($i = 1; $i < count($values); $i++) $check += $values[$i] * $i;
        $values[] = $check % 103;
        $values[] = 106;
        $modules = 20;
        foreach ($values as $value) foreach (str_split($patterns[$value]) as $part) $modules += (int)$part;
        $scale = $width / max(1, $modules);
        $cursor = $x + 10 * $scale;
        $bar = true;
        foreach ($values as $value) {
            foreach (str_split($patterns[$value]) as $part) {
                $w = (int)$part * $scale;
                if ($bar) $this->rect($cursor, $top, $w, $height, [16, 25, 38]);
                $cursor += $w;
                $bar = !$bar;
            }
        }
    }

    private function shapeAndBidi($text) {
        $codepoints = self::utf8Codepoints(html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8'));
        if (!$codepoints) return [];
        $forms = self::arabicForms();
        $shaped = [];
        foreach ($codepoints as $i => $cp) {
            $form_cp = $cp;
            if (isset($forms[$cp])) {
                $prev = $i > 0 ? $codepoints[$i-1] : null;
                $next = isset($codepoints[$i+1]) ? $codepoints[$i+1] : null;
                $prev_join = $prev !== null && isset($forms[$prev]) && count($forms[$prev]) >= 3 && count($forms[$prev]) === 4;
                $current_dual = count($forms[$cp]) === 4;
                $joins_prev = $prev_join && (count($forms[$cp]) >= 2);
                $next_joinable = $next !== null && isset($forms[$next]) && (count($forms[$next]) === 4 || count($forms[$next]) === 2);
                $joins_next = $current_dual && $next_joinable;
                $slot = ($joins_prev && $joins_next) ? 3 : (($joins_prev) ? 1 : (($joins_next) ? 2 : 0));
                $form_cp = $forms[$cp][$slot] ?? $forms[$cp][0];
            }
            $shaped[] = [$form_cp, $cp];
        }
        // Resolve neutral punctuation using the nearest strong direction.
        $dirs = [];
        foreach ($shaped as $i => $entry) {
            $cp = $entry[1];
            if (($cp >= 0x0590 && $cp <= 0x08FF) || ($cp >= 0xFB1D && $cp <= 0xFEFF)) $dirs[$i] = 'R';
            elseif (($cp >= 0x30 && $cp <= 0x39) || ($cp >= 0x41 && $cp <= 0x5A) || ($cp >= 0x61 && $cp <= 0x7A)) $dirs[$i] = 'L';
        }
        $base = 'L'; foreach ($dirs as $dir) { $base = $dir; break; }
        for ($i=0; $i<count($shaped); $i++) {
            if (isset($dirs[$i])) continue;
            $left = null; for ($j=$i-1; $j>=0; $j--) if (isset($dirs[$j])) { $left=$dirs[$j]; break; }
            $right = null; for ($j=$i+1; $j<count($shaped); $j++) if (isset($dirs[$j])) { $right=$dirs[$j]; break; }
            $dirs[$i] = ($left !== null && $right !== null && $left === $right) ? $left : ($left ?? $right ?? $base);
        }
        $runs=[]; foreach ($shaped as $i=>$entry) { $d=$dirs[$i] ?? $base; $last=count($runs)-1; if ($last<0 || $runs[$last]['dir']!==$d) $runs[]=['dir'=>$d,'chars'=>[]]; $runs[count($runs)-1]['chars'][]=$entry; }
        if ($base === 'R') $runs = array_reverse($runs);
        $visual=[];
        foreach ($runs as $run) {
            $chars=$run['chars'];
            if ($run['dir']==='R') $chars=array_reverse($chars);
            foreach ($chars as $entry) {
                $cp=$entry[0]; $gid=(int)($this->metrics['cmap'][(string)$cp] ?? $this->metrics['cmap']['63'] ?? 0);
                $visual[]=[$gid,$entry[1]];
            }
        }
        return $visual;
    }

    private static function utf8Codepoints($text) {
        $out=[]; $bytes=unpack('C*',(string)$text); if (!is_array($bytes)) return $out; $bytes=array_values($bytes);
        for ($i=0,$n=count($bytes);$i<$n;) {
            $b=$bytes[$i++];
            if ($b<0x80) {$out[]=$b;continue;}
            if (($b&0xE0)===0xC0 && $i<$n) {$out[]=(($b&0x1F)<<6)|($bytes[$i++]&0x3F);continue;}
            if (($b&0xF0)===0xE0 && $i+1<$n) {$out[]=(($b&0x0F)<<12)|(($bytes[$i]&0x3F)<<6)|($bytes[$i+1]&0x3F);$i+=2;continue;}
            if (($b&0xF8)===0xF0 && $i+2<$n) {$out[]=(($b&7)<<18)|(($bytes[$i]&0x3F)<<12)|(($bytes[$i+1]&0x3F)<<6)|($bytes[$i+2]&0x3F);$i+=3;continue;}
            $out[]=63;
        }
        return $out;
    }

    private static function arabicForms() {
        if (self::$arabic_forms !== null) return self::$arabic_forms;
        self::$arabic_forms = [
            0x0621=>[0xFE80],0x0622=>[0xFE81,0xFE82],0x0623=>[0xFE83,0xFE84],0x0624=>[0xFE85,0xFE86],0x0625=>[0xFE87,0xFE88],
            0x0626=>[0xFE89,0xFE8A,0xFE8B,0xFE8C],0x0627=>[0xFE8D,0xFE8E],0x0628=>[0xFE8F,0xFE90,0xFE91,0xFE92],
            0x0629=>[0xFE93,0xFE94],0x062A=>[0xFE95,0xFE96,0xFE97,0xFE98],0x062B=>[0xFE99,0xFE9A,0xFE9B,0xFE9C],
            0x062C=>[0xFE9D,0xFE9E,0xFE9F,0xFEA0],0x062D=>[0xFEA1,0xFEA2,0xFEA3,0xFEA4],0x062E=>[0xFEA5,0xFEA6,0xFEA7,0xFEA8],
            0x062F=>[0xFEA9,0xFEAA],0x0630=>[0xFEAB,0xFEAC],0x0631=>[0xFEAD,0xFEAE],0x0632=>[0xFEAF,0xFEB0],
            0x0633=>[0xFEB1,0xFEB2,0xFEB3,0xFEB4],0x0634=>[0xFEB5,0xFEB6,0xFEB7,0xFEB8],0x0635=>[0xFEB9,0xFEBA,0xFEBB,0xFEBC],
            0x0636=>[0xFEBD,0xFEBE,0xFEBF,0xFEC0],0x0637=>[0xFEC1,0xFEC2,0xFEC3,0xFEC4],0x0638=>[0xFEC5,0xFEC6,0xFEC7,0xFEC8],
            0x0639=>[0xFEC9,0xFECA,0xFECB,0xFECC],0x063A=>[0xFECD,0xFECE,0xFECF,0xFED0],0x0641=>[0xFED1,0xFED2,0xFED3,0xFED4],
            0x0642=>[0xFED5,0xFED6,0xFED7,0xFED8],0x0643=>[0xFED9,0xFEDA,0xFEDB,0xFEDC],0x0644=>[0xFEDD,0xFEDE,0xFEDF,0xFEE0],
            0x0645=>[0xFEE1,0xFEE2,0xFEE3,0xFEE4],0x0646=>[0xFEE5,0xFEE6,0xFEE7,0xFEE8],0x0647=>[0xFEE9,0xFEEA,0xFEEB,0xFEEC],
            0x0648=>[0xFEED,0xFEEE],0x0649=>[0xFEEF,0xFEF0],0x064A=>[0xFEF1,0xFEF2,0xFEF3,0xFEF4],
            0x067E=>[0xFB56,0xFB57,0xFB58,0xFB59],0x0686=>[0xFB7A,0xFB7B,0xFB7C,0xFB7D],0x0698=>[0xFB8A,0xFB8B],
            0x06A9=>[0xFB8E,0xFB8F,0xFB90,0xFB91],0x06AF=>[0xFB92,0xFB93,0xFB94,0xFB95],0x06BE=>[0xFBAA,0xFBAB,0xFBAC,0xFBAD],
            0x06C0=>[0xFBA4,0xFBA5],0x06C1=>[0xFBA6,0xFBA7,0xFBA8,0xFBA9],0x06CC=>[0xFBFC,0xFBFD,0xFBFE,0xFBFF],0x06D2=>[0xFBAE,0xFBAF],
        ];
        return self::$arabic_forms;
    }
}
