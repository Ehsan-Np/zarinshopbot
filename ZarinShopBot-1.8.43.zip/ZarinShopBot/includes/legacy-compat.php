<?php
if (!defined('ABSPATH')) exit;

// Keep prior Zarincode page URLs functional while the canonical settings route is namespaced.
add_action('admin_init', function () {
    if (!isset($_GET['page'])) return;
    $legacy = sanitize_key(wp_unslash($_GET['page']));
    $map = array(
        'zarincode_main' => 'zarincode_zarinshopbot',
        'zarincode_settings' => 'zarincode_zarinshopbot_setting',
    );
    if (!isset($map[$legacy])) return;
    $args = wp_unslash($_GET);
    $args['page'] = $map[$legacy];
    wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
    exit;
}, 1);

// Keep the supported TeleNexa REST server aliases available where needed.
if (class_exists('ZarinShopBot_REST_Server_Rewrite', false) && !class_exists('WP_REST_Server_Rewrite', false)) {
    class_alias('ZarinShopBot_REST_Server_Rewrite', 'WP_REST_Server_Rewrite');
}
if (class_exists('ZarinShopBot_REST_Server_Rewrite', false) && !class_exists('TeleNexa_REST_Server_Rewrite', false)) {
    class_alias('ZarinShopBot_REST_Server_Rewrite', 'TeleNexa_REST_Server_Rewrite');
}
