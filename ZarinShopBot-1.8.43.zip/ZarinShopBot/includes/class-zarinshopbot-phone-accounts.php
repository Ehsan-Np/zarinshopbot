<?php
/* Modified 2026-10-30 by Zarincode.com. Derived code remains under GPL-2.0-or-later. */
namespace ZarinShopBot;

if (!defined('ABSPATH')) { exit; }

/**
 * Phone normalization, SMS OTP adapters and race-safe phone ownership index.
 * The table's unique phone hash prevents two accounts claiming one number.
 */
final class Phone_Accounts {
    const SCHEMA_VERSION = '1';
    const OTP_TTL = 600;
    const VERIFIED_TTL = 900;

    public static function boot() {
        add_action('init', [__CLASS__, 'maybeCreateSchema'], 1);
        add_action('woocommerce_after_checkout_billing_form', [__CLASS__, 'renderCheckoutOtp'], 20);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueueCheckoutOtp']);
        add_action('wp_ajax_zsb_checkout_otp_send', [__CLASS__, 'ajaxSendCheckoutOtp']);
        add_action('wp_ajax_nopriv_zsb_checkout_otp_send', [__CLASS__, 'ajaxSendCheckoutOtp']);
        add_action('wp_ajax_zsb_checkout_otp_verify', [__CLASS__, 'ajaxVerifyCheckoutOtp']);
        add_action('wp_ajax_nopriv_zsb_checkout_otp_verify', [__CLASS__, 'ajaxVerifyCheckoutOtp']);
        add_action('woocommerce_created_customer', [__CLASS__, 'indexCreatedCustomer'], 20, 3);
        add_filter('authenticate', [__CLASS__, 'authenticateByPhone'], 15, 3);
        add_action('woocommerce_register_post', [__CLASS__, 'validateRegistrationPhone'], 10, 3);
        add_action('woocommerce_save_account_details_errors', [__CLASS__, 'validateAccountPhoneUpdate'], 10, 2);
    }

    public static function renderCheckoutOtp() {
        $settings = (array) get_option('zarincode_settings', []);
        if (($settings['phone_sms_verification'] ?? '0') !== '1') return;
        echo '<div class="zsb-checkout-otp" style="margin:12px 0;padding:12px;border:1px solid #d1d5db;border-radius:6px">';
        echo '<p>' . esc_html__('برای ادامه، شماره تلفن را با کد پیامکی تأیید کنید.', 'zarinshopbot') . '</p>';
        echo '<button type="button" class="button" id="zsb-checkout-otp-send">' . esc_html__('ارسال کد تأیید', 'zarinshopbot') . '</button> ';
        echo '<input type="text" id="zsb-checkout-otp-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="' . esc_attr__('کد شش‌رقمی', 'zarinshopbot') . '" style="max-width:150px"> ';
        echo '<button type="button" class="button" id="zsb-checkout-otp-verify">' . esc_html__('تأیید شماره', 'zarinshopbot') . '</button>';
        echo '<span id="zsb-checkout-otp-status" role="status" style="display:block;margin-top:8px"></span></div>';
    }

    public static function enqueueCheckoutOtp() {
        $settings = (array) get_option('zarincode_settings', []);
        if (($settings['phone_sms_verification'] ?? '0') !== '1' || !function_exists('is_checkout') || !is_checkout() || is_order_received_page()) return;
        wp_enqueue_script('zsb-checkout-otp', plugins_url('assets/js/checkout-otp.js', dirname(__DIR__) . '/zarinshopbot.php'), ['jquery'], defined('ZARINSHOPBOT_VERSION') ? (string) ZARINSHOPBOT_VERSION : '1.0', true);
        wp_localize_script('zsb-checkout-otp', 'zsbCheckoutOtp', ['ajaxUrl' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('zsb_checkout_otp_nonce'), 'i18n' => ['sent' => __('کد پیامک شد.', 'zarinshopbot'), 'verified' => __('شماره تأیید شد.', 'zarinshopbot'), 'failed' => __('ارسال یا تأیید کد ناموفق بود.', 'zarinshopbot')]]);
    }

    public static function checkoutScope() {
        if (!function_exists('WC') || !WC() || !isset(WC()->session) || !WC()->session) return '';
        $session_id = (string) WC()->session->get_customer_id();
        return $session_id === '' ? '' : 'checkout_' . substr(hash_hmac('sha256', $session_id, wp_salt('auth')), 0, 32);
    }

    public static function ajaxSendCheckoutOtp() {
        check_ajax_referer('zsb_checkout_otp_nonce', 'nonce');
        $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
        $scope = self::checkoutScope();
        if ($scope === '') wp_send_json_error(['message' => __('Checkout session could not be verified.', 'zarinshopbot')], 403);
        $result = self::sendOtp($phone, $scope);
        if (is_wp_error($result)) wp_send_json_error(['message' => __('Could not send a verification code.', 'zarinshopbot')], 400);
        wp_send_json_success();
    }

    public static function ajaxVerifyCheckoutOtp() {
        check_ajax_referer('zsb_checkout_otp_nonce', 'nonce');
        $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
        $code = isset($_POST['code']) ? sanitize_text_field(wp_unslash($_POST['code'])) : '';
        $scope = self::checkoutScope();
        if ($scope === '') wp_send_json_error(['message' => __('Checkout session could not be verified.', 'zarinshopbot')], 403);
        $result = self::verifyOtp($phone, $code, $scope);
        if (is_wp_error($result)) wp_send_json_error(['message' => __('Invalid or expired verification code.', 'zarinshopbot')], 400);
        wp_send_json_success();
    }

    private static function submittedPhone() {
        foreach (['billing_phone', 'phone'] as $key) {
            if (isset($_POST[$key]) && is_scalar($_POST[$key])) return sanitize_text_field(wp_unslash($_POST[$key]));
        }
        return '';
    }

    private static function addPhoneOwnershipError($errors, $user_id = 0) {
        $phone = self::submittedPhone();
        if ($phone === '') return;
        $normalized = self::normalizePhone($phone);
        if ($normalized === '') {
            if (is_object($errors) && method_exists($errors, 'add')) $errors->add('zsb_phone_invalid', __('Enter a valid phone number.', 'zarinshopbot'));
            return;
        }
        $owner = self::userIdForPhone($normalized);
        if ($owner && $owner !== absint($user_id) && is_object($errors) && method_exists($errors, 'add')) {
            $errors->add('zsb_phone_duplicate', __('This phone number is already associated with another customer account.', 'zarinshopbot'));
        }
    }

    public static function validateRegistrationPhone($username, $email, $errors) {
        self::addPhoneOwnershipError($errors, 0);
    }

    public static function validateAccountPhoneUpdate($errors, $user) {
        self::addPhoneOwnershipError($errors, is_object($user) ? (int) $user->ID : 0);
    }

    public static function authenticateByPhone($user, $username, $password) {
        if (is_a($user, 'WP_User') || is_wp_error($user) || !is_string($username) || !is_string($password)) return $user;
        $settings = (array) get_option('zarincode_settings', []);
        if (!in_array(($settings['customer_login_identifier'] ?? 'email'), ['phone', 'either'], true)) return $user;
        $normalized = self::normalizePhone($username);
        if ($normalized === '') return $user;
        $user_id = self::userIdForPhone($normalized);
        if (!$user_id) return $user;
        $account = get_user_by('id', $user_id);
        if (!$account) return $user;
        return wp_authenticate_username_password(null, $account->user_login, $password);
    }

    public static function indexCreatedCustomer($customer_id, $new_customer_data = [], $password_generated = false) {
        $phone = isset($_POST['billing_phone']) ? sanitize_text_field(wp_unslash($_POST['billing_phone'])) : (isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '');
        if ($phone === '') return;
        $scope = self::checkoutScope();
        $settings = (array) get_option('zarincode_settings', []);
        if (($settings['phone_sms_verification'] ?? '0') === '1' && ($scope === '' || !self::isVerified($phone, $scope))) return;
        if (!self::claimPhone((int) $customer_id, $phone) && function_exists('zarincode_log_event')) {
            zarincode_log_event('customer_phone_claim_conflict', ['user_id' => absint($customer_id)]);
        }
    }

    public static function normalizePhone($phone) {
        $phone = (string) $phone;
        $phone = strtr($phone, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
        $phone = preg_replace('/[^0-9+]/', '', $phone);
        if (strpos($phone, '00') === 0) $phone = '+' . substr($phone, 2);
        if (strpos($phone, '+') !== 0) $phone = '+' . ltrim($phone, '0');
        $digits = preg_replace('/\D/', '', $phone);
        if (strlen($digits) < 8 || strlen($digits) > 15) return '';
        return '+' . $digits;
    }

    private static function phoneIndexTable() {
        global $wpdb;
        if (!isset($wpdb) || empty($wpdb->prefix)) return '';
        $table = $wpdb->prefix . 'zsb_phone_index';
        $existing = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
        return $existing === $table ? $table : '';
    }

    public static function maybeCreateSchema() {
        if (get_option('zsb_phone_schema_version') === self::SCHEMA_VERSION && self::phoneIndexTable() !== '') return;
        if ((int) get_transient('zsb_phone_schema_retry_after') > time()) return;
        global $wpdb;
        if (!isset($wpdb) || empty($wpdb->prefix)) return;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = $wpdb->prefix . 'zsb_phone_index';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            phone_hash char(64) NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (phone_hash),
            UNIQUE KEY user_id (user_id)
        ) {$charset};";
        dbDelta($sql);
        if (self::phoneIndexTable() === $table) {
            update_option('zsb_phone_schema_version', self::SCHEMA_VERSION, false);
            delete_transient('zsb_phone_schema_retry_after');
        } else {
            delete_option('zsb_phone_schema_version');
            set_transient('zsb_phone_schema_retry_after', time() + 300, 300);
            if (function_exists('zarincode_log_event')) {
                zarincode_log_event('phone_index_schema_unavailable', array('component' => 'phone_accounts'));
            }
        }
    }

    private static function hashPhone($phone) {
        $normalized = self::normalizePhone($phone);
        return $normalized === '' ? '' : hash_hmac('sha256', $normalized, wp_salt('auth'));
    }

    public static function userIdForPhone($phone) {
        global $wpdb;
        $hash = self::hashPhone($phone);
        if ($hash === '') return 0;
        $table = self::phoneIndexTable();
        if ($table === '') return 0;
        $user_id = (int) $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$table} WHERE phone_hash = %s LIMIT 1", $hash));
        if ($user_id > 0 && get_user_by('id', $user_id)) return $user_id;
        $normalized = self::normalizePhone($phone);
        $indexed_meta_user = get_users(['fields' => 'ID', 'number' => 2, 'meta_key' => '_zsb_phone_normalized', 'meta_value' => $normalized]);
        if (count((array) $indexed_meta_user) === 1 && self::claimPhone((int) $indexed_meta_user[0], $phone)) {
            return (int) $indexed_meta_user[0];
        }
        // Lazy migration for existing WooCommerce customers; only accept one exact normalized match.
        $digits = preg_replace('/\\D/', '', $normalized);
        $suffix = substr((string) $digits, -8);
        $candidate_ids = [];
        if (strlen($suffix) === 8) {
            $candidate_ids = $wpdb->get_col($wpdb->prepare("SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value LIKE %s LIMIT 500", 'billing_phone', '%' . $wpdb->esc_like($suffix)));
        }
        $matches = [];
        foreach ((array) $candidate_ids as $candidate_id) {
            $candidate = get_user_meta((int) $candidate_id, 'billing_phone', true);
            if (self::normalizePhone($candidate) === $normalized) $matches[] = (int) $candidate_id;
        }
        if (count($matches) === 1 && self::claimPhone($matches[0], $phone)) return $matches[0];
        return 0;
    }

    /** Returns true if the index was claimed, false if another account owns it. */
    public static function claimPhone($user_id, $phone) {
        global $wpdb;
        $user_id = absint($user_id);
        $normalized = self::normalizePhone($phone);
        $hash = self::hashPhone($phone);
        if (!$user_id || $normalized === '' || $hash === '') return false;
        $table = self::phoneIndexTable();
        if ($table === '') return false;
        $existing_user = (int) $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$table} WHERE phone_hash = %s", $hash));
        if ($existing_user && $existing_user !== $user_id) return false;
        $existing_hash = $wpdb->get_var($wpdb->prepare("SELECT phone_hash FROM {$table} WHERE user_id = %d", $user_id));
        if ($existing_hash && hash_equals((string) $existing_hash, $hash)) return true;
        $wpdb->query('START TRANSACTION');
        if ($existing_hash) $wpdb->delete($table, ['user_id' => $user_id], ['%d']);
        $inserted = $wpdb->insert($table, ['phone_hash' => $hash, 'user_id' => $user_id, 'updated_at' => current_time('mysql', true)], ['%s', '%d', '%s']);
        if ($inserted === false) { $wpdb->query('ROLLBACK'); return false; }
        $wpdb->query('COMMIT');
        update_user_meta($user_id, '_zsb_phone_normalized', $normalized);
        update_user_meta($user_id, 'billing_phone', sanitize_text_field($phone));
        return true;
    }

    /** Decide safely whether a bot/Mini App order is guest or linked to a verified customer. */
    public static function customerIdForOrder($phone, $email, $name, $scope = 'web') {
        $settings = (array) get_option('zarincode_settings', []);
        $policy = sanitize_key((string) ($settings['customer_account_policy'] ?? 'optional'));
        if (!in_array($policy, ['guest', 'optional', 'account'], true) || $policy === 'guest') return 0;
        $verified = self::isVerified($phone, $scope);
        if ($policy === 'account' && !$verified) return new \WP_Error('phone_not_verified', __('Verify the phone number before creating or linking a customer account.', 'zarinshopbot'));
        if (!$verified) return 0; // Never link an order to an account based on an unverified phone or typed email.
        $user_id = self::userIdForPhone($phone);
        if (!$user_id && is_email($email)) {
            $email_user = get_user_by('email', sanitize_email($email));
            if ($email_user) $user_id = (int) $email_user->ID;
        }
        if ($user_id) {
            if (!self::claimPhone($user_id, $phone)) return new \WP_Error('phone_already_used', __('This phone number is already associated with another customer account.', 'zarinshopbot'));
            return $user_id;
        }
        if ($policy !== 'account') return 0;
        $email = sanitize_email($email);
        if (!is_email($email)) return new \WP_Error('customer_email_required', __('A valid email is required to create a WooCommerce customer account.', 'zarinshopbot'));
        if (!function_exists('wc_create_new_customer')) return new \WP_Error('woocommerce_unavailable', __('WooCommerce customer registration is unavailable.', 'zarinshopbot'));
        $username = sanitize_user(str_replace('+', '', self::normalizePhone($phone)), true);
        if ($username === '' || username_exists($username)) $username = sanitize_user('customer_' . wp_generate_password(8, false, false), true);
        $new_user = wc_create_new_customer($email, $username, wp_generate_password(32, true, true));
        if (is_wp_error($new_user) || !$new_user) return is_wp_error($new_user) ? $new_user : new \WP_Error('customer_create_failed', __('Could not create the WooCommerce customer account.', 'zarinshopbot'));
        $parts = preg_split('/\\s+/', trim(sanitize_text_field($name)), 2);
        update_user_meta((int) $new_user, 'first_name', $parts[0] ?? '');
        update_user_meta((int) $new_user, 'last_name', $parts[1] ?? '');
        if (!self::claimPhone((int) $new_user, $phone)) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
            wp_delete_user((int) $new_user);
            return new \WP_Error('phone_already_used', __('This phone number is already associated with another customer account.', 'zarinshopbot'));
        }
        return (int) $new_user;
    }

    private static function secret($key) {
        $options = (array) get_option('zarincode_settings', []);
        $stored = (string) ($options[$key . '_enc'] ?? '');
        if ($stored === '') return '';
        if (class_exists('\\ZarinShopBot\\Core\\Http\\ProxyManager')) return (string) \ZarinShopBot\Core\Http\ProxyManager::decrypt($stored);
        return '';
    }

    private static function otpKey($phone, $scope) {
        return 'zsb_otp_' . substr(hash_hmac('sha256', self::normalizePhone($phone) . '|' . sanitize_key($scope), wp_salt('secure_auth')), 0, 40);
    }

    public static function sendOtp($phone, $scope = 'web') {
        $options = (array) get_option('zarincode_settings', []);
        if (($options['phone_sms_verification'] ?? '0') !== '1') return new \WP_Error('otp_disabled', __('Phone verification is disabled.', 'zarinshopbot'));
        $normalized = self::normalizePhone($phone);
        if ($normalized === '') return new \WP_Error('otp_invalid_phone', __('Enter a valid phone number.', 'zarinshopbot'));
        $key = self::otpKey($normalized, $scope);
        $phone_limit = 'zsb_otp_phone_limit_' . substr(self::hashPhone($normalized), 0, 32);
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $ip_limit = 'zsb_otp_ip_limit_' . substr(hash_hmac('sha256', $ip, wp_salt('secure_auth')), 0, 32);
        if (get_transient($key . '_limit') || get_transient($phone_limit)) return new \WP_Error('otp_rate_limited', __('Please wait before requesting another code.', 'zarinshopbot'));
        $ip_count = (int) get_transient($ip_limit);
        if ($ip_count >= 20) return new \WP_Error('otp_ip_rate_limited', __('Too many verification requests. Try again later.', 'zarinshopbot'));
        set_transient($phone_limit, 1, 60);
        set_transient($ip_limit, $ip_count + 1, 3600);
        $code = (string) random_int(100000, 999999);
        $sent = self::sendProviderCode($normalized, $code, $options);
        if (is_wp_error($sent)) return $sent;
        set_transient($key, wp_hash_password($code), self::OTP_TTL);
        set_transient($key . '_limit', 1, 60);
        return true;
    }

    public static function verifyOtp($phone, $code, $scope = 'web') {
        $normalized = self::normalizePhone($phone);
        $code = preg_replace('/\D/', '', (string) $code);
        if ($normalized === '' || !preg_match('/\A[0-9]{6}\z/', $code)) return new \WP_Error('otp_invalid', __('Invalid verification code.', 'zarinshopbot'));
        $key = self::otpKey($normalized, $scope);
        $stored = get_transient($key);
        $tries_key = $key . '_tries';
        $tries = (int) get_transient($tries_key);
        if (!$stored || $tries >= 5) { delete_transient($key); delete_transient($tries_key); return new \WP_Error('otp_expired', __('The code has expired. Request a new code.', 'zarinshopbot')); }
        if (!wp_check_password($code, (string) $stored)) { set_transient($tries_key, $tries + 1, self::OTP_TTL); return new \WP_Error('otp_invalid', __('Invalid verification code.', 'zarinshopbot')); }
        delete_transient($key);
        delete_transient($tries_key);
        set_transient($key . '_verified', 1, self::VERIFIED_TTL);
        return true;
    }

    public static function isVerified($phone, $scope = 'web') {
        $normalized = self::normalizePhone($phone);
        return $normalized !== '' && (bool) get_transient(self::otpKey($normalized, $scope) . '_verified');
    }

    private static function sendProviderCode($phone, $code, $options) {
        $provider = sanitize_key((string) ($options['sms_provider'] ?? 'kavenegar'));
        if ($provider === 'kavenegar') {
            $api_key = self::secret('sms_kavenegar_api_key');
            $template = sanitize_text_field((string) ($options['sms_kavenegar_template'] ?? ''));
            if ($api_key === '' || $template === '') return new \WP_Error('otp_provider_config', __('Kavenegar credentials or template are not configured.', 'zarinshopbot'));
            $url = 'https://api.kavenegar.com/v1/' . rawurlencode($api_key) . '/verify/lookup.json';
            $response = wp_remote_get(add_query_arg(['receptor' => ltrim($phone, '+'), 'token' => $code, 'template' => $template], $url), ['timeout' => 15, 'redirection' => 0]);
        } elseif ($provider === 'melipayamak') {
            $username = self::secret('sms_melipayamak_username');
            $password = self::secret('sms_melipayamak_password');
            $body_id = sanitize_text_field((string) ($options['sms_melipayamak_body_id'] ?? ''));
            if ($username === '' || $password === '' || $body_id === '') return new \WP_Error('otp_provider_config', __('Melipayamak credentials or body ID are not configured.', 'zarinshopbot'));
            $response = wp_remote_post('https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber', ['timeout' => 15, 'redirection' => 0, 'body' => ['username' => $username, 'password' => $password, 'text' => $code, 'to' => ltrim($phone, '+'), 'bodyId' => $body_id]]);
        } else {
            return new \WP_Error('otp_provider_invalid', __('Select a supported SMS provider.', 'zarinshopbot'));
        }
        if (is_wp_error($response)) return new \WP_Error('otp_delivery_failed', __('Could not send the verification code. Try again later.', 'zarinshopbot'));
        $status = (int) wp_remote_retrieve_response_code($response);
        $body_raw = trim((string) wp_remote_retrieve_body($response));
        $body = json_decode($body_raw, true);
        $ok = $status >= 200 && $status < 300;
        if ($provider === 'kavenegar') $ok = $ok && is_array($body) && (int) ($body['return']['status'] ?? 0) === 200;
        if ($provider === 'melipayamak') {
            $result = is_array($body) ? ($body['Value'] ?? $body['value'] ?? null) : $body;
            $ok = $ok && is_numeric($result) && (int) $result > 0;
        }
        if (!$ok) return new \WP_Error('otp_delivery_failed', __('The SMS provider rejected the verification request.', 'zarinshopbot'));
        return true;
    }
}

Phone_Accounts::boot();
