<?php
/**
 * Shared rich-message editor and context-aware dynamic-variable UI.
 *
 * @package ZarinShopBot
 */
namespace ZarinShopBot;

if (!defined('ABSPATH')) { exit; }

final class Message_Editor {
    /** Safe subset for content authored in the WordPress visual editor. */
    public static function allowedHtml() {
        $style = ['style' => true];
        return [
            'p' => $style, 'div' => $style, 'span' => $style,
            'h1' => $style, 'h2' => $style, 'h3' => $style, 'h4' => $style, 'h5' => $style, 'h6' => $style,
            'ul' => $style, 'ol' => $style, 'li' => $style, 'br' => [], 'hr' => [],
            'b' => [], 'strong' => [], 'i' => [], 'em' => [], 'u' => [], 'ins' => [],
            's' => [], 'strike' => [], 'del' => [], 'sub' => [], 'sup' => [],
            'blockquote' => [], 'code' => [], 'pre' => [],
            'a' => ['href' => true, 'title' => true, 'target' => true, 'rel' => true],
        ];
    }

    /** Sanitize rich text using WordPress KSES, including its safe-CSS filtering. */
    public static function sanitize($value) {
        if (!is_scalar($value)) return '';
        return wp_kses((string) $value, self::allowedHtml());
    }

    /** Render an editor and an always-visible, editor-specific variable palette. */
    public static function render($id, $name, $value, $rows = 5, $variable_context = 'customer', $editor_class = '') {
        $id = sanitize_html_class((string) $id);
        if ($id === '') return;
        $toolbar = 'formatselect,bold,italic,underline,strikethrough,forecolor,backcolor,bullist,numlist,blockquote,link,unlink,removeformat,undo,redo';
        echo '<div class="zsb-message-editor-row">';
        echo '<div class="zsb-message-editor-main">';
        wp_editor((string) $value, $id, [
            'textarea_name' => (string) $name,
            'textarea_rows' => max(3, min(12, (int) $rows)),
            'editor_class' => sanitize_html_class((string) $editor_class),
            'media_buttons' => false,
            'drag_drop_upload' => false,
            'teeny' => false,
            'quicktags' => false,
            'tinymce' => [
                'menubar' => false,
                'branding' => false,
                'toolbar1' => $toolbar,
                'toolbar2' => '',
                'content_style' => 'body{direction:rtl;text-align:right;font-family:Tahoma,Arial,sans-serif;font-size:14px;line-height:1.8} p{margin:.5em 0}',
            ],
        ]);
        echo '</div>';
        self::renderVariables($id, $variable_context);
        echo '</div>';
    }

    /** Render variables in a local panel next to precisely the editor they target. */
    public static function renderVariables($editor_id, $variable_context = 'customer') {
        if ($variable_context === 'none') {
            echo '<aside class="zsb-message-variable-panel zsb-message-variable-empty"><strong>' . esc_html__('متغیرهای پویا', 'zarinshopbot') . '</strong><p>' . esc_html__('برای این متن در حال حاضر متغیر پویایی تعریف نشده است.', 'zarinshopbot') . '</p></aside>';
            return;
        }
        if ($variable_context === 'product') {
            $variables = [
                ['%product%', __('نام محصول جاری', 'zarinshopbot')],
            ];
        } else {
            $variables = [
                ['%FIRST_NAME%', __('نام کوچک کاربر یا نام گروه', 'zarinshopbot')],
                ['%LAST_NAME%', __('نام خانوادگی مخاطب', 'zarinshopbot')],
                ['%USERNAME%', __('نام کاربری مخاطب', 'zarinshopbot')],
                ['%CHAT_ID%', __('شناسهٔ گفت‌وگوی فعلی', 'zarinshopbot')],
                ['%LOCATION_LATITUDE%', __('عرض جغرافیایی؛ فقط پس از ارسال موقعیت', 'zarinshopbot')],
                ['%LOCATION_LONGITUDE%', __('طول جغرافیایی؛ فقط پس از ارسال موقعیت', 'zarinshopbot')],
            ];
        }
        echo '<aside class="zsb-message-variable-panel" aria-label="' . esc_attr__('متغیرهای پویای قابل استفاده', 'zarinshopbot') . '">';
        echo '<strong>' . esc_html__('متغیرهای پویا', 'zarinshopbot') . '</strong>';
        if ($variable_context === 'product') {
            echo '<p>' . esc_html__('این متغیر هنگام انتشار، با نام همان محصول جایگزین می‌شود.', 'zarinshopbot') . '</p>';
        } else {
            echo '<p>' . esc_html__('برای درج، روی هر متغیر بزنید؛ فقط متغیرهای دارای مقدار در زمان ارسال جایگزین می‌شوند.', 'zarinshopbot') . '</p>';
        }
        echo '<div class="zsb-message-variable-list">';
        foreach ($variables as $variable) {
            echo '<button type="button" class="zsb-message-variable" data-editor-id="' . esc_attr($editor_id) . '" data-variable="' . esc_attr($variable[0]) . '"><code>' . esc_html($variable[0]) . '</code><span>' . esc_html($variable[1]) . '</span></button>';
        }
        echo '</div>';
        echo '<p class="zsb-message-variable-note">' . esc_html__('رنگ متن در ویرایشگر برای نگارش بصری است؛ Telegram، Bale و Rubika رنگ دلخواه متن را نمایش نمی‌دهند. قالب‌بندی متنی، فهرست‌ها و پیوندها به نزدیک‌ترین قالب پشتیبانی‌شده تبدیل می‌شوند.', 'zarinshopbot') . '</p>';
        echo '</aside>';
    }
}
