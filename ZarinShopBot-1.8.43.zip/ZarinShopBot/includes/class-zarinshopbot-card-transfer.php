<?php
/**
 * Private, manually reviewed card-transfer payments for WooCommerce and Mini App checkout.
 *
 * @package ZarinShopBot
 */
namespace ZarinShopBot;

if (!defined('ABSPATH')) {
    exit;
}

final class Card_Transfer {
    const METHOD_ID = 'zarinshopbot_card_transfer';
    const OPTION_KEY = 'woocommerce_zarinshopbot_card_transfer_settings';
    const META_RECEIPT = '_zsb_transfer_receipt_encrypted';
    const META_REVIEW = '_zsb_transfer_review_status';
    const META_REVIEW_NONCE = '_zsb_transfer_review_nonce';
    const META_ACCOUNT = '_zsb_transfer_account_id';
    const META_BOT_DOWNLOADS_NOTICE = '_zsb_bot_downloads_notice_sent';

    /** Register integration hooks once WooCommerce has loaded its gateway base class. */
    public static function boot() {
        add_action('admin_init', [__CLASS__, 'registerPanelSettings']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_front_assets']);
        add_action('wp_ajax_zarincode_webapp_upload_card_receipt', [__CLASS__, 'ajaxUploadReceipt']);
        add_action('wp_ajax_nopriv_zarincode_webapp_upload_card_receipt', [__CLASS__, 'ajaxUploadReceipt']);
        add_action('woocommerce_thankyou_' . self::METHOD_ID, [__CLASS__, 'renderThankYou']);
        add_action('woocommerce_payment_complete', [__CLASS__, 'notifyPaidOrderDownloads'], 50, 1);
        add_action('woocommerce_order_details_after_order_table', [__CLASS__, 'renderOrderDetailsUpload']);
        add_action('woocommerce_admin_order_data_after_order_details', [__CLASS__, 'renderAdminOrderReview']);
        add_action('admin_footer', [__CLASS__, 'renderAdminReviewForms']);
        add_action('admin_post_zsb_card_transfer_review', [__CLASS__, 'handleAdminReview']);
        add_action('admin_post_zsb_card_transfer_receipt', [__CLASS__, 'handleWebsiteReceipt']);
        add_action('admin_post_nopriv_zsb_card_transfer_receipt', [__CLASS__, 'handleWebsiteReceipt']);
        add_action('admin_post_zsb_card_transfer_view_receipt', [__CLASS__, 'handleViewReceipt']);
    }

    public static function enqueue_front_assets() {
        if (!function_exists('is_checkout') || !(is_checkout() || (function_exists('is_account_page') && is_account_page()))) return;
        $plugin_file = dirname(__DIR__) . '/zarinshopbot.php';
        $version = defined('ZARINSHOPBOT_VERSION') ? ZARINSHOPBOT_VERSION : '1.8.43';
        wp_enqueue_style('zarinshopbot-card-transfer', plugins_url('assets/css/card-transfer.css', $plugin_file), [], $version);
        wp_enqueue_script('zarinshopbot-card-transfer', plugins_url('assets/js/card-transfer.js', $plugin_file), [], $version, true);
    }

    public static function defaults() {
        return [
            'enabled' => 'no',
            'title' => __('پرداخت کارت‌به‌کارت', 'zarinshopbot'),
            'description' => __('<p>مبلغ نهایی سفارش را به حساب بانکی مقصدی که انتخاب می‌کنید واریز کنید. پیش از انتقال، مبلغ، نام صاحب حساب و شمارهٔ کارت را با اطلاعات سفارش تطبیق دهید.</p><p>ارسال رسید: در Mini App، فایل رسید را همین‌جا و پیش از ثبت نهایی سفارش انتخاب کنید؛ در وب‌سایت، پس از ثبت سفارش آن را از صفحهٔ تأیید سفارش بارگذاری کنید. سفارش پس از دریافت رسید تا بررسی و تأیید مدیر فروشگاه در انتظار می‌ماند و سپس پردازش می‌شود.</p>', 'zarinshopbot'),
            'instructions' => __('<p>رسید باید کامل و خوانا باشد. مبلغ و تاریخ تراکنش باید مشخص و مبلغ واریزی برابر با مبلغ نهایی همین سفارش باشد؛ اگر رسید شمارهٔ پیگیری دارد، آن بخش را نیز خوانا نگه دارید.</p><p>در Mini App، فایل رسید را پیش از فشردن دکمهٔ ثبت نهایی سفارش انتخاب کنید. در وب‌سایت، پس از ثبت سفارش، رسید را از صفحهٔ تأیید یا جزئیات همان سفارش بارگذاری کنید. فرمت‌های مجاز و حداکثر حجم فایل کنار بخش بارگذاری نوشته شده است.</p><p>برای پرداخت، رمز کارت، رمز پویا، CVV2 یا اطلاعات ورود به حساب بانکی لازم نیست؛ این اطلاعات را ارسال نکنید. پس از بارگذاری، تا بررسی مدیر فروشگاه منتظر بمانید. در صورت رد رسید، وضعیت سفارش را بررسی کنید و از واریز دوبارهٔ مبلغ خودداری کنید.</p>', 'zarinshopbot'),
            'accounts' => '',
            'allowed_extensions' => 'jpg,jpeg,png,webp,pdf',
            'custom_mimes' => '',
            'max_upload_mb' => '2',
        ];
    }

    public static function registerPanelSettings() {
        register_setting('zarincode_settings_options', self::OPTION_KEY, [
            'type' => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitizeGatewaySettings'],
            'default' => self::defaults(),
        ]);
    }

    /** Keep the same WooCommerce option key so existing gateway data is retained. */
    public static function sanitizeGatewaySettings($input) {
        $existing = array_merge(self::defaults(), self::settings());
        if (!is_array($input)) return $existing;
        $settings = $existing;

        if (array_key_exists('enabled', $input)) {
            $settings['enabled'] = in_array((string) $input['enabled'], ['yes', '1', 'true'], true) ? 'yes' : 'no';
        }
        if (array_key_exists('title', $input)) {
            $title = sanitize_text_field((string) $input['title']);
            $settings['title'] = $title !== '' ? $title : (string) self::defaults()['title'];
        }
        if (array_key_exists('description', $input)) $settings['description'] = class_exists(Message_Editor::class) ? Message_Editor::sanitize($input['description']) : wp_kses_post((string) $input['description']);
        if (array_key_exists('instructions', $input)) $settings['instructions'] = class_exists(Message_Editor::class) ? Message_Editor::sanitize($input['instructions']) : wp_kses_post((string) $input['instructions']);
        if (array_key_exists('accounts', $input)) {
            $settings['accounts'] = self::serializeAccountsValue(self::parseAccountsValue($input['accounts']));
        }
        if (array_key_exists('allowed_extensions', $input)) $settings['allowed_extensions'] = sanitize_text_field((string) $input['allowed_extensions']);
        if (array_key_exists('custom_mimes', $input)) {
            $raw_mimes = is_scalar($input['custom_mimes']) ? (string) $input['custom_mimes'] : '';
            $lines = [];
            foreach (preg_split('/\\r\\n|\\r|\\n/', $raw_mimes) as $line) {
                $parts = array_map('trim', explode('|', $line, 2));
                if (count($parts) !== 2) continue;
                $extension = strtolower(ltrim(sanitize_key($parts[0]), '.'));
                $mime = strtolower(sanitize_text_field($parts[1]));
                if ($extension !== '' && preg_match('~^image/[a-z0-9.+-]+$~', $mime)) $lines[] = $extension . '|' . $mime;
            }
            $settings['custom_mimes'] = implode("\n", array_unique($lines));
        }
        if (array_key_exists('max_upload_mb', $input)) {
            $max_mb = is_numeric($input['max_upload_mb']) ? (float) $input['max_upload_mb'] : 2.0;
            $settings['max_upload_mb'] = (string) max(0.1, min(20.0, $max_mb));
        }
        return $settings;
    }

    public static function settings() {
        $settings = get_option(self::OPTION_KEY, []);
        return is_array($settings) ? $settings : [];
    }

    /** Return a usable gateway title even when a legacy saved option is empty. */
    public static function customerTitle() {
        $settings = self::settings();
        $value = isset($settings['title']) && is_scalar($settings['title'])
            ? trim(wp_strip_all_tags((string) $settings['title']))
            : '';
        return $value !== '' ? $value : (string) self::defaults()['title'];
    }

    /** Treat whitespace, empty editor markup and non-breaking spaces as an empty message. */
    private static function hasMeaningfulCustomerText($value) {
        if (!is_scalar($value)) return false;
        $plain = html_entity_decode(wp_strip_all_tags((string) $value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain = str_replace(["\xC2\xA0", "\xE2\x80\x8B", "\xE2\x80\x8C", "\xE2\x80\x8D", "\xEF\xBB\xBF"], '', $plain);
        return trim($plain) !== '';
    }

    /** Use the plugin's panel copy as the single source of truth, restoring defaults for visually empty legacy fields. */
    public static function customerDescription() {
        $settings = self::settings();
        $value = $settings['description'] ?? '';
        return self::hasMeaningfulCustomerText($value) ? (string) $value : (string) self::defaults()['description'];
    }

    public static function customerInstructions() {
        $settings = self::settings();
        $value = $settings['instructions'] ?? '';
        return self::hasMeaningfulCustomerText($value) ? (string) $value : (string) self::defaults()['instructions'];
    }

    /** Convert the rich-text panel content to safe plain text for the Mini App's textContent renderer. */
    private static function plainCustomerText($value) {
        $value = preg_replace('~<br\\s*/?>~i', "\n", (string) $value);
        $value = preg_replace('~</(?:p|div|li|h[1-6])\\s*>~i', "\n", $value);
        $value = wp_strip_all_tags($value);
        $value = preg_replace('/[ \\t]+/', ' ', $value);
        $value = preg_replace('/\\n{3,}/', "\n\n", $value);
        return trim($value);
    }

    public static function renderCustomerMessage($value) {
        $safe = wp_kses_post((string) $value);
        if (preg_match('~<(?:p|br|ul|ol|div|h[1-6])\\b~i', $safe)) return $safe;
        return wpautop($safe);
    }

    public static function renderCustomerInstructions() {
        $instructions = self::customerInstructions();
        if (trim(wp_strip_all_tags($instructions)) === '') return;
        echo '<div class="zsb-transfer-instructions">' . self::renderCustomerMessage($instructions) . '</div>';
    }

    public static function enabled() {
        $settings = self::settings();
        return isset($settings['enabled']) && $settings['enabled'] === 'yes' && !empty(self::accounts());
    }

    /** Convert Persian and Arabic-Indic digits to ASCII before validating bank identifiers. */
    public static function normalizeDigits($value) {
        return strtr((string) $value, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ]);
    }

    /** Read both the structured JSON format and pre-existing six-column account rows. */
    public static function parseAccountsValue($raw) {
        $rows = [];
        if (is_array($raw)) {
            $rows = array_values($raw);
        } else {
            $raw = is_scalar($raw) ? trim((string) $raw) : '';
            if ($raw === '') return [];

            $decoded = json_decode($raw, true);
            if (is_array($decoded) && (substr($raw, 0, 1) === '[' || substr($raw, 0, 1) === '{')) {
                $rows = array_values($decoded);
            } else {
                foreach (preg_split('/\\r\\n|\\r|\\n/', $raw) as $line) {
                    $line = trim($line);
                    if ($line === '' || strpos($line, '|') === false) continue;
                    $parts = array_map('trim', explode('|', $line));
                    $parts = array_pad($parts, 7, '');
                    // Columns 1-6 are the legacy format; account number is an optional seventh column.
                    $rows[] = [
                        'label' => $parts[0], 'bank' => $parts[1], 'holder' => $parts[2],
                        'card_number' => $parts[3], 'iban' => $parts[4], 'instructions' => $parts[5],
                        'account_number' => $parts[6],
                    ];
                }
            }
        }

        $accounts = [];
        foreach ($rows as $index => $row) {
            if (!is_array($row)) continue;
            $label = sanitize_text_field((string) ($row['label'] ?? ''));
            $bank = sanitize_text_field((string) ($row['bank'] ?? ''));
            $holder = sanitize_text_field((string) ($row['holder'] ?? $row['account_holder'] ?? ''));
            $card = preg_replace('/[^0-9\-\s]/', '', self::normalizeDigits($row['card_number'] ?? ''));
            $account_number = preg_replace('/[^A-Za-z0-9\-\s]/', '', self::normalizeDigits($row['account_number'] ?? ''));
            $iban = strtoupper(preg_replace('/[^A-Za-z0-9\s]/', '', self::normalizeDigits($row['iban'] ?? '')));
            $instructions = sanitize_text_field((string) ($row['instructions'] ?? ''));
            if ($label === '' || ($card === '' && $account_number === '' && $iban === '')) continue;

            $id = sanitize_key((string) ($row['id'] ?? ''));
            if ($id === '') $id = sanitize_key(substr($label, 0, 32));
            if ($id === '') $id = 'account-' . ($index + 1);
            if (isset($accounts[$id])) $id .= '-' . ($index + 1);
            $accounts[$id] = [
                'id' => $id,
                'label' => $label,
                'bank' => $bank,
                'holder' => $holder,
                'card_number' => trim($card),
                'account_number' => trim($account_number),
                'iban' => trim($iban),
                'instructions' => $instructions,
            ];
        }
        return array_values($accounts);
    }

    /** Preserve the historical newline/pipe storage format, appending account number as column seven. */
    public static function serializeAccountsValue($accounts) {
        $lines = [];
        foreach ((array) $accounts as $account) {
            if (!is_array($account)) continue;
            $fields = [
                $account['label'] ?? '', $account['bank'] ?? '', $account['holder'] ?? '',
                $account['card_number'] ?? '', $account['iban'] ?? '', $account['instructions'] ?? '',
                $account['account_number'] ?? '',
            ];
            $fields = array_map(static function($value) {
                return str_replace(['|', "\r", "\n"], ' ', sanitize_text_field((string) $value));
            }, $fields);
            if ($fields[0] === '' || ($fields[3] === '' && $fields[6] === '' && $fields[4] === '')) continue;
            $lines[] = implode(' | ', $fields);
        }
        return implode("\n", $lines);
    }

    /** Render the plugin-panel account editor, retaining a usable legacy textarea if JavaScript is unavailable. */
    public static function renderAccountsEditor($field_name, $raw_value = '') {
        $accounts = self::parseAccountsValue($raw_value);
        $stored_accounts = self::serializeAccountsValue($accounts);
        $labels = [
            'label' => __('عنوان حساب', 'zarinshopbot'),
            'bank' => __('نام بانک', 'zarinshopbot'),
            'holder' => __('نام صاحب حساب', 'zarinshopbot'),
            'card_number' => __('شماره کارت', 'zarinshopbot'),
            'account_number' => __('شماره حساب', 'zarinshopbot'),
            'iban' => __('شماره شبا', 'zarinshopbot'),
            'instructions' => __('یادداشت انتقال (اختیاری)', 'zarinshopbot'),
        ];
        $html = '<div class="zsb-account-editor" data-account-editor';
        foreach ($labels as $name => $label) $html .= ' data-label-' . esc_attr($name) . '="' . esc_attr($label) . '"';
        $html .= ' data-add-label="' . esc_attr__('افزودن حساب بانکی', 'zarinshopbot') . '" data-remove-label="' . esc_attr__('حذف این حساب', 'zarinshopbot') . '" data-empty-label="' . esc_attr__('هنوز حسابی ثبت نشده است؛ برای نمایش اطلاعات به مشتری، یک حساب اضافه کنید.', 'zarinshopbot') . '" data-card-placeholder="' . esc_attr__('شماره کارت ۱۶ رقمی', 'zarinshopbot') . '" data-required-message="' . esc_attr__('عنوان، نام صاحب حساب و شماره کارت را برای هر حساب کامل کنید.', 'zarinshopbot') . '">';
        $html .= '<div class="zsb-account-editor-list" data-account-list></div>';
        $html .= '<div class="zsb-account-editor-error" data-account-error role="alert" hidden></div>';
        $html .= '<button type="button" class="button zsb-account-add" data-add-account>＋ ' . esc_html__('افزودن حساب بانکی', 'zarinshopbot') . '</button>';
        $html .= '<label class="zsb-account-raw-fallback"><span>' . esc_html__('ویرایش متنی جایگزین (هر حساب در یک سطر؛ ستون‌ها با | جدا شوند)', 'zarinshopbot') . '</span>';
        $html .= '<textarea id="zsb_card_transfer_accounts_raw" name="' . esc_attr($field_name) . '" rows="4" dir="auto" placeholder="عنوان | بانک | صاحب حساب | شماره کارت | شبا | یادداشت | شماره حساب" data-account-raw>' . esc_textarea($stored_accounts) . '</textarea></label>';
        $html .= '<p class="description">' . esc_html__('اطلاعات حساب در گزینهٔ کارت‌به‌کارت ووکامرس ذخیره می‌شود؛ قالب‌های قدیمی حساب‌ها نیز حفظ و خوانده می‌شوند.', 'zarinshopbot') . '</p>';
        $html .= '</div>';
        return $html;
    }

    public static function accounts() {
        $settings = self::settings();
        return self::parseAccountsValue($settings['accounts'] ?? '');
    }

    public static function accountById($id) {
        $id = sanitize_key((string) $id);
        foreach (self::accounts() as $account) {
            if (hash_equals($account['id'], $id)) return $account;
        }
        return null;
    }

    public static function assignAccount($order, $account_id) {
        $account = self::accountById($account_id);
        if (!($order instanceof \WC_Order) || !$account) return false;
        $order->update_meta_data(self::META_ACCOUNT, $account['id']);
        $order->update_meta_data('_zsb_transfer_account_snapshot', $account);
        return true;
    }

    public static function accountForOrder($order) {
        if (!($order instanceof \WC_Order)) return null;
        $snapshot = $order->get_meta('_zsb_transfer_account_snapshot', true);
        if (is_array($snapshot) && !empty($snapshot['card_number'])) return $snapshot;
        return self::accountById((string) $order->get_meta(self::META_ACCOUNT, true));
    }

    public static function allowedTypes() {
        $settings = self::settings();
        $default = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];
        $raw = isset($settings['allowed_extensions']) ? (string) $settings['allowed_extensions'] : implode(',', $default);
        $extensions = array_values(array_unique(array_filter(array_map(static function($ext) {
            return strtolower(ltrim(sanitize_key(trim($ext)), '.'));
        }, preg_split('/[,\s]+/', $raw)))));
        $custom = [];
        $custom_raw = isset($settings['custom_mimes']) ? (string) $settings['custom_mimes'] : '';
        foreach (preg_split('/\r\n|\r|\n/', $custom_raw) as $line) {
            $parts = array_map('trim', explode('|', $line, 2));
            if (count($parts) !== 2) continue;
            $extension = strtolower(ltrim(sanitize_key($parts[0]), '.'));
            $mime = strtolower(sanitize_text_field($parts[1]));
            // Receipt formats are intentionally limited to non-executable images and PDF.
            if ($extension !== '' && preg_match('~^image/[a-z0-9.+-]+$~', $mime)) $custom[$extension] = $mime;
        }
        $mimes = [
            'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
            'webp' => 'image/webp', 'gif' => 'image/gif', 'bmp' => 'image/bmp',
            'tif' => 'image/tiff', 'tiff' => 'image/tiff', 'pdf' => 'application/pdf',
        ];
        foreach ($custom as $extension => $mime) $mimes[$extension] = $mime;
        $allowed = [];
        foreach ($extensions as $extension) {
            if (isset($mimes[$extension])) $allowed[$extension] = $mimes[$extension];
        }
        return $allowed;
    }

    public static function maxUploadBytes() {
        $settings = self::settings();
        $mb = isset($settings['max_upload_mb']) ? (float) $settings['max_upload_mb'] : 2.0;
        $mb = max(0.1, min(20.0, $mb));
        $bytes = (int) floor($mb * 1024 * 1024);
        $server_limit = self::phpUploadLimit();
        return $server_limit > 0 ? min($bytes, $server_limit) : $bytes;
    }

    private static function phpUploadLimit() {
        $parse = static function($value) {
            $value = trim((string) $value);
            if ($value === '') return 0;
            $unit = strtolower(substr($value, -1));
            $number = (float) $value;
            if ($unit === 'g') $number *= 1024;
            if ($unit === 'g' || $unit === 'm') $number *= 1024;
            if ($unit === 'g' || $unit === 'm' || $unit === 'k') $number *= 1024;
            return (int) $number;
        };
        $limits = array_filter([$parse(ini_get('upload_max_filesize')), $parse(ini_get('post_max_size'))]);
        return $limits ? min($limits) : 0;
    }

    public static function acceptAttribute() {
        return implode(',', array_map(static function($extension) { return '.' . $extension; }, array_keys(self::allowedTypes())));
    }

    /** Validate an uploaded receipt by extension, size, file signature and actual MIME. */
    public static function validateUpload($file) {
        if (!is_array($file) || !isset($file['error']) || (int) $file['error'] !== UPLOAD_ERR_OK || empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return new \WP_Error('zsb_receipt_upload', __('Please select a valid receipt file and try again.', 'zarinshopbot'));
        }
        $size = isset($file['size']) ? (int) $file['size'] : 0;
        $actual_size = @filesize($file['tmp_name']);
        if (!is_int($actual_size) && !is_float($actual_size)) $actual_size = 0;
        if ($size !== (int) $actual_size || $size < 1 || $size > self::maxUploadBytes()) {
            return new \WP_Error('zsb_receipt_size', sprintf(__('The receipt must be smaller than %s MB (also limited by the server upload settings).', 'zarinshopbot'), number_format(self::maxUploadBytes() / 1048576, 2)));
        }
        $original = sanitize_file_name(wp_unslash($file['name'] ?? 'receipt'));
        $extension = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $allowed = self::allowedTypes();
        if ($extension === '' || !isset($allowed[$extension])) {
            return new \WP_Error('zsb_receipt_type', __('This receipt file format is not allowed.', 'zarinshopbot'));
        }
        $actual = '';
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo) {
                $actual = (string) finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);
            }
        }
        $expected = $allowed[$extension];
        if ($expected === 'application/pdf') {
            $handle = @fopen($file['tmp_name'], 'rb');
            $signature = $handle ? fread($handle, 5) : '';
            if ($handle) fclose($handle);
            if ($signature !== '%PDF-' || ($actual !== '' && $actual !== 'application/pdf')) {
                return new \WP_Error('zsb_receipt_signature', __('The uploaded file is not a valid PDF receipt.', 'zarinshopbot'));
            }
        } else {
            if (!preg_match('~^image/[a-z0-9.+-]+$~', $expected) || ($actual !== '' && $actual !== $expected)) {
                return new \WP_Error('zsb_receipt_signature', __('The uploaded file content does not match an allowed image format.', 'zarinshopbot'));
            }
            if (!function_exists('getimagesize') || @getimagesize($file['tmp_name']) === false) {
                return new \WP_Error('zsb_receipt_signature', __('The uploaded image file could not be verified.', 'zarinshopbot'));
            }
        }
        return [
            'path' => $file['tmp_name'],
            'name' => $original,
            'size' => $size,
            'mime' => $expected,
        ];
    }

    private static function cryptoAvailable() {
        return (function_exists('openssl_encrypt') && function_exists('openssl_decrypt'))
            || (function_exists('sodium_crypto_secretbox') && function_exists('sodium_crypto_secretbox_open'));
    }

    public static function secureStorageAvailable() {
        return self::cryptoAvailable()
            && class_exists('ZarinShopBot\\Core\\Http\\ProxyManager')
            && method_exists('ZarinShopBot\\Core\\Http\\ProxyManager', 'encrypt')
            && method_exists('ZarinShopBot\\Core\\Http\\ProxyManager', 'decrypt');
    }

    /** Store encrypted bytes in private order metadata, never in the public media library. */
    public static function storeReceipt($order, $file) {
        if (!($order instanceof \WC_Order)) return new \WP_Error('zsb_receipt_order', __('Order not found.', 'zarinshopbot'));
        if ($order->get_payment_method() !== self::METHOD_ID || !in_array($order->get_status(), ['pending', 'on-hold'], true)) {
            return new \WP_Error('zsb_receipt_order_state', __('This order can no longer accept a receipt.', 'zarinshopbot'));
        }
        $existing_receipt = (string) $order->get_meta(self::META_RECEIPT, true);
        $review_status = (string) $order->get_meta(self::META_REVIEW, true);
        if ($existing_receipt !== '' && $review_status !== 'rejected') {
            return new \WP_Error('zsb_receipt_already_submitted', __('A receipt is already awaiting review. Upload a replacement only after the manager rejects it.', 'zarinshopbot'));
        }
        $valid = self::validateUpload($file);
        if (is_wp_error($valid)) return $valid;
        if (!self::secureStorageAvailable()) {
            return new \WP_Error('zsb_receipt_crypto', __('Secure receipt storage is unavailable on this server. Please contact the store administrator.', 'zarinshopbot'));
        }
        $bytes = file_get_contents($valid['path']);
        if (!is_string($bytes) || $bytes === '') return new \WP_Error('zsb_receipt_read', __('The receipt file could not be read.', 'zarinshopbot'));
        $encrypted = \ZarinShopBot\Core\Http\ProxyManager::encrypt($bytes);
        if (!is_string($encrypted) || $encrypted === '' || $encrypted === $bytes) {
            return new \WP_Error('zsb_receipt_encrypt', __('The receipt could not be stored securely.', 'zarinshopbot'));
        }
        $order->update_meta_data(self::META_RECEIPT, $encrypted);
        $order->update_meta_data('_zsb_transfer_receipt_name', $valid['name']);
        $order->update_meta_data('_zsb_transfer_receipt_mime', $valid['mime']);
        $order->update_meta_data('_zsb_transfer_receipt_size', $valid['size']);
        $order->update_meta_data(self::META_REVIEW, 'pending');
        // Each upload gets a fresh review nonce so buttons from an older receipt
        // cannot authorize payment after a rejected receipt is replaced.
        $order->update_meta_data(self::META_REVIEW_NONCE, wp_generate_password(16, false, false));
        $order->add_order_note(__('Customer uploaded a card-transfer receipt. Manager review is required before payment is completed.', 'zarinshopbot'));
        $order->save();
        self::notifyPlatformAdminReceipt($order);
        return $valid;
    }

    public static function decryptReceipt($order) {
        if (!($order instanceof \WC_Order)) return new \WP_Error('zsb_receipt_order', __('Order not found.', 'zarinshopbot'));
        $encrypted = (string) $order->get_meta(self::META_RECEIPT, true);
        if ($encrypted === '' || !class_exists('ZarinShopBot\Core\Http\ProxyManager') || !method_exists('ZarinShopBot\Core\Http\ProxyManager', 'decrypt')) {
            return new \WP_Error('zsb_receipt_missing', __('No receipt is available for this order.', 'zarinshopbot'));
        }
        $bytes = \ZarinShopBot\Core\Http\ProxyManager::decrypt($encrypted);
        if (!is_string($bytes) || $bytes === '') return new \WP_Error('zsb_receipt_decrypt', __('The receipt could not be decrypted.', 'zarinshopbot'));
        return $bytes;
    }

    /** Return mini-app payment choices: native provider if configured, otherwise every enabled WC gateway. */
    public static function miniAppPaymentMethods($platform) {
        if ($platform === 'bale' && class_exists(Bale_Payments::class) && Bale_Payments::is_enabled()) {
            return [[
                'id' => Bale_Payments::METHOD_ID,
                'title' => __('پرداخت کیف‌پولی بله', 'zarinshopbot'),
                'description' => __('پرداخت درون‌مینی‌اپ بله؛ وضعیت سفارش پس از تأیید سروری نهایی می‌شود.', 'zarinshopbot'),
                'type' => 'native',
            ]];
        }
        if ($platform !== 'bale' && function_exists('zarincode_option') && zarincode_option('telegram_invoice_enable') === '1' && (string) zarincode_option('telegram_provider_token') !== '') {
            return [[
                'id' => 'zarincode_telegram_invoice',
                'title' => __('پرداخت درون‌برنامه‌ای تلگرام', 'zarinshopbot'),
                'description' => __('پرداخت امن در مینی‌اپ تلگرام.', 'zarinshopbot'),
                'type' => 'native',
            ]];
        }
        if (!function_exists('WC') || !WC() || !WC()->payment_gateways()) return [];
        $gateway_objects = WC()->payment_gateways()->payment_gateways();
        $methods = [];
        foreach ($gateway_objects as $gateway) {
            if (!is_object($gateway) || empty($gateway->id) || !self::gatewayIsEnabled($gateway)) continue;
            // Expose every explicitly enabled website gateway. The selected gateway's
            // own WooCommerce order-pay flow applies its eligibility rules afterwards.
            if ($gateway->id === self::METHOD_ID) {
                try {
                    if (method_exists($gateway, 'is_available') && !$gateway->is_available()) continue;
                } catch (\Throwable $e) {
                    continue;
                }
            }
            $method = [
                'id' => sanitize_text_field((string) $gateway->id),
                'title' => wp_strip_all_tags((string) ($gateway->title ?? $gateway->method_title ?? $gateway->id)),
                'description' => $gateway->id === self::METHOD_ID
                    ? self::plainCustomerText(self::customerDescription())
                    : wp_strip_all_tags((string) ($gateway->description ?? '')),
                'type' => $gateway->id === self::METHOD_ID ? 'card_transfer' : 'website',
            ];
            if ($gateway->id === self::METHOD_ID) {
                $method['accounts'] = self::accounts();
                $method['allowed_extensions'] = array_keys(self::allowedTypes());
                $method['accept'] = self::acceptAttribute();
                $method['max_upload_bytes'] = self::maxUploadBytes();
                $method['max_upload_label'] = number_format(self::maxUploadBytes() / 1048576, 2) . ' MB';
                $method['account_prompt'] = __('Choose the destination account:', 'zarinshopbot');
                $method['instructions'] = self::plainCustomerText(self::customerInstructions());
            }
            $methods[] = $method;
        }
        return $methods;
    }

    public static function gatewayIsEnabled($gateway) {
        if (!is_object($gateway)) return false;
        $values = ['yes', '1', 1, true, 'true', 'on'];
        if (isset($gateway->enabled) && in_array($gateway->enabled, $values, true)) return true;
        $id = isset($gateway->id) ? (string) $gateway->id : '';
        if ($id === '') return false;
        $settings = get_option('woocommerce_' . sanitize_key($id) . '_settings', []);
        return is_array($settings) && isset($settings['enabled']) && in_array($settings['enabled'], $values, true);
    }

    public static function gatewayObject($id) {
        if (!function_exists('WC') || !WC() || !WC()->payment_gateways()) return null;
        $id = trim((string) $id);
        if ($id === '') return null;
        $gateways = WC()->payment_gateways()->payment_gateways();
        if (isset($gateways[$id]) && is_object($gateways[$id])) return $gateways[$id];
        $normalized_id = sanitize_key($id);
        foreach ((array) $gateways as $key => $gateway) {
            if (!is_object($gateway)) continue;
            $gateway_id = isset($gateway->id) ? (string) $gateway->id : (string) $key;
            if ($gateway_id === $id || sanitize_key($gateway_id) === $normalized_id || sanitize_key((string) $key) === $normalized_id) {
                return $gateway;
            }
        }
        return null;
    }

    private static function renderCopyButton($value, $label) {
        $value = (string) $value;
        if ($value === '') return;
        $copy_text = sprintf(__('Copy %s', 'zarinshopbot'), $label);
        echo '<button type="button" class="zsb-copy-value" data-copy-value="' . esc_attr($value) . '" data-copy-label="' . esc_attr($copy_text) . '" data-copy-default="' . esc_attr__('Copy', 'zarinshopbot') . '" data-copy-success="' . esc_attr__('Copied', 'zarinshopbot') . '" data-copy-failure="' . esc_attr__('Could not copy; select the value and copy it manually.', 'zarinshopbot') . '" aria-label="' . esc_attr($copy_text) . '">';
        echo '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="8" y="8" width="12" height="12" rx="2"></rect><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"></path></svg>';
        echo '<span>' . esc_html__('Copy', 'zarinshopbot') . '</span></button>';
    }

    private static function renderBankField($label, $value, $class = '') {
        $value = trim((string) $value);
        if ($value === '') return;
        echo '<div class="zsb-bank-field ' . esc_attr($class) . '"><div class="zsb-bank-field-copy"><span class="zsb-bank-field-label">' . esc_html($label) . '</span>';
        echo '<bdi dir="ltr" class="zsb-bank-field-value">' . esc_html($value) . '</bdi></div>';
        self::renderCopyButton($value, $label);
        echo '</div>';
    }

    public static function renderBankDetails($account = null) {
        $accounts = $account ? [$account] : self::accounts();
        if (!$accounts) return;
        echo '<div class="zsb-transfer-accounts">';
        foreach ($accounts as $item) {
            $label = (string) ($item['label'] ?? __('Bank account', 'zarinshopbot'));
            $bank = (string) ($item['bank'] ?? '');
            echo '<section class="zsb-transfer-account-card" aria-label="' . esc_attr($label) . '">';
            echo '<header class="zsb-bank-card-header"><span class="zsb-bank-card-chip" aria-hidden="true"><svg viewBox="0 0 42 32" focusable="false"><rect x="1" y="1" width="40" height="30" rx="5"></rect><path d="M1 11h40M14 11v10m14-10v10M1 21h40M14 21v10m14-10v10"></path></svg></span><span class="zsb-bank-card-title">' . esc_html__('Bank transfer', 'zarinshopbot') . '</span><span class="zsb-bank-card-brand">' . esc_html($bank !== '' ? $bank : $label) . '</span></header>';
            echo '<div class="zsb-bank-card-content"><div class="zsb-bank-card-name"><span>' . esc_html__('Account name', 'zarinshopbot') . '</span><strong>' . esc_html($label) . '</strong></div>';
            if (!empty($item['holder'])) self::renderBankField(__('Account holder', 'zarinshopbot'), $item['holder'], 'zsb-bank-field-holder');
            echo '<div class="zsb-bank-number-grid">';
            if (!empty($item['card_number'])) self::renderBankField(__('Card number', 'zarinshopbot'), $item['card_number'], 'zsb-bank-field-card');
            if (!empty($item['account_number'])) self::renderBankField(__('Account number', 'zarinshopbot'), $item['account_number'], 'zsb-bank-field-account');
            if (!empty($item['iban'])) self::renderBankField(__('IBAN', 'zarinshopbot'), $item['iban'], 'zsb-bank-field-iban');
            echo '</div>';
            if (!empty($item['instructions'])) echo '<p class="zsb-bank-instructions">' . esc_html($item['instructions']) . '</p>';
            echo '<span class="zsb-copy-status" role="status" aria-live="polite"></span></div></section>';
        }
        echo '</div>';
    }

    public static function renderThankYou($order_id) {
        $order = wc_get_order($order_id);
        if (!$order || $order->get_payment_method() !== self::METHOD_ID) return;
        echo '<section class="zsb-transfer-receipt">';
        echo '<h2>' . esc_html__('Card transfer payment', 'zarinshopbot') . '</h2>';
        self::renderBankDetails(self::accountForOrder($order));
        self::renderCustomerInstructions();
        $review_status = (string) $order->get_meta(self::META_REVIEW, true);
        if ((string) $order->get_meta(self::META_RECEIPT, true) !== '' && $review_status !== 'rejected') {
            echo '<p>' . esc_html__('Your receipt was received. The order will remain on hold until the store manager verifies the payment.', 'zarinshopbot') . '</p>';
            echo '</section>';
            return;
        }
        if ($review_status === 'rejected') echo '<p>' . esc_html__('The previous receipt was rejected. Please upload a replacement receipt.', 'zarinshopbot') . '</p>';
        self::renderWebsiteReceiptForm($order);
        echo '</section>';
    }

    public static function renderOrderDetailsUpload($order) {
        if (!($order instanceof \WC_Order) || $order->get_payment_method() !== self::METHOD_ID) return;
        if (function_exists('is_order_received_page') && is_order_received_page()) return;
        if (!in_array($order->get_status(), ['pending', 'on-hold'], true) || $order->get_meta(self::META_REVIEW, true) === 'approved') return;
        $review_status = (string) $order->get_meta(self::META_REVIEW, true);
        if ((string) $order->get_meta(self::META_RECEIPT, true) !== '' && $review_status !== 'rejected') return;
        echo '<section class="zsb-transfer-receipt"><h2>' . esc_html__('Card transfer payment', 'zarinshopbot') . '</h2>';
        self::renderBankDetails(self::accountForOrder($order));
        self::renderCustomerInstructions();
        if ($review_status === 'rejected') echo '<p>' . esc_html__('The previous receipt was rejected. Please upload a replacement receipt.', 'zarinshopbot') . '</p>';
        self::renderWebsiteReceiptForm($order);
        echo '</section>';
    }

    private static function renderWebsiteReceiptForm($order) {
        $accept = self::acceptAttribute();
        $size = number_format(self::maxUploadBytes() / 1048576, 2);
        echo '<form class="zsb-transfer-upload" method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="zsb_card_transfer_receipt">';
        echo '<input type="hidden" name="order_id" value="' . esc_attr($order->get_id()) . '">';
        echo '<input type="hidden" name="order_key" value="' . esc_attr($order->get_order_key()) . '">';
        wp_nonce_field('zsb_transfer_receipt_' . $order->get_id(), 'zsb_receipt_nonce');
        echo '<label for="zsb_transfer_receipt_file">' . esc_html__('Upload payment receipt', 'zarinshopbot') . '</label> ';
        echo '<input id="zsb_transfer_receipt_file" type="file" name="payment_receipt" accept="' . esc_attr($accept) . '" required>';
        echo '<p>' . esc_html(sprintf(__('Allowed formats: %1$s. Maximum file size: %2$s MB.', 'zarinshopbot'), implode(', ', array_keys(self::allowedTypes())), $size)) . '</p>';
        echo '<button type="submit" class="button alt">' . esc_html__('Submit receipt for review', 'zarinshopbot') . '</button>';
        echo '</form>';
    }

    public static function handleWebsiteReceipt() {
        $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $order = wc_get_order($order_id);
        $key = isset($_POST['order_key']) ? sanitize_text_field(wp_unslash($_POST['order_key'])) : '';
        if (!$order || $order->get_payment_method() !== self::METHOD_ID || !hash_equals((string) $order->get_order_key(), $key) || !wp_verify_nonce($_POST['zsb_receipt_nonce'] ?? '', 'zsb_transfer_receipt_' . $order_id)) {
            wp_die(esc_html__('Receipt submission could not be verified.', 'zarinshopbot'), '', ['response' => 403]);
        }
        if (!in_array($order->get_status(), ['pending', 'on-hold'], true) || $order->get_meta(self::META_REVIEW, true) === 'approved') {
            wp_die(esc_html__('This order can no longer accept a receipt.', 'zarinshopbot'), '', ['response' => 409]);
        }
        $stored = self::storeReceipt($order, $_FILES['payment_receipt'] ?? null);
        if (is_wp_error($stored)) wp_die(esc_html($stored->get_error_message()), '', ['response' => 400]);
        wp_safe_redirect(add_query_arg('zsb_receipt', 'received', $order->get_checkout_order_received_url()));
        exit;
    }

    /** Mini App AJAX uploads use signed platform initData, order ownership, same strict file validation and encryption. */
    public static function ajaxUploadReceipt() {
        if (!class_exists('ZarinShopBot\Core\WooBot')) {
            wp_send_json_error(['message' => __('Mini App verification is unavailable.', 'zarinshopbot')], 503);
        }
        $chat_id = isset($_POST['chat_id']) ? sanitize_text_field(wp_unslash($_POST['chat_id'])) : '';
        $auth = \ZarinShopBot\Core\WooBot::verifyWebAppSecurity($chat_id, true);
        if (is_wp_error($auth)) wp_send_json_error(['message' => $auth->get_error_message()], 403);
        $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $order = wc_get_order($order_id);
        if (!$order || $order->get_payment_method() !== self::METHOD_ID || (string) $order->get_meta('_chat_id', true) !== (string) $auth['chat_id'] || (string) $order->get_meta('_order_from', true) !== (string) $auth['platform']) {
            wp_send_json_error(['message' => __('Order ownership could not be verified.', 'zarinshopbot')], 403);
        }
        if (!in_array($order->get_status(), ['pending', 'on-hold'], true) || $order->get_meta(self::META_REVIEW, true) === 'approved') {
            wp_send_json_error(['message' => __('This order can no longer accept a receipt.', 'zarinshopbot')], 409);
        }
        $stored = self::storeReceipt($order, $_FILES['payment_receipt'] ?? null);
        if (is_wp_error($stored)) wp_send_json_error(['message' => $stored->get_error_message()], 400);
        wp_send_json_success(['message' => __('Receipt received. The order remains on hold until a manager verifies payment.', 'zarinshopbot')]);
    }

    public static function renderAdminOrderReview($order) {
        if (!($order instanceof \WC_Order) || $order->get_payment_method() !== self::METHOD_ID || !current_user_can('edit_shop_order', $order->get_id())) return;
        $order_id = absint($order->get_id());
        $GLOBALS['zsb_transfer_admin_review_order_id'] = $order_id;
        $form_id = 'zsb-transfer-review-form-' . $order_id;
        $status = (string) $order->get_meta(self::META_REVIEW, true);
        $receipt_exists = (string) $order->get_meta(self::META_RECEIPT, true) !== '';
        $account = self::accountForOrder($order);
        echo '<div class="zsb-transfer-admin-review"><h3>' . esc_html__('Card-transfer receipt review', 'zarinshopbot') . '</h3>';
        echo '<p>' . esc_html__('Review status:', 'zarinshopbot') . ' <strong>' . esc_html($status ?: 'awaiting_receipt') . '</strong></p>';
        if ($account) echo '<p>' . esc_html__('Selected account:', 'zarinshopbot') . ' ' . esc_html($account['label']) . ' — <bdi>' . esc_html($account['card_number']) . '</bdi></p>';
        if (!$receipt_exists) {
            echo '<p>' . esc_html__('No receipt has been uploaded yet. Payment cannot be approved until a receipt is available.', 'zarinshopbot') . '</p></div>';
            return;
        }
        $view_url = wp_nonce_url(add_query_arg(['action' => 'zsb_card_transfer_view_receipt', 'order_id' => $order_id], admin_url('admin-post.php')), 'zsb_view_receipt_' . $order_id);
        echo '<p><a class="button" href="' . esc_url($view_url) . '" target="_blank" rel="noopener">' . esc_html__('View private receipt', 'zarinshopbot') . '</a></p>';
        if ($status === 'pending' && in_array($order->get_status(), ['pending', 'on-hold'], true)) {
            echo '<button form="' . esc_attr($form_id) . '" name="operation" value="approve" class="button button-primary" type="submit">' . esc_html__('Approve payment', 'zarinshopbot') . '</button> ';
            echo '<button form="' . esc_attr($form_id) . '" name="operation" value="reject" class="button" type="submit">' . esc_html__('Reject receipt', 'zarinshopbot') . '</button>';
        }
        echo '</div>';
    }

    /**
     * Render the POST form outside WooCommerce's order form. Nested forms are
     * invalid HTML and caused the review buttons to submit the WooCommerce
     * order editor instead of admin-post.php on classic and HPOS screens.
     */
    public static function renderAdminReviewForms() {
        $order_id = absint($GLOBALS['zsb_transfer_admin_review_order_id'] ?? 0);
        if (!$order_id || !current_user_can('edit_shop_order', $order_id)) return;
        echo '<form id="zsb-transfer-review-form-' . esc_attr($order_id) . '" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="zsb_card_transfer_review">';
        echo '<input type="hidden" name="order_id" value="' . esc_attr($order_id) . '">';
        $order = wc_get_order($order_id);
        $review_nonce = $order instanceof \WC_Order ? (string) $order->get_meta(self::META_REVIEW_NONCE, true) : '';
        echo '<input type="hidden" name="review_nonce" value="' . esc_attr($review_nonce) . '">';
        wp_nonce_field('zsb_transfer_review_' . $order_id);
        echo '</form>';
    }

    private static function orderPlatform($order) {
        if (!($order instanceof \WC_Order)) return '';
        $platform = sanitize_key((string) $order->get_meta('_order_from', true));
        if (in_array($platform, ['telegram', 'bale', 'rubika'], true)) return $platform;
        $stored_chat = (string) $order->get_meta('_chat_id', true);
        foreach (['bale', 'rubika'] as $candidate) {
            if (strpos($stored_chat, $candidate . '_') === 0) return $candidate;
        }
        $order_platform = sanitize_key((string) $order->get_meta('_order_platform', true));
        foreach (['telegram', 'bale', 'rubika'] as $candidate) {
            if (strpos($order_platform, $candidate) === 0) return $candidate;
        }
        return $stored_chat !== '' ? 'telegram' : '';
    }

    private static function configuredAdminChatId($platform) {
        $platform = sanitize_key((string) $platform);
        if ($platform === 'telegram') {
            return trim((string) zarincode_option('admin_notification_chat_id'));
        }
        if (!in_array($platform, ['bale', 'rubika'], true) || !class_exists(Channels::class)) return '';
        $options = Channels::options();
        return trim((string) ($options[$platform . '_admin_chat_id'] ?? ''));
    }

    private static function platformToken($platform) {
        if ($platform === 'telegram') {
            return (string) zarincode_option('token');
        }
        if (!in_array($platform, ['bale', 'rubika'], true) || !class_exists(Channels::class)) return '';
        $options = Channels::options();
        if (($options[$platform . '_enabled'] ?? '0') !== '1') return '';
        return (string) ($options[$platform . '_token'] ?? '');
    }

    private static function sendPlatformMessage($platform, $chat_id, $text, array $keyboard = []) {
        $platform = sanitize_key((string) $platform);
        $chat_id = trim((string) $chat_id);
        if ($chat_id === '' || !in_array($platform, ['telegram', 'bale', 'rubika'], true)) {
            return new \WP_Error('zsb_transfer_channel_config', __('Platform destination is not configured.', 'zarinshopbot'));
        }
        $params = ['chat_id' => $chat_id, 'text' => (string) $text, 'parse_mode' => 'HTML'];
        if (strpos((string) $text, '<a href=') !== false && $platform === 'telegram') $params['disable_web_page_preview'] = true;
        if ($keyboard) $params['reply_markup'] = ['inline_keyboard' => $keyboard];
        if ($platform === 'telegram') {
            if (!class_exists('ZarinShopBot\Core\Http\TelegramApiAdapter')) return new \WP_Error('zsb_transfer_telegram_unavailable', __('Telegram API adapter is unavailable.', 'zarinshopbot'));
            return \ZarinShopBot\Core\Http\TelegramApiAdapter::call('sendMessage', $params, 0);
        }
        if (!class_exists(Channels::class)) return new \WP_Error('zsb_transfer_channel_unavailable', __('Channel API adapter is unavailable.', 'zarinshopbot'));
        $token = self::platformToken($platform);
        if ($token === '') return new \WP_Error('zsb_transfer_channel_disabled', __('The selected messaging platform is disabled or not configured.', 'zarinshopbot'));
        $api = new Channel_API($platform, $token);
        return $api->telegram_call('sendMessage', $params);
    }

    private static function orderEditUrl($order_id) {
        $hpos = class_exists('Automattic\WooCommerce\Utilities\OrderUtil')
            && method_exists('Automattic\WooCommerce\Utilities\OrderUtil', 'custom_orders_table_usage_is_enabled')
            && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
        return $hpos
            ? admin_url('admin.php?page=wc-orders&action=edit&id=' . absint($order_id))
            : admin_url('post.php?post=' . absint($order_id) . '&action=edit');
    }

    private static function reviewCallback($platform, $order_id, $operation, $admin_id, $review_nonce) {
        $action = $operation === 'approve' ? 'a' : 'r';
        $review_nonce = preg_match('/\\A[A-Za-z0-9]{16}\\z/', (string) $review_nonce) ? (string) $review_nonce : '';
        $payload = implode('|', ['zsb-card-transfer-review', $platform, absint($order_id), $action, (string) $admin_id, $review_nonce]);
        $signature = substr(hash_hmac('sha256', $payload, wp_salt('auth')), 0, 12);
        return 'ztr:' . $action . ':' . absint($order_id) . ':' . $review_nonce . ':' . $signature;
    }

    private static function notifyPlatformAdminReceipt($order) {
        if (!($order instanceof \WC_Order)) return false;
        $platform = self::orderPlatform($order);
        $admin_id = self::configuredAdminChatId($platform);
        if ($platform === '' || $admin_id === '') {
            if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_admin_alert_skipped', [
                'platform' => $platform ?: 'unknown', 'reason' => $platform === '' ? 'order_platform_missing' : 'admin_id_missing',
                'order_id' => (int) $order->get_id(),
            ]);
            return false;
        }
        $order_id = (int) $order->get_id();
        $customer = trim((string) $order->get_formatted_billing_full_name());
        $text = "🧾 <b>رسید کارت‌به‌کارت برای بررسی</b>\n\n"
            . 'سفارش: <b>#' . esc_html($order->get_order_number()) . "</b>\n"
            . 'مبلغ: <b>' . esc_html(wp_strip_all_tags($order->get_formatted_order_total())) . "</b>\n"
            . ($customer !== '' ? 'خریدار: <b>' . esc_html($customer) . "</b>\n" : '')
            . 'کانال خرید: <b>' . esc_html(strtoupper($platform)) . "</b>\n\n"
            . 'برای مشاهدهٔ فایل رسید، سفارش را در پیشخوان باز کنید؛ سپس از همین پیام تأیید یا رد را بزنید.';
        $keyboard = [[
            ['text' => '✅ تأیید پرداخت', 'callback_data' => self::reviewCallback($platform, $order_id, 'approve', $admin_id, (string) $order->get_meta(self::META_REVIEW_NONCE, true))],
            ['text' => '❌ رد رسید', 'callback_data' => self::reviewCallback($platform, $order_id, 'reject', $admin_id, (string) $order->get_meta(self::META_REVIEW_NONCE, true))],
        ], [[
            'text' => '🔎 مشاهدهٔ سفارش و رسید', 'url' => self::orderEditUrl($order_id),
        ]]];
        $result = self::sendPlatformMessage($platform, $admin_id, $text, $keyboard);
        if (is_wp_error($result)) {
            if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_admin_alert_failed', [
                'platform' => $platform, 'order_id' => $order_id, 'error_code' => sanitize_key($result->get_error_code()),
            ]);
            return false;
        }
        $order->update_meta_data('_zsb_transfer_admin_alert_sent', gmdate('c'));
        $order->save();
        if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_admin_alert_sent', [
            'platform' => $platform, 'order_id' => $order_id,
        ]);
        return true;
    }

    private static function approveOrder($order, $source) {
        if (!($order instanceof \WC_Order) || $order->get_payment_method() !== self::METHOD_ID
            || !in_array($order->get_status(), ['pending', 'on-hold'], true)
            || (string) $order->get_meta(self::META_REVIEW, true) !== 'pending'
            || (string) $order->get_meta(self::META_RECEIPT, true) === '') {
            return new \WP_Error('zsb_transfer_review_not_ready', __('Order is not awaiting card-transfer review or has no receipt.', 'zarinshopbot'));
        }
        $order->update_meta_data(self::META_REVIEW, 'approved');
        $order->update_meta_data('_zsb_transfer_approval_notice_state', 'pending');
        $order->add_order_note(sprintf(__('Card-transfer receipt approved by %s; completing WooCommerce payment.', 'zarinshopbot'), sanitize_text_field((string) $source)));
        $order->save();
        try {
            $order->payment_complete();
        } catch (\Throwable $error) {
            $order->update_meta_data(self::META_REVIEW, 'pending');
            $order->add_order_note(__('Payment completion threw an error after card-transfer approval; review remains pending for safe retry.', 'zarinshopbot'));
            $order->save();
            if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_payment_complete_failed', [
                'order_id' => (int) $order->get_id(), 'source' => sanitize_key((string) $source), 'error_type' => get_class($error),
            ]);
            return new \WP_Error('zsb_transfer_payment_complete_failed', __('WooCommerce could not complete this order payment. The review was left pending; check the order notes and WooCommerce logs.', 'zarinshopbot'));
        }
        if (!$order->is_paid()) {
            $order->update_meta_data(self::META_REVIEW, 'pending');
            $order->add_order_note(__('Card-transfer approval did not move the order into a paid status; review remains pending.', 'zarinshopbot'));
            $order->save();
            if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_payment_not_paid_after_complete', [
                'order_id' => (int) $order->get_id(), 'status' => sanitize_key((string) $order->get_status()),
            ]);
            return new \WP_Error('zsb_transfer_order_not_paid', __('WooCommerce did not mark the order as paid. Review was left pending.', 'zarinshopbot'));
        }
        $order->delete_meta_data(self::META_REVIEW_NONCE);
        $order->save();
        self::notifyBuyerApproved($order);
        if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_review_approved', [
            'order_id' => (int) $order->get_id(), 'status' => sanitize_key((string) $order->get_status()), 'source' => sanitize_key((string) $source),
        ]);
        return true;
    }

    private static function rejectOrder($order, $source) {
        if (!($order instanceof \WC_Order) || $order->get_payment_method() !== self::METHOD_ID
            || !in_array($order->get_status(), ['pending', 'on-hold'], true)
            || (string) $order->get_meta(self::META_REVIEW, true) !== 'pending'
            || (string) $order->get_meta(self::META_RECEIPT, true) === '') {
            return new \WP_Error('zsb_transfer_review_not_ready', __('Order is not awaiting card-transfer review or has no receipt.', 'zarinshopbot'));
        }
        $order->update_meta_data(self::META_REVIEW, 'rejected');
        $order->delete_meta_data(self::META_REVIEW_NONCE);
        $order->add_order_note(sprintf(__('Card-transfer receipt rejected by %s; customer may upload a replacement.', 'zarinshopbot'), sanitize_text_field((string) $source)));
        $order->save();
        self::notifyBuyerRejected($order);
        if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_review_rejected', [
            'order_id' => (int) $order->get_id(), 'status' => sanitize_key((string) $order->get_status()), 'source' => sanitize_key((string) $source),
        ]);
        return true;
    }

    /** Verify callback origin against the channel-specific admin destination and signed order action. */
    public static function handleBotReview($platform, $actor_id, $callback) {
        $platform = sanitize_key((string) $platform);
        $actor_id = trim((string) $actor_id);
        if (!in_array($platform, ['telegram', 'bale', 'rubika'], true)) {
            return new \WP_Error('zsb_transfer_review_platform', __('Unsupported review platform.', 'zarinshopbot'));
        }
        $prefix = $platform . '_';
        if (strpos($actor_id, $prefix) === 0) $actor_id = substr($actor_id, strlen($prefix));
        $admin_id = self::configuredAdminChatId($platform);
        $authorized = $admin_id !== '' && hash_equals($admin_id, $actor_id);
        $fail = static function($code, $message) use ($platform, $actor_id, $authorized) {
            if ($authorized) self::sendPlatformMessage($platform, $actor_id, __('این دکمه معتبر نیست یا سفارش دیگر در انتظار بررسی نیست.', 'zarinshopbot'));
            return new \WP_Error($code, $message);
        };
        if (!preg_match('/\Aztr:([ar]):([0-9]{1,12}):([A-Za-z0-9]{16}):([a-f0-9]{12})\z/i', trim((string) $callback), $matches)) {
            return $fail('zsb_transfer_callback_invalid', __('Invalid card-transfer review action.', 'zarinshopbot'));
        }
        if (!$authorized) {
            if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_review_denied', ['platform' => $platform, 'reason' => 'admin_identity_mismatch']);
            return new \WP_Error('zsb_transfer_review_forbidden', __('This account is not authorized to review card-transfer receipts.', 'zarinshopbot'));
        }
        $order_id = absint($matches[2]);
        $action = strtolower($matches[1]);
        $review_nonce = (string) $matches[3];
        $expected = self::reviewCallback($platform, $order_id, $action === 'a' ? 'approve' : 'reject', $admin_id, $review_nonce);
        if (!hash_equals($expected, trim((string) $callback))) {
            return $fail('zsb_transfer_callback_signature', __('This review button is invalid or has expired.', 'zarinshopbot'));
        }
        $order = wc_get_order($order_id);
        if (!$order || self::orderPlatform($order) !== $platform) {
            return $fail('zsb_transfer_callback_order', __('The order does not belong to this messaging platform.', 'zarinshopbot'));
        }
        $stored_review_nonce = (string) $order->get_meta(self::META_REVIEW_NONCE, true);
        if ($stored_review_nonce === '' || !hash_equals($stored_review_nonce, $review_nonce)
            || (string) $order->get_meta(self::META_REVIEW, true) !== 'pending') {
            return $fail('zsb_transfer_callback_stale', __('This receipt has already been reviewed or replaced; use the latest review message.', 'zarinshopbot'));
        }
        $result = $action === 'a' ? self::approveOrder($order, $platform . '_admin_bot') : self::rejectOrder($order, $platform . '_admin_bot');
        if (is_wp_error($result)) {
            self::sendPlatformMessage($platform, $actor_id, $result->get_error_message());
            return $result;
        }
        $message = $action === 'a'
            ? sprintf(__('پرداخت سفارش #%s تأیید شد و وضعیت ووکامرس به‌روزرسانی گردید.', 'zarinshopbot'), $order->get_order_number())
            : sprintf(__('رسید سفارش #%s رد شد؛ مشتری می‌تواند رسید جایگزین بفرستد.', 'zarinshopbot'), $order->get_order_number());
        $sent = self::sendPlatformMessage($platform, $actor_id, $message);
        if (is_wp_error($sent) && function_exists('zarincode_log_event')) {
            zarincode_log_event('card_transfer_admin_action_reply_failed', ['platform' => $platform, 'error_code' => sanitize_key($sent->get_error_code())]);
        }
        return true;
    }

    /** Send only WooCommerce-permitted downloads to the bot after a confirmed payment. */
    public static function notifyPaidOrderDownloads($order_id) {
        $order = wc_get_order(absint($order_id));
        if (!($order instanceof \WC_Order) || !$order->is_paid() || !$order->has_downloadable_item()
            || !$order->is_download_permitted() || $order->get_payment_method() === self::METHOD_ID
            || (string) $order->get_meta('_zsb_free_digital_checkout', true) === 'yes'
            || (string) $order->get_meta(self::META_BOT_DOWNLOADS_NOTICE, true) === 'sent') {
            return false;
        }
        $platform = self::orderPlatform($order);
        $chat_id = trim((string) $order->get_meta('_chat_id', true));
        if ($platform === '' || $chat_id === '') return false;

        $lock_key = '_zsb_bot_download_delivery_lock_' . absint($order_id);
        $lock_acquired = false;
        if (function_exists('add_option')) {
            $lock_acquired = add_option($lock_key, time(), '', false);
            if (!$lock_acquired) {
                $locked_at = function_exists('get_option') ? (int) get_option($lock_key, 0) : time();
                if ($locked_at > 0 && time() - $locked_at > 120 && function_exists('delete_option')) {
                    delete_option($lock_key);
                    $lock_acquired = add_option($lock_key, time(), '', false);
                }
                if (!$lock_acquired) return false;
            }
        }

        try {
            $links = array();
            foreach ((array) $order->get_downloadable_items() as $item) {
                $url = isset($item['download_url']) ? esc_url($item['download_url']) : '';
                if ($url === '') continue;
                $name = (string) ($item['download_name'] ?? $item['product_name'] ?? __('Download', 'zarinshopbot'));
                $links[] = '<a href="' . $url . '">' . esc_html($name) . '</a>';
                if (count($links) >= 10) break;
            }
            if (!$links) return false;
            $text = "✅ <b>پرداخت سفارش تأیید شد</b>\n\n"
                . 'سفارش: <b>#' . esc_html($order->get_order_number()) . "</b>\n\n"
                . '📥 <b>دریافت محصول:</b>\n' . implode("\n", $links);
            $sent = self::sendPlatformMessage($platform, $chat_id, $text, [[['text' => '📦 پیگیری سفارش', 'callback_data' => '/TRACK1']]]);
            if (is_wp_error($sent)) {
                if (function_exists('zarincode_log_event')) zarincode_log_event('bot_download_delivery_failed', [
                    'platform' => $platform, 'order_id' => (int) $order_id, 'error_code' => sanitize_key($sent->get_error_code()),
                ]);
                return false;
            }
            $order->update_meta_data(self::META_BOT_DOWNLOADS_NOTICE, 'sent');
            $order->save();
            return true;
        } finally {
            if ($lock_acquired && function_exists('delete_option')) delete_option($lock_key);
        }
    }

    private static function notifyBuyerApproved($order) {
        if (!($order instanceof \WC_Order)) return false;
        $platform = self::orderPlatform($order);
        $chat_id = trim((string) $order->get_meta('_chat_id', true));
        if ($platform === '' || $chat_id === '') return false;
        $text = "✅ <b>پرداخت کارت‌به‌کارت تأیید شد</b>\n\n"
            . 'سفارش: <b>#' . esc_html($order->get_order_number()) . "</b>\n"
            . 'مبلغ: <b>' . esc_html(wp_strip_all_tags($order->get_formatted_order_total())) . "</b>\n"
            . 'وضعیت: <b>' . esc_html(wc_get_order_status_name($order->get_status())) . "</b>";
        $downloads = [];
        if ($order->is_download_permitted()) {
            foreach ((array) $order->get_downloadable_items() as $item) {
                if (empty($item['download_url'])) continue;
                $label = (string) ($item['download_name'] ?? $item['product_name'] ?? __('Download', 'zarinshopbot'));
                $downloads[] = '<a href="' . esc_url($item['download_url']) . '">' . esc_html($label) . '</a>';
                if (count($downloads) >= 5) break;
            }
        }
        if ($downloads) $text .= "\n\n📥 <b>لینک دریافت محصول:</b>\n" . implode("\n", $downloads);
        $keyboard = [[['text' => '📦 پیگیری سفارش', 'callback_data' => '/TRACK1']]];
        $sent = self::sendPlatformMessage($platform, $chat_id, $text, $keyboard);
        if (!is_wp_error($sent)) {
            $order->update_meta_data('_zsb_transfer_approval_notice_state', 'sent');
            $order->update_meta_data('_zarincode_payment_notified', gmdate('c'));
            $order->save();
            return true;
        }
        if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_buyer_notice_failed', [
            'platform' => $platform, 'order_id' => (int) $order->get_id(), 'error_code' => sanitize_key($sent->get_error_code()),
        ]);
        return false;
    }

    private static function notifyBuyerRejected($order) {
        if (!($order instanceof \WC_Order)) return false;
        $platform = self::orderPlatform($order);
        $chat_id = trim((string) $order->get_meta('_chat_id', true));
        if ($platform === '' || $chat_id === '') return false;
        $text = sprintf(__('❌ رسید کارت‌به‌کارت سفارش #%s تأیید نشد. لطفاً از صفحهٔ سفارش، رسید واضح و معتبر دیگری ارسال کنید.', 'zarinshopbot'), $order->get_order_number());
        $sent = self::sendPlatformMessage($platform, $chat_id, $text, [[['text' => '📦 پیگیری سفارش', 'callback_data' => '/TRACK1']]]);
        return !is_wp_error($sent);
    }

    public static function handleAdminReview() {
        $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $order = wc_get_order($order_id);
        if (!$order || !current_user_can('edit_shop_order', $order_id) || $order->get_payment_method() !== self::METHOD_ID || !wp_verify_nonce($_POST['_wpnonce'] ?? '', 'zsb_transfer_review_' . $order_id)) {
            wp_die(esc_html__('You are not allowed to review this payment.', 'zarinshopbot'), '', ['response' => 403]);
        }
        $operation = isset($_POST['operation']) ? sanitize_key(wp_unslash($_POST['operation'])) : '';
        if (!in_array($operation, ['approve', 'reject'], true)) {
            wp_die(esc_html__('Invalid review action.', 'zarinshopbot'), '', ['response' => 400]);
        }
        $current_review_nonce = (string) $order->get_meta(self::META_REVIEW_NONCE, true);
        $submitted_review_nonce = isset($_POST['review_nonce']) ? sanitize_text_field(wp_unslash($_POST['review_nonce'])) : '';
        if ($current_review_nonce !== '' && !hash_equals($current_review_nonce, $submitted_review_nonce)) {
            wp_die(esc_html__('This receipt changed after the review page was opened. Reload the order and inspect the latest receipt.', 'zarinshopbot'), '', ['response' => 409]);
        }
        $result = $operation === 'approve' ? self::approveOrder($order, 'woocommerce_admin') : self::rejectOrder($order, 'woocommerce_admin');
        if (is_wp_error($result)) {
            if (function_exists('zarincode_log_event')) zarincode_log_event('card_transfer_admin_review_failed', [
                'order_id' => $order_id, 'operation' => $operation, 'error_code' => sanitize_key($result->get_error_code()),
            ]);
            wp_die(esc_html($result->get_error_message()), '', ['response' => 409]);
        }
        $referer = wp_get_referer();
        wp_safe_redirect($referer ?: self::orderEditUrl($order_id));
        exit;
    }

    public static function handleViewReceipt() {
        $order_id = isset($_GET['order_id']) ? absint($_GET['order_id']) : 0;
        $order = wc_get_order($order_id);
        if (!$order || !current_user_can('edit_shop_order', $order_id) || !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'zsb_view_receipt_' . $order_id)) {
            wp_die(esc_html__('You are not allowed to view this receipt.', 'zarinshopbot'), '', ['response' => 403]);
        }
        $bytes = self::decryptReceipt($order);
        if (is_wp_error($bytes)) wp_die(esc_html($bytes->get_error_message()), '', ['response' => 404]);
        $mime = strtolower((string) $order->get_meta('_zsb_transfer_receipt_mime', true));
        $extension = strtolower(pathinfo((string) $order->get_meta('_zsb_transfer_receipt_name', true), PATHINFO_EXTENSION));
        $safe_mime = $mime === 'application/pdf' || (bool) preg_match('~^image/[a-z0-9.+-]+$~', $mime);
        if (!$safe_mime || !preg_match('/^[a-z0-9]{1,12}$/', $extension)) {
            wp_die(esc_html__('Receipt format is not allowed.', 'zarinshopbot'), '', ['response' => 415]);
        }
        nocache_headers();
        header('Content-Type: ' . $mime);
        header('X-Content-Type-Options: nosniff');
        header('Content-Disposition: inline; filename="receipt-' . (int) $order->get_id() . '.' . $extension . '"');
        header('Content-Length: ' . strlen($bytes));
        echo $bytes;
        exit;
    }
}

add_action('plugins_loaded', static function() {
    if (!class_exists('WC_Payment_Gateway')) return;
    if (!class_exists(__NAMESPACE__ . '\\WC_Gateway_Card_Transfer')) {
        class WC_Gateway_Card_Transfer extends \WC_Payment_Gateway {
            public function __construct() {
                $this->id = Card_Transfer::METHOD_ID;
                $this->method_title = __('پرداخت کارت‌به‌کارت (بررسی دستی)', 'zarinshopbot');
                $this->method_description = __('دریافت رسید واریز بانکی و تأیید دستی پرداخت پیش از تکمیل سفارش.', 'zarinshopbot');
                $this->has_fields = true;
                $this->supports = ['products'];
                $this->init_form_fields();
                $this->init_settings();
                $this->enabled = $this->get_option('enabled', 'no');
                $panel_settings = Card_Transfer::settings();
                $this->title = Card_Transfer::customerTitle();
                $this->description = Card_Transfer::customerDescription();
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
            }

            public function init_form_fields() {
                $settings_url = admin_url('admin.php?page=zarincode_zarinshopbot_setting&tab=card-transfer');
                $this->form_fields = [
                    'panel_notice' => [
                        'title' => __('تنظیمات پرداخت کارت‌به‌کارت', 'zarinshopbot'),
                        'type' => 'title',
                        'description' => sprintf(
                            '%1$s <a href="%2$s">%3$s</a>',
                            esc_html__('مدیریت حساب‌های مقصد و رسیدها به پنل اصلی افزونه منتقل شده است.', 'zarinshopbot'),
                            esc_url($settings_url),
                            esc_html__('رفتن به تنظیمات کارت‌به‌کارت', 'zarinshopbot')
                        ),
                    ],
                ];
            }

            public function is_available() {
                return parent::is_available() && Card_Transfer::enabled() && Card_Transfer::secureStorageAvailable() && !empty(Card_Transfer::allowedTypes()) && Card_Transfer::maxUploadBytes() > 0;
            }

            public function payment_fields() {
                if ($this->description) echo '<div class="zsb-transfer-description">' . Card_Transfer::renderCustomerMessage($this->description) . '</div>';
                $accounts = Card_Transfer::accounts();
                if (!$accounts) {
                    echo '<p>' . esc_html__('This payment method is not configured yet.', 'zarinshopbot') . '</p>';
                    return;
                }
                echo '<fieldset class="zsb-transfer-account-selection"><legend>' . esc_html__('Choose a destination account', 'zarinshopbot') . '</legend>';
                foreach ($accounts as $index => $account) {
                    echo '<div class="zsb-transfer-account-choice ' . ($index === 0 ? 'is-selected' : '') . '">';
                    echo '<label><input type="radio" name="zsb_transfer_account" value="' . esc_attr($account['id']) . '" ' . checked($index === 0, true, false) . '> <span>' . esc_html($account['label']) . '</span></label>';
                    Card_Transfer::renderBankDetails($account);
                    echo '</div>';
                }
                echo '</fieldset>';
                Card_Transfer::renderCustomerInstructions();
            }

            public function validate_fields() {
                $id = isset($_POST['zsb_transfer_account']) ? sanitize_key(wp_unslash($_POST['zsb_transfer_account'])) : '';
                if (!$id || !Card_Transfer::accountById($id)) {
                    wc_add_notice(__('Please choose a valid destination account.', 'zarinshopbot'), 'error');
                    return false;
                }
                return true;
            }

            public function process_payment($order_id) {
                $order = wc_get_order($order_id);
                if (!$order) return ['result' => 'failure'];
                $account_id = isset($_POST['zsb_transfer_account']) ? sanitize_key(wp_unslash($_POST['zsb_transfer_account'])) : '';
                if (!$account_id || !Card_Transfer::accountById($account_id)) return ['result' => 'failure'];
                $order->set_payment_method($this);
                Card_Transfer::assignAccount($order, $account_id);
                $order->update_meta_data(Card_Transfer::META_REVIEW, 'awaiting_receipt');
                $order->update_status('on-hold', __('Awaiting card-transfer receipt and manual payment review.', 'zarinshopbot'));
                $order->save();
                if (function_exists('wc_reduce_stock_levels')) wc_reduce_stock_levels($order_id);
                return ['result' => 'success', 'redirect' => $this->get_return_url($order)];
            }
        }
    }
    Card_Transfer::boot();
    add_filter('woocommerce_payment_gateways', static function($gateways) {
        $gateways[] = __NAMESPACE__ . '\\WC_Gateway_Card_Transfer';
        return $gateways;
    });
}, 25);
