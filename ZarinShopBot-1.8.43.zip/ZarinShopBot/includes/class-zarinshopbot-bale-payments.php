<?php
/**
 * Bale Wallet payment lifecycle for WooCommerce orders.
 *
 * Copyright (C) 2026 Ehsan NaderiPanah / Zarincode.com.
 * Licensed under GPL-2.0-or-later; required upstream attribution is retained.
 */
namespace ZarinShopBot;

if (!defined('ABSPATH')) { exit; }

/**
 * Verifies Bale wallet invoices before changing WooCommerce order state.
 *
 * The provider token is stored in the private channel option, never rendered
 * back into HTML. Bale amounts are always integer IRR; conversion from the
 * store currency must be explicit or one of the supported automatic mappings.
 */
final class Bale_Payments {
    const META_PAYLOAD = '_zarinshopbot_bale_invoice_payload';
    const META_AMOUNT = '_zarinshopbot_bale_amount_irr';
    const META_USER = '_zarinshopbot_bale_user_id';
    const META_CHARGE = '_zarinshopbot_bale_charge_id';
    const META_PROVIDER_CHARGE = '_zarinshopbot_bale_provider_charge_id';
    const METHOD_ID = 'zarinshopbot_bale_wallet';
    const METHOD_TITLE = 'کیف پول بله (ربات زرین شاپ)';

    /** Whether native Bale wallet invoices are configured and enabled. */
    public static function is_enabled() {
        $options = Channels::options();
        return isset($options['bale_enabled'], $options['bale_wallet_enabled'])
            && $options['bale_enabled'] === '1'
            && $options['bale_wallet_enabled'] === '1'
            && !empty($options['bale_token'])
            && !empty($options['bale_provider_token']);
    }

    /** Create an in-chat Bale wallet invoice for an already-calculated WC order. */
    public static function create_invoice($order_id, $chat_id) {
        $order = wc_get_order(absint($order_id));
        if (!$order instanceof \WC_Order || $order->is_paid() || !$order->has_status(array('pending', 'failed'))) {
            return new \WP_Error('zarinshopbot_bale_order_invalid', __('سفارش برای ساخت صورتحساب بله معتبر یا در انتظار پرداخت نیست.', 'zarinshopbot'));
        }
        if (!self::is_enabled()) {
            return new \WP_Error('zarinshopbot_bale_not_configured', __('پرداخت کیف‌پولی بله در تنظیمات افزونه فعال و کامل نشده است.', 'zarinshopbot'));
        }
        $chat_id = self::unprefix_id($chat_id);
        if ($chat_id === '' || !hash_equals($chat_id, self::unprefix_id((string) $order->get_meta('_chat_id', true)))) {
            return new \WP_Error('zarinshopbot_bale_user_mismatch', __('شناسهٔ کاربر این سفارش معتبر نیست.', 'zarinshopbot'));
        }
        $amount = self::amount_in_irr($order);
        if (is_wp_error($amount)) { return $amount; }

        $options = Channels::options();
        $payload = 'zsb_bale_' . $order->get_id() . '_' . strtolower(wp_generate_password(28, false, false));
        $order->update_meta_data(self::META_PAYLOAD, $payload);
        $order->update_meta_data(self::META_AMOUNT, $amount);
        $order->update_meta_data(self::META_USER, $chat_id);
        $order->update_meta_data('_zarinshopbot_payment_provider', 'bale_wallet');
        $order->set_payment_method(self::METHOD_ID);
        $order->set_payment_method_title(__('کیف پول بله (ربات زرین شاپ)', 'zarinshopbot'));
        $order->add_order_note(sprintf(__('درخواست پرداخت کیف‌پولی بله آماده شد؛ مبلغ %1$s ریال، سفارش #%2$s.', 'zarinshopbot'), number_format_i18n($amount), $order->get_order_number()));
        $order->save();

        $title = self::short_text(sprintf(__('سفارش فروشگاه #%s', 'zarinshopbot'), $order->get_order_number()), 32);
        $description = self::short_text(sprintf(__('پرداخت سفارش #%s فروشگاه زرین', 'zarinshopbot'), $order->get_order_number()), 255);
        $api = new Channel_API('bale', $options['bale_token']);
        $response = $api->request('sendInvoice', array(
            'chat_id' => $chat_id,
            'title' => $title,
            'description' => $description,
            'payload' => $payload,
            'provider_token' => $options['bale_provider_token'],
            'prices' => array(array('label' => $title, 'amount' => $amount)),
        ));
        if (is_wp_error($response)) {
            $order->add_order_note(sprintf(__('ارسال صورتحساب کیف‌پولی بله ناموفق بود: %s', 'zarinshopbot'), $response->get_error_code()));
            $order->delete_meta_data(self::META_PAYLOAD);
            $order->delete_meta_data(self::META_AMOUNT);
            $order->delete_meta_data(self::META_USER);
            $order->delete_meta_data('_zarinshopbot_payment_provider');
            $order->delete_meta_data('_zarinshopbot_bale_invoice_params');
            $order->set_payment_method('');
            $order->set_payment_method_title('');
            $order->save();
            return $response;
        }
        $result = isset($response['result']) && is_array($response['result']) ? $response['result'] : array();
        if (!empty($result['message_id'])) {
            $order->update_meta_data('_zarinshopbot_bale_invoice_message_id', sanitize_text_field((string) $result['message_id']));
            $order->save();
        }
        return true;
    }

    /** Create a Bale wallet invoice identifier for the Bale Mini App openInvoice method. */
    public static function create_miniapp_invoice_link($order_id, $chat_id) {
        $order = wc_get_order(absint($order_id));
        if (!$order instanceof \WC_Order || $order->is_paid() || !$order->has_status(array('pending', 'failed'))) {
            return new \WP_Error('zarinshopbot_bale_order_invalid', __('سفارش برای ساخت صورتحساب مینی‌اپ بله معتبر یا در انتظار پرداخت نیست.', 'zarinshopbot'));
        }
        if (!self::is_enabled()) {
            return new \WP_Error('zarinshopbot_bale_not_configured', __('پرداخت کیف‌پولی بله برای مینی‌اپ فعال و کامل نشده است.', 'zarinshopbot'));
        }
        $chat_id = self::unprefix_id($chat_id);
        $order_chat_id = self::unprefix_id((string) $order->get_meta('_chat_id', true));
        if ($chat_id === '' || $order_chat_id === '' || !hash_equals($order_chat_id, $chat_id)) {
            return new \WP_Error('zarinshopbot_bale_user_mismatch', __('شناسهٔ کاربر این سفارش معتبر نیست.', 'zarinshopbot'));
        }
        $amount = self::amount_in_irr($order);
        if (is_wp_error($amount)) { return $amount; }

        $options = Channels::options();
        $payload = 'zsb_bale_' . $order->get_id() . '_' . strtolower(wp_generate_password(28, false, false));
        $order->update_meta_data(self::META_PAYLOAD, $payload);
        $order->update_meta_data(self::META_AMOUNT, $amount);
        $order->update_meta_data(self::META_USER, $chat_id);
        $order->update_meta_data('_zarinshopbot_payment_provider', 'bale_wallet');
        $order->set_payment_method(self::METHOD_ID);
        $order->set_payment_method_title(sprintf(__('%s — مینی‌اپ', 'zarinshopbot'), __('کیف پول بله (ربات زرین شاپ)', 'zarinshopbot')));
        $order->add_order_note(sprintf(__('شناسهٔ صورتحساب کیف‌پولی مینی‌اپ بله برای سفارش #%1$s ساخته شد؛ مبلغ %2$s ریال.', 'zarinshopbot'), $order->get_order_number(), number_format_i18n($amount)));
        $order->save();

        $title = self::short_text(sprintf(__('سفارش فروشگاه #%s', 'zarinshopbot'), $order->get_order_number()), 32);
        $description = self::short_text(sprintf(__('پرداخت سفارش #%s فروشگاه زرین', 'zarinshopbot'), $order->get_order_number()), 255);
        $api = new Channel_API('bale', $options['bale_token']);
        $response = $api->request('createInvoiceLink', array(
            'title' => $title,
            'description' => $description,
            'payload' => $payload,
            'provider_token' => $options['bale_provider_token'],
            'prices' => array(array('label' => $title, 'amount' => $amount)),
        ));
        if (is_wp_error($response)) {
            $order->add_order_note(sprintf(__('ساخت صورتحساب کیف‌پولی مینی‌اپ بله ناموفق بود (%s).', 'zarinshopbot'), $response->get_error_code()));
            $order->delete_meta_data(self::META_PAYLOAD);
            $order->delete_meta_data(self::META_AMOUNT);
            $order->delete_meta_data(self::META_USER);
            $order->delete_meta_data('_zarinshopbot_payment_provider');
            $order->delete_meta_data('_zarinshopbot_bale_invoice_params');
            $order->set_payment_method('');
            $order->set_payment_method_title('');
            $order->save();
            return $response;
        }
        $invoice_params = isset($response['result']) && is_string($response['result']) ? (string) $response['result'] : '';
        if (trim($invoice_params) === '') {
            $order->add_order_note(__('بله برای صورتحساب مینی‌اپ، شناسهٔ پرداخت برنگرداند.', 'zarinshopbot'));
            $order->delete_meta_data(self::META_PAYLOAD);
            $order->delete_meta_data(self::META_AMOUNT);
            $order->delete_meta_data(self::META_USER);
            $order->delete_meta_data('_zarinshopbot_payment_provider');
            $order->delete_meta_data('_zarinshopbot_bale_invoice_params');
            $order->set_payment_method('');
            $order->set_payment_method_title('');
            $order->save();
            return new \WP_Error('zarinshopbot_bale_invoice_link_empty', __('بله شناسهٔ صورتحساب مینی‌اپ را برنگرداند.', 'zarinshopbot'));
        }
        $order->update_meta_data('_zarinshopbot_bale_invoice_params', $invoice_params);
        $order->save();
        return array('invoice_params' => $invoice_params);
    }

    /** Handle Bale pre_checkout_query updates; Bale requires an answer within 10 seconds. */
    public static function handle_pre_checkout(array $body) {
        $query = isset($body['pre_checkout_query']) && is_array($body['pre_checkout_query']) ? $body['pre_checkout_query'] : array();
        if (empty($query['id'])) { return new \WP_Error('zarinshopbot_bale_precheckout_invalid', __('Missing pre_checkout_query id.', 'zarinshopbot')); }
        $order = self::order_from_payload(isset($query['invoice_payload']) ? (string) $query['invoice_payload'] : '');
        $error_message = '';
        if (!$order) {
            $error_message = __('این صورتحساب معتبر نیست یا اعتبار آن به پایان رسیده است.', 'zarinshopbot');
        } elseif ($order->is_paid() || !$order->has_status(array('pending', 'failed'))) {
            $error_message = __('این سفارش دیگر آمادهٔ پرداخت نیست.', 'zarinshopbot');
        } elseif (strtoupper((string) ($query['currency'] ?? '')) !== 'IRR') {
            $error_message = __('واحد صورتحساب باید ریال باشد.', 'zarinshopbot');
        } else {
            $expected_amount = (int) $order->get_meta(self::META_AMOUNT, true);
            $expected_user = (string) $order->get_meta(self::META_USER, true);
            $query_user = self::user_id_string($query['from']['id'] ?? null);
            $live_amount = self::amount_in_irr($order);
            if (is_wp_error($live_amount) || $expected_amount < 1 || (int) $live_amount !== $expected_amount || !self::amount_matches($query['total_amount'] ?? null, $expected_amount)) {
                $error_message = __('مبلغ صورتحساب با سفارش فروشگاه تطبیق ندارد.', 'zarinshopbot');
            } elseif ($expected_user === '' || $query_user === '' || !hash_equals($expected_user, $query_user)) {
                $error_message = __('این صورتحساب متعلق به حساب کاربری فعلی نیست.', 'zarinshopbot');
            } elseif (!self::order_items_available($order)) {
                $error_message = __('موجودی یک یا چند محصول تغییر کرده است؛ لطفاً سفارش را دوباره ثبت کنید.', 'zarinshopbot');
            } else {
                // A failed order is eligible for a Bale retry; restore the unpaid
                // state before WooCommerce applies its pending-order stock hold.
                $was_failed = $order->has_status('failed');
                if ($was_failed) {
                    $order->update_status('pending', __('پرداخت کیف‌پولی بله برای این سفارش دوباره آغاز شد.', 'zarinshopbot'));
                }
                if (!self::reserve_order_stock($order)) {
                    if ($was_failed) {
                        $order->update_status('failed', __('رزرو موجودی برای تلاش مجدد پرداخت بله انجام نشد.', 'zarinshopbot'));
                    }
                    $error_message = __('رزرو موجودی برای پرداخت ممکن نشد؛ لطفاً کمی بعد دوباره تلاش کنید یا با فروشگاه تماس بگیرید.', 'zarinshopbot');
                }
            }
        }

        $options = Channels::options();
        $api = new Channel_API('bale', (string) ($options['bale_token'] ?? ''));
        $params = array(
            'pre_checkout_query_id' => sanitize_text_field((string) $query['id']),
            'ok' => $error_message === '',
        );
        if ($error_message !== '') { $params['error_message'] = self::short_text($error_message, 200); }
        $response = $api->request('answerPreCheckoutQuery', $params, 5);
        if (is_wp_error($response)) {
            if ($order instanceof \WC_Order) {
                $order->add_order_note(sprintf(__('پاسخ به بررسی پیش از پرداخت بله ناموفق بود (%s). بله باید ظرف ۱۰ ثانیه پاسخ دریافت کند.', 'zarinshopbot'), $response->get_error_code()));
            }
            return $response;
        }
        if ($order instanceof \WC_Order) {
            $order->add_order_note($error_message === '' ? __('بررسی مبلغ، ارز، کاربر، موجودی و وضعیت سفارش برای پرداخت بله موفق بود.', 'zarinshopbot') : sprintf(__('پرداخت بله در مرحلهٔ پیش‌بررسی رد شد: %s', 'zarinshopbot'), $error_message));
        }
        return true;
    }

    /** Verify a successful_payment update with inquireTransaction, then complete the WC order once. */
    public static function handle_successful_payment(array $body) {
        $message = isset($body['message']) && is_array($body['message']) ? $body['message'] : array();
        $payment = isset($message['successful_payment']) && is_array($message['successful_payment']) ? $message['successful_payment'] : array();
        if (!$payment) { return false; }
        $payload = isset($payment['invoice_payload']) ? (string) $payment['invoice_payload'] : '';
        $order = self::order_from_payload($payload);
        if (!$order instanceof \WC_Order) {
            // Payloads embed the order ID. If a valid prior invoice was superseded,
            // retain an auditable manual-review trail without trusting it to fulfill.
            if (preg_match('/\Azsb_bale_(\d+)_([a-z0-9]{20,40})\z/', $payload, $payload_parts)) {
                $stale_order = wc_get_order(absint($payload_parts[1]));
                if ($stale_order instanceof \WC_Order) {
                    $stale_order->update_meta_data('_zarinshopbot_payment_review_required', 'bale_invoice_payload_mismatch');
                    $stale_charge_id = self::short_text(sanitize_text_field((string) ($payment['telegram_payment_charge_id'] ?? '')), 128);
                    $stale_order->add_order_note(sprintf(__('هشدار بررسی دستی: بله پرداخت موفقی را با شناسهٔ صورتحسابی فرستاد که دیگر با صورتحساب فعال سفارش تطبیق ندارد. سفارش خودکار تکمیل نشد؛ تراکنش %s را در پنل بله بررسی کنید.', 'zarinshopbot'), $stale_charge_id !== '' ? $stale_charge_id : '—'));
                    $stale_order->save();
                    if (function_exists('zarincode_log_event')) { zarincode_log_event('bale_payment_review_required', array('order_id' => $stale_order->get_id(), 'reason' => 'invoice_payload_mismatch')); }
                    return true;
                }
            }
            if (function_exists('zarincode_log_event')) { zarincode_log_event('bale_payment_review_required', array('reason' => 'unknown_invoice')); }
            return true;
        }
        $user_id = self::user_id_string($message['from']['id'] ?? ($message['chat']['id'] ?? null));
        $expected_user = (string) $order->get_meta(self::META_USER, true);
        $expected_amount = (int) $order->get_meta(self::META_AMOUNT, true);
        $charge_id = sanitize_text_field((string) ($payment['telegram_payment_charge_id'] ?? ''));
        $provider_charge_id = sanitize_text_field((string) ($payment['provider_payment_charge_id'] ?? ''));
        if (strtoupper((string) ($payment['currency'] ?? '')) !== 'IRR' || !self::amount_matches($payment['total_amount'] ?? null, $expected_amount) || $expected_user === '' || $user_id === '' || !hash_equals($expected_user, $user_id) || $charge_id === '') {
            $order->update_meta_data('_zarinshopbot_payment_review_required', 'bale_payment_mismatch');
            $order->add_order_note(__('هشدار بررسی دستی: اعلان پرداخت بله با ارز، مبلغ، کاربر یا شناسهٔ صورتحساب تطبیق نداشت؛ سفارش پرداخت‌شده علامت نخورد.', 'zarinshopbot'));
            $order->save();
            if (function_exists('zarincode_log_event')) { zarincode_log_event('bale_payment_review_required', array('order_id' => $order->get_id(), 'reason' => 'payment_mismatch')); }
            return true;
        }
        $saved_charge = (string) $order->get_meta(self::META_CHARGE, true);
        if ($order->is_paid()) {
            if ($saved_charge !== '' && hash_equals($saved_charge, $charge_id)) { return true; }
            $order->update_meta_data('_zarinshopbot_bale_unapplied_charge_id', $charge_id);
            if ($provider_charge_id !== '') { $order->update_meta_data('_zarinshopbot_bale_unapplied_provider_charge_id', $provider_charge_id); }
            $order->update_meta_data('_zarinshopbot_payment_review_required', 'bale_payment_after_existing_payment');
            $order->add_order_note(sprintf(__('هشدار بررسی فوری: پرداخت بله %1$s پس از آن‌که سفارش قبلاً پرداخت‌شده بود دریافت شد. سفارش تغییر نکرده است؛ پرداخت تکراری را در پنل بله بررسی و در صورت لزوم مسترد کنید.', 'zarinshopbot'), $charge_id));
            $order->save();
            if (function_exists('zarincode_log_event')) { zarincode_log_event('bale_payment_review_required', array('order_id' => $order->get_id(), 'reason' => 'already_paid')); }
            return true;
        }

        $options = Channels::options();
        $api = new Channel_API('bale', (string) ($options['bale_token'] ?? ''));
        $inquiry = $api->request('inquireTransaction', array('transaction_id' => $charge_id));
        if (is_wp_error($inquiry)) {
            $order->add_order_note(sprintf(__('استعلام تراکنش بله هنوز موفق نبود؛ پرداخت تا دریافت تأیید استعلام نهایی نشده است (%s).', 'zarinshopbot'), $inquiry->get_error_code()));
            return $inquiry;
        }
        $transaction = isset($inquiry['result']) && is_array($inquiry['result']) ? $inquiry['result'] : array();
        $transaction_user = self::user_id_string($transaction['userID'] ?? null);
        $live_amount = self::amount_in_irr($order);
        if (strtolower((string) ($transaction['status'] ?? '')) !== 'paid'
            || !self::amount_matches($transaction['amount'] ?? null, $expected_amount)
            || $expected_user === '' || $transaction_user === '' || !hash_equals($expected_user, $transaction_user)
            || is_wp_error($live_amount) || (int) $live_amount !== $expected_amount) {
            $order->update_meta_data('_zarinshopbot_payment_review_required', 'bale_transaction_unverified');
            $order->add_order_note(__('هشدار بررسی دستی: استعلام تراکنش بله انجام شد، اما وضعیت/مبلغ/کاربر با سفارش تطبیق نداشت؛ سفارش پرداخت‌شده علامت نخورد.', 'zarinshopbot'));
            $order->save();
            if (function_exists('zarincode_log_event')) { zarincode_log_event('bale_payment_review_required', array('order_id' => $order->get_id(), 'reason' => 'transaction_unverified')); }
            return true;
        }

        $previous_status = $order->get_status();
        $order->update_meta_data(self::META_CHARGE, $charge_id);
        if ($provider_charge_id !== '') { $order->update_meta_data(self::META_PROVIDER_CHARGE, $provider_charge_id); }
        $order->update_meta_data('_zarinshopbot_payment_provider', 'bale_wallet');
        $order->update_meta_data('_zarinshopbot_paid_currency', 'IRR');
        $order->update_meta_data('_zarinshopbot_paid_amount_irr', $expected_amount);
        $order->set_transaction_id($provider_charge_id !== '' ? $provider_charge_id : $charge_id);
        $order->add_order_note(sprintf(__('پرداخت کیف‌پولی بله با استعلام سروری تأیید شد. مبلغ: %1$s ریال؛ شناسه تراکنش: %2$s.', 'zarinshopbot'), number_format_i18n($expected_amount), $charge_id));
        if (in_array($previous_status, array('cancelled', 'refunded', 'failed'), true)) {
            $order->update_meta_data('_zarinshopbot_payment_after_terminal_status', $previous_status);
            $order->add_order_note(__('هشدار: پرداخت پس از وضعیت نهایی سفارش دریافت شد؛ سفارش برای بررسی فروشگاه به وضعیت پرداخت‌شده منتقل می‌شود.', 'zarinshopbot'));
        }
        $order->save();
        $order->payment_complete($provider_charge_id !== '' ? $provider_charge_id : $charge_id);
        return true;
    }

    /** Return IRR integer amount, rejecting unsupported currencies and fractional rials. */
    public static function amount_in_irr(\WC_Order $order) {
        $options = Channels::options();
        $multiplier = isset($options['bale_irr_per_store_unit']) ? (float) $options['bale_irr_per_store_unit'] : 0.0;
        if ($multiplier <= 0) {
            $currency = strtoupper((string) $order->get_currency());
            if ($currency === 'IRR') { $multiplier = 1.0; }
            elseif ($currency === 'IRT' || $currency === 'TOMAN') { $multiplier = 10.0; }
            else { return new \WP_Error('zarinshopbot_bale_currency', __('واحد پول فروشگاه به‌صورت خودکار به ریال بله تبدیل نمی‌شود؛ ضریب تبدیل ریال را در تنظیمات بله تعیین کنید.', 'zarinshopbot')); }
        }
        $raw_amount = (float) $order->get_total() * $multiplier;
        $amount = (int) round($raw_amount, 0, PHP_ROUND_HALF_UP);
        if ($amount < 1 || abs($raw_amount - $amount) > 0.00001) {
            return new \WP_Error('zarinshopbot_bale_amount', __('مبلغ این سفارش به عدد صحیح ریال تبدیل نمی‌شود؛ تنظیم ضریب تبدیل ارز را بررسی کنید.', 'zarinshopbot'));
        }
        return $amount;
    }

    private static function order_from_payload($payload) {
        if (!preg_match('/\Azsb_bale_(\d+)_([a-z0-9]{20,40})\z/', $payload, $matches)) { return null; }
        $order = wc_get_order(absint($matches[1]));
        if (!$order instanceof \WC_Order) { return null; }
        $stored = (string) $order->get_meta(self::META_PAYLOAD, true);
        return $stored !== '' && hash_equals($stored, $payload) ? $order : null;
    }

    /** Ask WooCommerce to atomically reserve stock before Bale approves payment. */
    private static function reserve_order_stock(\WC_Order $order) {
        if (!function_exists('wc_reserve_stock_for_order')) { return true; }
        try {
            $result = wc_reserve_stock_for_order($order);
            if (is_wp_error($result) || $result === false) {
                $code = is_wp_error($result) ? $result->get_error_code() : 'reservation_rejected';
                $order->add_order_note(sprintf(__('رزرو موجودی برای پرداخت بله ناموفق بود (%s).', 'zarinshopbot'), sanitize_key((string) $code)));
                return false;
            }
            return true;
        } catch (\Throwable $error) {
            $order->add_order_note(sprintf(__('رزرو موجودی برای پرداخت بله ناموفق بود (%s).', 'zarinshopbot'), sanitize_key(get_class($error))));
            if (function_exists('zarincode_log_event')) {
                zarincode_log_event('bale_stock_reservation_failed', array('order_id' => $order->get_id(), 'error_type' => get_class($error)));
            }
            return false;
        }
    }

    private static function order_items_available(\WC_Order $order) {
        $required_stock = array();
        $stock_products = array();
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if (!$product || !$product->exists() || !$product->is_purchasable()) { return false; }
            $quantity = function_exists('wc_stock_amount') ? wc_stock_amount($item->get_quantity()) : (float) $item->get_quantity();
            if ($quantity <= 0) { return false; }
            if ($product->managing_stock()) {
                if (!$product->has_enough_stock($quantity)) { return false; }
                if (!$product->backorders_allowed() && !function_exists('wc_reserve_stock_for_order')) { return false; }
                if (!$product->backorders_allowed()) {
                    // Variations can share a parent stock ID. Aggregate all order
                    // lines for that stock source before comparing held quantities.
                    $stock_id = (string) $product->get_stock_managed_by_id();
                    $required_stock[$stock_id] = ($required_stock[$stock_id] ?? 0) + $quantity;
                    $stock_products[$stock_id] = $product;
                }
            }
            if (!$product->is_in_stock()) { return false; }
        }

        // WooCommerce holds stock for pending/check-out-draft orders. Exclude this
        // order's own reservation, but account for competing orders on each stock ID.
        if (function_exists('wc_get_held_stock_quantity')) {
            foreach ($required_stock as $stock_id => $quantity) {
                $product = $stock_products[$stock_id];
                $stock_quantity = $product->get_stock_quantity();
                $held_quantity = wc_get_held_stock_quantity($product, $order->get_id());
                if ($stock_quantity !== null && (float) $stock_quantity - (float) $held_quantity < (float) $quantity) { return false; }
            }
        }
        return true;
    }

    /** Compare integer IRR values without accepting partial numeric strings or overflow. */
    private static function amount_matches($value, $expected) {
        if (!(is_int($value) || is_string($value)) || (int) $expected < 1 || !preg_match('/\A[0-9]+\z/', (string) $value)) { return false; }
        $normalized = ltrim((string) $value, '0');
        if ($normalized === '') { $normalized = '0'; }
        return hash_equals((string) (int) $expected, $normalized);
    }

    /** Accept only Bale numeric user IDs, optionally carrying this plugin's prefix. */
    private static function user_id_string($value) {
        if (is_int($value) && $value > 0) { return (string) $value; }
        if (!is_string($value) || !preg_match('/\A(?:bale_)?[0-9]+\z/', $value)) { return ''; }
        return self::unprefix_id($value);
    }

    private static function unprefix_id($value) {
        $value = (string) $value;
        return strpos($value, 'bale_') === 0 ? substr($value, 5) : $value;
    }

    private static function short_text($text, $length) {
        $text = sanitize_text_field((string) $text);
        return function_exists('mb_substr') ? mb_substr($text, 0, $length, 'UTF-8') : substr($text, 0, $length);
    }
}
